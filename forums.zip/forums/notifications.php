<?php
// notifications.php � full list view
// GPL-3.0-or-later
define('PUN_ROOT', dirname(__FILE__) . '/');
require PUN_ROOT.'include/common.php';

if ($pun_user['is_guest'])
    message($lang_common['No view']);

$page_title = array(pun_htmlspecialchars($pun_config['o_board_title']), 'Notifications');
define('PUN_ACTIVE_PAGE', 'notifications');
require PUN_ROOT.'header.php';

// Actions
if (isset($_GET['action'])) {
    check_csrf($_GET['csrf_token']);
    if ($_GET['action'] === 'read' && isset($_GET['id'])) {
        $nid = intval($_GET['id']);
        $db->query('UPDATE gs_notifications SET is_read=1 WHERE id='.$nid.' AND user_id='.$pun_user['id'])
            or error('Unable to mark notification read', __FILE__, __LINE__, $db->error());
        redirect('notifications.php', 'Notification marked read');
    } elseif ($_GET['action'] === 'read_all') {
        $db->query('UPDATE gs_notifications SET is_read=1 WHERE user_id='.$pun_user['id'].' AND is_read=0')
            or error('Unable to mark notifications read', __FILE__, __LINE__, $db->error());
        redirect('notifications.php', 'All notifications marked read');
    } elseif ($_GET['action'] === 'clear_read') {
        $db->query('DELETE FROM gs_notifications WHERE user_id='.$pun_user['id'].' AND is_read=1')
            or error('Unable to clear read notifications', __FILE__, __LINE__, $db->error());
        redirect('notifications.php', 'Read notifications cleared');
    }
}

// Pagination
$per_page = 25;
$page = max(1, isset($_GET['p']) ? intval($_GET['p']) : 1);
$start_from = ($page - 1) * $per_page;

// Total count
$tot_res = $db->query('SELECT COUNT(*) AS c FROM gs_notifications WHERE user_id='.$pun_user['id'])
    or error('Unable to count notifications', __FILE__, __LINE__, $db->error());
$total = (int)$db->result($tot_res);

// Fetch items
$q = $db->query('
    SELECT n.*, u.username AS actor_name, u.group_id AS actor_group
    FROM gs_notifications n
    LEFT JOIN gs_users u ON u.id = n.actor_id
    WHERE n.user_id='.$pun_user['id'].'
    ORDER BY n.created_at DESC
    LIMIT '.$start_from.', '.$per_page
) or error('Unable to fetch notifications', __FILE__, __LINE__, $db->error());
?>
<div class="block">
    <h2 class="block2"><span>Notifications</span></h2>
    <div class="box">
        <div class="inbox" style="padding:0">
            <div style="padding:8px;border-bottom:1px solid #ddd">
                <a href="notifications.php?csrf_token=<?php echo pun_csrf_token(); ?>&action=read_all">Mark all as read</a>
                &nbsp;�&nbsp;
                <a href="notifications.php?csrf_token=<?php echo pun_csrf_token(); ?>&action=clear_read">Clear read</a>
            </div>
            <table>
                <thead>
                    <tr>
                        <th class="tc3">Notification</th>
                        <th class="tc3">Time</th>
                        <th class="tc3">Action</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (!$db->num_rows($q)): ?>
                    <tr><td colspan="3" style="text-align:center;padding:8px">You're all caught up!</td></tr>
                <?php else: while ($n = $db->fetch_assoc($q)): 
                    $is_unread = !$n['is_read'];
                    $who = $n['actor_name'] ? colorize_group($n['actor_name'], $n['actor_group']) : 'System';
                    $line = $n['message'];
                    if ($line === '' || $line === null) {
                        if ($n['type'] === 'mention') $line = 'You were tagged in a post';
                        elseif ($n['type'] === 'hwid_accept') $line = 'Your Hardware ID was accepted';
                        elseif ($n['type'] === 'hwid_deny') $line = 'Your Hardware ID was denied';
                        else $line = 'You have a new notification';
                    }
                    $link_open = $n['url'] ? '<a href="'.pun_htmlspecialchars($n['url']).'">' : '';
                    $link_close = $n['url'] ? '</a>' : '';
                ?>
                    <tr<?php echo $is_unread ? ' style="background:#2d2d2d1a;font-weight:bold;"' : ''; ?>>
                        <td class="tc3"><?php echo $link_open.pun_htmlspecialchars($line).$link_close; ?></td>
                        <td class="tc3"><?php echo format_time(strtotime($n['created_at']), false, null, null, false, true); ?></td>
                        <td class="tc3"><?php if ($is_unread): ?>
                            <a href="notifications.php?csrf_token=<?php echo pun_csrf_token(); ?>&action=read&id=<?php echo $n['id']; ?>">Mark read</a>
                        <?php else: ?>-<?php endif; ?></td>
                    </tr>
                <?php endwhile; endif; ?>
                </tbody>
            </table>
            <?php if ($total > $per_page):
                $pages = (int)ceil($total / $per_page); ?>
                <div class="pagelink conl" style="padding:6px">
                    <?php for ($i=1; $i<=$pages; $i++): ?>
                        <?php if ($i==$page): ?><strong><?php echo $i; ?></strong>
                        <?php else: ?><a href="notifications.php?p=<?php echo $i; ?>"><?php echo $i; ?></a>
                        <?php endif; ?>&nbsp;
                    <?php endfor; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php require PUN_ROOT.'footer.php'; ?>
