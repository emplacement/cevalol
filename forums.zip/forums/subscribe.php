<?php
define('PUN_ROOT', dirname(__FILE__).'/');
require PUN_ROOT.'include/common.php';

if ($pun_user['is_guest'])
    message($lang_common['No permission']);

if (isset($_POST['subscribe'])) {
    $luaId = (int)$_POST['lua_id'];
    $username = $pun_user['username'];
    
    if (!file_exists('userslua')) {
        mkdir('userslua', 0755, true);
    }
    
    $userFile = "userslua/{$username}.txt";
    $subscribedLuas = [];
    
    if (file_exists($userFile)) {
        $subscribedLuas = array_filter(array_map('trim', file($userFile)));
    }
    
    if (!in_array($luaId, $subscribedLuas)) {
        $subscribedLuas[] = $luaId;
        file_put_contents($userFile, implode("\n", $subscribedLuas));
    }
}

redirect('workshop.php', 'Subscribed successfully');