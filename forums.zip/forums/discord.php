<?php
// Redirect to the Discord server
header("Location: https://discord.gg/hrisito");
exit();
?>
