<?php
// balls.php - Invite code generator endpoint
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET');
header('Access-Control-Allow-Headers: Content-Type');

// Set max execution time
set_time_limit(30);

// Database configuration
$host = 'localhost';
$username = 'interlection';
$password = 'xRoles13:)';
$database = 'hrisito';

// Log function for debugging
function logMessage($message) {
    error_log(date('Y-m-d H:i:s') . " - " . $message . PHP_EOL, 3, 'invite_bot.log');
}

logMessage("Request received: " . $_SERVER['REQUEST_URI']);

try {
    // Connect to database
    logMessage("Connecting to database...");
    $pdo = new PDO("mysql:host=$host;dbname=$database;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_TIMEOUT, 5);
    logMessage("Database connected successfully");
    
    // Get count parameter (default to 1, max 10)
    $count = isset($_GET['count']) ? (int)$_GET['count'] : 1;
    $count = max(1, min(10, $count)); // Clamp between 1 and 10
    logMessage("Generating $count codes");
    
    // Function to generate invite code
    function generateInviteCode($length = 48) {
        $chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        $result = '';
        
        for ($i = 0; $i < $length; $i++) {
            $result .= $chars[random_int(0, strlen($chars) - 1)];
        }
        
        return $result;
    }
    
    // Function to check if code exists
    function codeExists($pdo, $code) {
        $stmt = $pdo->prepare("SELECT id FROM gs_codes WHERE code = ?");
        $stmt->execute([$code]);
        return $stmt->rowCount() > 0;
    }
    
    // Function to generate unique code
    function generateUniqueCode($pdo) {
        $maxAttempts = 10;
        $attempts = 0;
        
        do {
            $code = generateInviteCode();
            $exists = codeExists($pdo, $code);
            $attempts++;
        } while ($exists && $attempts < $maxAttempts);
        
        if ($exists) {
            throw new Exception('Failed to generate unique code after maximum attempts');
        }
        
        return $code;
    }
    
    // Generate the requested number of codes
    $generatedCodes = [];
    
    for ($i = 0; $i < $count; $i++) {
        // Generate unique code
        $code = generateUniqueCode($pdo);
        
        // Insert into database
        $stmt = $pdo->prepare("
            INSERT INTO gs_codes (code, `by`, used, admin, user, date, usedat, beta) 
            VALUES (?, 2, 0, NULL, NULL, NOW(), NULL, 0)
        ");
        
        $stmt->execute([$code]);
        $insertId = $pdo->lastInsertId();
        
        $generatedCodes[] = [
            'id' => $insertId,
            'code' => $code,
            'created_at' => date('Y-m-d H:i:s')
        ];
    }
    
    // Return success response
    logMessage("Successfully generated $count codes");
    echo json_encode([
        'success' => true,
        'count' => $count,
        'codes' => $generatedCodes,
        'message' => "Successfully generated $count invite code" . ($count > 1 ? 's' : '')
    ]);
    
} catch (PDOException $e) {
    // Database error
    logMessage("Database error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Database error',
        'message' => 'Failed to connect to database or execute query'
    ]);
    
} catch (Exception $e) {
    // General error
    logMessage("General error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Generation error',
        'message' => $e->getMessage()
    ]);
}
?>