<?php

define('PUN_ROOT', dirname(__FILE__).'/');
require PUN_ROOT.'include/common.php';

if ($pun_user['is_guest'])
    message($lang_common['No permission']);

// === Helper functions ===
function getUserStats($username) {
    $username = strtolower($username);
    $statsFile = PUN_ROOT."casestats/{$username}.json";
    if (file_exists($statsFile)) {
        return json_decode(file_get_contents($statsFile), true) ?: ['opened' => 0, 'rocks' => 0, 'invites' => 0];
    }
    return ['opened' => 0, 'rocks' => 0, 'invites' => 0];
}

function saveUserStats($username, $stats) {
    $username = strtolower($username);
    $dir = PUN_ROOT.'casestats/';
    if (!is_dir($dir)) {
        mkdir($dir, 0777, true);
    }
    file_put_contents($dir.$username.'.json', json_encode($stats, JSON_PRETTY_PRINT));
}

// === Handle AJAX Case Opening BEFORE any HTML ===
if (isset($_POST['open_case'])) {
    $token = $_POST['csrf_token'] ?? '';
    if ($token !== pun_hash($pun_user['id'].$pun_user['cookie_seed'])) {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['error' => 'Invalid CSRF token']);
        exit;
    }

    $stats = getUserStats($pun_user['username']);
    $stats['opened']++;

    // Random result
    $rand = mt_rand(1, 1000) / 10;
    if ($rand <= 5.6) {
        $result = 'invite';
        $stats['invites']++;
    } else {
        $result = 'rock';
        $stats['rocks']++;
    }

    saveUserStats($pun_user['username'], $stats);

    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['result' => $result, 'stats' => $stats]);
    exit; // 🚨 Important: stop further HTML output
}

// === Normal Page Load ===
$userStats = getUserStats($pun_user['username']);
require PUN_ROOT.'header.php';
?>

<style>
.forumdesc { color:#999;font-size:0.9em;font-style:italic;margin-top:2px; }
.workshop-action-btn { overflow:visible;padding:4px 12px;border:1px solid;font-size:1em;cursor:pointer; }
.open-case-btn { background:#2ecc71;color:#fff;border-color:#27ae60;padding:8px 24px;font-size:1.1em; }
.open-case-btn:hover { background:#27ae60;color:#fff; }
.open-case-btn:disabled { background:#555;border-color:#444;cursor:not-allowed;opacity:0.5; }
.case-container { text-align:center;padding:30px;background:#2a2a2a;border-radius:5px;margin-bottom:20px; }
.case-box { width:200px;height:200px;margin:0 auto 20px;background:linear-gradient(135deg,#3a3a3a 0%,#2a2a2a 100%);border:3px solid #555;border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:5em;position:relative; }
.case-box.opening { animation:shake 0.5s infinite; }
@keyframes shake { 0%,100%{transform:rotate(0deg);}25%{transform:rotate(-5deg);}75%{transform:rotate(5deg);} }
.spinner-area { height:250px;overflow:hidden;position:relative;background:#1a1a1a;border:2px solid #333;margin:20px 0;display:none; }
.spinner-area.active { display:block; }
.spinner-track { display:flex;position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);transition:none; }
.spinner-item { min-width:150px;height:200px;margin:0 5px;background:#2a2a2a;border:2px solid;border-radius:5px;display:flex;flex-direction:column;align-items:center;justify-content:center;font-size:4em; }
.spinner-item.rock { border-color:#888;background:linear-gradient(135deg,#4a4a4a 0%,#3a3a3a 100%); }
.spinner-item.invite { border-color:#ffd700;background:linear-gradient(135deg,#ffa500 0%,#ff8c00 100%);box-shadow:0 0 20px rgba(255,215,0,0.5); }
.spinner-item-name { font-size:0.3em;margin-top:10px;font-weight:bold; }
.selector-line { position:absolute;top:0;left:50%;width:3px;height:100%;background:#e74c3c;z-index:10;box-shadow:0 0 10px rgba(231,76,60,0.8); }
.result-display { padding:30px;text-align:center;display:none;animation:fadeIn 0.5s; }
.result-display.show { display:block; }
@keyframes fadeIn { from{opacity:0;transform:translateY(10px);}to{opacity:1;transform:translateY(0);} }
.result-icon { font-size:6em;margin-bottom:15px; }
.result-text { font-size:1.8em;font-weight:bold;margin-bottom:10px; }
.result-rock { color:#888; }
.result-invite { color:#ffd700;text-shadow:0 0 10px rgba(255,215,0,0.5); }
.stats-table { margin-top:20px; }
.stats-table td { padding:8px 15px; }
.stat-value { font-weight:bold;font-size:1.2em;color:#2ecc71; }
.warning-table { margin-bottom:1em; }
.warning-table td { padding:8px 15px;vertical-align:middle; }
.warning-icon { font-size:24px;padding-right:5px; }
.warning-text { color:#f39c12;font-weight:bold;font-size:1.1em; }
</style>

<div id="brdmain">
<div class="linkst"><div class="inbox crumbsplus">
<ul class="crumbs"><li><a href="index.php">Index</a></li><li><span>»&nbsp;</span><strong><a href="gamble.php">Case Opener</a></strong></li></ul>
<div class="clearer"></div></div></div>

<div class="blocktable warning-table"><div class="box"><div class="inbox">
<table><tr><td style="width:40px;text-align:center;"><span class="warning-icon">⚠️</span></td>
<td><span class="warning-text">5.6% chance for Invite | 94.4% chance for Rock</span></td></tr></table>
</div></div></div>

<div class="blocktable">
<h2><span>Mystery Case</span></h2>
<div class="box"><div class="inbox">
<div class="case-container">
<div class="case-box" id="caseBox">📦</div>
<form method="post" id="openCaseForm">
    <input type="hidden" name="csrf_token" value="<?php echo pun_hash($pun_user['id'].$pun_user['cookie_seed']); ?>">
    <input type="submit" name="open_case" value="Open Case" class="workshop-action-btn open-case-btn" id="openBtn">
</form>
</div>

<div class="spinner-area" id="spinnerArea">
    <div class="selector-line"></div>
    <div class="spinner-track" id="spinnerTrack"></div>
</div>

<div class="result-display" id="resultDisplay"></div>
</div></div></div>

<div class="blocktable">
<h2><span>Your Statistics</span></h2>
<div class="box"><div class="inbox">
<table class="stats-table" style="width:100%;">
<tr>
<td style="width:50%;text-align:center;border-right:1px solid #333;">
    <div>Cases Opened</div><div class="stat-value" id="statOpened"><?php echo $userStats['opened']; ?></div>
</td>
<td style="width:25%;text-align:center;border-right:1px solid #333;">
    <div>🪨 Rocks</div><div class="stat-value" id="statRocks"><?php echo $userStats['rocks']; ?></div>
</td>
<td style="width:25%;text-align:center;">
    <div>🎫 Invites</div><div class="stat-value" style="color:#ffd700;" id="statInvites"><?php echo $userStats['invites']; ?></div>
</td>
</tr></table></div></div></div>

<div class="linksb"><div class="inbox crumbsplus">
<ul class="crumbs"><li><a href="index.php">Index</a></li><li><span>»&nbsp;</span><strong><a href="gamble.php">Case Opener</a></strong></li></ul>
<div class="clearer"></div></div></div></div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('openCaseForm');
    const openBtn = document.getElementById('openBtn');
    const caseBox = document.getElementById('caseBox');
    const spinnerArea = document.getElementById('spinnerArea');
    const spinnerTrack = document.getElementById('spinnerTrack');
    const resultDisplay = document.getElementById('resultDisplay');

    form.addEventListener('submit', function(e) {
        e.preventDefault();
        openBtn.disabled = true;
        caseBox.classList.add('opening');
        resultDisplay.classList.remove('show');
        resultDisplay.innerHTML = '';

        const formData = new FormData(form);

        fetch('gamble.php', { method: 'POST', body: formData })
        .then(response => response.text())
        .then(text => {
            console.log('Raw server response:', text); // debug line
            let data;
            try { data = JSON.parse(text); } 
            catch (err) { throw new Error("Invalid JSON: " + err.message); }

            if (data.error) throw new Error(data.error);

            // Generate spinner items
            const items = [];
            for (let i = 0; i < 40; i++) {
                if (i === 20) items.push(data.result);
                else items.push(Math.random() < 0.944 ? 'rock' : 'invite');
            }

            spinnerTrack.innerHTML = '';
            items.forEach(item => {
                const div = document.createElement('div');
                div.className = `spinner-item ${item}`;
                div.innerHTML = item === 'rock'
                    ? '<div>🪨</div><div class="spinner-item-name">Rock</div>'
                    : '<div>🎫</div><div class="spinner-item-name">Invite</div>';
                spinnerTrack.appendChild(div);
            });

            spinnerArea.classList.add('active');
            spinnerTrack.style.transition = 'none';
            spinnerTrack.style.transform = 'translate(-50%, -50%)';
            spinnerTrack.offsetHeight; // Force reflow

            const baseWidth = 160;
            const offset = -((20 * baseWidth) + (Math.random() * 80 - 40));
            spinnerTrack.style.transition = 'transform 8s cubic-bezier(0.05, 0.9, 0.1, 1)';
            spinnerTrack.style.transform = `translate(calc(-50% + ${offset}px), -50%)`;

            setTimeout(() => {
                caseBox.classList.remove('opening');
                spinnerArea.classList.remove('active');

                const resultClass = data.result === 'rock' ? 'result-rock' : 'result-invite';
                const resultIcon = data.result === 'rock' ? '🪨' : '🎫';
                const resultText = data.result === 'rock' ? 'Rock' : 'Invite';

                resultDisplay.innerHTML = `
                    <div class="result-icon">${resultIcon}</div>
                    <div class="result-text ${resultClass}">You got: ${resultText}!</div>
                `;
                resultDisplay.classList.add('show');

                document.getElementById('statOpened').textContent = data.stats.opened;
                document.getElementById('statRocks').textContent = data.stats.rocks;
                document.getElementById('statInvites').textContent = data.stats.invites;
                openBtn.disabled = false;
            }, 8200);
        })
        .catch(err => {
            console.error('Error:', err);
            alert('Error opening case: ' + err.message);
            openBtn.disabled = false;
            caseBox.classList.remove('opening');
        });
    });
});
</script>

<?php require PUN_ROOT.'footer.php'; ?>
