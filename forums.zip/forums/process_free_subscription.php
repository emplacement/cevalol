<?php
// process_free_subscription.php
define('PUN_ROOT', dirname(__FILE__).'/');
require PUN_ROOT.'include/common.php';

// Never include header.php/footer.php here – this must output JSON only
header('Content-Type: application/json; charset=utf-8');

// Helper to send a uniform JSON response and exit
function json_reply($ok, $msg, array $extra = []) {
    http_response_code(200); // Keep 200 so jQuery 'success' handler runs
    echo json_encode(array_merge(['success' => (bool)$ok, 'message' => $msg], $extra));
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_reply(false, 'Invalid request method');
}

// CSRF: must be present and valid
if (empty($_POST['csrf_token'])) {
    json_reply(false, 'Missing CSRF token.');
}
try {
    // check_csrf will throw/exit on failure in most FluxBB/PunBB forks
    check_csrf($_POST['csrf_token']);
} catch (Exception $e) {
    json_reply(false, 'Invalid CSRF token.');
}

// Minimal input (UI still sends these, but the server should not trust them blindly)
$username = isset($_POST['username']) ? trim($_POST['username']) : '';
$email    = isset($_POST['email']) ? trim($_POST['email']) : '';
$game     = isset($_POST['game']) ? trim($_POST['game']) : '';
$days_in  = isset($_POST['days']) ? (int)$_POST['days'] : 0;

// Enforce allowed values server-side
$allowed_games = ['csgo'];
$allowed_plans = [30, 90, 365, 1825];

if (!in_array($game, $allowed_games, true)) {
    json_reply(false, 'Invalid game selected.');
}
if (!in_array($days_in, $allowed_plans, true)) {
    json_reply(false, 'Invalid plan selected.');
}

// IMPORTANT: Identify the target account safely.
// If the user is logged in, prefer their identity over a posted username/email.
$targetUsername = $pun_user['is_guest'] ? $username : $pun_user['username'];
if ($targetUsername === '') {
    json_reply(false, 'Username is required.');
}

// Build PDO using your existing credentials (consider moving these to config)
$host = '185.194.177.9';
$dbname = 'hrisito';
$db_username = 'interlection';
$db_password = 'xRoles13:)';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $db_username, $db_password, [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
} catch (PDOException $e) {
    json_reply(false, 'Database connection failed.');
}

// Look up user by username (case-sensitive as before; change to LOWER() if you want)
$stmt = $pdo->prepare('SELECT id, username, csgo, group_id FROM gs_users WHERE username = ?');
$stmt->execute([$targetUsername]);
$user = $stmt->fetch();

if (!$user) {
    json_reply(false, 'User not found in database.');
}

// Block extension if active sub exists (matches your earlier behavior)
$current_csgo_expiry = $user['csgo'];
if (!empty($current_csgo_expiry) && strtotime($current_csgo_expiry) > time() && (int)$pun_user['g_id'] != 4) {
    json_reply(false, 'You already have an active HrisitoSense subscription! Expires: ' . date('M j, Y', strtotime($current_csgo_expiry)));
}

// Calculate new expiry
$expiration_timestamp = time() + ($days_in * 24 * 60 * 60);
$expiration_date = date('Y-m-d H:i:s', $expiration_timestamp);

// Update subscription and set group to premium (5)
$upd = $pdo->prepare('UPDATE gs_users SET csgo = ?, group_id = 5 WHERE username = ?');
$ok = $upd->execute([$expiration_date, $user['username']]);

if (!$ok) {
    json_reply(false, 'Failed to update subscription.');
}

// Everything good – reply JSON only
json_reply(true, 'HrisitoSense CS:GO subscription activated for '.$days_in.' days!', [
    'expires' => date('M j, Y', $expiration_timestamp)
]);
