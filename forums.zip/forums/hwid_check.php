<?php
// hwid_check.php - Standalone Hardware ID validation backend
// Disable error display to prevent header issues
error_reporting(0);
ini_set('display_errors', 0);

// Database configuration - UPDATE THESE VALUES
$db_host = '185.194.177.9';        // Your database host
$db_name = 'hrisito';  // Your database name
$db_user = 'interlection';  // Your database username
$db_pass = 'xRoles13:)';       // Your database password
$db_table = 'gs_users';        // Your users table name

// Function to get client IP address
function getClientIP() {
    $ipKeys = ['HTTP_CLIENT_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_FORWARDED', 
               'HTTP_X_CLUSTER_CLIENT_IP', 'HTTP_FORWARDED_FOR', 'HTTP_FORWARDED', 'REMOTE_ADDR'];
    
    foreach ($ipKeys as $key) {
        if (array_key_exists($key, $_SERVER) === true) {
            foreach (explode(',', $_SERVER[$key]) as $ip) {
                $ip = trim($ip);
                if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) !== false) {
                    return $ip;
                }
            }
        }
    }
    return $_SERVER['REMOTE_ADDR'] ?? 'unknown';
}

// Function to log debug information
function logDebug($message) {
    $timestamp = date('Y-m-d H:i:s');
    $logMessage = "[$timestamp] $message\n";
    file_put_contents('/tmp/hwid_debug.log', $logMessage, FILE_APPEND);
}

/* ------------------ NEW: helpers to ignore motherboard for user 5348 ------------------ */
function normalize_parts_ignore_mb($parts) {
    if ($parts === '' || $parts === null) return '';
    // Remove the MB: section (up to next pipe or end), case-insensitive.
    // Examples it handles:
    //  " | MB: something"  or  "MB: something" at end/no trailing pipe
    $noMb = preg_replace('/(\s*\|\s*)?MB:\s*[^|]*/i', '', $parts);
    // Collapse multiple spaces and tidy delimiters
    $noMb = preg_replace('/\s+/', ' ', trim($noMb));
    // Also normalize spacing around pipes so comparisons are stable
    $noMb = preg_replace('/\s*\|\s*/', ' | ', $noMb);
    return $noMb;
}
/* -------------------------------------------------------------------------------------- */

// Set content type
header('Content-Type: text/plain');

// Log request details
logDebug("Request Method: " . $_SERVER['REQUEST_METHOD']);
logDebug("Request URI: " . $_SERVER['REQUEST_URI']);
logDebug("POST Data: " . print_r($_POST, true));
logDebug("Client IP: " . getClientIP());

// Check if request method is POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    logDebug("Invalid request method: " . $_SERVER['REQUEST_METHOD']);
    http_response_code(405);
    echo 'ERROR: Method not allowed - Only POST requests are accepted';
    exit;
}

// Get POST data
$username = isset($_POST['username']) ? trim($_POST['username']) : '';
$hwid     = isset($_POST['hwid']) ? trim($_POST['hwid']) : '';
$parts    = isset($_POST['parts']) ? trim($_POST['parts']) : '';
$clientIP = getClientIP();

logDebug("Parsed - Username: '$username', HWID: '$hwid', Parts: '$parts', IP: '$clientIP'");

// Validate input
if (empty($username) || empty($hwid) || empty($parts)) {
    logDebug("Missing required parameters");
    http_response_code(400);
    echo 'ERROR: Missing required parameters';
    exit;
}

// Database connection
try {
    $pdo = new PDO("mysql:host=$db_host;dbname=$db_name;charset=utf8mb4", $db_user, $db_pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false
    ]);
    logDebug("Database connection successful");
} catch (PDOException $e) {
    logDebug("Database connection failed: " . $e->getMessage());
    http_response_code(500);
    echo 'ERROR: Database connection failed';
    exit;
}

try {
    // Get user from database using prepared statement
    $stmt = $pdo->prepare("SELECT * FROM `$db_table` WHERE `username` = :username");
    $stmt->execute(['username' => $username]);
    $user = $stmt->fetch();
    
    if (!$user) {
        logDebug("User not found: $username");
        http_response_code(401);
        echo 'ERROR: User not found';
        exit;
    }
    
    $userId = (int)$user['id'];
    logDebug("User found: ID=$userId");
    
    // Check current HWID status
    $currentHwid   = $user['hwid'] ?? '';
    $currentParts  = $user['parts'] ?? '';
    $currentHwidIP = $user['hwid_ip'] ?? '';
    
    logDebug("Current HWID: '$currentHwid'");
    logDebug("Current Parts: '$currentParts'");
    logDebug("Current IP: '$currentHwidIP'");
    
    // If user has no HWID set (first time)
    if (empty($currentHwid) || empty($currentParts) || empty($currentHwidIP)) {
        logDebug("Setting initial HWID for user");
        $stmt = $pdo->prepare("UPDATE `$db_table` SET 
                              `hwid` = :hwid, 
                              `parts` = :parts, 
                              `hwid_ip` = :ip 
                              WHERE `id` = :id");
        $result = $stmt->execute([
            'hwid'  => $hwid,
            'parts' => $parts,
            'ip'    => $clientIP,
            'id'    => $userId
        ]);
        if ($result) {
            logDebug("Initial HWID set successfully");
            echo 'SUCCESS: HWID registered successfully';
            exit;
        } else {
            logDebug("Failed to set initial HWID");
            http_response_code(500);
            echo 'ERROR: Unable to update user HWID';
            exit;
        }
    }
    
    /* ------------------ NEW: special-case match for user 5348 ignoring MB ------------------ */
    if ($userId === 5348) {
        $normalizedIncoming = normalize_parts_ignore_mb($parts);
        $normalizedCurrent  = normalize_parts_ignore_mb($currentParts);
        logDebug("User 5348 normalized parts - Incoming: '$normalizedIncoming' | Current: '$normalizedCurrent'");
        
        if ($normalizedIncoming !== '' && $normalizedIncoming === $normalizedCurrent) {
            // Treat as valid even if hwid hashes differ, since only MB changed.
            logDebug("HWID validated for user 5348 ignoring motherboard differences");
            // Optional: keep IP fresh, without changing stored hwid/parts
            try {
                $ipUpd = $pdo->prepare("UPDATE `$db_table` SET `hwid_ip` = :ip WHERE `id` = :id");
                $ipUpd->execute(['ip' => $clientIP, 'id' => $userId]);
            } catch (Exception $e) {
                logDebug("Non-fatal: failed to update IP for user 5348: " . $e->getMessage());
            }
            echo 'SUCCESS: HWID validated successfully';
            exit;
        }
    }
    /* --------------------------------------------------------------------------------------- */
    
    // If HWID matches current one
    if ($currentHwid === $hwid) {
        logDebug("HWID validated successfully");
        echo 'SUCCESS: HWID validated successfully';
        exit;
    }
    
    logDebug("HWID mismatch - Current: '$currentHwid', Provided: '$hwid'");
    
    // HWID doesn't match - check if there's already a pending request
    $hwidNew  = $user['hwid_new'] ?? '';
    $newParts = $user['newparts'] ?? '';
    $hwidIpNew = $user['hwid_ip_new'] ?? '';
    
    if (!empty($hwidNew) || !empty($newParts) || !empty($hwidIpNew)) {
        logDebug("HWID change request already pending");
        http_response_code(403);
        echo 'ERROR: HWID change request pending approval';
        exit;
    }
    
    // HWID doesn't match and no pending request - create new request
    logDebug("Creating new HWID change request");
    $stmt = $pdo->prepare("UPDATE `$db_table` SET 
                          `hwid_new` = :hwid_new, 
                          `newparts` = :newparts, 
                          `hwid_ip_new` = :hwid_ip_new
                          WHERE `id` = :id");
    $result = $stmt->execute([
        'hwid_new'    => $hwid,
        'newparts'    => $parts,
        'hwid_ip_new' => $clientIP,
        'id'          => $userId
    ]);
    
    if ($result) {
        logDebug("HWID change request created successfully");
        http_response_code(403);
        echo 'ERROR: HWID mismatch - Change request submitted for admin approval';
    } else {
        logDebug("Failed to create HWID change request");
        http_response_code(500);
        echo 'ERROR: Unable to create HWID change request';
    }
    
} catch (Exception $e) {
    logDebug("Exception occurred: " . $e->getMessage());
    http_response_code(500);
    echo 'ERROR: Server error occurred';
}
?>