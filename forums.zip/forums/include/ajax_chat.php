<?php
//
// Ajax Chat shoutbox integration by adaur
// Written by Sebastian Tschan
// Contributors : Ettelcar, Massimiliano Tiraboschi, Xytovl
// License GNU Affero General Public License
// See https://blueimp.net/ajax/
//
if ($pun_user['language'] == 'French')
{
	$lang_ajax_chat = array(
	'Shoutbox'		=>	'Chatbox',
	'Messages'		=>	'Messages',
	);
}
else
{
	$lang_ajax_chat = array(
	'Shoutbox'		=>	'Shoutbox',
	'Messages'		=>	'Messages',
	);
}

$allow_guests = 1; // Set to 1 if you want to allow guests

function getShoutBoxContent() {
    // URL to the chat directory:
    if(!defined('AJAX_CHAT_URL')) {
        define('AJAX_CHAT_URL', './chat/');
    }
    
    // Path to the chat directory:
    if(!defined('AJAX_CHAT_PATH')) {
        define('AJAX_CHAT_PATH', realpath(dirname($_SERVER['SCRIPT_FILENAME']).'/chat').'/');
    }
    
    // Validate the path to the chat:
    if(@is_file(AJAX_CHAT_PATH.'lib/classes.php')) {
        
        // Include Class libraries:
        require(AJAX_CHAT_PATH.'lib/classes.php');
        
        // Initialize the shoutbox:
        $ajaxChat = new CustomAJAXChatShoutBox();
        
        // Parse and return the shoutbox template content:
        return $ajaxChat->getShoutBoxContent();
    }
    
    return null;
}

if(!$pun_user['is_guest'] || $allow_guests) :
?>
<div class="blockform">
	<h2><span>Chat</span></h2>
	<div class="box">
		<div class="inbox">
			<thead>
				<tr>
					<th class="tcl" scope="col"></th>
				</tr>
			</thead>
			<tbody>
			</tbody>
		
			<?php echo getShoutBoxContent(); ?>
		</div>
	</div>
</div>

<!-- Mention Highlight Styles -->
<style>
  .mention {
    background: #f1f5f9;
    color: #0f172a;
    padding: 0 .35rem;
    border-radius: .4rem;
    font-weight: 600;
    display: inline-block;
    line-height: 1.25;
  }
  .mention--me {
    background: #2563eb;
    color: #fff;
  }
</style>

<!-- AJAX Chat Fix Script with Spam Protection -->
<script type="text/javascript">
$(document).ready(function() {
    console.log('Chat fix initializing...');
    
    var lastMessageTime = 0;
    var spamCooldown = 1000;
    var isOnCooldown = false;
    
    function showCooldownMessage() {
        var inputField = $('#inputField');
        var originalPlaceholder = inputField.attr('placeholder');
        inputField.attr('placeholder', 'Please wait 1 second before sending another message...');
        inputField.prop('disabled', true);
        
        setTimeout(function() {
            inputField.attr('placeholder', originalPlaceholder || 'Type your message...');
            inputField.prop('disabled', false);
            isOnCooldown = false;
        }, spamCooldown);
    }
    
    var originalSendMessage = null;
    if (typeof ajaxChat !== 'undefined' && ajaxChat.sendMessage) {
        originalSendMessage = ajaxChat.sendMessage;
        ajaxChat.sendMessage = function() {
            var currentTime = new Date().getTime();
            
            if (currentTime - lastMessageTime < spamCooldown) {
                console.log('Message blocked due to spam protection');
                if (!isOnCooldown) {
                    isOnCooldown = true;
                    showCooldownMessage();
                }
                return false;
            }
            
            lastMessageTime = currentTime;
            return originalSendMessage.apply(this, arguments);
        };
    }

    // Prevent spam on form submit or enter key
    $(document).on('submit', '#chatForm', function(e) {
        var currentTime = new Date().getTime();
        if (currentTime - lastMessageTime < spamCooldown) {
            e.preventDefault();
            console.log('Form submission blocked due to spam protection');
            if (!isOnCooldown) {
                isOnCooldown = true;
                showCooldownMessage();
            }
            return false;
        }
        lastMessageTime = currentTime;
    });
    
    $(document).on('keydown', '#inputField', function(e) {
        if (e.which === 13 || e.keyCode === 13) {
            var currentTime = new Date().getTime();
            if (currentTime - lastMessageTime < spamCooldown) {
                e.preventDefault();
                console.log('Enter key blocked due to spam protection');
                if (!isOnCooldown) {
                    isOnCooldown = true;
                    showCooldownMessage();
                }
                return false;
            }
        }
    });
    
    $(document).on('click', '#chatButton, #sendButton, input[type="submit"]', function(e) {
        var currentTime = new Date().getTime();
        if (currentTime - lastMessageTime < spamCooldown) {
            e.preventDefault();
            console.log('Send button blocked due to spam protection');
            if (!isOnCooldown) {
                isOnCooldown = true;
                showCooldownMessage();
            }
            return false;
        }
    });
    
    var loadAttempts = 0;
    var maxAttempts = 5;
    
    function forceLoadChat() {
        loadAttempts++;
        console.log('Chat load attempt #' + loadAttempts);
        
        if (typeof ajaxChat !== 'undefined') {
            if (ajaxChat.startChat && typeof ajaxChat.startChat === 'function') ajaxChat.startChat();
            if (ajaxChat.updateChat && typeof ajaxChat.updateChat === 'function') ajaxChat.updateChat();
            if (ajaxChat.login && typeof ajaxChat.login === 'function') ajaxChat.login();
        }
        
        $.ajax({
            url: './chat/?ajax=true',
            type: 'GET',
            cache: false,
            timeout: 10000,
            success: function(data, textStatus, xhr) {
                var chatList = $('#chatList');
                if (chatList.length && typeof data === 'string' && data.indexOf('<') !== -1) {
                    chatList.html(data);
                    processMentions();
                }
            }
        });
        
        setTimeout(function() {
            var chatList = $('#chatList');
            if (chatList.length) {
                chatList.css({
                    'display': 'block !important',
                    'visibility': 'visible !important',
                    'opacity': '1 !important'
                });
                if (chatList.children().length === 0 && loadAttempts < maxAttempts) {
                    setTimeout(forceLoadChat, 1000);
                }
            }
        }, 500);
    }
    
    setTimeout(forceLoadChat, 300);
});
</script>

<!-- BBCode Blocker -->
<script>
(function(){
  function nukeClientBB(){
    if (!window.ajaxChat) return false;
    try {
      if (Array.isArray(ajaxChat.bbCodeTags)) ajaxChat.bbCodeTags.length = 0;
      else ajaxChat.bbCodeTags = [];
      try { ajaxChat.regExpMediaUrl = /$a/; } catch(e){}
      return true;
    } catch(e){ return false; }
  }
  function escapeBB(text){ return text.replace(/\[/g, '&#91;').replace(/\]/g, '&#93;'); }
  function wrapSend(){
    if (!window.ajaxChat || typeof ajaxChat.sendMessage !== 'function') return false;
    var _send = ajaxChat.sendMessage;
    ajaxChat.sendMessage = function(){
      try {
        var el = document.getElementById('inputField');
        if (el && el.value) el.value = escapeBB(el.value);
      } catch(e){}
      return _send.apply(this, arguments);
    };
    return true;
  }
  function boot(tries){
    var ok1 = nukeClientBB();
    var ok2 = wrapSend();
    if (!(ok1 && ok2) && (tries||0)<40) setTimeout(function(){boot((tries||0)+1)},150);
  }
  if (document.readyState === 'complete' || document.readyState === 'interactive') boot();
  else document.addEventListener('DOMContentLoaded', boot);
})();
</script>

<!-- Mention Highlighter Script -->
<script>
(function () {
  var CURRENT_USER = <?php echo json_encode($pun_user['username'] ?? ''); ?>;
  var mentionRe = /(^|\s)@([A-Za-z0-9_]{2,32})\b/g;

  function wrapMentionsIn(node) {
    var walker = document.createTreeWalker(node, NodeFilter.SHOW_TEXT, null);
    var texts = [], t;
    while ((t = walker.nextNode())) texts.push(t);

    texts.forEach(function(textNode){
      if (!mentionRe.test(textNode.nodeValue)) return;
      var html = textNode.nodeValue.replace(mentionRe, function(_, lead, handle){
        var cls = 'mention' + (CURRENT_USER && handle.toLowerCase() === CURRENT_USER.toLowerCase() ? ' mention--me' : '');
        return lead + '<span class="' + cls + '">@' + handle + '</span>';
      });
      var temp = document.createElement('span');
      temp.innerHTML = html;
      textNode.parentNode.replaceChild(temp, textNode);
      while (temp.firstChild) temp.parentNode.insertBefore(temp.firstChild, temp);
      temp.remove();
    });
  }

  function processMentions() {
    var chatList = document.getElementById('chatList') || document;
    wrapMentionsIn(chatList);
  }

  document.addEventListener('DOMContentLoaded', processMentions);
  if (window.MutationObserver) {
    var target = document.getElementById('chatList');
    if (target) {
      var mo = new MutationObserver(processMentions);
      mo.observe(target, { childList: true, subtree: true });
    }
  }
})();
</script>

<?php
endif;
?>
