<?php
// Tell header.php to use the admin template
define('PUN_ADMIN_CONSOLE', 1);

define('PUN_ROOT', dirname(__FILE__).'/');
require PUN_ROOT.'include/common.php';
require PUN_ROOT.'include/common_admin.php';

if (!$pun_user['is_admmod'])
	message($lang_common['No permission']);

if ($pun_user['g_moderator'] == '1')
	message($lang_common['No permission'], false, '403 Forbidden');

// Load the admin_index.php language file
require PUN_ROOT.'lang/'.$admin_language.'/admin_index.php';

$page_title = array(pun_htmlspecialchars($pun_config['o_board_title']), $lang_admin_common['Admin'], "Invite Wave");
define('PUN_ACTIVE_PAGE', 'invite_wave');
require PUN_ROOT.'header.php';

// Allowed group IDs for invite wave
$allowed_groups = array(5, 8, 9);

// Handle invite wave creation
if (isset($_GET['action']) && $_GET['action'] == 'create_wave') {
	// CSRF check (this is sufficient security)
	check_csrf($_GET['csrf_token']);
	
	$codes_per_user = isset($_GET['codes']) ? intval($_GET['codes']) : 1;
	$is_beta = isset($_GET['beta']) ? 1 : 0;
	$admin_id = $pun_user['id'];
	
	$total_created = 0;
	
	// Get all users with allowed group IDs
	$result_users = $db->query("SELECT id FROM `gs_users` WHERE `group_id` IN (" . implode(',', $allowed_groups) . ")") 
					or error('Unable to fetch users', __FILE__, __LINE__, $db->error());
	
	while ($user = $db->fetch_assoc($result_users)) {
		for ($i = 0; $i < $codes_per_user; $i++) {
			// Generate code like: Bg0mlFNPSB85WS5N7HPJjZpk1tH3sMu071JSqHOjSy6vT9JY
			$invite_code = substr(str_replace(['+', '/', '='], '', base64_encode(random_bytes(36))), 0, 48);
			
			$db->query("INSERT INTO `gs_codes` (`code`, `by`, `used`, `admin`, `user`, `date`, `usedat`, `beta`) 
						VALUES ('".$db->escape($invite_code)."', '".$user['id']."', 0, '$admin_id', NULL, NOW(), NULL, '$is_beta')") 
						or error('Unable to create invite code', __FILE__, __LINE__, $db->error());
			
			$total_created++;
		}
	}
	
	redirect('admin_invite.php', "Invite wave created successfully! Generated $total_created codes for groups: " . implode(', ', $allowed_groups));
	die();
}

// Handle code deletion
if (isset($_GET['action']) && $_GET['action'] == 'delete_code' && isset($_GET['id'])) {
	// CSRF check
	check_csrf($_GET['csrf_token']);
	
	$code_id = intval($_GET['id']);
	
	$db->query("DELETE FROM `gs_codes` WHERE `id` = '$code_id' AND `by` IN (SELECT id FROM gs_users WHERE group_id IN (" . implode(',', $allowed_groups) . "))") 
			or error('Unable to delete invite code', __FILE__, __LINE__, $db->error());
	
	redirect('admin_invite.php', "Invite code deleted successfully");
	die();
}

// Handle clearing all unused codes for allowed groups
if (isset($_GET['action']) && $_GET['action'] == 'clear_unused') {
	// CSRF check
	check_csrf($_GET['csrf_token']);
	
	$db->query("DELETE FROM `gs_codes` WHERE `used` = 0 OR `used` IS NULL")
		or error('Unable to clear unused codes', __FILE__, __LINE__, $db->error());
	
	redirect('admin_invite.php', "All unused codes cleared successfully");
	die();
}

generate_admin_menu('invite_wave');
?>

<div class="block">
	<?php if ($pun_user['id'] == 13): // Only UID 13 can see this section ?>
	<h2><span>Create Invite Wave</span></h2>
	<div id="adintro" class="box">
		<div class="inbox">
			<p>Create invite codes for users in groups: <strong><?php echo implode(', ', $allowed_groups); ?></strong></p>
			<form method="get" action="admin_invite.php">
				<input type="hidden" name="action" value="create_wave">
				<input type="hidden" name="csrf_token" value="<?php echo pun_csrf_token(); ?>">
				
				<table>
					<tr>
						<td><label>Codes per user:</label></td>
						<td><input type="number" name="codes" value="1" min="1" max="10" style="width: 80px;"></td>
					</tr>
					<tr>
						<td><label>Beta wave:</label></td>
						<td><input type="checkbox" name="beta" value="1"> <em>Check if this is a beta invite wave</em></td>
					</tr>
					<tr>
						<td colspan="2">
							<input type="submit" value="Create Wave" onclick="return confirm('Are you sure you want to create a new invite wave?');">
							<a href="admin_invite.php?csrf_token=<?php echo pun_csrf_token(); ?>&action=clear_unused" onclick="return confirm('Are you sure you want to clear all unused codes?');" style="margin-left: 20px; color: #c33;">Clear All Unused</a>
						</td>
					</tr>
				</table>
			</form>
		</div>
	</div>
	<?php endif; ?>

	<h2 class="block2"><span>Wave Statistics</span></h2>
	<div id="adintro" class="box">
		<div class="inbox">
			<table>
				<thead>
					<tr>
						<th class="tc3" scope="col">Group ID</th>
						<th class="tc3" scope="col">Users Count</th>
						<th class="tc3" scope="col">Total Codes</th>
						<th class="tc3" scope="col">Used Codes</th>
						<th class="tc3" scope="col">Available Codes</th>
						<th class="tc3" scope="col">Usage Rate</th>
					</tr>
				</thead>
				<tbody>
					<?php 
					$overall_total = 0;
					$overall_used = 0;
					$overall_users = 0;
					
					foreach ($allowed_groups as $group_id): 
						// Get user count for this group
						$result_user_count = $db->query("SELECT COUNT(*) as user_count FROM `gs_users` WHERE `group_id` = '$group_id'") 
											or error('Unable to fetch user count', __FILE__, __LINE__, $db->error());
						$user_count_data = $db->fetch_assoc($result_user_count);
						$user_count = $user_count_data['user_count'];
						
						// Get code stats for users in this group
						$result_stats = $db->query("SELECT 
							COUNT(*) as total_codes,
							SUM(CASE WHEN c.used = 1 THEN 1 ELSE 0 END) as used_codes,
							SUM(CASE WHEN c.used = 0 THEN 1 ELSE 0 END) as available_codes
							FROM `gs_codes` c
							INNER JOIN `gs_users` u ON c.by = u.id
							WHERE u.group_id = '$group_id'") or error('Unable to fetch stats', __FILE__, __LINE__, $db->error());
						
						$stats = $db->fetch_assoc($result_stats);
						$overall_total += $stats['total_codes'];
						$overall_used += $stats['used_codes'];
						$overall_users += $user_count;
						$usage_rate = $stats['total_codes'] > 0 ? round(($stats['used_codes'] / $stats['total_codes']) * 100, 1) : 0;
					?>
					<tr>
						<td class="tc3"><strong><?php echo $group_id; ?></strong></td>
						<td class="tc3"><?php echo $user_count; ?></td>
						<td class="tc3"><?php echo $stats['total_codes']; ?></td>
						<td class="tc3"><?php echo $stats['used_codes']; ?></td>
						<td class="tc3"><?php echo $stats['available_codes']; ?></td>
						<td class="tc3"><?php echo $usage_rate; ?>%</td>
					</tr>
					<?php endforeach; ?>
					
					<tr style="background-color: #f0f0f0; font-weight: bold;">
						<td class="tc3">TOTAL</td>
						<td class="tc3"><?php echo $overall_users; ?></td>
						<td class="tc3"><?php echo $overall_total; ?></td>
						<td class="tc3"><?php echo $overall_used; ?></td>
						<td class="tc3"><?php echo $overall_total - $overall_used; ?></td>
						<td class="tc3"><?php echo $overall_total > 0 ? round(($overall_used / $overall_total) * 100, 1) : 0; ?>%</td>
					</tr>
				</tbody>
			</table>
		</div>
	</div>

	<div class="clearer"></div>
</div>

<?php
require PUN_ROOT.'footer.php';
?>