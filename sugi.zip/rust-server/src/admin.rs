use axum::{
    Json, Router,
    extract::{Path as AxumPath, State},
    http::{HeaderMap, StatusCode},
    middleware::{self, Next},
    response::{Html, IntoResponse, Response},
    routing::{delete, get},
};
use serde::Deserialize;
use serde_json::json;

use crate::AppState;

const PANEL_HTML: &str = include_str!("admin_panel.html");

pub fn router(state: AppState) -> Router {
    let protected = Router::new()
        .route(
            "/admin/api/accounts",
            get(list_accounts).post(create_account),
        )
        .route(
            "/admin/api/accounts/{id}",
            delete(delete_account).patch(toggle_account),
        )
        .route_layer(middleware::from_fn_with_state(
            state.clone(),
            require_admin_key,
        ));

    Router::new()
        .route("/admin", get(panel_page))
        .merge(protected)
        .with_state(state)
}

async fn require_admin_key(
    State(state): State<AppState>,
    headers: HeaderMap,
    request: axum::extract::Request,
    next: Next,
) -> Response {
    let provided = headers
        .get("x-admin-key")
        .and_then(|v| v.to_str().ok())
        .unwrap_or("");

    if provided.is_empty() || provided != state.admin_key.as_str() {
        return (StatusCode::UNAUTHORIZED, "invalid admin key").into_response();
    }
    next.run(request).await
}

async fn panel_page() -> Html<&'static str> {
    Html(PANEL_HTML)
}

async fn list_accounts(State(state): State<AppState>) -> Response {
    let accounts = state.accounts.list().await;
    Json(json!({ "accounts": accounts })).into_response()
}

#[derive(Deserialize)]
struct CreateAccountBody {
    username: String,
    #[serde(default)]
    note: String,
    #[serde(default)]
    expires_days: Option<i64>,
}

async fn create_account(
    State(state): State<AppState>,
    Json(body): Json<CreateAccountBody>,
) -> Response {
    let username = body.username.trim();
    if username.is_empty() {
        return (StatusCode::BAD_REQUEST, "username required").into_response();
    }

    match state
        .accounts
        .create(username.to_string(), body.note, body.expires_days)
        .await
    {
        Ok(account) => Json(account).into_response(),
        Err(e) => {
            tracing::error!("[admin] failed to create account: {e}");
            (StatusCode::INTERNAL_SERVER_ERROR, "failed to create account").into_response()
        }
    }
}

#[derive(Deserialize)]
struct ToggleBody {
    enabled: bool,
}

async fn toggle_account(
    State(state): State<AppState>,
    AxumPath(id): AxumPath<String>,
    Json(body): Json<ToggleBody>,
) -> Response {
    match state.accounts.set_enabled(&id, body.enabled).await {
        Ok(true) => StatusCode::OK.into_response(),
        Ok(false) => (StatusCode::NOT_FOUND, "not found").into_response(),
        Err(e) => {
            tracing::error!("[admin] failed to toggle account: {e}");
            (StatusCode::INTERNAL_SERVER_ERROR, "failed to update account").into_response()
        }
    }
}

async fn delete_account(State(state): State<AppState>, AxumPath(id): AxumPath<String>) -> Response {
    match state.accounts.delete(&id).await {
        Ok(true) => StatusCode::OK.into_response(),
        Ok(false) => (StatusCode::NOT_FOUND, "not found").into_response(),
        Err(e) => {
            tracing::error!("[admin] failed to delete account: {e}");
            (StatusCode::INTERNAL_SERVER_ERROR, "failed to delete account").into_response()
        }
    }
}
