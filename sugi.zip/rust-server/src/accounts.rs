use std::path::PathBuf;
use std::sync::Arc;

use anyhow::{Context, Result};
use serde::{Deserialize, Serialize};
use tokio::sync::RwLock;
use uuid::Uuid;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Account {
    pub id: String,
    pub username: String,
    pub token: String,
    pub enabled: bool,
    #[serde(default)]
    pub note: String,
    pub created_at: String,
    /// Unix timestamp (seconds) after which the token stops working. None = never expires.
    #[serde(default)]
    pub expires_at: Option<i64>,
    #[serde(default)]
    pub last_connected_at: Option<String>,
}

#[derive(Default, Serialize, Deserialize)]
struct AccountsFile {
    #[serde(default)]
    accounts: Vec<Account>,
}

pub struct AccountStore {
    path: PathBuf,
    inner: Arc<RwLock<Vec<Account>>>,
}

impl Clone for AccountStore {
    fn clone(&self) -> Self {
        AccountStore {
            path: self.path.clone(),
            inner: Arc::clone(&self.inner),
        }
    }
}

impl AccountStore {
    pub async fn load_or_init(root: &std::path::Path) -> Result<Self> {
        let path = root.join("accounts.json");
        let accounts = if path.exists() {
            let json = tokio::fs::read_to_string(&path)
                .await
                .with_context(|| format!("failed to read {}", path.display()))?;
            let file: AccountsFile =
                serde_json::from_str(&json).with_context(|| "failed to parse accounts.json")?;
            file.accounts
        } else {
            Vec::new()
        };

        Ok(AccountStore {
            path,
            inner: Arc::new(RwLock::new(accounts)),
        })
    }

    async fn persist(&self, accounts: &[Account]) -> Result<()> {
        let file = AccountsFile {
            accounts: accounts.to_vec(),
        };
        let json = serde_json::to_vec_pretty(&file).context("failed to serialize accounts")?;
        let tmp = self.path.with_extension("json.tmp");
        if let Some(parent) = self.path.parent() {
            tokio::fs::create_dir_all(parent).await.ok();
        }
        tokio::fs::write(&tmp, &json)
            .await
            .with_context(|| format!("failed to write {}", tmp.display()))?;
        tokio::fs::rename(&tmp, &self.path)
            .await
            .with_context(|| format!("failed to rename into {}", self.path.display()))
    }

    pub async fn list(&self) -> Vec<Account> {
        let mut accounts = self.inner.read().await.clone();
        accounts.sort_by(|a, b| b.created_at.cmp(&a.created_at));
        accounts
    }

    pub async fn create(
        &self,
        username: String,
        note: String,
        expires_days: Option<i64>,
    ) -> Result<Account> {
        let mut accounts = self.inner.write().await;
        let expires_at = expires_days
            .filter(|d| *d > 0)
            .map(|d| unix_now() + d * 86400);

        let account = Account {
            id: Uuid::new_v4().to_string(),
            username,
            token: generate_secret(),
            enabled: true,
            note,
            created_at: crate::storage::now_iso(),
            expires_at,
            last_connected_at: None,
        };
        accounts.push(account.clone());
        self.persist(&accounts).await?;
        Ok(account)
    }

    pub async fn set_enabled(&self, id: &str, enabled: bool) -> Result<bool> {
        let mut accounts = self.inner.write().await;
        let Some(acc) = accounts.iter_mut().find(|a| a.id == id) else {
            return Ok(false);
        };
        acc.enabled = enabled;
        self.persist(&accounts).await?;
        Ok(true)
    }

    pub async fn delete(&self, id: &str) -> Result<bool> {
        let mut accounts = self.inner.write().await;
        let before = accounts.len();
        accounts.retain(|a| a.id != id);
        let changed = accounts.len() != before;
        if changed {
            self.persist(&accounts).await?;
        }
        Ok(changed)
    }

    /// Returns the matching account if the token is known, enabled, and not expired.
    pub async fn validate(&self, token: &str) -> Option<Account> {
        let accounts = self.inner.read().await;
        let acc = accounts.iter().find(|a| a.token == token)?;
        if !acc.enabled {
            return None;
        }
        if let Some(exp) = acc.expires_at {
            if exp <= unix_now() {
                return None;
            }
        }
        Some(acc.clone())
    }

    pub async fn touch_last_connected(&self, id: &str) {
        let mut accounts = self.inner.write().await;
        if let Some(acc) = accounts.iter_mut().find(|a| a.id == id) {
            acc.last_connected_at = Some(crate::storage::now_iso());
            let _ = self.persist(&accounts).await;
        }
    }
}

fn unix_now() -> i64 {
    std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .unwrap_or_default()
        .as_secs() as i64
}

/// Generates a random 64-char hex secret (two v4 UUIDs concatenated, no dashes).
pub fn generate_secret() -> String {
    format!(
        "{}{}",
        Uuid::new_v4().simple(),
        Uuid::new_v4().simple()
    )
}
