<?php
//for own use please change this otherwise you could
//be faced by exploit
// this file is used to configure the database connection
$db_type = 'mysqli_innodb';
$db_host = '185.194.177.9';
$db_name = 'hrisito';
$db_username = 'interlection';
$db_password = 'xRoles13:)';
$db_prefix = 'gs_';
$p_connect = false;

// for own use/forum please change this otherwise you could
// be faced by exploits
$cookie_name   = 'pun_cookie_7d4f2a';        // random suffix for uniqueness
$cookie_domain = '.hrisitosense.top';         // valid across subdomains
$cookie_path   = '/';
$cookie_secure = 1;                           // only over HTTPS
$cookie_seed   = '33a8ccd030dca5e17abbaf9a464b6691297f948ff573ffcf8b160863f2498fa8';

define('PUN', 1);
