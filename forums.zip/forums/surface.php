<?php

define('PUN_ROOT', dirname(__FILE__).'/');

require PUN_ROOT.'include/common.php';

require PUN_ROOT.'header.php';

if ($pun_user['g_read_board'] == '0')

	message($lang_common['No view']);

?>



<head>

<title>Surface renderer / HrisitoSense</title>

</head>



<div id="brdmain">




<div id="p230506" class="blockpost firstpost blockpost1">
	<h2><span><span class="conr">#1</span> Surface renderer</span></h2>
	<div class="box">
		<div class="inbox">
			<div class="postbody">
				
				
					<h3>Surface renderer</h3>
					<div class="postmsg">
						<p>[ <span style="color: #83B806"><strong>Description</strong></span> ]<br>  This library lets you use the CS:GO ISurface renderer as an alternative to the built-in renderer. It's made to be compatible with Aviarita's surface renderer and works as a drop-in replacement for it.</p><p>[ <span style="color: #83B806"><strong>Usage</strong></span> ]<br>  To update a lua script that's using Aviaritas surface renderer, replace <strong>local surface = require("surface")</strong> with <strong>local renderer = require "gamesense/surface"</strong></p><p>  API documentation:</p><div class="quotebox"><blockquote><div><p><strong>surface.create_font(windows_font_name, tall, [weight], [flags])</strong><br>&nbsp; &nbsp; windows_font_name: Windows font name, only supports .ttf.<br>&nbsp; &nbsp; tall: Font size.<br>&nbsp; &nbsp; weight: Font thickness/weight. (create_font_weights)<br>&nbsp; &nbsp; flags: Text flags, this can be a table, for example {0x001, 0x002} (create_font_flags)<br>&nbsp; &nbsp; Returns a special value that can be passed to draw_text, draw_localized_string, test_font and get_text_size<br>&nbsp; &nbsp; <br><strong>surface.draw_text(x, y, r, g, b, a, font, text)</strong><br>&nbsp; &nbsp; x: Screen coordinate<br>&nbsp; &nbsp; y: Screen coordinate<br>&nbsp; &nbsp; r: Red (1-255)<br>&nbsp; &nbsp; g: Green (1-255)<br>&nbsp; &nbsp; b: Blue (1-255)<br>&nbsp; &nbsp; a: Alpha (1-255)<br>&nbsp; &nbsp; font: Returned value of renderer.create_font<br>&nbsp; &nbsp; text: Text that will be drawn<br>&nbsp; &nbsp; <br><strong>surface.localize_string(text)</strong><br>&nbsp; &nbsp; text: #SFUI_ or other localized strings from csgo/resources/csgo_&lt;language&gt;.txt, that will be drawn<br>&nbsp; &nbsp; Returns the localized string<br>&nbsp; &nbsp; <br><strong>surface.draw_localized_text(x, y, r, g, b, a, font, text)</strong><br>&nbsp; &nbsp; x: Screen coordinate<br>&nbsp; &nbsp; y: Screen coordinate<br>&nbsp; &nbsp; r: Red (1-255)<br>&nbsp; &nbsp; g: Green (1-255)<br>&nbsp; &nbsp; b: Blue (1-255)<br>&nbsp; &nbsp; a: Alpha (1-255)<br>&nbsp; &nbsp; font: Returned value of renderer.create_font<br>&nbsp; &nbsp; text: #SFUI_ or other localized strings from csgo/resources/csgo_&lt;language&gt;.txt, that will be drawn<br>&nbsp; &nbsp; <br><strong>surface.draw_line(x0, y0, x1, y1, r, g, b, a)</strong><br>&nbsp; &nbsp; x0: Screen coordinate of point A<br>&nbsp; &nbsp; y0: Screen coordinate of point A<br>&nbsp; &nbsp; x1: Screen coordinate of point B<br>&nbsp; &nbsp; y1: Screen coordinate of point B<br>&nbsp; &nbsp; r: Red (1-255)<br>&nbsp; &nbsp; g: Green (1-255)<br>&nbsp; &nbsp; b: Blue (1-255)<br>&nbsp; &nbsp; a: Alpha (1-255)</p><p><strong>surface.draw_filled_rect(x, y, w, h, r, g, b, a)</strong><br>&nbsp; &nbsp; x: Screen coordinate<br>&nbsp; &nbsp; y: Screen coordinate<br>&nbsp; &nbsp; w: Width in pixels<br>&nbsp; &nbsp; h: Height in pixels<br>&nbsp; &nbsp; r: Red (1-255)<br>&nbsp; &nbsp; g: Green (1-255)<br>&nbsp; &nbsp; b: Blue (1-255)<br>&nbsp; &nbsp; a: Alpha (1-255)</p><p><strong>surface.draw_outlined_rect(x, y, w, h, r, g, b, a)</strong><br>&nbsp; &nbsp; x: Screen coordinate<br>&nbsp; &nbsp; y: Screen coordinate<br>&nbsp; &nbsp; w: Width in pixels<br>&nbsp; &nbsp; h: Height in pixels<br>&nbsp; &nbsp; r: Red (1-255)<br>&nbsp; &nbsp; g: Green (1-255)<br>&nbsp; &nbsp; b: Blue (1-255)<br>&nbsp; &nbsp; a: Alpha (1-255)<br>&nbsp; &nbsp; <br><strong>surface.draw_filled_outlined_rect(x, y, w, h, r0, g0, b0, a0, r1, g1, b1, a1)</strong><br>&nbsp; &nbsp; x: Screen coordinate<br>&nbsp; &nbsp; y: Screen coordinate<br>&nbsp; &nbsp; w: Width in pixels<br>&nbsp; &nbsp; h: Height in pixels<br>&nbsp; &nbsp; r0: Filled Red (1-255)<br>&nbsp; &nbsp; g0: Filled Green (1-255)<br>&nbsp; &nbsp; b0: Filled Blue (1-255)<br>&nbsp; &nbsp; a0: Filled Alpha (1-255)<br>&nbsp; &nbsp; r1: Outline Red (1-255)<br>&nbsp; &nbsp; g1: Outline Green (1-255)<br>&nbsp; &nbsp; b1: Outline Blue (1-255)<br>&nbsp; &nbsp; a1: Outline Alpha (1-255)<br>&nbsp; &nbsp; <br><strong>surface.draw_filled_gradient_rect(x, y, w, h, r0, g0, b0, a0, r1, g1, b1, a1, horizontal)</strong><br>&nbsp; &nbsp; x: Screen coordinate<br>&nbsp; &nbsp; y: Screen coordinate<br>&nbsp; &nbsp; w: Width in pixels<br>&nbsp; &nbsp; h: Height in pixels<br>&nbsp; &nbsp; r0: Red (1-255)<br>&nbsp; &nbsp; g0: Green (1-255)<br>&nbsp; &nbsp; b0: Blue (1-255)<br>&nbsp; &nbsp; a0: Alpha (1-255)<br>&nbsp; &nbsp; r1: Red (1-255)<br>&nbsp; &nbsp; g1: Green (1-255)<br>&nbsp; &nbsp; b1: Blue (1-255)<br>&nbsp; &nbsp; a1: Alpha (1-255)<br>&nbsp; &nbsp; horizontal: Left to right. Pass true for horizontal gradient, or false for vertical<br>&nbsp; &nbsp; <br><strong>surface.draw_outlined_circle(x, y, r, g, b, a, radius, segments)</strong><br>&nbsp; &nbsp; x: Screen coordinate<br>&nbsp; &nbsp; y: Screen coordinate<br>&nbsp; &nbsp; r: Red (1-255)<br>&nbsp; &nbsp; g: Green (1-255)<br>&nbsp; &nbsp; b: Blue (1-255)<br>&nbsp; &nbsp; a: Alpha (1-255)<br>&nbsp; &nbsp; radius: Radius of the circle in pixels.<br>&nbsp; &nbsp; segments: How many edges the circle should have<br>&nbsp; &nbsp; <br><strong>surface.test_font(x, y, r, g, b, a, font)</strong><br>&nbsp; &nbsp; x: Screen coordinate<br>&nbsp; &nbsp; y: Screen coordinate<br>&nbsp; &nbsp; r: Red (1-255)<br>&nbsp; &nbsp; g: Green (1-255)<br>&nbsp; &nbsp; b: Blue (1-255)<br>&nbsp; &nbsp; a: Alpha (1-255)<br>&nbsp; &nbsp; font: Returned value of renderer.create_font</p><p><strong>surface.get_mouse_pos()</strong><br>&nbsp; &nbsp; Returns current mosue coordinates x, y<br>&nbsp; &nbsp; <br><strong>surface.set_mouse_pos(x, y)</strong><br>&nbsp; &nbsp; x: Screen coordiantes<br>&nbsp; &nbsp; y: Screen coordiantes<br>&nbsp; &nbsp; <br><strong>surface.get_text_size(font, text)</strong><br>&nbsp; &nbsp; font: Returned value of renderer.create_font<br>&nbsp; &nbsp; text: Text that will be measured<br>&nbsp; &nbsp; Returns width, height.<br>&nbsp; &nbsp; <br><strong>surface.load_texture(filename)</strong><br>&nbsp; &nbsp; filename: .vmt file from csgo/materials<br>&nbsp; &nbsp; Returns an integer that can be passed to renderer.texture<br>&nbsp; &nbsp; </p><h5>Custom argument types</h5><p>&nbsp; &nbsp; <br><strong>create_font_weights</strong></p><p>&nbsp; &nbsp; <br><strong>create_font_flags</strong></p><div class="codebox"><pre><code class="hljs">    FONTFLAG_NONE           = 0x000
    FONTFLAG_ITALIC         = 0x001
    FONTFLAG_UNDERLINE      = 0x002
    FONTFLAG_STRIKEOUT      = 0x004
    FONTFLAG_SYMBOL         = 0x008
    FONTFLAG_ANTIALIAS      = 0x010
    FONTFLAG_GAUSSIANBLUR   = 0x020
    FONTFLAG_ROTARY         = 0x040
    FONTFLAG_DROPSHADOW     = 0x080
    FONTFLAG_ADDITIVE       = 0x100
    FONTFLAG_OUTLINE        = 0x200
    FONTFLAG_CUSTOM         = 0x400
    FONTFLAG_BITMAP         = 0x800</code></pre></div></div></blockquote></div><p>[ <span style="color: #83B806"><strong>Credits</strong></span> ]<br>- Aviarita (<a href="https://gamesense.pub/forums/viewtopic.php?id=13342" rel="nofollow">original thread</a>, <a href="https://github.com/Aviarita/surface" rel="nofollow">github</a>)</p>
					</div>

			</div>
		</div>
		<div class="inbox">
			<div class="postfoot clearb">
				<div class="postfootleft"></div>
				
			</div>
		</div>
	</div>
    <br>
</div>

































</div><?php

require PUN_ROOT.'footer.php';