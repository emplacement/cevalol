<?php

define('PUN_BANS_LOADED', 1);

$pun_bans = array (
  0 => 
  array (
    'id' => '39',
    'username' => 'Moderator',
    'ip' => '2a00:11b7:1223:c000:308e:d42b:454c:f58a',
    'email' => 'acidwxrth2@gmail.com',
    'message' => 'Disrespectful Behaviour',
    'expire' => NULL,
    'ban_creator' => '2',
  ),
  1 => 
  array (
    'id' => '42',
    'username' => 'guy',
    'ip' => '89.164.222.91',
    'email' => 'tebitasmurf3@gmail.com',
    'message' => 'retard',
    'expire' => NULL,
    'ban_creator' => '2',
  ),
  2 => 
  array (
    'id' => '43',
    'username' => 'cockandchocolate',
    'ip' => '79.127.154.6',
    'email' => 'swh85750@jioso.com',
    'message' => 'retard',
    'expire' => NULL,
    'ban_creator' => '2',
  ),
  3 => 
  array (
    'id' => '44',
    'username' => 'kanco',
    'ip' => '37.205.31.201',
    'email' => 'karnexmazalice@gmail.com',
    'message' => 'Spam',
    'expire' => NULL,
    'ban_creator' => '46',
  ),
  4 => 
  array (
    'id' => '47',
    'username' => 'velja',
    'ip' => '77.46.131.1',
    'email' => 'spasiveljko@gmail.com',
    'message' => 'Under Investigation',
    'expire' => NULL,
    'ban_creator' => '14',
  ),
  5 => 
  array (
    'id' => '50',
    'username' => 'Camora',
    'ip' => NULL,
    'email' => 'wondermakerm5@gmail.com',
    'message' => 'mutli acc',
    'expire' => NULL,
    'ban_creator' => '14',
  ),
  6 => 
  array (
    'id' => '54',
    'username' => 'lime',
    'ip' => '85.221.149.210',
    'email' => 'limepolish@gmail.com',
    'message' => 'Racism',
    'expire' => NULL,
    'ban_creator' => '16',
  ),
  7 => 
  array (
    'id' => '55',
    'username' => 'georgefloyd',
    'ip' => '104.28.162.192',
    'email' => 'limedick@mail.ru',
    'message' => 'Stop',
    'expire' => NULL,
    'ban_creator' => '2',
  ),
  8 => 
  array (
    'id' => '57',
    'username' => 'adolfhitler',
    'ip' => '104.223.111.206',
    'email' => 'adolfhitler@mail.ru',
    'message' => NULL,
    'expire' => NULL,
    'ban_creator' => '28',
  ),
  9 => 
  array (
    'id' => '58',
    'username' => 'meganigger',
    'ip' => '149.36.50.227',
    'email' => 'nigger@nigger.ru',
    'message' => 'Spamming the N word,',
    'expire' => NULL,
    'ban_creator' => '2',
  ),
  10 => 
  array (
    'id' => '59',
    'username' => 'v1xengoat',
    'ip' => '46.205.200.62',
    'email' => 'filip08filip1111@gmail.com',
    'message' => 'Faggot',
    'expire' => NULL,
    'ban_creator' => '2',
  ),
  11 => 
  array (
    'id' => '60',
    'username' => 'a1most',
    'ip' => '73.18.150.170',
    'email' => 'anthonyve8889@gmail.com',
    'message' => 'Under Investigation',
    'expire' => NULL,
    'ban_creator' => '14',
  ),
  12 => 
  array (
    'id' => '61',
    'username' => 'Insulin4ik',
    'ip' => '46.109.240.164',
    'email' => 'ser0vdanya@yandex.com',
    'message' => 'Under Investigation',
    'expire' => NULL,
    'ban_creator' => '14',
  ),
  13 => 
  array (
    'id' => '66',
    'username' => 'ALIREZA',
    'ip' => '89.36.94.148',
    'email' => 'simple78ali@gmail.com',
    'message' => 'Trying to scam pepole.',
    'expire' => NULL,
    'ban_creator' => '53',
  ),
  14 => 
  array (
    'id' => '68',
    'username' => 'mOnEyMaCk1337',
    'ip' => '81.182.197.127',
    'email' => 'krisszmark@gmail.com',
    'message' => 'Under Investigation.',
    'expire' => NULL,
    'ban_creator' => '2',
  ),
  15 => 
  array (
    'id' => '69',
    'username' => 'idle',
    'ip' => '95.83.62.144',
    'email' => 'dolinskzaebisvoda@gmail.com',
    'message' => 'TRIED to Sell invites.',
    'expire' => NULL,
    'ban_creator' => '46',
  ),
  16 => 
  array (
    'id' => '70',
    'username' => 'Clever',
    'ip' => '178.45.232.93',
    'email' => '123123@mail.ru',
    'message' => 'Under investigation.',
    'expire' => NULL,
    'ban_creator' => '46',
  ),
  17 => 
  array (
    'id' => '72',
    'username' => 'BGD',
    'ip' => '2a04:2413:8103:9200:d4ff:5e25:cd42:2c0e',
    'email' => 'bogdannistoroiu2@gmail.com',
    'message' => 'Banned by esoterik himself.',
    'expire' => NULL,
    'ban_creator' => '53',
  ),
  18 => 
  array (
    'id' => '74',
    'username' => 'agagaandopalla',
    'ip' => '185.57.239.16',
    'email' => 'okolocs227@yandex.ru',
    'message' => 'Invite Selling.',
    'expire' => NULL,
    'ban_creator' => '2',
  ),
  19 => 
  array (
    'id' => '76',
    'username' => 'mouje',
    'ip' => '2a02:8388:e5bf:880:8491:4f40:c36:6511',
    'email' => 'drysift@gmx.at',
    'message' => 'Selling invites (Note: Most likely scamming)',
    'expire' => NULL,
    'ban_creator' => '46',
  ),
  20 => 
  array (
    'id' => '77',
    'username' => 'silent1337',
    'ip' => '109.161.1.104',
    'email' => 'zapasnoja935@gmail.com',
    'message' => 'Selling invites (yes, even on VacBan) isn\'t alllowed. Contact "spinynuggie" on discord to appeal.',
    'expire' => '1791586800',
    'ban_creator' => '39',
  ),
  21 => 
  array (
    'id' => '81',
    'username' => 'D1ckerxxx',
    'ip' => '188.253.121.66',
    'email' => 'k1rasa@163.com',
    'message' => 'Shared Account.',
    'expire' => NULL,
    'ban_creator' => '2',
  ),
  22 => 
  array (
    'id' => '82',
    'username' => 'hyp3X',
    'ip' => '2001:2044:120d:bb00:8d98:58c2:817a:dc3e',
    'email' => 'bertilkuksugare@gmail.com',
    'message' => 'scamming regarded',
    'expire' => NULL,
    'ban_creator' => '53',
  ),
  23 => 
  array (
    'id' => '88',
    'username' => 'hitler',
    'ip' => '2001:a61:3535:a801:e48d:cab7:2efa:b03',
    'email' => 'fbi@gov.net',
    'message' => 'Silly guy',
    'expire' => NULL,
    'ban_creator' => '13',
  ),
  24 => 
  array (
    'id' => '89',
    'username' => 'kseno',
    'ip' => '5.166.67.179',
    'email' => 'spokoynichforever@mail.ru',
    'message' => 'invite selling (vacban)',
    'expire' => NULL,
    'ban_creator' => '2118',
  ),
  25 => 
  array (
    'id' => '91',
    'username' => 'Mnhuknm',
    'ip' => '84.40.219.120',
    'email' => 'knoperknoper12@gmail.com',
    'message' => 'invite selling',
    'expire' => NULL,
    'ban_creator' => '2118',
  ),
  26 => 
  array (
    'id' => '92',
    'username' => 'Smithy',
    'ip' => '209.198.144.95',
    'email' => 'smithydesigner@t-online.de',
    'message' => 'invite selling (vacban)',
    'expire' => NULL,
    'ban_creator' => '2118',
  ),
  27 => 
  array (
    'id' => '99',
    'username' => 'AndreW',
    'ip' => '46.124.161.36',
    'email' => 'zewx.sasuke@gmail.com',
    'message' => 'invite selling',
    'expire' => NULL,
    'ban_creator' => '2118',
  ),
  28 => 
  array (
    'id' => '100',
    'username' => 'bmwM3',
    'ip' => '12.75.211.12',
    'email' => 'haydenlast86@gmail.com',
    'message' => 'Selling invite codes',
    'expire' => NULL,
    'ban_creator' => '39',
  ),
  29 => 
  array (
    'id' => '102',
    'username' => 'gibbon',
    'ip' => '37.76.156.245',
    'email' => 'mishasamokater@mail.ru',
    'message' => 'invite selling',
    'expire' => NULL,
    'ban_creator' => '2118',
  ),
  30 => 
  array (
    'id' => '103',
    'username' => 'vedro7',
    'ip' => '185.20.45.93',
    'email' => 'agsddfj@mail.ru',
    'message' => 'invite selling',
    'expire' => NULL,
    'ban_creator' => '2118',
  ),
  31 => 
  array (
    'id' => '104',
    'username' => 'py2n',
    'ip' => '94.190.80.139',
    'email' => 'sergei.vvv1v1vvv@gmail.com',
    'message' => 'Under investigation.',
    'expire' => NULL,
    'ban_creator' => '46',
  ),
  32 => 
  array (
    'id' => '105',
    'username' => 'xcheetosx',
    'ip' => '78.88.60.156',
    'email' => 'chinczykmilk@gmail.com',
    'message' => 'invite selling stop trying',
    'expire' => NULL,
    'ban_creator' => '2118',
  ),
  33 => 
  array (
    'id' => '106',
    'username' => 'SigmaBoy',
    'ip' => '84.40.218.29',
    'email' => 'oskartozejb@gmail.com',
    'message' => NULL,
    'expire' => NULL,
    'ban_creator' => '2118',
  ),
  34 => 
  array (
    'id' => '107',
    'username' => 'kenarf',
    'ip' => '85.202.150.4',
    'email' => 'kenarf64@gmail.com',
    'message' => 'invite selling',
    'expire' => NULL,
    'ban_creator' => '2118',
  ),
  35 => 
  array (
    'id' => '108',
    'username' => '772',
    'ip' => '122.56.205.123',
    'email' => 'haha@genius.org',
    'message' => 'Funny',
    'expire' => NULL,
    'ban_creator' => '2',
  ),
  36 => 
  array (
    'id' => '110',
    'username' => 'lyrq',
    'ip' => '134.255.50.212',
    'email' => 'siposbalazs656@gmail.com',
    'message' => NULL,
    'expire' => NULL,
    'ban_creator' => '2118',
  ),
  37 => 
  array (
    'id' => '111',
    'username' => 'Sxby',
    'ip' => '37.191.46.235',
    'email' => 'beneszabi021@gmail.com',
    'message' => 'Invite selling',
    'expire' => NULL,
    'ban_creator' => '2118',
  ),
  38 => 
  array (
    'id' => '112',
    'username' => 'niggaheilhitler',
    'ip' => '85.193.32.76',
    'email' => 'microsicek2@seznam.cz',
    'message' => 'Acting a little silly in the shoutbox',
    'expire' => NULL,
    'ban_creator' => '13',
  ),
  39 => 
  array (
    'id' => '115',
    'username' => 'bimbas',
    'ip' => '82.144.151.227',
    'email' => 'petrykz@email.cz',
    'message' => 'Invite selling.',
    'expire' => NULL,
    'ban_creator' => '46',
  ),
  40 => 
  array (
    'id' => '116',
    'username' => 'source',
    'ip' => '185.209.196.249',
    'email' => 'otc@mailhaven.su',
    'message' => 'Under investigation',
    'expire' => NULL,
    'ban_creator' => '46',
  ),
  41 => 
  array (
    'id' => '118',
    'username' => 'Sean',
    'ip' => NULL,
    'email' => 'sean@osintforums.org',
    'message' => NULL,
    'expire' => NULL,
    'ban_creator' => '13',
  ),
  42 => 
  array (
    'id' => '119',
    'username' => 'Kizo',
    'ip' => NULL,
    'email' => 'obzpioneiros@gmail.com',
    'message' => NULL,
    'expire' => NULL,
    'ban_creator' => '13',
  ),
  43 => 
  array (
    'id' => '120',
    'username' => 'sadist',
    'ip' => '178.85.164.108',
    'email' => 'djordin2009@gmail.com',
    'message' => NULL,
    'expire' => NULL,
    'ban_creator' => '13',
  ),
  44 => 
  array (
    'id' => '122',
    'username' => 'RokyYTR',
    'ip' => '185.33.138.101',
    'email' => 'rokynamrokynam@gmail.com',
    'message' => 'Invite selling',
    'expire' => NULL,
    'ban_creator' => '46',
  ),
  45 => 
  array (
    'id' => '123',
    'username' => '67king67',
    'ip' => '2600:382:2770:4c62:99ad:d9da:9f5e:cb9a',
    'email' => 'iloveugang98@gmail.com',
    'message' => 'Invite selling',
    'expire' => NULL,
    'ban_creator' => '2118',
  ),
  46 => 
  array (
    'id' => '125',
    'username' => 'femboylover',
    'ip' => '2a09:bac1:76c1:3eb8::2cf:c4',
    'email' => 'gangilovep@gmail.com',
    'message' => 'Invite selling',
    'expire' => NULL,
    'ban_creator' => '46',
  ),
  47 => 
  array (
    'id' => '126',
    'username' => 'Sanytaar18',
    'ip' => '78.111.126.63',
    'email' => 'rocekl.vladislav@gmail.com',
    'message' => 'Buying an invite',
    'expire' => NULL,
    'ban_creator' => '46',
  ),
  48 => 
  array (
    'id' => '131',
    'username' => 'easy',
    'ip' => '106.219.66.240',
    'email' => 'easyalbcsgo@gmail.com',
    'message' => 'Under investigation',
    'expire' => NULL,
    'ban_creator' => '46',
  ),
  49 => 
  array (
    'id' => '134',
    'username' => 'ByYun',
    'ip' => '155.117.84.63',
    'email' => 'nxys1227@gmail.com',
    'message' => 'Under investigation',
    'expire' => NULL,
    'ban_creator' => '46',
  ),
  50 => 
  array (
    'id' => '138',
    'username' => 'D7ldo245KmPeek',
    'ip' => '185.9.75.207',
    'email' => 'andro23bro@gmail.com',
    'message' => 'Invite selling',
    'expire' => NULL,
    'ban_creator' => '46',
  ),
  51 => 
  array (
    'id' => '139',
    'username' => 'Geldlover',
    'ip' => '87.132.155.105',
    'email' => 'kamilziel347@gmail.com',
    'message' => 'lmao imagine selling invites',
    'expire' => NULL,
    'ban_creator' => '46',
  ),
  52 => 
  array (
    'id' => '142',
    'username' => 'mayskiy',
    'ip' => '80.246.92.144',
    'email' => 'crakenhvh@bk.ru',
    'message' => 'Suspected invite selling',
    'expire' => NULL,
    'ban_creator' => '13',
  ),
  53 => 
  array (
    'id' => '143',
    'username' => 'maysk4iy',
    'ip' => '80.246.81.46',
    'email' => 'kokosikhy@gmail.com',
    'message' => 'Suspected invite selling',
    'expire' => NULL,
    'ban_creator' => '13',
  ),
  54 => 
  array (
    'id' => '144',
    'username' => 'ever',
    'ip' => '77.222.96.98',
    'email' => 'cerion222@gmail.com',
    'message' => 'Invite selling on VacBan',
    'expire' => NULL,
    'ban_creator' => '13',
  ),
  55 => 
  array (
    'id' => '147',
    'username' => 'beastisreallyawesome',
    'ip' => '71.93.57.186',
    'email' => 'nmasonak@gmail.com',
    'message' => 'Listening to bs',
    'expire' => NULL,
    'ban_creator' => '13',
  ),
  56 => 
  array (
    'id' => '149',
    'username' => 'maximka69',
    'ip' => '77.82.49.156',
    'email' => 'repz7580@gmail.com',
    'message' => 'Under Investigation.',
    'expire' => NULL,
    'ban_creator' => '2',
  ),
  57 => 
  array (
    'id' => '150',
    'username' => 'nediad',
    'ip' => '193.169.127.191',
    'email' => 'notdiad@icloud.com',
    'message' => 'Under investigation.',
    'expire' => NULL,
    'ban_creator' => '53',
  ),
  58 => 
  array (
    'id' => '153',
    'username' => 'Illuminati',
    'ip' => '84.15.179.213',
    'email' => 'nar4omano@gmail.com',
    'message' => 'Invite selling',
    'expire' => NULL,
    'ban_creator' => '46',
  ),
  59 => 
  array (
    'id' => '154',
    'username' => 'dxnis',
    'ip' => '81.196.3.233',
    'email' => 'eusuntkernel@gmail.com',
    'message' => 'Invite selling',
    'expire' => NULL,
    'ban_creator' => '46',
  ),
  60 => 
  array (
    'id' => '155',
    'username' => 'FENTDEALER',
    'ip' => '90.252.77.27',
    'email' => 'maxizcool0713@protonmail.com',
    'message' => 'Invite selling',
    'expire' => NULL,
    'ban_creator' => '2118',
  ),
  61 => 
  array (
    'id' => '156',
    'username' => 'faggotnigger',
    'ip' => '2001:2042:fc2e:4a00:4858:1fd3:d2ca:f2bf',
    'email' => 'dossoj22@gmail.com',
    'message' => 'Racist / Homophobic Username',
    'expire' => NULL,
    'ban_creator' => '46',
  ),
  62 => 
  array (
    'id' => '157',
    'username' => 'Ril1k',
    'ip' => '2.203.102.123',
    'email' => 'cerikovsasa999@gmail.com',
    'message' => 'Invite selling',
    'expire' => NULL,
    'ban_creator' => '46',
  ),
  63 => 
  array (
    'id' => '158',
    'username' => 'xdwddll',
    'ip' => '193.247.216.251',
    'email' => 'babashevmt@gmail.com',
    'message' => 'Invite selling',
    'expire' => NULL,
    'ban_creator' => '2118',
  ),
  64 => 
  array (
    'id' => '159',
    'username' => 'Jew',
    'ip' => '46.19.136.231',
    'email' => 'argartha@charliekirk.gov',
    'message' => 'Compromised account',
    'expire' => NULL,
    'ban_creator' => '13',
  ),
  65 => 
  array (
    'id' => '160',
    'username' => 'K1Z4RU',
    'ip' => '169.150.227.225',
    'email' => 'netanyahu@israel.gov.usa.israel.israel.jewsssss',
    'message' => NULL,
    'expire' => NULL,
    'ban_creator' => '13',
  ),
  66 => 
  array (
    'id' => '162',
    'username' => 'Sonyyx',
    'ip' => '2a00:f41:70ab:960:dd48:2f52:1500:fece',
    'email' => 'thebestsonyyx@gmail.com',
    'message' => 'Invite selling',
    'expire' => NULL,
    'ban_creator' => '46',
  ),
  67 => 
  array (
    'id' => '163',
    'username' => 'mapp',
    'ip' => '109.198.224.117',
    'email' => 'memriseek@mail.ru',
    'message' => 'Invite selling',
    'expire' => NULL,
    'ban_creator' => '46',
  ),
  68 => 
  array (
    'id' => '164',
    'username' => 'Propaganda1337',
    'ip' => '109.198.227.203',
    'email' => 'kaneki-ken1000-7@bk.ru',
    'message' => 'Invite selling',
    'expire' => NULL,
    'ban_creator' => '2118',
  ),
  69 => 
  array (
    'id' => '165',
    'username' => 'old',
    'ip' => '176.120.107.30',
    'email' => 'vasyaceo@gmail.com',
    'message' => 'Retard',
    'expire' => NULL,
    'ban_creator' => '2',
  ),
  70 => 
  array (
    'id' => '167',
    'username' => 'dankor',
    'ip' => '146.70.126.212',
    'email' => 'dankorpro@protonmail.com',
    'message' => NULL,
    'expire' => NULL,
    'ban_creator' => '13',
  ),
  71 => 
  array (
    'id' => '170',
    'username' => 'traktorke',
    'ip' => '193.192.170.186',
    'email' => 'ttraktorub@gmail.com',
    'message' => 'Scamming other users',
    'expire' => NULL,
    'ban_creator' => '13',
  ),
  72 => 
  array (
    'id' => '171',
    'username' => 'kellygf',
    'ip' => '77.234.242.114',
    'email' => 'snoothmark@gmail.com',
    'message' => 'Invite selling',
    'expire' => NULL,
    'ban_creator' => '13',
  ),
  73 => 
  array (
    'id' => '172',
    'username' => 'mOnEyMaCk1336',
    'ip' => '2001:4c4e:2463:5800:1af:a33e:e8ac:e7c8',
    'email' => 'ruzsoihpikovoljsam@fxavaj.com',
    'message' => 'Invite selling',
    'expire' => NULL,
    'ban_creator' => '13',
  ),
  74 => 
  array (
    'id' => '173',
    'username' => 'voidije',
    'ip' => '2001:41d0:700:72de::',
    'email' => 'fdszyn123@gmail.com',
    'message' => 'Invite selling',
    'expire' => NULL,
    'ban_creator' => '46',
  ),
  75 => 
  array (
    'id' => '174',
    'username' => 'Mordini123',
    'ip' => '37.30.28.38',
    'email' => 'kleczkowskigabriel@gmail.com',
    'message' => 'Invite selling',
    'expire' => NULL,
    'ban_creator' => '46',
  ),
  76 => 
  array (
    'id' => '175',
    'username' => 'Myself',
    'ip' => '178.40.240.127',
    'email' => 'tozek1959@gmail.com',
    'message' => 'Invite selling',
    'expire' => NULL,
    'ban_creator' => '46',
  ),
  77 => 
  array (
    'id' => '176',
    'username' => 'chereches14',
    'ip' => '188.27.130.225',
    'email' => 'chereches6969@gmail.com',
    'message' => 'Invite selling',
    'expire' => NULL,
    'ban_creator' => '53',
  ),
  78 => 
  array (
    'id' => '178',
    'username' => 'vectexcephandler',
    'ip' => '23.162.40.159',
    'email' => 'zoppendhvh@gmail.com',
    'message' => 'associated with dirty activities',
    'expire' => NULL,
    'ban_creator' => '2118',
  ),
  79 => 
  array (
    'id' => '179',
    'username' => 'vedro6',
    'ip' => '23.154.136.106',
    'email' => 'qgasg@rambler.ru',
    'message' => 'Invite selling on VacBan',
    'expire' => NULL,
    'ban_creator' => '13',
  ),
  80 => 
  array (
    'id' => '181',
    'username' => 'steffTALENT',
    'ip' => '85.186.48.178',
    'email' => 'adiivlg2@gmail.com',
    'message' => 'Under Investigation.',
    'expire' => NULL,
    'ban_creator' => '2',
  ),
  81 => 
  array (
    'id' => '182',
    'username' => 'sulamarecuvaloare69',
    'ip' => '2a02:2f08:5906:a800:5d7c:a64a:abad:4c95',
    'email' => 'steffsteam4@gmail.com',
    'message' => 'Under Investigation.',
    'expire' => NULL,
    'ban_creator' => '2',
  ),
  82 => 
  array (
    'id' => '184',
    'username' => 'CaRtiE',
    'ip' => '31.182.251.60',
    'email' => 'cartiesspp@gmail.com',
    'message' => 'Invite selling on VacBan',
    'expire' => NULL,
    'ban_creator' => '13',
  ),
  83 => 
  array (
    'id' => '185',
    'username' => 'vedro5',
    'ip' => '207.210.110.149',
    'email' => 'gamesense1337@re146.dev',
    'message' => 'Alt account',
    'expire' => NULL,
    'ban_creator' => '13',
  ),
  84 => 
  array (
    'id' => '186',
    'username' => 'RIKY00',
    'ip' => '37.160.176.253',
    'email' => 'sunnyalraggi@gmail.com',
    'message' => 'Invite selling',
    'expire' => '1923260400',
    'ban_creator' => '39',
  ),
  85 => 
  array (
    'id' => '187',
    'username' => 'Hardnewplayer1234',
    'ip' => '151.115.98.120',
    'email' => 'h47771942@gmail.com',
    'message' => 'Invite selling',
    'expire' => '1923260400',
    'ban_creator' => '39',
  ),
  86 => 
  array (
    'id' => '188',
    'username' => 'Clawzzz',
    'ip' => '72.46.54.105',
    'email' => 'aikillough50@gmail.com',
    'message' => 'Invite selling',
    'expire' => '1923260400',
    'ban_creator' => '39',
  ),
  87 => 
  array (
    'id' => '189',
    'username' => 'sacas',
    'ip' => '89.163.221.14',
    'email' => 'sacas8271@gmail.com',
    'message' => 'Invite selling',
    'expire' => '1923260400',
    'ban_creator' => '39',
  ),
  88 => 
  array (
    'id' => '190',
    'username' => 'yuyu',
    'ip' => '74.57.193.193',
    'email' => 'yudickinson67@gmail.com',
    'message' => 'Invite selling',
    'expire' => '1923260400',
    'ban_creator' => '39',
  ),
  89 => 
  array (
    'id' => '191',
    'username' => 'albertocapone',
    'ip' => '37.30.20.127',
    'email' => 'ckwl1942@gmail.com',
    'message' => 'Invite selling',
    'expire' => '1923260400',
    'ban_creator' => '39',
  ),
  90 => 
  array (
    'id' => '192',
    'username' => 'mxwrq',
    'ip' => '37.215.1.15',
    'email' => 'savickiidaniil52@gmail.com',
    'message' => 'Invite selling on VacBan',
    'expire' => NULL,
    'ban_creator' => '13',
  ),
  91 => 
  array (
    'id' => '193',
    'username' => 's1mtry',
    'ip' => '2a02:a58:950a:ca00:f8ec:8433:2195:90ee',
    'email' => 'telefonnoualex@gmail.com',
    'message' => 'invite selling',
    'expire' => NULL,
    'ban_creator' => '639',
  ),
  92 => 
  array (
    'id' => '194',
    'username' => 'Topor',
    'ip' => '5.173.129.214',
    'email' => 'tkuzma1106@proton.me',
    'message' => 'Under Investigation.',
    'expire' => NULL,
    'ban_creator' => '2',
  ),
  93 => 
  array (
    'id' => '196',
    'username' => 'aimware',
    'ip' => '2a09:bac1:6180:60::4f:d8',
    'email' => 'blokpostmobail44@gmail.com',
    'message' => 'Advertising.',
    'expire' => '1763157600',
    'ban_creator' => '2',
  ),
);

?>