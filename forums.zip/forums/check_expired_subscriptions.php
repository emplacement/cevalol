<?php
define('PUN_ROOT', dirname(__FILE__).'/');
require PUN_ROOT.'include/common.php';

// Find all users with expired CS:GO subscriptions who are still in group 5
$expired_users = $db->query('SELECT id, username, csgo FROM gs_users WHERE group_id = 5 AND csgo IS NOT NULL AND csgo < NOW()');

$updated_count = 0;

while ($user = $db->fetch_assoc($expired_users)) {
    // Move expired subscribers back to regular user group (assuming group 3 or 4)
    $db->query('UPDATE gs_users SET group_id = 3 WHERE id = '.$user['id']);
    $updated_count++;
    echo "Expired subscription for user: " . $user['username'] . " (was valid until: " . $user['csgo'] . ")\n";
}

echo "Updated $updated_count expired subscriptions\n";
?>