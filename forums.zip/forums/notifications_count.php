<?php
// notifications_count.php
define('PUN_ROOT', dirname(__FILE__).'/');
require PUN_ROOT.'include/common.php';

header('Content-Type: application/json');

if ($pun_user['is_guest']) {
    echo json_encode(['unread' => 0, 'display' => '0']);
    exit;
}

$r = $db->query('SELECT COUNT(*) FROM gs_notifications WHERE user_id='.$pun_user['id'].' AND is_read=0')
    or error('Unable to fetch notification count', __FILE__, __LINE__, $db->error());

$count = (int)$db->result($r);
$display = $count > 99 ? '99+' : (string)$count;

echo json_encode(['unread' => $count, 'display' => $display]);
