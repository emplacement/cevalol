<?php
/**
 * discordd.php — FluxBB login + Discord OAuth + guild join (NO ROLES)
 * - Uses FluxBB's $pun_user['username'] as the Discord nickname
 * - If the bot can't set nicknames, it retries join without 'nick'
 * - Mirrors your original gs_users fields/logic
 */

declare(strict_types=1);
session_start();

// ================== CONFIG (fill these) ==================
const DISCORD_CLIENT_ID     = '1372296269677985852';       // e.g. 1372296269677985852
const DISCORD_CLIENT_SECRET = 'EWxQE4yOGQpGf6x2USXynOQ3lGvMzeR5';   // from Discord Developer Portal
const DISCORD_REDIRECT_URI  = 'https://hrisitosense.top/forums/discordd.php'; // must match exactly in the app settings
const DISCORD_BOT_TOKEN     = 'MTM3MjI5NjI2OTY3Nzk4NTg1Mg.G1XUX9.agW5NLy25y5e4eMWHaR-O-FSre6OfsRzclUQJE';       // bot must already be in your server
const DISCORD_GUILD_ID      = 1430204502212083825;     // numeric guild/server ID

// =============== FLUXBB / FORUM BOOTSTRAP ===============
define('PUN_ROOT', __DIR__ . '/');
require PUN_ROOT . 'include/common.php';

// Composer packages: Wohali OAuth2 + RestCord
require __DIR__ . '/vendor/autoload.php';

use Wohali\OAuth2\Client\Provider\Discord as DiscordProvider;
use RestCord\DiscordClient;

// =============== BASIC GUARDS & HELPERS =================
if ($pun_user['g_read_board'] == '0') {
    message($lang_common['No view']);
}

function redirect_now(string $url): void {
    header('Location: ' . $url, true, 302);
    exit;
}

function render_page(string $title, string $message): void {
    echo "<!doctype html><html lang='en'><head><meta charset='utf-8'>
<title>{$title}</title><meta name='viewport' content='width=device-width,initial-scale=1'>
<style>:root{color-scheme:dark}body{margin:0;display:grid;place-items:center;min-height:100vh;background:#101010;color:#eee;font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif}
.card{background:#151515;border:1px solid #333;border-radius:12px;padding:28px;max-width:560px;box-shadow:0 6px 24px rgba(0,0,0,.35)}
h1{margin:0 0 10px;font-size:1.6rem}p{margin:0 0 10px;color:#ccc}.btn{display:inline-block;padding:10px 14px;border:1px solid #2a2a2a;border-radius:8px;color:#eee;text-decoration:none}
</style></head><body><div class='card'><h1>{$title}</h1><p>{$message}</p>
<a class='btn' href='/forums/'>Back to forums</a></div></body></html>";
    exit;
}

function db_escape($db, string $s): string {
    if (method_exists($db, 'escape')) return $db->escape($s);
    if (property_exists($db, '_conn') && $db->_conn instanceof mysqli)
        return mysqli_real_escape_string($db->_conn, $s);
    return addslashes($s);
}

function error_page(string $code): void {
    $msgs = [
        'state'    => 'Security check failed. Please try again.',
        'nouser'   => 'You must be logged in to the forum.',
        'user'     => 'Could not find your forum account.',
        'perm'     => 'Your account is not entitled to join the server.',
        'mismatch' => 'This Discord account doesn’t match the one on file.',
        'oauth'    => 'Discord OAuth failed. Please try again.',
        'join'     => 'We couldn’t add you to the Discord server. Please contact support.',
    ];
    render_page('Error', $msgs[$code] ?? 'An unknown error occurred.');
}

// Show final pages (no output before redirects during flow)
if (isset($_GET['status']) && $_GET['status'] === 'success') {
    render_page('Discord linked', 'Your Discord account was linked and added to the server.');
}
if (isset($_GET['error'])) {
    error_page($_GET['error']);
}

// =============== REQUIRE A LOGGED-IN USER ===============
$sessionUser = isset($pun_user['username']) ? trim((string)$pun_user['username']) : '';
if ($sessionUser === '') {
    error_page('nouser');
}

// =============== OAUTH PROVIDER =========================
$provider = new DiscordProvider([
    'clientId'     => DISCORD_CLIENT_ID,
    'clientSecret' => DISCORD_CLIENT_SECRET,
    'redirectUri'  => DISCORD_REDIRECT_URI,
]);
$scope = ['identify', 'guilds.join'];

// =================== OAUTH FLOW =========================
try {
    // Kick off OAuth
    if (!isset($_GET['code'])) {
        $authUrl = $provider->getAuthorizationUrl(['scope' => $scope]);
        $_SESSION['oauth2state'] = $provider->getState();
        redirect_now($authUrl);
    }

    // Validate state
    if (empty($_GET['state']) || !isset($_SESSION['oauth2state']) || $_GET['state'] !== $_SESSION['oauth2state']) {
        unset($_SESSION['oauth2state']);
        redirect_now('discordd.php?error=state');
    }

    // Exchange code for token
    $token = $provider->getAccessToken('authorization_code', ['code' => $_GET['code']]);

    // Get Discord user
    $discordUser = $provider->getResourceOwner($token);
    $discordId   = (string) $discordUser->getId();

    // ======== Mirror your original DB checks/updates ========
    $escUser = db_escape($db, $sessionUser);
    $res = $db->query("SELECT `discord`, `group_id`, `csgo` FROM `gs_users` WHERE `username` = '{$escUser}' LIMIT 1");
    if (!$res || $res->num_rows === 0) {
        redirect_now('discordd.php?error=user');
    }
    $row = $res->fetch_assoc();

    $existingDiscordId = $row['discord'] ?: null;
    $groupId           = (int) $row['group_id'];

    // entitlement based on csgo datetime (same as original)
    $valid = true;
    if (!empty($row['csgo'])) {
        $now     = new DateTimeImmutable('now');
        $subEnds = new DateTimeImmutable($row['csgo']);
        $valid   = $subEnds > $now;
    }
    if ($groupId == 4 || !$valid) {
        redirect_now('discordd.php?error=perm');
    }

    // mismatch handling like original
    if ($existingDiscordId !== null && $existingDiscordId !== $discordId) {
        $ip = $_SERVER['HTTP_CF_CONNECTING_IP'] ?? ($_SERVER['REMOTE_ADDR'] ?? '');
        $escDid = db_escape($db, $discordId);
        $escIp  = db_escape($db, $ip);
        $db->query("UPDATE `gs_users` SET `discord_new` = '{$escDid}', `discord_ip_new` = '{$escIp}' WHERE `username` = '{$escUser}'");
        redirect_now('discordd.php?error=mismatch');
    }

    // store primary discord id + ip (as original)
    $ip = $_SERVER['HTTP_CF_CONNECTING_IP'] ?? ($_SERVER['REMOTE_ADDR'] ?? '');
    $escDid = db_escape($db, $discordId);
    $escIp  = db_escape($db, $ip);
    $db->query("UPDATE `gs_users` SET `discord` = '{$escDid}', `discord_ip` = '{$escIp}' WHERE `username` = '{$escUser}'");

    // ================== GUILD JOIN ========================
    $discord = new DiscordClient(['token' => DISCORD_BOT_TOKEN]); // raw bot token
    $guildId = (int) DISCORD_GUILD_ID;
    $userId  = (int) $discordId;

    // Treat “already a member” as success
    $already = false;
    try {
        $discord->guild->getGuildMember(['guild.id' => $guildId, 'user.id' => $userId]);
        $already = true;
    } catch (\Throwable $e) { /* not in guild (likely 404) */ }

    if (!$already) {
        // First try WITH forum nickname
        $payload = [
            'guild.id'     => $guildId,
            'user.id'      => $userId,
            'access_token' => $token->getToken(),  // IMPORTANT: token string
            'nick'         => $sessionUser,        // FluxBB username
        ];

        try {
            $discord->guild->addGuildMember($payload);
        } catch (\Throwable $e) {
            // If nickname perms fail, retry WITHOUT nick so join still succeeds
            try {
                $payloadNoNick = $payload;
                unset($payloadNoNick['nick']);
                $discord->guild->addGuildMember($payloadNoNick);
            } catch (\Throwable $e2) {
                redirect_now('discordd.php?error=join');
            }
        }
    }

    unset($_SESSION['oauth2state']);
    redirect_now('discordd.php?status=success');

} catch (\League\OAuth2\Client\Provider\Exception\IdentityProviderException $e) {
    unset($_SESSION['oauth2state']);
    redirect_now('discordd.php?error=oauth');
} catch (\Throwable $e) {
    unset($_SESSION['oauth2state']);
    redirect_now('discordd.php?error=join');
}
