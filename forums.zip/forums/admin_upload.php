<?php
// Tell header.php to use the admin template
define('PUN_ADMIN_CONSOLE', 1);

define('PUN_ROOT', dirname(__FILE__).'/');
require PUN_ROOT.'include/common.php';
require PUN_ROOT.'include/common_admin.php';

// Allow access for admins/moderators AND g_id 9
if (!$pun_user['is_admmod'] && $pun_user['g_id'] != 9)
    message($lang_common['No permission']);

require PUN_ROOT.'lang/'.$admin_language.'/admin_index.php';

$page_title = array(pun_htmlspecialchars($pun_config['o_board_title']), $lang_admin_common['Admin'], "Lua Upload Manager");
define('PUN_ACTIVE_PAGE', 'lua_upload');

// Handle metadata editing
if (isset($_POST['edit_metadata'])) {
    check_csrf($_POST['csrf_token']);
    
    $scriptId = intval($_POST['script_id']);
    $metadataFile = PUN_ROOT.'luas/metadata.json';
    
    if (file_exists($metadataFile)) {
        $metadata = json_decode(file_get_contents($metadataFile), true) ?: [];
        
        if (isset($metadata[$scriptId])) {
            // Update metadata fields
            $metadata[$scriptId]['name'] = trim($_POST['meta_name']);
            $metadata[$scriptId]['topic'] = trim($_POST['meta_topic']);
            $metadata[$scriptId]['icon'] = intval($_POST['meta_icon']);
            $metadata[$scriptId]['uploaded_by'] = trim($_POST['meta_uploaded_by']);
            $metadata[$scriptId]['uploaded_id'] = trim($_POST['meta_uploaded_id']);
            $metadata[$scriptId]['preview'] = trim($_POST['meta_preview']);
            $metadata[$scriptId]['promoted'] = isset($_POST['meta_promoted']) ? "1" : "0";
            $metadata[$scriptId]['closed_source'] = isset($_POST['meta_closed_source']) ? "1" : "0";
            $metadata[$scriptId]['usage'] = trim($_POST['meta_usage']);
            $metadata[$scriptId]['changelogs'] = trim($_POST['meta_changelogs']);
            $metadata[$scriptId]['updated'] = date('M j Y');
            
            if (file_put_contents($metadataFile, json_encode($metadata, JSON_PRETTY_PRINT))) {
                redirect('admin_upload.php', "Metadata for script ID {$scriptId} updated successfully");
            } else {
                $metadataError = 'Failed to save metadata';
            }
        } else {
            $metadataError = 'Script ID not found';
        }
    } else {
        $metadataError = 'Metadata file not found';
    }
}

// Get metadata for editing
$editingMetadata = null;
if (isset($_GET['action']) && $_GET['action'] == 'edit_meta' && isset($_GET['id'])) {
    $scriptId = intval($_GET['id']);
    $metadataFile = PUN_ROOT.'luas/metadata.json';
    
    if (file_exists($metadataFile)) {
        $metadata = json_decode(file_get_contents($metadataFile), true) ?: [];
        if (isset($metadata[$scriptId])) {
            $editingMetadata = $metadata[$scriptId];
            $editingMetadata['id'] = $scriptId;
        }
    }
}

// Handle file upload with metadata
if (isset($_POST['upload'])) {
    check_csrf($_POST['csrf_token']);
    
    $uploadDir = PUN_ROOT.'luas/';
    
    if (!file_exists($uploadDir)) {
        mkdir($uploadDir, 0755, true);
    }
    
    if (isset($_FILES['lua_file']) && $_FILES['lua_file']['error'] === UPLOAD_ERR_OK) {
        $tempName = $_FILES['lua_file']['tmp_name'];
        $fileSize = $_FILES['lua_file']['size'];
        
        // Get metadata from form
        $scriptName = trim($_POST['script_name']);
        $scriptTopic = trim($_POST['script_topic']);
        $scriptIcon = intval($_POST['script_icon']);
        
        $fileExtension = strtolower(pathinfo($_FILES['lua_file']['name'], PATHINFO_EXTENSION));
        if ($fileExtension !== 'lua') {
            $uploadError = 'Only .lua files are allowed';
        } elseif ($fileSize > 5 * 1024 * 1024) {
            $uploadError = 'File size must be less than 5MB';
        } elseif (empty($scriptName)) {
            $uploadError = 'Script name is required';
        } else {
            // Use script name as filename, sanitize it
            $fileName = preg_replace('/[^a-zA-Z0-9._-]/', '_', $scriptName) . '.lua';
            $targetPath = $uploadDir . $fileName;
            
            if (file_exists($targetPath)) {
                $uploadError = 'A file with this script name already exists';
            } else {
                if (move_uploaded_file($tempName, $targetPath)) {
                    $idMappingFile = $uploadDir.'id_mapping.json';
                    $metadataFile = $uploadDir.'metadata.json';
                    
                    // Load or create ID mapping
                    $idMapping = [];
                    if (file_exists($idMappingFile)) {
                        $idMapping = json_decode(file_get_contents($idMappingFile), true) ?: [];
                    }
                    
                    // Load or create metadata
                    $metadata = [];
                    if (file_exists($metadataFile)) {
                        $metadata = json_decode(file_get_contents($metadataFile), true) ?: [];
                    }
                    
                    // Assign ID
                    if (!isset($idMapping[$fileName])) {
                        $nextId = empty($idMapping) ? 1 : max($idMapping) + 1;
                        $idMapping[$fileName] = $nextId;
                    }
                    
                    $scriptId = $idMapping[$fileName];
                    
                    // Get uploader name from form
                    $uploadedBy = trim($_POST['uploaded_by']);
                    if (empty($uploadedBy)) {
                        $uploadedBy = $pun_user['username']; // Default to current admin
                    }
                    
                    // Save metadata
                    $metadata[$scriptId] = [
                        'name' => $scriptName,
                        'topic' => $scriptTopic,
                        'icon' => $scriptIcon,
                        'updated' => date('M j Y'),
                        'uploaded_by' => $uploadedBy,
                        'uploaded_id' => '',
                        'promoted' => '0',
                        'preview' => '',
                        'closed_source' => '0',
                        'usage' => '',
                        'changelogs' => '',
                        'file' => $fileName
                    ];
                    
                    file_put_contents($idMappingFile, json_encode($idMapping, JSON_PRETTY_PRINT));
                    file_put_contents($metadataFile, json_encode($metadata, JSON_PRETTY_PRINT));
                    
                    redirect('admin_upload.php', "File '{$fileName}' uploaded successfully");
                } else {
                    $uploadError = 'Failed to upload file';
                }
            }
        }
    } else {
        $uploadError = 'Please select a file to upload';
    }
}

// Function to remove lua ID from all user subscription files
function removeSubscriptionFromAllUsers($luaId) {
    $usersluaDir = PUN_ROOT.'userslua/';
    $removedCount = 0;
    
    if (is_dir($usersluaDir)) {
        $files = scandir($usersluaDir);
        foreach ($files as $file) {
            if (pathinfo($file, PATHINFO_EXTENSION) === 'txt') {
                $userFile = $usersluaDir . $file;
                $subscriptions = array_filter(array_map('trim', file($userFile)));
                
                // Check if user has this subscription
                if (in_array($luaId, $subscriptions)) {
                    // Remove the lua ID from subscriptions
                    $subscriptions = array_diff($subscriptions, [$luaId]);
                    // Save updated subscriptions
                    file_put_contents($userFile, implode("\n", $subscriptions));
                    $removedCount++;
                }
            }
        }
    }
    
    return $removedCount;
}

// Handle file editing
if (isset($_POST['edit_save'])) {
    check_csrf($_POST['csrf_token']);
    
    $fileToEdit = $_POST['file'];
    $filePath = PUN_ROOT.'luas/' . $fileToEdit;
    $newContent = $_POST['lua_content'];
    
    if (strpos($fileToEdit, '..') === false && 
        pathinfo($fileToEdit, PATHINFO_EXTENSION) === 'lua' && 
        file_exists($filePath)) {
        
        if (file_put_contents($filePath, $newContent) !== false) {
            redirect('admin_upload.php', "File '{$fileToEdit}' updated successfully");
        } else {
            $editError = 'Failed to save file';
        }
    } else {
        $editError = 'Invalid file or file not found';
    }
}

// Get file content for editing
$editingFile = null;
$editingContent = '';
if (isset($_GET['action']) && $_GET['action'] == 'edit' && isset($_GET['file'])) {
    $fileToEdit = $_GET['file'];
    $filePath = PUN_ROOT.'luas/' . $fileToEdit;
    
    if (strpos($fileToEdit, '..') === false && 
        pathinfo($fileToEdit, PATHINFO_EXTENSION) === 'lua' && 
        file_exists($filePath)) {
        
        $editingFile = $fileToEdit;
        $editingContent = file_get_contents($filePath);
    }
}

// Handle file deletion
if (isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_GET['file'])) {
    check_csrf($_GET['csrf_token']);
    
    $fileToDelete = $_GET['file'];
    $filePath = PUN_ROOT.'luas/' . $fileToDelete;
    $idMappingFile = PUN_ROOT.'luas/id_mapping.json';
    $metadataFile = PUN_ROOT.'luas/metadata.json';
    
    if (strpos($fileToDelete, '..') === false && 
        pathinfo($fileToDelete, PATHINFO_EXTENSION) === 'lua' && 
        file_exists($filePath)) {
        
        // Get the script ID before deleting
        $scriptIdToRemove = null;
        if (file_exists($idMappingFile)) {
            $idMapping = json_decode(file_get_contents($idMappingFile), true) ?: [];
            $scriptIdToRemove = isset($idMapping[$fileToDelete]) ? $idMapping[$fileToDelete] : null;
        }
        
        if (unlink($filePath)) {
            // Remove subscriptions from all users
            if ($scriptIdToRemove !== null) {
                $removedCount = removeSubscriptionFromAllUsers($scriptIdToRemove);
            }
            
            // Clean up ID mapping
            if (file_exists($idMappingFile)) {
                $idMapping = json_decode(file_get_contents($idMappingFile), true) ?: [];
                
                if (isset($idMapping[$fileToDelete])) {
                    unset($idMapping[$fileToDelete]);
                    file_put_contents($idMappingFile, json_encode($idMapping, JSON_PRETTY_PRINT));
                }
                
                // Clean up metadata
                if ($scriptIdToRemove && file_exists($metadataFile)) {
                    $metadata = json_decode(file_get_contents($metadataFile), true) ?: [];
                    if (isset($metadata[$scriptIdToRemove])) {
                        unset($metadata[$scriptIdToRemove]);
                        file_put_contents($metadataFile, json_encode($metadata, JSON_PRETTY_PRINT));
                    }
                }
            }
            
            $successMsg = "File '{$fileToDelete}' deleted successfully";
            if (isset($removedCount) && $removedCount > 0) {
                $successMsg .= " and removed from {$removedCount} user subscription(s)";
            }
            redirect('admin_upload.php', $successMsg);
        } else {
            $deleteError = 'Failed to delete file';
        }
    } else {
        $deleteError = 'Invalid file or file not found';
    }
}

// Count subscribers for a script
function countSubscribers($luaId) {
    $count = 0;
    $dir = PUN_ROOT.'userslua/';
    if (is_dir($dir)) {
        $files = scandir($dir);
        foreach ($files as $file) {
            if (pathinfo($file, PATHINFO_EXTENSION) === 'txt') {
                $subs = array_filter(array_map('trim', file($dir.$file)));
                if (in_array($luaId, $subs)) {
                    $count++;
                }
            }
        }
    }
    return $count;
}

// Get existing Lua files with metadata
function getLuaFiles() {
    $files = [];
    $idMappingFile = PUN_ROOT.'luas/id_mapping.json';
    $metadataFile = PUN_ROOT.'luas/metadata.json';
    
    $idMapping = [];
    if (file_exists($idMappingFile)) {
        $idMapping = json_decode(file_get_contents($idMappingFile), true) ?: [];
    }
    
    $metadata = [];
    if (file_exists($metadataFile)) {
        $metadata = json_decode(file_get_contents($metadataFile), true) ?: [];
    }
    
    if (is_dir(PUN_ROOT.'luas')) {
        $scanFiles = scandir(PUN_ROOT.'luas');
        $nextId = empty($idMapping) ? 1 : max($idMapping) + 1;
        $updated = false;
        
        foreach ($scanFiles as $file) {
            if (pathinfo($file, PATHINFO_EXTENSION) === 'lua') {
                if (!isset($idMapping[$file])) {
                    $idMapping[$file] = $nextId;
                    $nextId++;
                    $updated = true;
                }
                
                $scriptId = $idMapping[$file];
                $meta = isset($metadata[$scriptId]) ? $metadata[$scriptId] : [];
                
                $files[] = [
                    'id' => $scriptId,
                    'file' => $file,
                    'name' => isset($meta['name']) ? $meta['name'] : pathinfo($file, PATHINFO_FILENAME),
                    'topic' => isset($meta['topic']) ? $meta['topic'] : '',
                    'icon' => isset($meta['icon']) ? $meta['icon'] : 4,
                    'uploaded_by' => isset($meta['uploaded_by']) ? $meta['uploaded_by'] : 'Unknown',
                    'subscribers' => countSubscribers($scriptId),
                    'updated' => isset($meta['updated']) ? $meta['updated'] : date('M j Y', filemtime(PUN_ROOT.'luas/' . $file)),
                    'size' => filesize(PUN_ROOT.'luas/' . $file),
                    'modified' => filemtime(PUN_ROOT.'luas/' . $file)
                ];
            }
        }
        
        foreach ($idMapping as $file => $id) {
            if (!file_exists(PUN_ROOT.'luas/' . $file)) {
                unset($idMapping[$file]);
                $updated = true;
            }
        }
        
        if ($updated) {
            file_put_contents($idMappingFile, json_encode($idMapping, JSON_PRETTY_PRINT));
        }
        
        usort($files, function($a, $b) {
            return $a['id'] - $b['id'];
        });
    }
    return $files;
}

$luaFiles = getLuaFiles();

require PUN_ROOT.'header.php';

generate_admin_menu('lua_upload');
?>

<style>
/* VS Code-like Editor Overlay */
.editor-overlay {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.8);
    z-index: 9999;
    animation: fadeIn 0.2s ease;
}

.editor-overlay.active {
    display: flex;
    align-items: center;
    justify-content: center;
}

.editor-container {
    width: 90%;
    height: 90%;
    background: #1e1e1e;
    border-radius: 8px;
    overflow: hidden;
    display: flex;
    flex-direction: column;
    box-shadow: 0 10px 50px rgba(0, 0, 0, 0.5);
    animation: slideUp 0.3s ease;
}

.editor-header {
    background: #323233;
    padding: 12px 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-bottom: 1px solid #2d2d30;
}

.editor-title {
    color: #cccccc;
    font-size: 14px;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    display: flex;
    align-items: center;
    gap: 10px;
}

.editor-file-icon {
    color: #519aba;
    font-weight: bold;
}

.editor-actions {
    display: flex;
    gap: 10px;
}

.editor-btn {
    padding: 6px 16px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    font-size: 13px;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    transition: all 0.2s;
}

.editor-btn-save {
    background: #0e639c;
    color: white;
}

.editor-btn-save:hover {
    background: #1177bb;
}

.editor-btn-cancel {
    background: #3e3e42;
    color: #cccccc;
}

.editor-btn-cancel:hover {
    background: #505053;
}

.editor-body {
    flex: 1;
    display: flex;
    overflow: hidden;
    position: relative;
}

.editor-line-numbers {
    background: #1e1e1e;
    color: #858585;
    padding: 20px 15px 20px 10px;
    text-align: right;
    font-family: 'Consolas', 'Monaco', 'Courier New', monospace;
    font-size: 14px;
    line-height: 21px;
    user-select: none;
    border-right: 1px solid #2d2d30;
    overflow-y: hidden;
    overflow-x: hidden;
    white-space: pre;
    flex-shrink: 0;
}

.editor-content {
    flex: 1;
    position: relative;
    display: flex;
    min-width: 0;
    overflow: hidden;
}

.editor-textarea {
    flex: 1;
    min-width: 0;
    width: 100%;
    height: 100%;
    background: transparent;
    color: #d4d4d4;
    border: none;
    outline: none;
    padding: 20px;
    margin: 0;
    font-family: 'Consolas', 'Monaco', 'Courier New', monospace;
    font-size: 14px;
    line-height: 21px;
    resize: none;
    overflow-y: scroll;
    overflow-x: scroll;
    tab-size: 4;
    box-sizing: border-box;
    white-space: pre;
    position: absolute;
    top: 0;
    left: 0;
    z-index: 2;
    caret-color: #ffffff;
}

.editor-textarea::selection {
    background: #264f78;
}

.editor-highlight {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    padding: 20px;
    margin: 0;
    font-family: 'Consolas', 'Monaco', 'Courier New', monospace;
    font-size: 14px;
    line-height: 21px;
    white-space: pre;
    overflow: hidden;
    pointer-events: none;
    z-index: 1;
    color: transparent;
    box-sizing: border-box;
}

/* Lua Syntax Highlighting */
.lua-keyword { color: #569cd6; }
.lua-string { color: #ce9178; }
.lua-comment { color: #6a9955; font-style: italic; }
.lua-number { color: #b5cea8; }
.lua-function { color: #dcdcaa; }
.lua-boolean { color: #569cd6; }
.lua-nil { color: #569cd6; }
.lua-operator { color: #d4d4d4; }
.lua-builtin { color: #4ec9b0; }

.editor-footer {
    background: #007acc;
    padding: 6px 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    font-size: 12px;
    color: white;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
}

.editor-info {
    display: flex;
    gap: 20px;
}

/* Metadata Editor Styles */
.metadata-overlay {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.85);
    z-index: 9999;
    animation: fadeIn 0.2s ease;
}

.metadata-overlay.active {
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 40px 20px;
    overflow-y: auto;
}

.metadata-container {
    width: 100%;
    max-width: 1000px;
    animation: slideUp 0.3s ease;
    margin: auto;
}

.metadata-blockform {
    /* Uses existing blockform styles from PunBB */
}

.metadata-blockform h2 {
    margin-bottom: 0;
}

.metadata-script-info {
    background: #2E3338;
    padding: 10px 15px;
    border: 1px solid #ddd;
    border-top: none;
    font-size: 12px;
    color: #ccc;
}

.metadata-blockform .box {
    max-height: calc(90vh - 150px);
    overflow-y: auto;
}

.metadata-blockform textarea {
    width: 100%;
    font-family: 'Consolas', 'Monaco', 'Courier New', monospace;
}

.metadata-blockform textarea.large {
    height: 200px;
}

.metadata-buttons {
    background: #2E3338;
    padding: 10px 15px;
    border: 1px solid #ddd;
    border-top: none;
    text-align: right;
}

.metadata-buttons input,
.metadata-buttons button {
    margin-left: 8px;
}

.metadata-buttons .metadata-info {
    float: left;
    color: #ccc;
    font-size: 11px;
    line-height: 24px;
}

@keyframes fadeIn {
    from { opacity: 0; }
    to { opacity: 1; }
}

@keyframes slideUp {
    from { transform: translateY(30px); opacity: 0; }
    to { transform: translateY(0); opacity: 1; }
}

.edit-action {
    color: #0e639c;
    margin-right: 10px;
}

.edit-action:hover {
    color: #1177bb;
}

.delete-action {
    color: #c33;
}

.delete-action:hover {
    color: #e44;
}

.meta-action {
    color: #2d862d;
    margin-right: 10px;
}

.meta-action:hover {
    color: #3da03d;
}
</style>

<?php if ($editingMetadata): ?>
<!-- Metadata Editor Overlay -->
<div class="metadata-overlay active" id="metadataOverlay">
    <div class="metadata-container">
        <div class="blockform metadata-blockform">
            <h2><span>Edit Script Metadata</span></h2>
            <div class="metadata-script-info">
                Script ID: <strong><?php echo $editingMetadata['id']; ?></strong> | 
                File: <strong><?php echo pun_htmlspecialchars($editingMetadata['file']); ?></strong>
            </div>
            <div class="box">
                <form method="post" action="admin_upload.php" id="metadataForm">
                    <div class="inform">
                        <input type="hidden" name="csrf_token" value="<?php echo pun_csrf_token(); ?>">
                        <input type="hidden" name="script_id" value="<?php echo $editingMetadata['id']; ?>">
                        
                        <fieldset>
                            <legend>Basic Information</legend>
                            <div class="infldset">
                                <table class="aligntop">
                                    <tr>
                                        <th scope="row">Script Name:<span class="conr">*</span></th>
                                        <td>
                                            <input type="text" name="meta_name" size="70" maxlength="200" 
                                                   value="<?php echo pun_htmlspecialchars($editingMetadata['name']); ?>" required>
                                            <p><em>Display name shown in the workshop</em></p>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Topic/Description:</th>
                                        <td>
                                            <input type="text" name="meta_topic" size="70" maxlength="300" 
                                                   value="<?php echo pun_htmlspecialchars($editingMetadata['topic']); ?>">
                                            <p><em>Short description of what the script does</em></p>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Icon:</th>
                                        <td>
                                            <select name="meta_icon">
                                                <?php
                                                $icons = [
                                                    0 => 'Icon 0 (AA)',
                                                    1 => 'Icon 1 (LBOT)',
                                                    2 => 'Icon 2 (Lua)',
                                                    3 => 'Icon 3 (Misc)',
                                                    4 => 'Icon 4 (Lua - Default)',
                                                    5 => 'Icon 5 (Skins)',
                                                    6 => 'Icon 6 (Misc)',
                                                    7 => 'Icon 7 (Visuals)',
                                                    8 => 'Icon 8 (Library)'
                                                ];
                                                foreach ($icons as $value => $label) {
                                                    $selected = ($editingMetadata['icon'] == $value) ? ' selected' : '';
                                                    echo "<option value=\"{$value}\"{$selected}>{$label}</option>";
                                                }
                                                ?>
                                            </select>
                                            <p><em>Icon displayed in workshop</em></p>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Uploaded By:</th>
                                        <td>
                                            <input type="text" name="meta_uploaded_by" size="40" maxlength="100" 
                                                   value="<?php echo pun_htmlspecialchars($editingMetadata['uploaded_by']); ?>">
                                            <p><em>Author/uploader name</em></p>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Uploaded ID:</th>
                                        <td>
                                            <input type="text" name="meta_uploaded_id" size="20" maxlength="50" 
                                                   value="<?php echo pun_htmlspecialchars(isset($editingMetadata['uploaded_id']) ? $editingMetadata['uploaded_id'] : ''); ?>">
                                            <p><em>User ID of the uploader (optional)</em></p>
                                        </td>
                                    </tr>
                                </table>
                            </div>
                        </fieldset>
                        
                        <fieldset>
                            <legend>Settings</legend>
                            <div class="infldset">
                                <table class="aligntop">
                                    <tr>
                                        <th scope="row">Promoted:</th>
                                        <td>
                                            <input type="checkbox" name="meta_promoted" value="1"
                                                   <?php echo (isset($editingMetadata['promoted']) && $editingMetadata['promoted'] == '1') ? 'checked' : ''; ?>>
                                            <p><em>Mark this script as promoted/featured</em></p>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Preview:</th>
                                        <td>
                                            <textarea name="meta_preview" rows="4" cols="70"><?php echo pun_htmlspecialchars(isset($editingMetadata['preview']) ? $editingMetadata['preview'] : ''); ?></textarea>
                                            <p><em>Image preview of the script<br>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Closed Source:</th>
                                        <td>
                                            <input type="checkbox" name="meta_closed_source" value="1"
                                                   <?php echo (isset($editingMetadata['closed_source']) && $editingMetadata['closed_source'] == '1') ? 'checked' : ''; ?>>
                                            <p><em>Mark this script as closed source</em></p>
                                        </td>
                                    </tr>
                                </table>
                            </div>
                        </fieldset>
                        
                        <fieldset>
                            <legend>Additional Information</legend>
                            <div class="infldset">
                                <table class="aligntop">
                                    <tr>
                                        <th scope="row">Usage Instructions:</th>
                                        <td>
                                            <textarea name="meta_usage" rows="4" cols="70"><?php echo pun_htmlspecialchars(isset($editingMetadata['usage']) ? $editingMetadata['usage'] : ''); ?></textarea>
                                            <p><em>Instructions or links for using the script (supports HTML)<br>
                                            Example: &lt;a href="https://example.com/config" target="_blank"&gt;Download the default config&lt;/a&gt;</em></p>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Changelogs:</th>
                                        <td>
                                            <textarea name="meta_changelogs" rows="10" cols="70" class="large"><?php echo pun_htmlspecialchars(isset($editingMetadata['changelogs']) ? $editingMetadata['changelogs'] : ''); ?></textarea>
                                            <p><em>Version history and changes (use plain text, line breaks preserved)<br>
                                            Format example:<br>
                                            update DD.MM.YYYY<br>
                                            - feature added<br>
                                            - bug fixed<br>
                                            <br>
                                            published DD.MM.YYYY<br>
                                            - initial release</em></p>
                                        </td>
                                    </tr>
                                </table>
                            </div>
                        </fieldset>
                    </div>
                </form>
            </div>
            <div class="metadata-buttons">
                <div class="metadata-info">
                    Last updated: <strong><?php echo $editingMetadata['updated']; ?></strong> | 
                    Will be automatically updated to current date when saved
                </div>
                <input type="button" value="Cancel" onclick="closeMetadataEditor()">
                <input type="submit" name="edit_metadata" value="Save Metadata" onclick="document.getElementById('metadataForm').submit(); return false;">
            </div>
        </div>
    </div>
</div>

<script>
function closeMetadataEditor() {
    if (confirm('Close metadata editor without saving changes?')) {
        window.location.href = 'admin_upload.php';
    }
}

// Keyboard shortcut: Ctrl+S to save
document.addEventListener('keydown', function(e) {
    if (e.ctrlKey && e.key === 's') {
        e.preventDefault();
        document.getElementById('metadataForm').submit();
    }
});
</script>
                                   maxlength="100">
                            <span class="field-hint">Author/uploader name</span>
                        </div>
                    </div>
                    
                    <div class="metadata-field">
                        <label for="meta_uploaded_id">Uploaded ID</label>
                        <input type="text" id="meta_uploaded_id" name="meta_uploaded_id" 
                               value="<?php echo pun_htmlspecialchars(isset($editingMetadata['uploaded_id']) ? $editingMetadata['uploaded_id'] : ''); ?>" 
                               maxlength="50">
                        <span class="field-hint">User ID of the uploader (optional)</span>
                    </div>
                </div>
                
                <!-- Settings Section -->
                <div class="metadata-section">
                    <h3>Settings</h3>
                    
                    <div class="metadata-field">
                        <div class="checkbox-wrapper">
                            <input type="checkbox" id="meta_promoted" name="meta_promoted" value="1"
                                   <?php echo (isset($editingMetadata['promoted']) && $editingMetadata['promoted'] == '1') ? 'checked' : ''; ?>>
                            <label for="meta_promoted" class="checkbox-label">
                                <strong>Promoted</strong> - Mark this script as promoted/featured
                            </label>
                        </div>
                    </div>
                    
                    <div class="metadata-field">
                        <div class="checkbox-wrapper">
                            <input type="checkbox" id="meta_closed_source" name="meta_closed_source" value="1"
                                   <?php echo (isset($editingMetadata['closed_source']) && $editingMetadata['closed_source'] == '1') ? 'checked' : ''; ?>>
                            <label for="meta_closed_source" class="checkbox-label">
                                <strong>Closed Source</strong> - Mark this script as closed source
                            </label>
                        </div>
                    </div>
                </div>
                
                <!-- Additional Information Section -->
                <div class="metadata-section">
                    <h3>Additional Information</h3>
                    
                    <div class="metadata-field">
                        <label for="meta_usage">Usage Instructions (HTML allowed)</label>
                        <textarea id="meta_usage" name="meta_usage" 
                                  placeholder="e.g., <a href=&quot;https://example.com/config&quot; target=&quot;_blank&quot;>Download the default config</a>"><?php echo pun_htmlspecialchars(isset($editingMetadata['usage']) ? $editingMetadata['usage'] : ''); ?></textarea>
                        <span class="field-hint">Instructions or links for using the script (supports HTML)</span>
                    </div>
                    
                    <div class="metadata-field">
                        <label for="meta_changelogs">Changelogs</label>
                        <textarea id="meta_changelogs" name="meta_changelogs" class="large" 
                                  placeholder="update DD.MM.YYYY&#10;- feature added&#10;- bug fixed&#10;&#10;published DD.MM.YYYY&#10;- initial release"><?php echo pun_htmlspecialchars(isset($editingMetadata['changelogs']) ? $editingMetadata['changelogs'] : ''); ?></textarea>
                        <span class="field-hint">Version history and changes (use plain text, line breaks preserved)</span>
                    </div>
                </div>
            </div>
            
            <div class="metadata-footer">
                <div class="metadata-footer-left">
                    Last updated: <strong><?php echo $editingMetadata['updated']; ?></strong>
                    <br>
                    <small>Will be automatically updated to current date when saved</small>
                </div>
                <div class="metadata-footer-right">
                    <button type="button" class="editor-btn editor-btn-cancel" onclick="closeMetadataEditor()">
                        Cancel
                    </button>
                    <button type="submit" name="edit_metadata" class="editor-btn editor-btn-save">
                        Save Metadata
                    </button>
                </div>
            </div>
        </form>
    </div>
</div>

<script>
function closeMetadataEditor() {
    if (confirm('Close metadata editor without saving changes?')) {
        window.location.href = 'admin_upload.php';
    }
}

// Keyboard shortcut: Ctrl+S to save
document.addEventListener('keydown', function(e) {
    if (e.ctrlKey && e.key === 's') {
        e.preventDefault();
        document.getElementById('metadataForm').submit();
    }
});
</script>
<?php endif; ?>

<?php if ($editingFile): ?>
<!-- Code Editor Overlay -->
<div class="editor-overlay active" id="editorOverlay">
    <div class="editor-container">
        <div class="editor-header">
            <div class="editor-title">
                <span class="editor-file-icon">📄</span>
                <span>Editing: <?php echo pun_htmlspecialchars($editingFile); ?></span>
            </div>
            <div class="editor-actions">
                <button class="editor-btn editor-btn-save" onclick="document.getElementById('editForm').submit()">
                    Save Changes
                </button>
                <button class="editor-btn editor-btn-cancel" onclick="closeEditor()">
                    Cancel
                </button>
            </div>
        </div>
        <div class="editor-body">
            <div class="editor-line-numbers" id="lineNumbers"></div>
            <form method="post" action="admin_upload.php" id="editForm" style="flex: 1; display: flex; min-width: 0;">
                <input type="hidden" name="csrf_token" value="<?php echo pun_csrf_token(); ?>">
                <input type="hidden" name="file" value="<?php echo pun_htmlspecialchars($editingFile); ?>">
                <div class="editor-content">
                    <div class="editor-highlight" id="highlighted"></div>
                    <textarea 
                        class="editor-textarea" 
                        name="lua_content" 
                        id="luaEditor"
                        spellcheck="false"
                        wrap="off"
                    ><?php echo pun_htmlspecialchars($editingContent); ?></textarea>
                </div>
                <input type="hidden" name="edit_save" value="1">
            </form>
        </div>
        <div class="editor-footer">
            <div class="editor-info">
                <span>Lua</span>
                <span>UTF-8</span>
                <span id="editorStats">Lines: 1 | Chars: 0</span>
            </div>
            <div>
                <span>Press Ctrl+S to save</span>
            </div>
        </div>
    </div>
</div>

<script>
function escapeHtml(text) {
    const map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
    };
    return text.replace(/[&<>"']/g, m => map[m]);
}

function highlightLua(code) {
    const keywords = /\b(and|break|do|else|elseif|end|false|for|function|if|in|local|nil|not|or|repeat|return|then|true|until|while)\b/g;
    const builtins = /\b(print|assert|error|pcall|xpcall|type|tonumber|tostring|pairs|ipairs|next|select|getmetatable|setmetatable|rawget|rawset|rawequal|require|table|string|math|io|os|debug|coroutine|package|bit|collectgarbage|dofile|loadfile|load|loadstring)\b/g;
    
    let highlighted = code;
    
    highlighted = highlighted.replace(/-{2}\[\[[\s\S]*?\]\]/g, match => {
        return `<span class="lua-comment">${escapeHtml(match)}</span>`;
    });
    
    highlighted = highlighted.replace(/--(?!\[\[)[^\n]*/g, match => {
        return `<span class="lua-comment">${escapeHtml(match)}</span>`;
    });
    
    highlighted = highlighted.replace(/"(?:[^"\\]|\\.)*"|'(?:[^'\\]|\\.)*'|\[\[[\s\S]*?\]\]/g, match => {
        if (match.includes('<span')) return match;
        return `<span class="lua-string">${escapeHtml(match)}</span>`;
    });
    
    highlighted = highlighted.replace(/\b\d+\.?\d*\b/g, match => {
        if (match.match(/^<span/)) return match;
        return `<span class="lua-number">${match}</span>`;
    });
    
    highlighted = highlighted.replace(keywords, match => {
        if (match.match(/^<span/)) return match;
        return `<span class="lua-keyword">${match}</span>`;
    });
    
    highlighted = highlighted.replace(builtins, match => {
        if (match.match(/^<span/)) return match;
        return `<span class="lua-builtin">${match}</span>`;
    });
    
    highlighted = highlighted.replace(/function\s+([a-zA-Z_][a-zA-Z0-9_:.]*)/g, (match, funcName) => {
        if (match.includes('<span')) return match;
        return `<span class="lua-keyword">function</span> <span class="lua-function">${funcName}</span>`;
    });
    
    return highlighted;
}

function updateHighlighting() {
    const textarea = document.getElementById('luaEditor');
    const highlighted = document.getElementById('highlighted');
    const code = textarea.value;
    
    highlighted.innerHTML = highlightLua(escapeHtml(code));
}

function syncScroll() {
    const textarea = document.getElementById('luaEditor');
    const highlighted = document.getElementById('highlighted');
    const lineNumbers = document.getElementById('lineNumbers');
    
    highlighted.scrollTop = textarea.scrollTop;
    highlighted.scrollLeft = textarea.scrollLeft;
    lineNumbers.scrollTop = textarea.scrollTop;
}

function updateLineNumbers() {
    const textarea = document.getElementById('luaEditor');
    const lineNumbers = document.getElementById('lineNumbers');
    const lines = textarea.value.split('\n').length;
    
    let numbers = '';
    for (let i = 1; i <= lines; i++) {
        numbers += i + '\n';
    }
    lineNumbers.textContent = numbers;
    
    const stats = document.getElementById('editorStats');
    const chars = textarea.value.length;
    stats.textContent = `Lines: ${lines} | Chars: ${chars}`;
}

function closeEditor() {
    if (confirm('Close editor without saving changes?')) {
        window.location.href = 'admin_upload.php';
    }
}

document.addEventListener('DOMContentLoaded', function() {
    const textarea = document.getElementById('luaEditor');
    
    updateLineNumbers();
    updateHighlighting();
    
    textarea.addEventListener('input', function() {
        updateLineNumbers();
        updateHighlighting();
    });
    
    textarea.addEventListener('scroll', syncScroll);
    
    textarea.addEventListener('keydown', function(e) {
        if (e.ctrlKey && e.key === 's') {
            e.preventDefault();
            document.getElementById('editForm').submit();
        }
        
        if (e.key === 'Tab') {
            e.preventDefault();
            const start = this.selectionStart;
            const end = this.selectionEnd;
            this.value = this.value.substring(0, start) + '    ' + this.value.substring(end);
            this.selectionStart = this.selectionEnd = start + 4;
            updateLineNumbers();
            updateHighlighting();
        }
    });
});
</script>
<?php endif; ?>

<div class="blockform">
    <h2><span>Upload New Lua Script</span></h2>
    <div class="box">
        <form method="post" enctype="multipart/form-data" action="admin_upload.php">
            <div class="inform">
                <input type="hidden" name="csrf_token" value="<?php echo pun_csrf_token(); ?>">
                
                <?php if (isset($uploadSuccess)): ?>
                <div class="infldset">
                    <p style="color: green; font-weight: bold;"><?php echo pun_htmlspecialchars($uploadSuccess); ?></p>
                </div>
                <?php endif; ?>
                
                <?php if (isset($uploadError)): ?>
                <div class="infldset">
                    <p style="color: red; font-weight: bold;"><?php echo pun_htmlspecialchars($uploadError); ?></p>
                </div>
                <?php endif; ?>
                
                <fieldset>
                    <legend>Upload Lua File</legend>
                    <div class="infldset">
                        <table class="aligntop">
                            <tr>
                                <th scope="row">Script Name:<span class="conr">*</span></th>
                                <td>
                                    <input type="text" name="script_name" size="50" maxlength="100" required>
                                    <p><em>Display name for the script (e.g., "Helper V3 - Grenades, Movement")</em></p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">Topic/Description:</th>
                                <td>
                                    <input type="text" name="script_topic" size="70" maxlength="200">
                                    <p><em>Short description (e.g., "Makes it easy to throw perfect grenades")</em></p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">Icon:</th>
                                <td>
                                    <select name="script_icon">
                                        <option value="0">Icon 0 (AA)</option>
                                        <option value="1">Icon 1 (LBOT)</option>
                                        <option value="2">Icon 2 (Lua)</option>
                                        <option value="3">Icon 3 (Misc)</option>
                                        <option value="4" selected>Icon 4 (Lua - Default)</option>
                                        <option value="5">Icon 5 (Skins)</option>
                                        <option value="6">Icon 6 (Misc)</option>
                                        <option value="7">Icon 7 (Visuals)</option>
                                        <option value="8">Icon 8 (Library)</option>
                                    </select>
                                    <p><em>Select the icon to display in the workshop</em></p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">Uploaded By:</th>
                                <td>
                                    <input type="text" name="uploaded_by" size="30" maxlength="50" placeholder="<?php echo pun_htmlspecialchars($pun_user['username']); ?>">
                                    <p><em>Author/uploader name (defaults to your username if left empty)</em></p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">Select Lua file:<span class="conr">*</span></th>
                                <td>
                                    <input type="file" name="lua_file" accept=".lua" required>
                                    <p><em>Maximum file size: 5MB | Allowed format: .lua only</em></p>
                                </td>
                            </tr>
                        </table>
                    </div>
                </fieldset>
            </div>
            <p class="buttons"><input type="submit" name="upload" value="Upload Lua Script"></p>
        </form>
    </div>
</div>

<div class="block">
    <h2 class="block2"><span>Lua Scripts (<?php echo count($luaFiles); ?>)</span></h2>
    <div id="adintro" class="box">
        <div class="inbox">
            <?php if (empty($luaFiles)): ?>
                <p style="text-align: center; color: #999; font-style: italic; padding: 30px;">No Lua scripts uploaded yet</p>
            <?php else: ?>
                <table cellspacing="0">
                    <thead>
                        <tr>
                            <th class="tc3" scope="col">ID</th>
                            <th class="tc3" scope="col">Icon</th>
                            <th class="tcl" scope="col">Name</th>
                            <th class="tcl" scope="col">Topic</th>
                            <th class="tc3" scope="col">Uploaded By</th>
                            <th class="tc3" scope="col">Subscribers</th>
                            <th class="tc3" scope="col">Updated</th>
                            <th class="tcr" scope="col">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $row_class = 'rowodd';
                        foreach ($luaFiles as $file): 
                        ?>
                        <tr class="<?php echo $row_class; ?>">
                            <td class="tc3"><strong><?php echo $file['id']; ?></strong></td>
                            <td class="tc3"><img src="icons/cat_<?php echo ['aa', 'lbot', 'lua', 'misc', 'lua', 'skins', 'misc', 'vis', 'lib'][$file['icon']]; ?>.png" width="24" height="24" alt="Icon"></td>
                            <td class="tcl"><?php echo pun_htmlspecialchars($file['name']); ?></td>
                            <td class="tcl"><em><?php echo pun_htmlspecialchars($file['topic']); ?></em></td>
                            <td class="tc3"><?php echo pun_htmlspecialchars(isset($file['uploaded_by']) ? $file['uploaded_by'] : 'Unknown'); ?></td>
                            <td class="tc3"><?php echo $file['subscribers']; ?></td>
                            <td class="tc3"><?php echo $file['updated']; ?></td>
                            <td class="tcr">
                                <a href="admin_upload.php?action=edit_meta&id=<?php echo $file['id']; ?>" 
                                   class="meta-action" title="Edit Metadata">Metadata</a>
                                <a href="admin_upload.php?action=edit&file=<?php echo urlencode($file['file']); ?>" 
                                   class="edit-action" title="Edit Code">Edit</a>
                                <a href="admin_upload.php?action=delete&file=<?php echo urlencode($file['file']); ?>&csrf_token=<?php echo pun_csrf_token(); ?>" 
                                   onclick="return confirm('Are you sure you want to delete this file? This will also remove it from all user subscriptions.');" 
                                   class="delete-action">Delete</a>
                            </td>
                        </tr>
                        <?php 
                        $row_class = ($row_class == 'rowodd') ? 'roweven' : 'rowodd';
                        endforeach; 
                        ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
    </div>
    <div class="clearer"></div>
</div>

<?php
require PUN_ROOT.'footer.php';
?>