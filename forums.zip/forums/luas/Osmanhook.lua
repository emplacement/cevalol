_NAME = nil
getfenv(1)._NAME = nil
local _BETA = true
local _USER = _BETA and "admin" or panorama.open("CSGOHud").MyPersonaAPI.GetName()
local _VER = 297

--region @import
local ffi = require("ffi")
local vector = require("vector")
local base64 = require("gamesense/base64")
local http = require("gamesense/http")
local inspect = require("gamesense/inspect")
local c_entity = require("gamesense/entity")
local csgo_weapons = require("gamesense/csgo_weapons")
local clipboard = require("gamesense/clipboard")
local afunc = require("gamesense/antiaim_funcs")
local images = require("gamesense/images")
 local clip = require("gamesense/clipboard")
 --region @import end

--region @vtable
local native_GetClientEntity = vtable_bind('client.dll', 'VClientEntityList003', 3, 'void*(__thiscall*)(void*, int)')
local native_GetClientEntity1 = vtable_bind("client_panorama.dll", "VClientEntityList003", 3, "void*(__thiscall*)(void*,int)")
-- Helper function to safely get native function pointer
local function safe_get_native(ctype, module, signature)
    local addr = client.find_signature(module, signature)
    if addr then
        return ffi.cast(ctype, addr)
    end
    return nil
end

local native_GetSequenceActivity = safe_get_native("int(__thiscall*)(void*, int)", "client.dll", "\x55\x8B\xEC\x53\x8B\x5D\x08\x56\x8B\xF1\x83")
local native_IsWeapon = vtable_thunk(166, "bool(__thiscall*)(void*)")
local native_GetInaccuracy = vtable_thunk(483, "float(__thiscall*)(void*)")
local native_CreateFont = vtable_bind("vguimatsurface.dll", "VGUI_Surface031", 71, "unsigned int(__thiscall*)(void*)")
local native_SetGlyph = vtable_bind("vguimatsurface.dll", "VGUI_Surface031", 72, "bool(__thiscall*)(void*, unsigned long, const char*, int, int, int, int, unsigned long, int, int)")
local native_DrawText = vtable_bind("vguimatsurface.dll", "VGUI_Surface031", 163, "void(__stdcall*)(void*, unsigned int, int, int, int, int, int, int, const char*, ...)")

local native_GetBoneMatrix = safe_get_native("void*(__thiscall*)(void*, int)", "client.dll", "\x55\x8B\xEC\x83\xE4\xF0\xB8\xD8\x15\x00\x00\x53\x56\x8B\xF1")
local native_GetPlayerAnimState = safe_get_native("void*(__thiscall*)(void*)", "client.dll", "\x8B\x91\x00\x00\x00\x00\x85\xD2\x74\x10")
local native_GetAnimationLayer = safe_get_native("void*(__thiscall*)(void*, int)", "client.dll", "\x55\x8B\xEC\x51\x53\x56\x57\x8B\xF9\x8B\xB7")
local native_GetNetworkable = safe_get_native("void*(__thiscall*)(void*)", "client.dll", "\x55\x8B\xEC\x8B\x45\x08\x8B\x00\x8B\x80")
local native_GetServerAnimating = safe_get_native("void*(__thiscall*)(void*)", "client.dll", "\x55\x8B\xEC\x8B\x45\x08\x8B\x00\x8B\x80")
local native_GetModelPtr = safe_get_native("void*(__thiscall*)(void*)", "client.dll", "\x55\x8B\xEC\x8B\x45\x08\x8B\x00\x8B\x80")
local native_GetStudioHdr = safe_get_native("void*(__thiscall*)(void*)", "client.dll", "\x55\x8B\xEC\x8B\x45\x08\x8B\x00\x8B\x80")
local native_ReadMemory = safe_get_native("int(__cdecl*)(void*, void*, int)", "kernel32.dll", "\x55\x8B\xEC\x8B\x45\x08\x8B\x4D\x0C\x8B\x55\x10")
local native_WriteMemory = safe_get_native("bool(__cdecl*)(void*, void*, int)", "kernel32.dll", "\x55\x8B\xEC\x8B\x45\x08\x8B\x4D\x0C\x8B\x55\x10")
local native_ProtectMemory = safe_get_native("bool(__cdecl*)(void*, int, int, int*)", "kernel32.dll", "\x55\x8B\xEC\x8B\x45\x08\x8B\x4D\x0C\x8B\x55\x10")
local native_GetNetworkChannel = safe_get_native("void*(__thiscall*)(void*)", "engine.dll", "\x55\x8B\xEC\x8B\x45\x08\x8B\x00\x8B\x80")
local native_GetLatency = safe_get_native("float(__thiscall*)(void*, int)", "engine.dll", "\x55\x8B\xEC\x8B\x45\x08\x8B\x4D\x0C\xD9\x40")
local native_GetPacketLoss = safe_get_native("float(__thiscall*)(void*)", "engine.dll", "\x55\x8B\xEC\x8B\x45\x08\x8B\x00\x8B\x80")
local native_GetTickBase = safe_get_native("int(__thiscall*)(void*)", "client.dll", "\x55\x8B\xEC\x8B\x45\x08\x8B\x00\x8B\x80")
local native_SetTickBase = safe_get_native("void(__thiscall*)(void*, int)", "client.dll", "\x55\x8B\xEC\x8B\x45\x08\x8B\x4D\x0C\x89\x80")
local native_GetSimulationTime = safe_get_native("float(__thiscall*)(void*)", "client.dll", "\x55\x8B\xEC\x8B\x45\x08\x8B\x00\x8B\x80")
local native_SetSimulationTime = safe_get_native("void(__thiscall*)(void*, float)", "client.dll", "\x55\x8B\xEC\x8B\x45\x08\xD9\x45\x0C\xD9\x98")
local native_GetEyeAngles = safe_get_native("void*(__thiscall*)(void*)", "client.dll", "\x55\x8B\xEC\x8B\x45\x08\x8B\x00\x8B\x80")
local native_SetEyeAngles = safe_get_native("void(__thiscall*)(void*, void*)", "client.dll", "\x55\x8B\xEC\x8B\x45\x08\x8B\x4D\x0C\x89\x80")
local native_GetAbsOrigin = safe_get_native("void*(__thiscall*)(void*)", "client.dll", "\x55\x8B\xEC\x8B\x45\x08\x8B\x00\x8B\x80")
local native_SetAbsOrigin = safe_get_native("void(__thiscall*)(void*, void*)", "client.dll", "\x55\x8B\xEC\x8B\x45\x08\x8B\x4D\x0C\x89\x80")

--region @vtable end

--region @animstate
local animstate_t = ffi.typeof 'struct { int layer_order_preset; bool first_run_since_init; bool first_foot_plant_since_init; int last_update_tick; float eye_position_smooth_lerp; float strafe_change_weight_smooth_fall_off; float stand_walk_duration_state_has_been_valid; float stand_walk_duration_state_has_been_invalid; float stand_walk_how_long_to_wait_until_transition_can_blend_in; float stand_walk_how_long_to_wait_until_transition_can_blend_out; float stand_walk_blend_value; float stand_run_duration_state_has_been_valid; float stand_run_duration_state_has_been_invalid; float stand_run_how_long_to_wait_until_transition_can_blend_in; float stand_run_how_long_to_wait_until_transition_can_blend_out; float stand_run_blend_value; float crouch_walk_duration_state_has_been_valid; float crouch_walk_duration_state_has_been_invalid; float crouch_walk_how_long_to_wait_until_transition_can_blend_in; float crouch_walk_how_long_to_wait_until_transition_can_blend_out; float crouch_walk_blend_value; int cached_model_index; float step_height_left; float step_height_right; void* weapon_last_bone_setup; void* player; void* weapon; void* weapon_last; float last_update_time; int last_update_frame; float last_update_increment; float eye_yaw; float eye_pitch; float abs_yaw; float abs_yaw_last; float move_yaw; float move_yaw_ideal; float move_yaw_current_to_ideal; char pad1[4]; float primary_cycle; float move_weight; float move_weight_smoothed; float anim_duck_amount; float duck_additional; float recrouch_weight; float position_current[3]; float position_last[3]; float velocity[3]; float velocity_normalized[3]; float velocity_normalized_non_zero[3]; float velocity_length_xy; float velocity_length_z; float speed_as_portion_of_run_top_speed; float speed_as_portion_of_walk_top_speed; float speed_as_portion_of_crouch_top_speed; float duration_moving; float duration_still; bool on_ground; bool landing; float jump_to_fall; float duration_in_air; float left_ground_height; float land_anim_multiplier; float walk_run_transition; bool landed_on_ground_this_frame; bool left_the_ground_this_frame; float in_air_smooth_value; bool on_ladder; float ladder_weight; float ladder_speed; bool walk_to_run_transition_state; bool defuse_started; bool plant_anim_started; bool twitch_anim_started; bool adjust_started; char activity_modifiers_server[20]; float next_twitch_time; float time_of_last_known_injury; float last_velocity_test_time; float velocity_last[3]; float target_acceleration[3]; float acceleration[3]; float acceleration_weight; float aim_matrix_transition; float aim_matrix_transition_delay; bool flashed; float strafe_change_weight; float strafe_change_target_weight; float strafe_change_cycle; int strafe_sequence; bool strafe_changing; float duration_strafing; float foot_lerp; bool feet_crossed; bool player_is_accelerating; char pad2[24]; float duration_move_weight_is_too_high; float static_approach_speed; int previous_move_state; float stutter_step; float action_weight_bias_remainder; char pad3[112]; float camera_smooth_height; bool smooth_height_valid; float last_time_velocity_over_ten; float unk; float aim_yaw_min; float aim_yaw_max; float aim_pitch_min; float aim_pitch_max; int animstate_model_version; } **'

local matrix3x4_t = ffi.typeof("struct { float m_flMatVal[3][4]; }")
local vector3_t = ffi.typeof("struct { float x, y, z; }")
local quaternion_t = ffi.typeof("struct { float x, y, z, w; }")
local animation_layer_t = ffi.typeof("struct { void* pStudioHdr; int nSequence; float flPrevCycle; float flWeight; float flWeightDeltaRate; float flPlaybackRate; float flCycle; void* pOwner; int nOrder; }")
local network_var_t = ffi.typeof("struct { int m_nTick; int m_nNewTick; bool m_bNetworked; }")

local get_animstate = function(ent)
    if not ent then return false end
    local address = type(ent) == "cdata" and ent or native_GetClientEntity(ent)
    if not address or address == ffi.NULL then return false end
    local address_vtable = ffi.cast("void***", address)
    return ffi.cast(animstate_t, ffi.cast("char*", address_vtable) + 0x9960)[0]
end

local advanced_ffi = {}

advanced_ffi.get_bone_matrix = function(ent, bone_id)
    if not ent or not native_GetBoneMatrix then return nil end
    local address = type(ent) == "cdata" and ent or native_GetClientEntity(ent)
    if not address or address == ffi.NULL then return nil end
    local matrix_ptr = native_GetBoneMatrix(address, bone_id)
    if matrix_ptr and matrix_ptr ~= ffi.NULL then
        return ffi.cast(matrix3x4_t, matrix_ptr)
    end
    return nil
end

advanced_ffi.get_animation_layers = function(ent)
    if not ent or not native_GetAnimationLayer then return nil end
    local address = type(ent) == "cdata" and ent or native_GetClientEntity(ent)
    if not address or address == ffi.NULL then return nil end
    local layers = {}
    for i = 0, 12 do
        local layer = native_GetAnimationLayer(address, i)
        if layer and layer ~= ffi.NULL then
            layers[i] = ffi.cast(animation_layer_t, layer)
        end
    end
    return layers
end

advanced_ffi.get_network_data = function(ent)
    if not ent or not native_GetNetworkable then return nil end
    local address = type(ent) == "cdata" and ent or native_GetClientEntity(ent)
    if not address or address == ffi.NULL then return nil end
    local networkable = native_GetNetworkable(address)
    if not networkable or networkable == ffi.NULL then return nil end
    return ffi.cast(network_var_t, ffi.cast("char*", networkable) + 0x8)
end

advanced_ffi.read_memory_safe = function(address, size)
    if not address or address == ffi.NULL or not native_ProtectMemory or not native_ReadMemory then return nil end
    local buffer = ffi.new("char[?]", size)
    local old_protect = ffi.new("int[1]")
    if native_ProtectMemory(address, size, 0x40, old_protect) then
        local result = native_ReadMemory(address, buffer, size)
        native_ProtectMemory(address, size, old_protect[0], ffi.NULL)
        return buffer
    end
    return nil
end

advanced_ffi.write_memory_safe = function(address, data, size)
    if not address or address == ffi.NULL or not native_ProtectMemory or not native_WriteMemory then return false end
    local old_protect = ffi.new("int[1]")
    if native_ProtectMemory(address, size, 0x40, old_protect) then
        local result = native_WriteMemory(address, data, size)
        native_ProtectMemory(address, size, old_protect[0], ffi.NULL)
        return result
    end
    return false
end

advanced_ffi.get_lag_compensation = function(ent)
    if not ent or not native_GetNetworkable or not native_GetNetworkChannel or not native_GetLatency or not native_GetPacketLoss then return nil end
    local address = type(ent) == "cdata" and ent or native_GetClientEntity(ent)
    if not address or address == ffi.NULL then return nil end
    local networkable = native_GetNetworkable(address)
    if not networkable or networkable == ffi.NULL then return nil end
    local channel = native_GetNetworkChannel(networkable)
    if not channel or channel == ffi.NULL then return nil end
    return {
        latency = native_GetLatency(channel, 0),
        packet_loss = native_GetPacketLoss(channel)
    }
end

advanced_ffi.manipulate_tick = function(ent, new_tick)
    if not ent or not native_SetTickBase then return false end
    local address = type(ent) == "cdata" and ent or native_GetClientEntity(ent)
    if not address or address == ffi.NULL then return false end
    native_SetTickBase(address, new_tick)
    return true
end

advanced_ffi.get_eye_angles_raw = function(ent)
    if not ent or not native_GetEyeAngles then return nil end
    local address = type(ent) == "cdata" and ent or native_GetClientEntity(ent)
    if not address or address == ffi.NULL then return nil end
    return native_GetEyeAngles(address)
end

advanced_ffi.set_eye_angles_raw = function(ent, angles)
    if not ent or not angles or not native_SetEyeAngles then return false end
    local address = type(ent) == "cdata" and ent or native_GetClientEntity(ent)
    if not address or address == ffi.NULL then return false end
    native_SetEyeAngles(address, angles)
    return true
end
--region @animstate end

--region @говнокода
local utils, colors, cfg, misc, visuals, antiaims, rage, logs, indicate, cvardef, hide, ticks, hitlogger = {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}

--region @utils
utils.max = function(var1, var2, mode, specialsvalue)
    local md1, md2;
    if specialsvalue then
        md1 = mode(specialsvalue, var1)
        md2 = mode(specialsvalue, var2)
    else
        md1 = mode(var1)
        md2 = mode(var2)
    end
    return math.max(md1, md2) == md1 and var1 or var2
end
utils.distance = function(origin1, origin2)
    return math.sqrt((origin2.x - origin1.x)^2 + (origin2.y - origin1.y)^2) -- d=√((x_2-x_1)²+(y_2-y_1)²)
end
utils.vecsum = function(vec1, vec2)
    return { vec1[1] + vec2[1], vec1[2] + vec2[2], vec1[3] + vec2[3] }
end
utils.handle_mouse = function()
    if not ui.is_menu_open() then return end
    oldcursor = cursor or {0, 0}
    cursor = {ui.mouse_position()}
    oldclick = clicked
    clicked = client.key_state(0x01)
    firstclick = clicked and not oldclick
end
utils.create_font = function(fontname, height, width, blur, flags)
    if type(flags) ~= "number" and type(flags) ~= "table" then return client.error_log("flags must be number or table type") end
    local fflags = 0
    if type(flags) == "table" then 
        for _, v in pairs(flags) do
            fflags = fflags + v
        end
    else
        fflags = flags
    end
    local font_handler = native_CreateFont()
    native_SetGlyph(font_handler, fontname, height, width, blur, 0, fflags, 0, 0)
    return font_handler
end
utils.clamp = function(number, min, max)
	if number < min then
		return min
	elseif number > max then
		return max    
	end
	return number
end
utils.lerp = function(start, end_pos, time, ampl)
    if start == end_pos then return end_pos end
    ampl = ampl or math.min(40, 1/globals.frametime())
    local frametime = globals.frametime() * ampl
    time = time * frametime
    local val = start + (end_pos - start) * time
    if(math.abs(val - end_pos) < 0.01) then return end_pos end
    return val 
end
utils.in_table = function(tbl, val, key)
    for k, v in pairs(tbl) do
        if key and k == val then return true end
        if not key and v == val then return true end
    end
    return false
end
utils.table_index = function(tbl, val)
    for k, v in ipairs(tbl) do
        if v == val then
            return k
        end
    end
    return nil
end
utils.round = function(num, decimals)
    decimals = math.pow(10, decimals or 0)
    num = num * decimals
    if num >= 0 then num = math.floor(num + 0.5) else num = math.ceil(num - 0.5) end
    return num / decimals
end
utils.menu_col =  function()
    return {ui.get(ui.reference("Misc", "Settings", "Menu color"))}
end
utils.get_screen = function()
    local screen_width, screen_height = client.screen_size()
    return {
        x = screen_width,
        y = screen_height
    }
end

local screen = utils.get_screen()
local g = {10, 10, 10}
local a = {60, 60, 60}
local b = {40, 40, 40}
local l = {20, 20, 20}
local g1 = {100, 150, 200} 
local g2 = {180, 100, 160}
local g3 = {180, 230, 100}
local B="\x14\x14\x14\xFF"
local C="\x0c\x0c\x0c\xFF"
local jg = renderer.load_rgba(table.concat({B,B,B,C,B,C,B,C,B,C,B,B,B,C,B,C}),4,4)
colors.white = {255, 255, 255, 255}
colors.red = {255, 0, 0, 255}
colors.gray = {200, 200, 200, 255}
colors.dark_gray = {92, 92, 92, 255}
colors.green = {0, 255, 0, 255}
colors.skeet_logs = {159, 202, 43, 255}
utils.logoc = utils.menu_col()
utils.logoh = string.format('\a%02x%02x%02xFF', utils.logoc[1], utils.logoc[2], utils.logoc[3])
utils.printr = function(color, ...)
    client.color_log(color[1], color[2], color[3], "osmanhook\0")
    client.color_log(colors.dark_gray[1], colors.dark_gray[2], colors.dark_gray[3], ": \0")
    client.color_log(color[1], color[2], color[3], string.format(...))
end
utils.fade_anim = function(speed, color1, color2, text)
    local final_text = ''
    local curtime = globals.curtime()

    for i = 0, #text do
        local x_offset = i * 10
        local wave = math.cos(8 * speed * curtime + x_offset / 30)
        local color = string.format('%02x%02x%02x%02x',
            utils.lerp(color1[1], color2[1], utils.clamp(wave, 0, 1)),
            utils.lerp(color1[2], color2[2], utils.clamp(wave, 0, 1)),
            utils.lerp(color1[3], color2[3], utils.clamp(wave, 0, 1)),
            color1[4]
        )
        final_text = final_text .. '\a' .. color .. text:sub(i, i)
    end
    return final_text
end
utils.get_table = function(tabl)
    if type(tabl) == "number" and ui.type(tabl) ~= "button" and ui.type(tabl) ~= "textbox" and ui.type(tabl) ~= "listbox" then
      if ui.type(tabl) == "color_picker" or ui.type(tabl) == "hotkey" then
        return {ui.get(tabl)}
      else
        return ui.get(tabl)
      end
    elseif type(tabl) == "table" then
        local gtlv = {}
        for key, val in pairs(tabl) do
            gtlv[key] = utils.get_table(val)
        end
        return gtlv
    end
end

antiaims.point_to_enemy_enforce = function(cmd)
    if not antiaims.point_at_enemy_180_active then return end
    local lplayer = entity.get_local_player()
    if lplayer == nil or not entity.is_alive(lplayer) then return end
    local target_idx = antiaims.target or client.current_threat()
    if target_idx == nil then return end
    local tpose = vector(entity.hitbox_position(target_idx, 0))
    local lpose = vector(client.eye_position())
    if not tpose or not lpose then return end
    local pitcht, yawt = lpose:to(tpose):angles()
    cmd.yaw = utils.normalize_yaw(yawt)
    local def = antiaims.to_apply and antiaims.to_apply.defensive
    local dp = def and def.pitch or nil
    local pval = nil
    if def and dp and dp ~= "Default" then
        local dc = def.pitchc and def.pitchc[dp]
        if dp == "Up" then
            pval = -89
        elseif dp == "Down" then
            pval = 89
        elseif dp == "Zero" then
            pval = 0
        elseif dp == "Custom" then
            pval = dc
        elseif dp == "Random" then
            pval = client.random_float(-89, 89)
        elseif dp == "Random v2" then
            if type(dc) == "table" then pval = client.random_int(dc[1], dc[2]) end
        elseif dp == "Fluctate" and type(dc) == "table" then
            antiaims.fluctate_handler(cmd, dc[2], dc[3], (dc[4]*0.01)*20, dc[1])
            pval = antiaims.fluctate_def and antiaims.fluctate_def[antiaims.current_cond]
        elseif dp == "Jitter" and type(dc) == "table" then
            antiaims.pitchjit_hamdler(cmd, dc[1], dc[2])
            pval = antiaims.pitch_jit and antiaims.pitch_jit[antiaims.current_cond]
        elseif dp == "L&R" and type(dc) == "table" then
            pval = antiaims.current_side and dc[1] or dc[2]
        end
    else
        local pmode = antiaims.to_apply and antiaims.to_apply.pitch
        if pmode == "Up" then
            pval = -89
        elseif pmode == "Down" then
            pval = 89
        elseif pmode == "Random" then
            pval = client.random_float(-89, 89)
        elseif pmode == "Custom" then
            pval = antiaims.to_apply.pitchc and antiaims.to_apply.pitchc[1]
        elseif pmode == "Off" then
            pval = nil
        else
            local gs_mode = ui.get(skeetgui.aagui.angles.pitch[1])
            if gs_mode == "Off" then
                pval = nil
            elseif gs_mode == "Up" then
                pval = -89
            elseif gs_mode == "Down" then
                pval = 89
            elseif gs_mode == "Random" then
                pval = client.random_float(-89, 89)
            elseif gs_mode == "Custom" then
                pval = ui.get(skeetgui.aagui.angles.pitch[2])
            end
        end
    end
    if pval ~= nil then
        if pval > 89 then pval = 89 end
        if pval < -89 then pval = -89 end
        cmd.pitch = pval
    end
end
utils.split = function(inputstr, sep)
    if sep == nil then
      sep = "%s"
    end
    local t = {}
    for str in string.gmatch(inputstr, "([^"..sep.."]+)") do
      table.insert(t, str)
    end
    return t
end
utils.split_num = function(number, sep)
    local temp = {}
    for dig in tostring(number):gmatch("%d") do
        table.insert(temp, tonumber(dig))
    end
    return table.concat(temp, sep)
end
function outlined_rectangle(x, y, w, h, r, g, b, a, thickness)
    local data = {
        {x, y, w, thickness},
        {x, y + h - thickness, w, thickness},
        {x, y, thickness, h},
        {x + w - thickness, y, thickness, h},
    }
    for _, data in next, data do
        renderer.rectangle(data[1], data[2], data[3], data[4], r, g, b, a)
    end
end
local function rounded_rect(x, y, w, h, r, g, b, a, radius)
    y = y + radius
    local data_circle = {
        {x + radius, y, 180},
        {x + w - radius, y, 90},
        {x + radius, y + h - radius * 2, 270},
        {x + w - radius, y + h - radius * 2, 0},
    }

    local data = {
        {x + radius, y, w - radius * 2, h - radius * 2},
        {x + radius, y - radius, w - radius * 2, radius},
        {x + radius, y + h - radius * 2, w - radius * 2, radius},
        {x, y, radius, h - radius * 2},
        {x + w - radius, y, radius, h - radius * 2},
    }

    for _, data in next, data_circle do
        renderer.circle(data[1], data[2], r, g, b, a, radius, data[3], 0.25)
    end

    for _, data in next, data do
        renderer.rectangle(data[1], data[2], data[3], data[4], r, g, b, a)
    end
end
local function outlined_rounded_rect(x, y, w, h, r, g, b, a, radius, thickness)
    y = y + radius
    local data_circle = {
        {x + radius, y, 180},
        {x + w - radius, y, 270},
        {x + radius, y + h - radius * 2, 90},
        {x + w - radius, y + h - radius * 2, 0},
    }

    local data = {
        {x + radius, y - radius, w - radius * 2, thickness},
        {x + radius, y + h - radius - thickness, w - radius * 2, thickness},
        {x, y, thickness, h - radius * 2},
        {x + w - thickness, y, thickness, h - radius * 2},
    }

    for _, data in next, data_circle do
        renderer.circle_outline(data[1], data[2], r, g, b, a, radius, data[3], 0.25, thickness)
    end

    for _, data in next, data do
        renderer.rectangle(data[1], data[2], data[3], data[4], r, g, b, a)
    end
end
--region @utils end

--region @tweaks
utils.ogcheckbox = ui.new_checkbox
utils.oghotkey = ui.new_hotkey
utils.ogtextbox = ui.new_textbox
utils.ogpicker = ui.new_color_picker
utils.ogcombo = ui.new_combobox
utils.ogmulti = ui.new_multiselect
utils.ogslider = ui.new_slider
utils.ogname = ui.name
utils.uinames = {}
utils.uioptions = {}
utils.slider_ranges = {}
utils.slider_tooltips = {}
function _G.ui.new_checkbox(tab, container, name)
    local ind;
    if type(name) == "table" then
        namec = table.concat(name)
        ind = utils.ogcheckbox(tab, container, namec)
        utils.uinames[ind] = name[#name]
    else
        ind = utils.ogcheckbox(tab, container, name)
        utils.uinames[ind] = name
    end
    return ind
end
function _G.ui.new_hotkey(tab, container, name, inline, default_hotkey)
    local ind;
    default_hotkey = default_hotkey or 0x00
    if type(name) == "table" then
        namec = table.concat(name)
        ind = utils.oghotkey(tab, container, namec, inline, default_hotkey)
        utils.uinames[ind] = name[#name]
    else
        ind = utils.oghotkey(tab, container, name, inline, default_hotkey)
        utils.uinames[ind] = name
    end
    return ind
end
function _G.ui.new_combobox(tab, container, name, ...)
    local ind;
    local opts = {...}
    if #opts == 1 and type(opts[1]) == "table" then opts = opts[1] end
    if type(name) == "table" then
        namec = table.concat(name)
        ind = utils.ogcombo(tab, container, namec, unpack(opts))
        utils.uinames[ind] = name[#name]
    else
        ind = utils.ogcombo(tab, container, name, unpack(opts))
        utils.uinames[ind] = name
    end
    utils.uioptions[ind] = opts
    return ind
end
function _G.ui.new_multiselect(tab, container, name, ...)
    local ind;
    local opts = {...}
    if #opts == 1 and type(opts[1]) == "table" then opts = opts[1] end
    if type(name) == "table" then
        namec = table.concat(name)
        ind = utils.ogmulti(tab, container, namec, unpack(opts))
        utils.uinames[ind] = name[#name]
    else
        ind = utils.ogmulti(tab, container, name, unpack(opts))
        utils.uinames[ind] = name
    end
    utils.uioptions[ind] = opts
    return ind
end
function _G.ui.new_textbox(tab, container, name)
    local ind;
    if type(name) == "table" then
        namec = table.concat(name)
        ind = utils.ogtextbox(tab, container, namec)
        utils.uinames[ind] = name[#name]
    else
        ind = utils.ogtextbox(tab, container, name)
        utils.uinames[ind] = name
    end
    return ind
end
function _G.ui.new_slider(tab, container, name, min, max, init_value, show_tooltip, unit, scale, tooltips)
    tooltips = tooltips or nil
    scale = scale or 1
    local ind;
    if type(name) == "table" then
        namec = table.concat(name)
        ind = utils.ogslider(tab, container, namec, min, max, init_value, show_tooltip, unit, scale, tooltips)
        utils.uinames[ind] = name[#name]
    else
        ind = utils.ogslider(tab, container, name, min, max, init_value, show_tooltip, unit, scale, tooltips)
        utils.uinames[ind] = name
    end
    utils.slider_ranges[ind] = { min = min, max = max }
    utils.slider_tooltips[ind] = tooltips
    return ind
end
function _G.ui.new_color_picker(tab, container, name, r, g, b, a)
    r = r or 255
    g = g or 255
    b = b or 255
    a = a or 255
    local ind;
    if type(name) == "table" then
        namec = table.concat(name)
        ind = utils.ogpicker(tab, container, namec, r, g, b, a)
        utils.uinames[ind] = name[#name]
    else
        ind = utils.ogpicker(tab, container, name, r, g, b, a)
        utils.uinames[ind] = name
    end
    return ind
end
function _G.ui.name(item)
    local name;
    if utils.in_table(utils.uinames, item, true) then
        name = utils.uinames[item]
    else
        name = utils.ogname(item)
    end
    return name
end
--region @tweaks end

local skeetgui = {
    aagui = {
        angles = {
            enabled = ui.reference("AA", "Anti-aimbot angles", "Enabled"),
            pitch = {ui.reference("AA", "Anti-aimbot angles", "Pitch")},
            yaw_base = ui.reference("AA", "Anti-aimbot angles", "Yaw base"),
            yaw = {ui.reference("AA", "Anti-aimbot angles", "Yaw")},
            yaw_jitter = {ui.reference("AA", "Anti-aimbot angles", "Yaw jitter")},
            body_yaw = {ui.reference("AA", "Anti-aimbot angles", "Body yaw")},
            freestanding_body_yaw = ui.reference("AA", "Anti-aimbot angles", "Freestanding body yaw"),
            edge_yaw = ui.reference("AA", "Anti-aimbot angles", "Edge yaw"),
            freestanding = {ui.reference("AA", "Anti-aimbot angles", "Freestanding")},
            roll = ui.reference("AA", "Anti-aimbot angles", "Roll")
        },

        fakelag = {
            enabled = {ui.reference("AA", "Fake lag", "Enabled")},
            amount = ui.reference("AA", "Fake lag", "Amount"),
            variance = ui.reference("AA", "Fake lag", "Variance"),
            limit = ui.reference("AA", "Fake lag", "Limit")
        },

        other = {
            slow_motion = {ui.reference("AA", "Other", "Slow motion")},
            leg_movement = ui.reference("AA", "Other", "Leg movement"),
            on_shot_antiaim = {ui.reference("AA", "Other", "On shot anti-aim")},
            fake_peek = {ui.reference("AA", "Other", "Fake peek")},
        },
    },
    ragegui = {
        weapon = {
            weapon_type = ui.reference("Rage", "Weapon type", "Weapon type")
        },

        aimbot = {
            enabled = {ui.reference("Rage", "Aimbot", "Enabled")},
            target_selection = ui.reference("Rage", "Aimbot", "Target selection"),
            hitboxes = ui.reference("Rage", "Aimbot", "Target hitbox"),
            multipoint_scale = ui.reference("Rage", "Aimbot", "Multi-point scale"),
            minimum_damage = ui.reference("Rage", "Aimbot", "Minimum damage"),
            hitchance = ui.reference('Rage', 'Aimbot', 'Minimum hit chance'),
            auto_scope = ui.reference('Rage', 'Aimbot', 'Automatic Scope'),
            minimum_damage_override = {ui.reference("Rage", "Aimbot", "Minimum damage override")},
            prefer_safe_point = ui.reference("Rage", "Aimbot", "Prefer safe point"),
            prefer_body_aim = ui.reference("Rage", "Aimbot", "Prefer body aim"),
            force_safe_point = ui.reference("Rage", "Aimbot", "Force safe point"),
            force_body_aim = ui.reference("Rage", "Aimbot", "Force body aim"),
            double_tap = {ui.reference("Rage", "Aimbot", "Double tap")},
            double_tap_lag_limit = ui.reference("Rage", "Aimbot", "Double tap fake lag limit"),
        },

        other = {
            delay_shot = ui.reference("Rage", "Other", "Delay shot"),
            quick_peek_assist = {ui.reference("Rage", "Other", "Quick peek assist")},
            duck_peek_assist = ui.reference("Rage", "Other", "Duck peek assist"),
        },
    },
    visualgui = {
        player_esp = {
            name = {ui.reference("Visuals", "Player ESP", "Name")},
            weapon_icon = {ui.reference("Visuals", "Player ESP", "Weapon icon")},
            ammo = {ui.reference("Visuals", "Player ESP", "Ammo")},
        },
        colored_models = {
            local_chams = {ui.reference("Visuals", "Colored models", "Local player")},
            local_transp = ui.reference("Visuals", "Colored models", "Local player transparency"),
        },
        effects = {
            tperson = {ui.reference("Visuals", "Effects", "Force third person (alive)")},
            remove_soverlay = ui.reference("Visuals", "Effects", "Remove scope overlay"),
        },
    },
    miscgui = {
        misc = {
            ping_spike = {ui.reference("Misc", "Miscellaneous", "Ping spike")},
            free_look = ui.reference("Misc", "Miscellaneous", "Free look"),
        },
        settings = {
            menu_key = ui.reference("Misc", "Settings", "Menu key"),
            dpi_scale = ui.reference("Misc", "Settings", "DPI Scale"),
        },
    },
    configgui = {
        presets = {
            presets = {ui.reference("Config", "Presets", "Presets")},
            load = ui.reference("Config", "Presets", "Load"),
            save = ui.reference("Config", "Presets", "Save"),
        },
    },
}
utils.weapgroup = {
	"Global",
	"G3SG1 / SCAR-20",
    "SSG 08",
	"R8 Revolver",
	"AWP",
	"R8 Revolver",
	"Desert Eagle",
	"Pistol",
	"Rifle",
	"Shotgun",
	"SMG",
	"Machine gun"
}
cvardef.default_view = {cvar.viewmodel_fov:get_float(), cvar.viewmodel_offset_x:get_float(), cvar.viewmodel_offset_y:get_float(), cvar.viewmodel_offset_z:get_float()}
cvardef.def_tdist = cvar.cam_idealdist:get_int()
--region @tabs
local switchtb = {"Main", "Rage", "Anti-Aimbot", "Visuals", "Misc", "Manipulations", "Configs"}
local switch = ui.new_combobox("AA", "Fake lag", "Tabs", switchtb)
local discordbutton = ui.new_button("AA", "Fake lag", "Discord", function() panorama.open().SteamOverlayAPI.OpenExternalBrowserURL("https://discord.gg/AVYKNR5UEP") end)
local altuibutton = ui.new_button("AA", "Fake lag", "Alternative UI", function()end)
local altuibutton1 = ui.new_button("AA", "Fake lag", "Default UI", function()end)
local defaultabbutton = ui.new_button("AA", "Fake lag", "Default Tab", function()end)
local defaultabbutton1 = ui.new_button("AA", "Fake lag", "Osmanhook Tab", function()end)
local search = {ui.new_label("AA", "Fake lag", "Search"), ui.new_textbox("AA", "Fake lag", "Search")}
visuals.keynames = {"Double tap", "Onshot anti-aimbot", "Force body aim", "Damage override", "Force safe point", "Quick peek assist", "Duck peek assist", "Freestands", "Force head aim", "Jumpshot", "Anti-aimbot inverted", "Edgeyaw", "Ping spike", "Hitchance override", "Body on lethal", "Dormant aimbot", "Lower body yaw breaker", "Delay shot", "Free look", "Auto smoke"}
antiaims.conds = {"Shared", "Standing", "Moving", "Slowwalk", "Crouch", "Crouch-Moving", "Air", "Air-Crouch", "On-Use", "Fakelags", "Duckpeek"}
antiaims.yawbox = {"Off", "180", "Spin", "Static", "L&R", "Delayed"}
antiaims.pitchbox = {"Off", "Up", "Down", "Random", "Custom"}
visuals.arms_skin_colors = {"White", "Black", "Brown", "Asian", "Mexican", "Tattoo"}
visuals._arms_last_skin = nil
antiaims.jitterbox = {"Off", "Offset", "Center", "Skitter", "Random", "Nway", "Min/Max Center", "L&R Center", "Custom Center", "Custom Offset"}
antiaims.bodybox = {"Off", "Static", "Opposite", "Sway", "Jitter", "Custom Jitter", "Jitter v2", "Static v2"}
antiaims.defforcebox = {"Off", "On-Hittable", "Always"}
antiaims.basebox = {"Local view", "At targets", "Closest enemy"}
antiaims.defpitchbox = {"Default", "Up", "Down", "Zero", "Random", "Custom", "Random v2", "Fluctate", "Jitter", "L&R"}
antiaims.defyawbox = {"Default", "180", "Spin", "Spin v2", "Random", "Opposite", "Jitter", "L&R"}
antiaims.fakelagbox = {"Maximum", "Dynamic", "Fluctuate", "Fluctuate v2", "Jitter", "Random"}
rage.weaponstweaks = {"Global", "SSG 08", "AWP", "G3SG1 / SCAR-20", "R8 Revolver", "Desert Eagle", "Pistol"}
rage.mpoints = {"SSG 08", "AWP", "R8 Revolver"}
rage.dormanthp = {}

rage.dormanthp[0] = "Inherited"
for i=1, 26 do
	rage.dormanthp[100 + i] = "HP + "..i
end

local tabs = {
    ["Main"] = {
        ui.new_label("AA", "Anti-aimbot angles", "osmanhook.lua"),
        ui.new_label("AA", "Anti-aimbot angles", "Version: "),
        ui.new_label("AA", "Anti-aimbot angles", "Username: "),
    },
    ["Rage"] = {
        dormant = {
            ui.new_checkbox("AA", "Anti-aimbot angles", "Dormant Aimbot"),
            ui.new_hotkey("AA", "Anti-aimbot angles", "Dormant Aimbot", true, 0x00),
            ui.new_combobox("AA", "Anti-aimbot angles", {"\n", "Dormant Aimbot"}, rage.weaponstweaks),
            tbl = {
                ["Global"] = {
                    ui.new_slider("AA", "Anti-aimbot angles", "[Global] Dormant accuracy", 50, 100, 75, true, "%", 1, nil),
                    ui.new_slider("AA", "Anti-aimbot angles", "[Global] Dormant damage", 0, 126, 10, true, nil, 1, rage.dormanthp),
                },
                ["SSG 08"] = {
                    ui.new_slider("AA", "Anti-aimbot angles", "[SSG 08] Dormant accuracy", 50, 100, 75, true, "%", 1, nil),
                    ui.new_slider("AA", "Anti-aimbot angles", "[SSG 08] Dormant damage", 0, 126, 10, true, nil, 1, rage.dormanthp),
                },
                ["AWP"] = {
                    ui.new_slider("AA", "Anti-aimbot angles", "[AWP] Dormant accuracy", 50, 100, 75, true, "%", 1, nil),
                    ui.new_slider("AA", "Anti-aimbot angles", "[AWP] Dormant damage", 0, 126, 10, true, nil, 1, rage.dormanthp),
                },
                ["G3SG1 / SCAR-20"] = {
                    ui.new_slider("AA", "Anti-aimbot angles", "[G3SG1 / SCAR-20] Dormant accuracy", 50, 100, 75, true, "%", 1, nil),
                    ui.new_slider("AA", "Anti-aimbot angles", "[G3SG1 / SCAR-20] Dormant damage", 0, 126, 10, true, nil, 1, rage.dormanthp),
                },
                ["R8 Revolver"] = {
                    ui.new_slider("AA", "Anti-aimbot angles", "[R8 Revolver] Dormant accuracy", 50, 100, 75, true, "%", 1, nil),
                    ui.new_slider("AA", "Anti-aimbot angles", "[R8 Revolver] Dormant damage", 0, 126, 10, true, nil, 1, rage.dormanthp),
                },
                ["Desert Eagle"] = {
                    ui.new_slider("AA", "Anti-aimbot angles", "[Desert Eagle] Dormant accuracy", 50, 100, 75, true, "%", 1, nil),
                    ui.new_slider("AA", "Anti-aimbot angles", "[Desert Eagle] Dormant damage", 0, 126, 10, true, nil, 1, rage.dormanthp),
                },
                ["Pistol"] = {
                    ui.new_slider("AA", "Anti-aimbot angles", "[Pistol] Dormant accuracy", 50, 100, 75, true, "%", 1, nil),
                    ui.new_slider("AA", "Anti-aimbot angles", "[Pistol] Dormant damage", 0, 126, 10, true, nil, 1, rage.dormanthp),
                },
            },
        },
        jumpshot = {
            ui.new_checkbox("AA", "Anti-aimbot angles", "Jumpshot"),
            ui.new_hotkey("AA", "Anti-aimbot angles", "JumpshotK", true, 0x00),
            ui.new_multiselect("AA", "Anti-aimbot angles", {"\n", "Jumpshot"}, {"R8", "Scout"}),
            ui.new_slider("AA", "Anti-aimbot angles", "R8 Distance", 80, 420, 280, true, "in", 1, nil), --ui.new_slider(-180, 180, 0, true, "°", 1, nil),
            ui.new_slider("AA", "Anti-aimbot angles", "Scout Distance", 280, 1200, 800, true, "in", 1, nil),
        },
        hitchance = {
            ui.new_checkbox("AA", "Anti-aimbot angles", "Hitchance"),
            ui.new_hotkey("AA", "Anti-aimbot angles", "Hitchance", true, 0x00),
            ui.new_combobox("AA", "Anti-aimbot angles", {"\n", "Hitchance"}, rage.weaponstweaks),
            tbl = {
                ["Global"] = ui.new_slider("AA", "Anti-aimbot angles", "Global Hitchance", -1, 100, -1, true, "%", 1, {[-1] = "Disabled", [0] = "Off"}),
                ["SSG 08"] = ui.new_slider("AA", "Anti-aimbot angles", "SSG 08 Hitchance", -1, 100, -1, true, "%", 1, {[-1] = "Disabled", [0] = "Off"}),
                ["AWP"] = ui.new_slider("AA", "Anti-aimbot angles", "AWP Hitchance", -1, 100, -1, true, "%", 1, {[-1] = "Disabled", [0] = "Off"}),
                ["G3SG1 / SCAR-20"] = ui.new_slider("AA", "Anti-aimbot angles", "G3SG1 / SCAR-20 Hitchance", -1, 100, -1, true, "%", 1, {[-1] = "Disabled", [0] = "Off"}),
                ["R8 Revolver"] = ui.new_slider("AA", "Anti-aimbot angles", "R8 Revolver Hitchance", -1, 100, -1, true, "%", 1, {[-1] = "Disabled", [0] = "Off"}),
                ["Desert Eagle"] = ui.new_slider("AA", "Anti-aimbot angles", "Desert Eagle Hitchance", -1, 100, -1, true, "%", 1, {[-1] = "Disabled", [0] = "Off"}),
                ["Pistol"] = ui.new_slider("AA", "Anti-aimbot angles", "Pistol Hitchance", -1, 100, -1, true, "%", 1, {[-1] = "Disabled", [0] = "Off"}),
            },
        },
        lethal = {
            ui.new_checkbox("AA", "Anti-aimbot angles", "Force body on Lethal"),
            ui.new_hotkey("AA", "Anti-aimbot angles", "Force body on Lethal", true, 0x00),
            ui.new_combobox("AA", "Anti-aimbot angles", {"\n", "Force body on Lethal"}, rage.weaponstweaks),
            tbl = {
                ["Global"] = ui.new_slider("AA", "Anti-aimbot angles", "Global Lethal", 0, 100, 0, true, "hp", 1, {[0] = "Disabled"}),
                ["SSG 08"] = ui.new_slider("AA", "Anti-aimbot angles", "SSG 08 Lethal", 0, 100, 0, true, "hp", 1, {[0] = "Disabled"}),
                ["AWP"] = ui.new_slider("AA", "Anti-aimbot angles", "AWP Lethal", 0, 100, 0, true, "hp", 1, {[0] = "Disabled"}),
                ["G3SG1 / SCAR-20"] = ui.new_slider("AA", "Anti-aimbot angles", "G3SG1 / SCAR-20 Lethal", 0, 100, 0, true, "hp", 1, {[0] = "Disabled"}),
                ["R8 Revolver"] = ui.new_slider("AA", "Anti-aimbot angles", "R8 Revolver Lethal", 0, 100, 0, true, "hp", 1, {[0] = "Disabled"}),
                ["Desert Eagle"] = ui.new_slider("AA", "Anti-aimbot angles", "Desert Eagle Lethal", 0, 100, 0, true, "hp", 1, {[0] = "Disabled"}),
                ["Pistol"] = ui.new_slider("AA", "Anti-aimbot angles", "Pistol Lethal", 0, 100, 0, true, "hp", 1, {[0] = "Disabled"}),
            },
        },
        mpoints = {
            ui.new_checkbox("AA", "Anti-aimbot angles", "Conditional Multipoints"),
            ui.new_combobox("AA", "Anti-aimbot angles", {"\n", "Conditional Multipoints"}, rage.mpoints),
            enbl = {
                ["SSG 08"] = ui.new_checkbox("AA", "Anti-aimbot angles", "[SSG 08] Enable Multipoints"),
                ["AWP"] = ui.new_checkbox("AA", "Anti-aimbot angles", "[AWP] Enable Multipoints"),
                ["R8 Revolver"] = ui.new_checkbox("AA", "Anti-aimbot angles", "[R8 Revolver] Enable Multipoints"),
            },
            tbl = {   
                ["SSG 08"] = {
                    ui.new_slider("AA", "Anti-aimbot angles", "[SSG 08] Standing Multipoints", 24, 100, 60, true, "%", 1, {[24] = "Auto"}),
                    ui.new_slider("AA", "Anti-aimbot angles", "[SSG 08] Moving Multipoints", 24, 100, 60, true, "%", 1, {[24] = "Auto"}),
                    ui.new_slider("AA", "Anti-aimbot angles", "[SSG 08] Slowwalk Multipoints", 24, 100, 60, true, "%", 1, {[24] = "Auto"}),
                    ui.new_slider("AA", "Anti-aimbot angles", "[SSG 08] Air Multipoints", 24, 100, 60, true, "%", 1, {[24] = "Auto"}),
                    ui.new_slider("AA", "Anti-aimbot angles", "[SSG 08] Air-Crouch Multipoints", 24, 100, 60, true, "%", 1, {[24] = "Auto"}),
                    ui.new_slider("AA", "Anti-aimbot angles", "[SSG 08] Crouch Multipoints", 24, 100, 60, true, "%", 1, {[24] = "Auto"}),
                    ui.new_slider("AA", "Anti-aimbot angles", "[SSG 08] Duck Multipoints", 24, 100, 60, true, "%", 1, {[24] = "Auto"}),
                },
                ["AWP"] = {
                    ui.new_slider("AA", "Anti-aimbot angles", "[AWP] Standing Multipoints", 24, 100, 60, true, "%", 1, {[24] = "Auto"}),
                    ui.new_slider("AA", "Anti-aimbot angles", "[AWP] Moving Multipoints", 24, 100, 60, true, "%", 1, {[24] = "Auto"}),
                    ui.new_slider("AA", "Anti-aimbot angles", "[AWP] Slowwalk Multipoints", 24, 100, 60, true, "%", 1, {[24] = "Auto"}),
                    ui.new_slider("AA", "Anti-aimbot angles", "[AWP] Air Multipoints", 24, 100, 60, true, "%", 1, {[24] = "Auto"}),
                    ui.new_slider("AA", "Anti-aimbot angles", "[AWP] Air-Crouch Multipoints", 24, 100, 60, true, "%", 1, {[24] = "Auto"}),
                    ui.new_slider("AA", "Anti-aimbot angles", "[AWP] Crouch Multipoints", 24, 100, 60, true, "%", 1, {[24] = "Auto"}),
                    ui.new_slider("AA", "Anti-aimbot angles", "[AWP] Duck Multipoints", 24, 100, 60, true, "%", 1, {[24] = "Auto"}),
                },
                ["R8 Revolver"] = {
                    ui.new_slider("AA", "Anti-aimbot angles", "[R8 Revolver] Standing Multipoints", 24, 100, 60, true, "%", 1, {[24] = "Auto"}),
                    ui.new_slider("AA", "Anti-aimbot angles", "[R8 Revolver] Moving Multipoints", 24, 100, 60, true, "%", 1, {[24] = "Auto"}),
                    ui.new_slider("AA", "Anti-aimbot angles", "[R8 Revolver] Slowwalk Multipoints", 24, 100, 60, true, "%", 1, {[24] = "Auto"}),
                    ui.new_slider("AA", "Anti-aimbot angles", "[R8 Revolver] Air Multipoints", 24, 100, 60, true, "%", 1, {[24] = "Auto"}),
                    ui.new_slider("AA", "Anti-aimbot angles", "[R8 Revolver] Air-Crouch Multipoints", 24, 100, 60, true, "%", 1, {[24] = "Auto"}),
                    ui.new_slider("AA", "Anti-aimbot angles", "[R8 Revolver] Crouch Multipoints", 24, 100, 60, true, "%", 1, {[24] = "Auto"}),
                    ui.new_slider("AA", "Anti-aimbot angles", "[R8 Revolver] Duck Multipoints", 24, 100, 60, true, "%", 1, {[24] = "Auto"}),
                },
            },
        },
        unsafe_charge = {
            ui.new_checkbox("AA", "Anti-aimbot angles", {"\aFF0000FF", "Unsafe Charge"}),
            ui.new_multiselect("AA", "Anti-aimbot angles", {"\n", "Unsafe Charge"}, {"Air", "Ground"}),
        },
        onlyhs = {
            ui.new_checkbox("AA", "Other", "Force Head"),
            ui.new_hotkey("AA", "Other", "Force HeadK", true, 0x00),
        },
        delay_shot = {
            ui.new_hotkey("AA", "Other", "Delay Shot", false, 0x00),
        },
        resolver = {
            ui.new_checkbox("AA", "Anti-aimbot angles", "Resolver"),
            ui.new_checkbox("AA", "Anti-aimbot angles", "Show panel"),
            ui.new_combobox("AA", "Anti-aimbot angles", {"\n", "Resolver"}, {"default", "smart"}),
            ui.new_multiselect("AA", "Anti-aimbot angles", "Resolver features", {"reset on target change", "per-target memory", "boost hitchance", "boost mindmg"}),
            ui.new_slider("AA", "Anti-aimbot angles", "Max steps", 1, 6, 4, true, nil, 1, nil),
            ui.new_slider("AA", "Anti-aimbot angles", "Hitchance boost", 0, 30, 5, true, "%", 1, nil),
            ui.new_slider("AA", "Anti-aimbot angles", "Mindmg boost", 0, 30, 0, true, "hp", 1, nil),
        },
    },
    ["Anti-Aimbot"] = {
        ui.new_checkbox("AA", "Anti-aimbot angles", "Enable"),
        builder = ui.new_combobox("AA", "Anti-aimbot angles", "Builder Type", {"gamesense", "osmanhook"}),
        side_specific_enabled = ui.new_checkbox("AA", "Anti-aimbot angles", "Side-Specific AA"),
        side_specific_team = ui.new_combobox("AA", "Anti-aimbot angles", "Side-Specific Team", {"Counter-Terrorists", "Terrorists"}),
        condition = ui.new_combobox("AA", "Anti-aimbot angles", "Conditions", antiaims.conds),
        inverter = {
            ui.new_hotkey("AA", "Other", {"\aE6D349FF", "Antiaim Inverter"}, false, 0x00),
        },
        edgeyaw = {
            ui.new_hotkey("AA", "Other", {"\aB6B665FF", "Edgeyaw"}, false, 0x00),
        },
        freestand = {
            ui.new_hotkey("AA", "Other", {"\aB6B665FF", "Freestanding"}, false, 0x00),
        },
        exttep = {
            ui.new_hotkey("AA", "Other", {"\aB6B665FF", "Extented Teleport"}, false, 0x00),
            ui.new_hotkey("AA", "Other", {"\aB6B665FF", "Unsafe Teleport"}, false, 0x00),
            ui.new_slider("AA", "Other", "Teleport Ticks", 1, 6, 1, true, "t", 1, nil),
        },
        manuals = {
            ui.new_checkbox("AA", "Other", {"\aB6B665FF", "Manuals"}),
            ui.new_hotkey("AA", "Other", "Left", false, 0x00),
            ui.new_hotkey("AA", "Other", "Right", false, 0x00),
            ui.new_hotkey("AA", "Other", "Reset", false, 0x00),
        },
        lby_breaker = {
            ui.new_checkbox("AA", "Other", {"\aE6D349FF", "LBY"}),
            ui.new_hotkey("AA", "Other", "LBY", true, 0x00),
            ui.new_slider("AA", "Other", "LBY Desync", 0, 160, 110, true, "°", 1, nil),
        },
        other = {
            ui.new_multiselect("AA", "Other", "Tweaks", {"Anti-Backstab", "Safe on knife", "Safe on zeus", "Safe on heigh", "Static on manuals", "Local view on manuals", "Flick manual on peek", "Allow defensive on manuals", "Disable fakelags on os"})
        },
        team_anti_aim = {
            enabled = ui.new_checkbox("AA", "Anti-aimbot angles", "Enable Team Anti-Aim"),
            ct_settings = {
                ui.new_label("AA", "Anti-aimbot angles", "Counter-Terrorist Settings"),
                pitch = ui.new_combobox("AA", "Anti-aimbot angles", "CT Pitch", antiaims.pitchbox),
                pitch_custom = ui.new_slider("AA", "Anti-aimbot angles", "CT Custom Pitch", -89, 89, 0, true, "°", 1, nil),
                yaw = ui.new_combobox("AA", "Anti-aimbot angles", "CT Yaw", antiaims.yawbox),
                yaw_custom = ui.new_slider("AA", "Anti-aimbot angles", "CT Custom Yaw", -180, 180, 0, true, "°", 1, nil),
                yaw_jitter = ui.new_combobox("AA", "Anti-aimbot angles", "CT Yaw Jitter", antiaims.jitterbox),
                yaw_jitter_custom = ui.new_slider("AA", "Anti-aimbot angles", "CT Yaw Jitter Amount", -180, 180, 0, true, "°", 1, nil),
                body_yaw = ui.new_combobox("AA", "Anti-aimbot angles", "CT Body Yaw", antiaims.bodybox),
                body_yaw_custom = ui.new_slider("AA", "Anti-aimbot angles", "CT Body Yaw Amount", -60, 60, 0, true, "°", 1, nil),
                fakelag = ui.new_combobox("AA", "Anti-aimbot angles", "CT Fake Lag", antiaims.fakelagbox),
                fakelag_limit = ui.new_slider("AA", "Anti-aimbot angles", "CT Fake Lag Limit", 1, 15, 14, true, nil, 1, nil),
                fakelag_variance = ui.new_slider("AA", "Anti-aimbot angles", "CT Fake Lag Variance", 0, 100, 0, true, "%", 1, nil),
            },
            t_settings = {
                ui.new_label("AA", "Anti-aimbot angles", "Terrorist Settings"),
                pitch = ui.new_combobox("AA", "Anti-aimbot angles", "T Pitch", antiaims.pitchbox),
                pitch_custom = ui.new_slider("AA", "Anti-aimbot angles", "T Custom Pitch", -89, 89, 0, true, "°", 1, nil),
                yaw = ui.new_combobox("AA", "Anti-aimbot angles", "T Yaw", antiaims.yawbox),
                yaw_custom = ui.new_slider("AA", "Anti-aimbot angles", "T Custom Yaw", -180, 180, 0, true, "°", 1, nil),
                yaw_jitter = ui.new_combobox("AA", "Anti-aimbot angles", "T Yaw Jitter", antiaims.jitterbox),
                yaw_jitter_custom = ui.new_slider("AA", "Anti-aimbot angles", "T Yaw Jitter Amount", -180, 180, 0, true, "°", 1, nil),
                body_yaw = ui.new_combobox("AA", "Anti-aimbot angles", "T Body Yaw", antiaims.bodybox),
                body_yaw_custom = ui.new_slider("AA", "Anti-aimbot angles", "T Body Yaw Amount", -60, 60, 0, true, "°", 1, nil),
                fakelag = ui.new_combobox("AA", "Anti-aimbot angles", "T Fake Lag", antiaims.fakelagbox),
                fakelag_limit = ui.new_slider("AA", "Anti-aimbot angles", "T Fake Lag Limit", 1, 15, 14, true, nil, 1, nil),
                fakelag_variance = ui.new_slider("AA", "Anti-aimbot angles", "T Fake Lag Variance", 0, 100, 0, true, "%", 1, nil),
            },
        },
    },
    ["Visuals"] = {
        indicators = {
            ui.new_checkbox("AA", "Anti-aimbot angles", "Indicators"),
            ui.new_color_picker("AA", "Anti-aimbot angles", "Indicators Color", 255, 255, 255, 255),
            ui.new_combobox("AA", "Anti-aimbot angles", "Indicators Type", {"Default", "GlowSet", "Rippler", "Pixies"}),
            ui.new_multiselect("AA", "Anti-aimbot angles", "Indicators Modify", {"Animation", "Shadow", "Scope"}),
        },
        nimbus = {
            ui.new_checkbox("AA", "Anti-aimbot angles", "Nimbus"),
            ui.new_color_picker("AA", "Anti-aimbot angles", "Nimbus Color", 255, 255, 255, 255)
        },
        crossdamage = {
            ui.new_checkbox("AA", "Anti-aimbot angles", "Damage on cross"),
            ui.new_checkbox("AA", "Anti-aimbot angles", "Only mindamage"),
            ui.new_checkbox("AA", "Anti-aimbot angles", "Small font"),
            ui.new_combobox("AA", "Anti-aimbot angles", "Damage Position", {"Right-Top", "Right-Bottom", "Left-Top", "Left-Bottom"}),
        },
        arrows = {
            ui.new_checkbox("AA", "Anti-aimbot angles", "Anti-Aimbot Arrows"),
            ui.new_combobox("AA", "Anti-aimbot angles", "Arrows Style", {"TeamSkeet", "CS2", "Triangle", "Arrows"}),
            ui.new_label("AA", "Anti-aimbot angles", "Manual Color"),
            ui.new_color_picker("AA", "Anti-aimbot angles", "Manual Color", 175, 255, 0, 255),
            ui.new_label("AA", "Anti-aimbot angles", "Desync Side Color"),
            ui.new_color_picker("AA", "Anti-aimbot angles", "Desync Side Color", 0, 200, 255, 255),
            ui.new_slider("AA", "Anti-aimbot angles", "Arrows Gap", 5, 150, 25, true, "px", 1, nil),
            ui.new_slider("AA", "Anti-aimbot angles", "Arrows Adding", 10, 50, 10, true, "px", 1, nil),
        },
        scopelines = {
            ui.new_checkbox("AA", "Anti-aimbot angles", "Custom Scope"),
            ui.new_checkbox("AA", "Anti-aimbot angles", "Animated"),
            ui.new_checkbox("AA", "Anti-aimbot angles", "Inverted"),
            ui.new_label("AA", "Anti-aimbot angles", "Scope First Color"),
            ui.new_color_picker("AA", "Anti-aimbot angles", "Scope First Color", 255, 255, 255, 255),
            ui.new_label("AA", "Anti-aimbot angles", "Scope Second Color"),
            ui.new_color_picker("AA", "Anti-aimbot angles", "Scope Second Color", 0, 0, 0, 0),
            ui.new_combobox("AA", "Anti-aimbot angles", "Scopelines Shape", "Default", "T-Shape", "Vertical only", "Horizontal Only"),

            ui.new_slider("AA", "Anti-aimbot angles", "Lines Gap", 0, 150, 10, true, "px", 1, nil),
            ui.new_slider("AA", "Anti-aimbot angles", "Lines Lenght", 5, screen.x, 100, true, "px", 1, nil),
            ui.new_slider("AA", "Anti-aimbot angles", "Lines Thickens", 1, 10, 1, true, "px", 1, nil),
        },
        sidemark = {
            ui.new_checkbox("AA", "Anti-aimbot angles", "Sidemark"),
            ui.new_combobox("AA", "Anti-aimbot angles", "Side", {"Left", "Right"}),
        },
        predictbox = {
            ui.new_checkbox("AA", "Anti-aimbot angles", "Prediction Box"),
            ui.new_multiselect("AA", "Anti-aimbot angles", {"\n", "Prediction Box"}, {"Self", "Target"}),
        },
        betternade = {
            ui.new_checkbox("AA", "Anti-aimbot angles", "Better Nade Esp"),
            ui.new_multiselect("AA", "Anti-aimbot angles", {"\n", "Better Nade Esp"}, {"Smoke", "Fire"}),
            ui.new_multiselect("AA", "Anti-aimbot angles", "Addons", {"Radius", "Smoke Timer"}),
            ui.new_multiselect("AA", "Anti-aimbot angles", "Radius Addons", {"Fill radius", "Ignore harmless molotov"}),
            smoke = {
                ui.new_label("AA", "Anti-aimbot angles", "Smoke Color"),
                ui.new_color_picker("AA", "Anti-aimbot angles", "Smoke Color", 62, 158, 250, 255),
            },
            fire = {
                ui.new_label("AA", "Anti-aimbot angles", "Fire Color"),
                ui.new_color_picker("AA", "Anti-aimbot angles", "Fire Color", 250, 62, 90, 255),
            },
            ui.new_label("AA", "Anti-aimbot angles", "Smoke Timer Color"),
            ui.new_color_picker("AA", "Anti-aimbot angles", "Smoke Timer Color", 255, 255, 255, 255),
        },
        watermark = {
            ui.new_checkbox("AA", "Anti-aimbot angles", "Watermark"),
            ui.new_multiselect("AA", "Anti-aimbot angles", "Display", {"Name", "Config", "Ticks", "Ping", "FPS", "Time"}),
            ui.new_label("AA", "Anti-aimbot angles", "Display Name"),
            ui.new_textbox("AA", "Anti-aimbot angles", "Display Name"),
        },
        spectators = {
            ui.new_checkbox("AA", "Anti-aimbot angles", "Spectators"),
            ui.new_checkbox("AA", "Anti-aimbot angles", "Avatars"),
        },
        keybinds = {
            ui.new_checkbox("AA", "Anti-aimbot angles", "Keybinds"),
        },
        velwar = {
            ui.new_checkbox("AA", "Anti-aimbot angles", "Velocity Warning"),
            ui.new_color_picker("AA", "Anti-aimbot angles", "Velocity Warning", 255, 255, 255, 255),
        },
        defind = {
            ui.new_checkbox("AA", "Anti-aimbot angles", "Defensive Indicator"),
            ui.new_color_picker("AA", "Anti-aimbot angles", "Defensive Indicator", 255, 255, 255, 255),
        },
        tracer = {
            ui.new_checkbox("AA", "Anti-aimbot angles", "Bullet Tracer"),
            ui.new_color_picker("AA", "Anti-aimbot angles", "Bullet Tracer", 255, 255, 255, 255),
            ui.new_slider("AA", "Anti-aimbot angles", {"\n", "Bullet Tracer"}, 1, 10, 3, true, "s", 1, nil),
        },
        out_of_fov = {
            ui.new_checkbox("AA", "Anti-aimbot angles", "Better Out Of Fov"),
            ui.new_multiselect("AA", "Anti-aimbot angles", {"\n", "Better Out Of Fov"}, {"Name", "Bounding box", "Health", "Ammo", "Weapon icon"}),
            ui.new_slider("AA", "Anti-aimbot angles", "Better Out Of Fov Distance", 1, 100, 50, true, "%", 1, nil),
            ui.new_slider("AA", "Anti-aimbot angles", "Better Out Of Fov Adding", 1, 20, 5, true, "px", 1, nil),
        },
        profile_picture = {
            ui.new_checkbox("AA", "Anti-aimbot angles", "Profile Picture"),
            ui.new_combobox("AA", "Anti-aimbot angles", "Profile Picture Side", "Left", "Right"),
        },
        arms_skin = {
            ui.new_checkbox("AA", "Anti-aimbot angles", "Arms Skin Changer"),
            ui.new_checkbox("AA", "Anti-aimbot angles", "T No Sleeve"),
            ui.new_combobox("AA", "Anti-aimbot angles", "T Skin", visuals.arms_skin_colors),
            ui.new_checkbox("AA", "Anti-aimbot angles", "CT No Sleeve"),
            ui.new_combobox("AA", "Anti-aimbot angles", "CT Skin", visuals.arms_skin_colors),
        },
        altui_icon_colors = {
            ui.new_checkbox("AA", "Anti-aimbot angles", "Tab Icon Colors"),
            ui.new_label("AA", "Anti-aimbot angles", "Tab Icon Color (Default)"),
            ui.new_color_picker("AA", "Anti-aimbot angles", "Tab Icon Color (Default)", 90, 90, 90, 255),
            ui.new_label("AA", "Anti-aimbot angles", "Tab Icon Color (Selected)"),
            ui.new_color_picker("AA", "Anti-aimbot angles", "Tab Icon Color (Selected)", 210, 210, 210, 255),
            ui.new_label("AA", "Anti-aimbot angles", "Tab Icon Color (Hovered)"),
            ui.new_color_picker("AA", "Anti-aimbot angles", "Tab Icon Color (Hovered)", 167, 167, 167, 255),
        },
        fpsboost = {
            ui.new_checkbox("AA", "Other", "Fps boost"),
            ui.new_multiselect("AA", "Other", {"\n", "Fps boost"}, {"3d sky", "fog", "shadows", "blood", "decals", "bloom", "other"}),
        },
        addind = {ui.new_multiselect("AA", "Other", "Additional Indicators", {"Force Head", "Dormant", "Jumpshot", "Hitchance", "Charge", "Target"}),},
        concol = {ui.new_checkbox("AA", "Other", "Console Color"), ui.new_color_picker("AA", "Other", "Console Color", 255, 255, 255, 255)},
        
    },
    ["Misc"] = {
        tperson = {
            ui.new_checkbox("AA", "Anti-aimbot angles", "Thirdperson Distance"),
            ui.new_slider("AA", "Anti-aimbot angles", {"\n", "Thirdperson Distance"}, 10, 100, cvardef.def_tdist, true, nil, 1, nil)
        },
        aspectratio = {
            ui.new_checkbox("AA", "Anti-aimbot angles", "Aspect Ratio"),
            ui.new_slider("AA", "Anti-aimbot angles", {"\n", "Aspect Ratio"}, 0, 200, 200, true, nil, 0.01, {[200] = "Off"})
        },
        viewmodel = {
            ui.new_checkbox("AA", "Anti-aimbot angles", "Viewmodel Changer"),
            ui.new_slider("AA", "Anti-aimbot angles", "Fov", -350, 1250, cvardef.default_view[1], true, nil, 0.1, nil),
            ui.new_slider("AA", "Anti-aimbot angles", "X", -1800, 1800, cvardef.default_view[2], true, nil, 0.1, nil),
            ui.new_slider("AA", "Anti-aimbot angles", "Y", -1800, 1800, cvardef.default_view[3], true, nil, 0.1, nil),
            ui.new_slider("AA", "Anti-aimbot angles", "Z", -500, 500, cvardef.default_view[4], true, nil, 0.1, nil)
        },
        ducarigym = {
            ui.new_checkbox("AA", "Anti-aimbot angles", "Ducari in gym"),
            ui.new_slider("AA", "Anti-aimbot angles", {"\n", "Ducari in gym"}, 1, 100, 100, true, "%", 1, nil),
        },
        transcope = {
            ui.new_checkbox("AA", "Anti-aimbot angles", "Better transparency"),
            ui.new_multiselect("AA", "Anti-aimbot angles", {"\n", "Better transparency"}, {"Scoped", "Grenade"}),
            ui.new_slider("AA", "Anti-aimbot angles", "Percentage", 0, 100, 50, true, "%", 1, nil),
        },
        fastladder = {
            ui.new_checkbox("AA", "Other", "Fast Ladder"),
        },
        tagspamer = {
            ui.new_checkbox("AA", "Other", "ClanTag Spammer"),
        },
        scopeviewmodel = {
            ui.new_checkbox("AA", "Other", "Viewmodel in Scope"),
        },
        lefthand = {
            ui.new_checkbox("AA", "Other", "Left Hand on Knife"),
        },
        autosmoke = {
            ui.new_checkbox("AA", "Other", {"\aFF0000FF", "Autosmoke"}),
            ui.new_hotkey("AA", "Other", "Autosmoke", true, 0x00),
        },
        animbreak = {
            ui.new_checkbox("AA", "Anti-aimbot angles", 'Animation Breaker'),
            ui.new_checkbox("AA", "Anti-aimbot angles", "Pitch 0 on land"),
            ui.new_combobox("AA", "Anti-aimbot angles", "Air", {"Disabled", "Ground Animlayer", "Jitter", "Static Legs", "Allah", "Crab", "T-Pose", "Slowmo", "Old Fall"}),
            ui.new_combobox("AA", "Anti-aimbot angles", "Ground", {"Disabled", "Static", "Jitter", "Jitter v2", "Allah", "Crab", "Forwards", "Backwards", "T-Pose", "Slowmo"}),
            ui.new_combobox("AA", "Anti-aimbot angles", "Move Lean", {"Disabled", "No Lean", "Full Lean", "Earthquake"}),
            ui.new_multiselect("AA", "Anti-aimbot angles", "Aditional Breaker", {"Air", "Ground"}),
            ui.new_combobox("AA", "Anti-aimbot angles", "Aditional Breaker Conditions", {"Flashed", "Piano"}),
        },
        dumbass_features = {
            ui.new_checkbox("AA", "Anti-aimbot angles", 'Dumbass Breaker'),
            ui.new_combobox("AA", "Anti-aimbot angles", "Type", {"Push-Ups"}),
            ui.new_multiselect("AA", "Anti-aimbot angles", "Dumb Conds", {"Freezetime", "No enemy"}),
        },
        logs = {
            ui.new_checkbox("AA", "Anti-aimbot angles", "Aimbot Logs"),
            ui.new_multiselect("AA", "Anti-aimbot angles", {"\n", "Aimbot Logs"}, {"Console", "Screen"}),
            ui.new_multiselect("AA", "Anti-aimbot angles", "Events", {"On Hit", "On Miss", "On Hurt", "On Fire"}),
            ui.new_label("AA", "Anti-aimbot angles", "On Hit Color"),
            ui.new_color_picker("AA", "Anti-aimbot angles", "Hit Logs Color", colors.skeet_logs[1], colors.skeet_logs[2], colors.skeet_logs[3], 255),
            ui.new_label("AA", "Anti-aimbot angles", "On Miss Color"),
            ui.new_color_picker("AA", "Anti-aimbot angles", "Miss Logs Color", 255, 180, 0, 255),
            ui.new_label("AA", "Anti-aimbot angles", "On Hurt Color"),
            ui.new_color_picker("AA", "Anti-aimbot angles", "Hurt Logs Color", 166, 160, 220, 255),
        },
        trashtalk = {
            ui.new_checkbox("AA", "Anti-aimbot angles", "Trashtalk"),
            ui.new_multiselect("AA", "Anti-aimbot angles", {"\n", "Trashtalk"}, {"Kill", "Death", "Killer Death"}),
            ui.new_multiselect("AA", "Anti-aimbot angles", "Trashtalk Type", {"Instant", "Sentences"}),
        },
        buybot = {
            ui.new_checkbox("AA", "Anti-aimbot angles", "Buybot"),
            ui.new_combobox("AA", "Anti-aimbot angles", "Primary", {"AWP", "Scout", "Auto"}),
            ui.new_combobox("AA", "Anti-aimbot angles", "Secondary", {"Deagle/R8", "FS/T-9", "P250", "Berreta"}),
            ui.new_multiselect("AA", "Anti-aimbot angles", "Tollie", {"Kevlar", "Helmet", "Defuser", "Zeus", "Fire", "HE", "Smoky"}),
        },
    },
    ["Manipulations"] = {
            uistyle = {
                ui.new_combobox("AA", "Anti-aimbot angles", "UI Style", {"Skeet", "晨花", "Methamod", "Stasis", "Astral"}),
                ui.new_checkbox("AA", "Anti-aimbot angles", "Gradient UI"),
                ui.new_color_picker("AA", "Anti-aimbot angles", "UI Style", 120, 150, 200, 255),
                ui.new_checkbox("AA", "Anti-aimbot angles", "Glow UI"),
            },
            keynames = {
                ui.new_listbox("AA", "Anti-aimbot angles", "Keybinds names", visuals.keynames),
                ui.new_label("AA", "Anti-aimbot angles", "Current name: Double Tap"),
                ui.new_textbox("AA", "Anti-aimbot angles", "Custom name"),
                ui.new_button("AA", "Anti-aimbot angles", "Apply name", function()end),
                ui.new_button("AA", "Anti-aimbot angles", "Restore name", function()end),
            },
    },
    ["Configs"] = {
        configbox = ui.new_listbox("AA", "Anti-aimbot angles", "Configs", ""),
        textbox = ui.new_textbox("AA", "Anti-aimbot angles", "Config Name"),
        onlyload = ui.new_multiselect("AA", "Anti-aimbot angles", "Only load", {"All", "Anti-Aim", "Visuals", "Misc", "Rage"}),
        loadcfg = ui.new_button("AA", "Anti-aimbot angles", "Load Config",  function()end),
        savecfg = ui.new_button("AA", "Anti-aimbot angles", "Save Config", function()end),
        deletecfg = ui.new_button("AA", "Anti-aimbot angles", "Delete Config", function()end),
        importcfg = ui.new_button("AA", "Anti-aimbot angles", "Import Config",  function()end),
        exportcfg = ui.new_button("AA", "Anti-aimbot angles", "Export Config", function()end),
        restorecfg = ui.new_button("AA", "Anti-aimbot angles", "Restore Config", function()end),
    }
}

-- Ensure 'Only load' behaves correctly: default empty; if 'All' + others, drop 'All'
ui.set(tabs["Configs"].onlyload, {})
ui.set_callback(tabs["Configs"].onlyload, function(id)
    local sel = ui.get(id) or {}
    local has_all = false
    for _, v in ipairs(sel) do if v == "All" then has_all = true break end end
    if has_all and #sel > 1 then
        -- remove 'All' and keep specific selections
        local filtered = {}
        for _, v in ipairs(sel) do if v ~= "All" then table.insert(filtered, v) end end
        ui.set(id, filtered)
    end
end)

for _, name in ipairs(antiaims.conds) do
    local tbh;
    if name ~= "Shared" then
        tbh = ui.new_checkbox("AA", "Anti-aimbot angles", "Override "..name:lower())
    end
    tabs["Anti-Aimbot"][name] = {
            override = tbh,
            fakelag = ui.new_combobox("AA", "Anti-aimbot angles", name.." ⮞ Fake lag type", antiaims.fakelagbox),
            fakelaglimit = ui.new_slider("AA", "Anti-aimbot angles", name.." ⮞ Fake lag limit", 1, 15, 14, true, nil, 1, nil),
            fakelagc = {
                ["Maximum"] = {ui.new_slider("AA", "Anti-aimbot angles", name.." ⮞ Maximum Variance", 0, 100, 0, true, "%", 1, nil)},
                ["Dynamic"] = {ui.new_slider("AA", "Anti-aimbot angles", name.." ⮞ Dynamic Variance", 0, 100, 0, true, "%", 1, nil)},
                ["Fluctuate"] = {ui.new_slider("AA", "Anti-aimbot angles", name.." ⮞ Fluctuate Variance", 0, 100, 0, true, "%", 1, nil)},
                ["Random"] = {ui.new_slider("AA", "Anti-aimbot angles", name.."  Random Variance", 0, 100, 0, true, "%", 1, nil)},
                ["Fluctuate v2"] = {
                    ui.new_slider("AA", "Anti-aimbot angles", name.." ⮞ Fluctuate v2 Variance", 0, 100, 0, true, "%", 1, nil),
                    ui.new_slider("AA", "Anti-aimbot angles", name.." ⮞ Fluctuate Min", 1, 15, 1, true, nil, 1, nil),
                },
                ["Jitter"] = {
                    ui.new_slider("AA", "Anti-aimbot angles", name.." ⮞ Lag Jitter Offset", 1, 15, 1, true, nil, 1, nil),
                },
            },
            pitch = ui.new_combobox("AA", "Anti-aimbot angles", name.." ⮞ Pitch", antiaims.pitchbox),
            pitchc = {ui.new_slider("AA", "Anti-aimbot angles", name.." ⮞ Custom Pitch", -89, 89, 0, true, "°", 1, nil)},
            yaw_base = ui.new_combobox("AA", "Anti-aimbot angles", name.." ⮞ Yaw base", antiaims.basebox),
            yaw = ui.new_combobox("AA", "Anti-aimbot angles", name.." ⮞ Yaw", antiaims.yawbox),
            yawc = {
                ["180"] = ui.new_slider("AA", "Anti-aimbot angles", name.." ⮞ 180", -180, 180, 0, true, "°", 1, nil),
                ["Spin"] = ui.new_slider("AA", "Anti-aimbot angles", name.." ⮞ Spin", -180, 180, 0, true, "°", 1, nil),
                ["Static"] = ui.new_slider("AA", "Anti-aimbot angles", name.." ⮞ Static yaw", -180, 180, 0, true, "°", 1, nil),
                ["L&R"] = {
                    ui.new_slider("AA", "Anti-aimbot angles", name.." ⮞ Left yaw", -180, 180, 0, true, "°", 1, nil),
                    ui.new_slider("AA", "Anti-aimbot angles", name.." ⮞ Right yaw", -180, 180, 0, true, "°", 1, nil),
                    ui.new_slider("AA", "Anti-aimbot angles", name.." ⮞ Yaw random", 0, 100, 0, true, "%", 1, nil),
                },
                ["Delayed"] = {
                    ui.new_slider("AA", "Anti-aimbot angles", name.." ⮞ Offset 1", -180, 180, 0, true, "°", 1, nil),
                    ui.new_slider("AA", "Anti-aimbot angles", name.." ⮞ Offset 2", -180, 180, 0, true, "°", 1, nil),
                    ui.new_slider("AA", "Anti-aimbot angles", name.." ⮞ Delay ticks", 1, 14, 1, true, "t", 1, nil),
                },
            },
            yaw_jitter = ui.new_combobox("AA", "Anti-aimbot angles", name.." ⮞ Yaw jitter", antiaims.jitterbox),
            yaw_jitterc = {
                ["Offset"] = ui.new_slider("AA", "Anti-aimbot angles", name.." ⮞ Offset", -180, 180, 0, true, "°", 1, nil),
                ["Center"] = {
                    ui.new_slider("AA", "Anti-aimbot angles", name.." ⮞ Center", -180, 180, 0, true, "°", 1, nil),
                    ui.new_slider("AA", "Anti-aimbot angles", name.." ⮞ Center min ticks", 1, 14, 3, true, "t", 1, nil),
                    ui.new_slider("AA", "Anti-aimbot angles", name.." ⮞ Center max ticks", 1, 14, 10, true, "t", 1, nil),
                },
                ["Skitter"] = ui.new_slider("AA", "Anti-aimbot angles", name.." ⮞ Skitter", -180, 180, 0, true, "°", 1, nil),
                ["Random"] = ui.new_slider("AA", "Anti-aimbot angles", name.." ⮞ Random", -180, 180, 0, true, "°", 1, nil),
                ["Nway"] = {
                    ui.new_slider("AA", "Anti-aimbot angles", name.." ⮞ Yaw N", 3, 18, 3, true, nil, 1, nil),
                    ui.new_slider("AA", "Anti-aimbot angles", name.." ⮞ Nway angle", 0, 180, 0, true, "°", 1, nil),
                    ui.new_slider("AA", "Anti-aimbot angles", name.." ⮞ Nway delay", 1, 14, 1, true, "t", 1, nil),
                },
                ["Min/Max Center"] = {
                    ui.new_slider("AA", "Anti-aimbot angles", name.." ⮞ Min/Max Center min", -180, 180, 0, true, "°", 1, nil),
                    ui.new_slider("AA", "Anti-aimbot angles", name.." ⮞ Min/Max Center max", -180, 180, 0, true, "°", 1, nil),
                    ui.new_slider("AA", "Anti-aimbot angles", name.." ⮞ Min/Max Center speed", 25, 500, 100, true, "x", 0.01, nil),
                    ui.new_slider("AA", "Anti-aimbot angles", name.." ⮞ Min/Max Center tick", 1, 14, 1, true, "t", 1, nil),
                },
                ["L&R Center"] = {
                    ui.new_slider("AA", "Anti-aimbot angles", name.." ⮞ Left center", -180, 180, 0, true, "°", 1, nil),
                    ui.new_slider("AA", "Anti-aimbot angles", name.." ⮞ Right center", -180, 180, 0, true, "°", 1, nil),
                    ui.new_slider("AA", "Anti-aimbot angles", name.." ⮞ Center random", 0, 100, 0, true, "%", 1, nil),
                },
                ["Custom Center"] = {
                    ui.new_slider("AA", "Anti-aimbot angles", name.." ⮞ Custom center", -180, 180, 0, true, "°", 1, nil),
                    ui.new_slider("AA", "Anti-aimbot angles", name.." ⮞ Custom center random", 0, 100, 0, true, "%", 1, nil),
                    ui.new_slider("AA", "Anti-aimbot angles", name.." ⮞ Custom center delay", 1, 14, 1, true, "t", 1, nil),
                },
                ["Custom Offset"] = {
                    ui.new_slider("AA", "Anti-aimbot angles", name.." ⮞ Custom Offset", -180, 180, 0, true, "°", 1, nil),
                    ui.new_slider("AA", "Anti-aimbot angles", name.." ⮞ Custom Offset random", 0, 100, 0, true, "%", 1, nil),
                    ui.new_slider("AA", "Anti-aimbot angles", name.." ⮞ Custom Offset delay", 1, 14, 1, true, "t", 1, nil),
                },
            },
            body_yaw = ui.new_combobox("AA", "Anti-aimbot angles", name.." ⮞ Body yaw", antiaims.bodybox),
            body_yawc = {
                ["Static"] = ui.new_slider("AA", "Anti-aimbot angles", name.." ⮞ Static", -60, 60, 0, true, "°", 1, nil),
                ["Jitter"] = ui.new_slider("AA", "Anti-aimbot angles", name.." ⮞ Jitter angle", -60, 60, 0, true, "°", 1, nil),
                ["Sway"] = {
                    ui.new_slider("AA", "Anti-aimbot angles", name.." ⮞ Sway min", -60, 60, 0, true, "°", 1, nil),
                    ui.new_slider("AA", "Anti-aimbot angles", name.." ⮞ Sway max", -60, 60, 0, true, "°", 1, nil),
                    ui.new_slider("AA", "Anti-aimbot angles", name.." ⮞ Sway ticks", 1, 8, 0, true, "t", 1, nil),
                },
                ["Custom Jitter"] = {
                    ui.new_slider("AA", "Anti-aimbot angles", name.." ⮞ Custom Jitter angle", -60, 60, 0, true, "°", 1, nil),
                    ui.new_slider("AA", "Anti-aimbot angles", name.." ⮞ Custom Jitter ticks", 1, 14, 1, true, "t", 1, nil),
                    ui.new_slider("AA", "Anti-aimbot angles", name.." ⮞ Custom Jitter random", 0, 14, 0, true, "t", 1, nil),
                    ui.new_slider("AA", "Anti-aimbot angles", name.." ⮞ Delay Ticks", 8, 64, 14, true, "t", 1, nil),
                },
                ["Jitter v2"] = {
                    ui.new_slider("AA", "Anti-aimbot angles", name.." ⮞ Jitter v2 angle", 0, 60, 0, true, "°", 1, nil),
                    ui.new_slider("AA", "Anti-aimbot angles", name.." ⮞ Jitter v2 ticks", 1, 14, 1, true, "t", 1, nil),
                },
                ["Static v2"] = ui.new_slider("AA", "Anti-aimbot angles", name.." ⮞ Static v2 angle", -60, 60, 0, true, "°", 1, nil),
            },
            body_yaw_freestand = ui.new_checkbox("AA", "Anti-aimbot angles", name.." ⮞ Freestanding body yaw"),
        }
    if name ~= "Fakelags" and name ~= "Duckpeek" then
        tabs["Anti-Aimbot"][name].force_def = ui.new_combobox("AA", "Anti-aimbot angles", name.." ⮞ Force Defensive", antiaims.defforcebox)
        tabs["Anti-Aimbot"][name].defensive = {
                enable = ui.new_checkbox("AA", "Anti-aimbot angles", name.." ⮞ Defensive AA"),
                pitch = ui.new_combobox("AA", "Anti-aimbot angles", name.." ⮞ Defensive Pitch", antiaims.defpitchbox),
                pitchc = {
                    ["Custom"] = ui.new_slider("AA", "Anti-aimbot angles", name.." ⮞ Custom Defensive Pitch", -89, 89, 0, true, "°", 1, nil),
                    ["Random v2"] = {
                        ui.new_slider("AA", "Anti-aimbot angles", name.." ⮞ Random Pitch Min", -89, 89, 0, true, "°", 1, nil),
                        ui.new_slider("AA", "Anti-aimbot angles", name.." ⮞ Random Pitch Max", -89, 89, 0, true, "°", 1, nil),
                    },
                    ["Fluctate"] = {
                        ui.new_checkbox("AA", "Anti-aimbot angles", name.." ⮞ Fluctate one way"),
                        ui.new_slider("AA", "Anti-aimbot angles", name.." ⮞ Fluctate Offset 1", -89, 89, 0, true, "°", 1, nil),
                        ui.new_slider("AA", "Anti-aimbot angles", name.." ⮞ Fluctate Offset 2", -89, 89, 0, true, "°", 1, nil),
                        ui.new_slider("AA", "Anti-aimbot angles", name.." ⮞ Fluctate Speed", 1, 100, 50, true, "%", 1, nil),
                    },
                    ["Jitter"] = {
                        ui.new_slider("AA", "Anti-aimbot angles", name.." ⮞ Offset Pitch 1", -89, 89, 0, true, "°", 1, nil),
                        ui.new_slider("AA", "Anti-aimbot angles", name.." ⮞ Offset Pitch 2", -89, 89, 0, true, "°", 1, nil),
                    },
                    ["L&R"] = {
                        ui.new_slider("AA", "Anti-aimbot angles", name.." ⮞ Pitch Left", -89, 89, 0, true, "°", 1, nil),
                        ui.new_slider("AA", "Anti-aimbot angles", name.." ⮞ Pitch Right", -89, 89, 0, true, "°", 1, nil),
                    },
                },
                yaw = ui.new_combobox("AA", "Anti-aimbot angles", name.." ⮞ Defensive Yaw", antiaims.defyawbox),
                yawc = {
                    ["180"] = ui.new_slider("AA", "Anti-aimbot angles", name.." ⮞ Defensive 180", -180, 180, 0, true, "°", 1, nil),
                    ["Spin"] = ui.new_slider("AA", "Anti-aimbot angles", name.." ⮞ Defensive Spin", -180, 180, 0, true, "°", 1, nil),
                    ["Spin v2"] = {
                        ui.new_slider("AA", "Anti-aimbot angles", name.." ⮞ Spin Offset 1", -180, 180, 0, true, "°", 1, nil),
                        ui.new_slider("AA", "Anti-aimbot angles", name.." ⮞ Spin Offset 2", -180, 180, 0, true, "°", 1, nil),
                        ui.new_slider("AA", "Anti-aimbot angles", name.." ⮞ Spin Speed", 1, 100, 50, true, "%", 1, nil),
                    },
                    ["Random"] = {
                        ui.new_slider("AA", "Anti-aimbot angles", name.." ⮞ Random Offset 1", -180, 180, 0, true, "°", 1, nil),
                        ui.new_slider("AA", "Anti-aimbot angles", name.." ⮞ Random Offset 2", -180, 180, 0, true, "°", 1, nil),
                    },
                    ["Opposite"] = ui.new_slider("AA", "Anti-aimbot angles", name.." ⮞ Defensive Opposite", 0, 180, 90, true, "°", 1, nil),
                    ["Jitter"] = {
                        ui.new_slider("AA", "Anti-aimbot angles", name.." ⮞ Yaw Offset 1", -180, 180, 0, true, "°", 1, nil),
                        ui.new_slider("AA", "Anti-aimbot angles", name.." ⮞ Yaw Offset 2", -180, 180, 0, true, "°", 1, nil),
                    },
                    ["L&R"] = {
                        ui.new_slider("AA", "Anti-aimbot angles", name.." ⮞ Yaw Left", -180, 180, 0, true, "°", 1, nil),
                        ui.new_slider("AA", "Anti-aimbot angles", name.." ⮞ Yaw Right", -180, 180, 0, true, "°", 1, nil),
                    },
                },
                point_180 = ui.new_checkbox("AA", "Anti-aimbot angles", name.." ⮞ Point at enemy (180)"),
                tick = ui.new_slider("AA", "Anti-aimbot angles", name.." ⮞ Defensive Tick", 1, 14, 1, true, "t", 1, nil),
            }
            tabs["Anti-Aimbot"][name].def_flick = {ui.new_checkbox("AA", "Anti-aimbot angles", name.." ⮞ Defensive Flick"),}
        end
end

-- Side-Specific AA Button (created after all conditions are defined)
tabs["Anti-Aimbot"].copy_to_opposite_team = ui.new_button("AA", "Anti-aimbot angles", "Copy to Opposite Team", function() end)

ui.set(tabs["Configs"].textbox, "Default")

-- Load hitlogger position
hitlogger.x = database.read("osmanhook::hitlogger_x") or 300
hitlogger.y = database.read("osmanhook::hitlogger_y") or 100

tabs["Anti-Aimbot"].team_anti_aim_btn = ui.new_button("AA", "Anti-aimbot angles", "Team Anti-Aim", function()
    ui.set_visible(tabs["Anti-Aimbot"].team_anti_aim.enabled, true)
    ui.set_visible(tabs["Anti-Aimbot"].team_anti_aim.ct_settings[1], true)
    ui.set_visible(tabs["Anti-Aimbot"].team_anti_aim.ct_settings.pitch, true)
    ui.set_visible(tabs["Anti-Aimbot"].team_anti_aim.ct_settings.pitch_custom, true)
    ui.set_visible(tabs["Anti-Aimbot"].team_anti_aim.ct_settings.yaw, true)
    ui.set_visible(tabs["Anti-Aimbot"].team_anti_aim.ct_settings.yaw_custom, true)
    ui.set_visible(tabs["Anti-Aimbot"].team_anti_aim.ct_settings.yaw_jitter, true)
    ui.set_visible(tabs["Anti-Aimbot"].team_anti_aim.ct_settings.yaw_jitter_custom, true)
    ui.set_visible(tabs["Anti-Aimbot"].team_anti_aim.ct_settings.body_yaw, true)
    ui.set_visible(tabs["Anti-Aimbot"].team_anti_aim.ct_settings.body_yaw_custom, true)
    ui.set_visible(tabs["Anti-Aimbot"].team_anti_aim.ct_settings.fakelag, true)
    ui.set_visible(tabs["Anti-Aimbot"].team_anti_aim.ct_settings.fakelag_limit, true)
    ui.set_visible(tabs["Anti-Aimbot"].team_anti_aim.ct_settings.fakelag_variance, true)
    
    ui.set_visible(tabs["Anti-Aimbot"].team_anti_aim.t_settings[1], true)
    ui.set_visible(tabs["Anti-Aimbot"].team_anti_aim.t_settings.pitch, true)
    ui.set_visible(tabs["Anti-Aimbot"].team_anti_aim.t_settings.pitch_custom, true)
    ui.set_visible(tabs["Anti-Aimbot"].team_anti_aim.t_settings.yaw, true)
    ui.set_visible(tabs["Anti-Aimbot"].team_anti_aim.t_settings.yaw_custom, true)
    ui.set_visible(tabs["Anti-Aimbot"].team_anti_aim.t_settings.yaw_jitter, true)
    ui.set_visible(tabs["Anti-Aimbot"].team_anti_aim.t_settings.yaw_jitter_custom, true)
    ui.set_visible(tabs["Anti-Aimbot"].team_anti_aim.t_settings.body_yaw, true)
    ui.set_visible(tabs["Anti-Aimbot"].team_anti_aim.t_settings.body_yaw_custom, true)
    ui.set_visible(tabs["Anti-Aimbot"].team_anti_aim.t_settings.fakelag, true)
    ui.set_visible(tabs["Anti-Aimbot"].team_anti_aim.t_settings.fakelag_limit, true)
    ui.set_visible(tabs["Anti-Aimbot"].team_anti_aim.t_settings.fakelag_variance, true)
end)

local team_mapping = {
    ["Counter-Terrorists"] = "ct",
    ["Terrorists"] = "t"
}

local side_specific_configs = {}
for _, condition in pairs(antiaims.conds) do
    side_specific_configs[condition] = {
        ct = {},
        t = {}
    }
end

local team_auto_detector = {
    last_check = 0,
    check_interval = 0.1,
    last_detected_team = nil,
    last_selected_team = nil,
    config_mode = false
}

local function save_current_settings_to_team(condition, team_display)
    if not tabs["Anti-Aimbot"][condition] then return end
    
    local team = team_mapping[team_display] or team_display
    local config = tabs["Anti-Aimbot"][condition]
    side_specific_configs[condition][team] = {}
    for key, control in pairs(config) do
        if type(control) == "number" then
            side_specific_configs[condition][team][key] = ui.get(control)
        elseif type(control) == "table" and control[1] then
            side_specific_configs[condition][team][key] = ui.get(control[1])
        end
    end
end

local function load_team_settings(condition, team_display)
    if not tabs["Anti-Aimbot"][condition] then return end
    
    local team = team_mapping[team_display] or team_display
    if not side_specific_configs[condition][team] then return end
    
    local config = tabs["Anti-Aimbot"][condition]
    local saved_settings = side_specific_configs[condition][team]
    
    for key, value in pairs(saved_settings) do
        if config[key] then
            if type(config[key]) == "number" then
                ui.set(config[key], value)
            elseif type(config[key]) == "table" and config[key][1] then
                ui.set(config[key][1], value)
            end
        end
    end
end

local function auto_detect_and_update_team()
    if not ui.get(tabs["Anti-Aimbot"].side_specific_enabled) then return end
    if team_auto_detector.config_mode then return end
    
    local current_time = globals.realtime()
    
    if current_time - team_auto_detector.last_check >= team_auto_detector.check_interval then
        team_auto_detector.last_check = current_time
        
        local detected_team = antiaims.team_detection()
        
        if detected_team ~= "Unknown" then
            local team_lowercase = detected_team:lower()
            local team_display = team_lowercase == "ct" and "Counter-Terrorists" or "Terrorists"
            
            if team_auto_detector.last_detected_team ~= team_lowercase then
                team_auto_detector.last_detected_team = team_lowercase
                
                local current_dropdown_team = ui.get(tabs["Anti-Aimbot"].side_specific_team)
                if current_dropdown_team ~= team_display then
                    if team_auto_detector.last_selected_team then
                        local current_condition = ui.get(tabs["Anti-Aimbot"].condition)
                        save_current_settings_to_team(current_condition, team_auto_detector.last_selected_team)
                    end
                    
                    ui.set(tabs["Anti-Aimbot"].side_specific_team, team_display)
                    team_auto_detector.last_selected_team = team_display
                    
                    local current_condition = ui.get(tabs["Anti-Aimbot"].condition)
                    load_team_settings(current_condition, team_display)
                end
            end
        end
    end
end

local function setup_auto_save_callbacks()
    for _, condition in pairs(antiaims.conds) do
        if tabs["Anti-Aimbot"][condition] then
            for key, control in pairs(tabs["Anti-Aimbot"][condition]) do
                if type(control) == "number" then
                    ui.set_callback(control, function()
                        if ui.get(tabs["Anti-Aimbot"].side_specific_enabled) then
                            local current_team = ui.get(tabs["Anti-Aimbot"].side_specific_team)
                            save_current_settings_to_team(condition, current_team)
                        end
                    end)
                elseif type(control) == "table" and control[1] then
                    ui.set_callback(control[1], function()
                        if ui.get(tabs["Anti-Aimbot"].side_specific_enabled) then
                            local current_team = ui.get(tabs["Anti-Aimbot"].side_specific_team)
                            save_current_settings_to_team(condition, current_team)
                        end
                    end)
                end
            end
        end
    end
end

-- Setup button callbacks after all functions are defined
ui.set_callback(tabs["Anti-Aimbot"].copy_to_opposite_team, function()
    local current_team = ui.get(tabs["Anti-Aimbot"].side_specific_team)
    local current_condition = ui.get(tabs["Anti-Aimbot"].condition)
    local opposite_team = current_team == "Counter-Terrorists" and "Terrorists" or "Counter-Terrorists"
    
    save_current_settings_to_team(current_condition, current_team)
    
    local current_team_internal = team_mapping[current_team]
    local opposite_team_internal = team_mapping[opposite_team]
    
    if side_specific_configs[current_condition] and side_specific_configs[current_condition][current_team_internal] then
        side_specific_configs[current_condition][opposite_team_internal] = {}
        for key, value in pairs(side_specific_configs[current_condition][current_team_internal]) do
            side_specific_configs[current_condition][opposite_team_internal][key] = value
        end
    end
end)

setup_auto_save_callbacks()

ui.set(tabs["Anti-Aimbot"].side_specific_enabled, false)
ui.set_visible(tabs["Anti-Aimbot"].side_specific_team, false)
ui.set_visible(tabs["Anti-Aimbot"].copy_to_opposite_team, false)

team_auto_detector.last_selected_team = ui.get(tabs["Anti-Aimbot"].side_specific_team)

ui.set_callback(tabs["Anti-Aimbot"].side_specific_enabled, function()
    local aa_enabled = ui.get(tabs["Anti-Aimbot"][1])
    local side_specific = ui.get(tabs["Anti-Aimbot"].side_specific_enabled)
    ui.set_visible(tabs["Anti-Aimbot"].side_specific_team, aa_enabled and side_specific)
    ui.set_visible(tabs["Anti-Aimbot"].copy_to_opposite_team, aa_enabled and side_specific)
end)

ui.set_callback(tabs["Anti-Aimbot"].side_specific_team, function()
    if not ui.get(tabs["Anti-Aimbot"].side_specific_enabled) then return end
    
    team_auto_detector.config_mode = true
    
    local current_condition = ui.get(tabs["Anti-Aimbot"].condition)
    local new_team = ui.get(tabs["Anti-Aimbot"].side_specific_team)
    
    if team_auto_detector.last_selected_team and team_auto_detector.last_selected_team ~= new_team then
        save_current_settings_to_team(current_condition, team_auto_detector.last_selected_team)
    end
    
    team_auto_detector.last_selected_team = new_team
    
    load_team_settings(current_condition, new_team)
    
    client.delay_call(10, function()
        team_auto_detector.config_mode = false
    end)
end)

ui.set_callback(tabs["Anti-Aimbot"].condition, function()
    if not ui.get(tabs["Anti-Aimbot"].side_specific_enabled) then return end
    
    local current_team = ui.get(tabs["Anti-Aimbot"].side_specific_team)
    local new_condition = ui.get(tabs["Anti-Aimbot"].condition)
    
    load_team_settings(new_condition, current_team)
end)


ui.set_callback(ui.reference("Misc", "Settings", "Menu color"), function()
    utils.logoc = utils.menu_col()
    utils.logoh = string.format('\a%02x%02x%02xFF', utils.logoc[1], utils.logoc[2], utils.logoc[3])
end)
utils.animmain = function()
    local iswhite = utils.logoc[1] == utils.logoc[2] and utils.logoc[2] == utils.logoc[3]
    local offset = 50
    local seccol = iswhite and {55, 55, 55} or {utils.logoc[1] >= offset and utils.logoc[1] - offset or utils.logoc[1] + offset, utils.logoc[2] >= offset and utils.logoc[2] - offset or utils.logoc[2] + offset, utils.logoc[3] >= offset and utils.logoc[3] - offset or utils.logoc[3] + offset}
    ui.set(tabs["Main"][1], utils.fade_anim(-0.5, utils.logoc, seccol, "osmanhook.lua"..(_BETA and " [BETA]" or " [STABLE]")))
    ui.set(tabs["Main"][2], "Version: "..utils.fade_anim(-0.5, utils.logoc, seccol, utils.split_num(_VER, ".")))
    local steam_username = panorama.open("CSGOHud").MyPersonaAPI.GetName()
    ui.set(tabs["Main"][3], "Username: "..utils.fade_anim(-0.5, utils.logoc, seccol, steam_username))
end
--region @tabs end
--region @cfg
utils.keypos = database.read("expensive::keypos") or {x = 0, y = screen.y*0.5}
utils.specpos = database.read("expensive::specpos") or {x = screen.x*0.1, y = screen.y*0.2}
utils.get_config = function(tabl)
    local config = {}
    for key, val in pairs(tabl) do
        if key == "Configs" or key == "Main" then goto skip end
        config[key] = utils.get_table(val)
        ::skip::
    end
    config["User"] = _USER
    config["ID"] = client.unix_time()
    config["Version"] = _VER
    config["utils.keypos"] = utils.keypos
    config["utils.specpos"] = utils.specpos
    return json.stringify(config)
end
cfg.names = database.read("expensive::cfg_names") or {"Default"}
-- colorize Default (green 98FBB8FF) and Experimental (red FB9898FF) in the Configs listbox
local function cfg_colored_name(name)
    if name == "Default" then
        return "\a98FBB8FFDefault"
    elseif name == "Experimental" then
        return "\aFB9898FFExperimental"
    elseif name == "Experimental #2" then
        return "\a98C8FBFFExperimental #2"
    else
        return name
    end
end

cfg.update_listbox = function()
    local display = {}
    for i, n in ipairs(cfg.names) do
        display[i] = cfg_colored_name(n)
    end
    ui.update(tabs["Configs"].configbox, display)
end

utils.set_cfg = function(cfg_tbl, tab)
    local tab = tab or tabs
    if cfg_tbl == nil then return end
    if type(tab) == "number" and ui.type(tab) ~= "label" then
        if ui.type(tab) == "color_picker" then
            if type(cfg_tbl) == "table" then
                ui.set(tab, unpack(cfg_tbl))
            elseif type(cfg_tbl) == "string" then
                local nums = {}
                for n in string.gmatch(cfg_tbl, "%d+") do
                    nums[#nums+1] = tonumber(n)
                end
                if #nums >= 3 then
                    ui.set(tab, nums[1], nums[2], nums[3], nums[4] or 255)
                end
            end
        elseif ui.type(tab) == "hotkey" then
            ui.set(tab, cfg_tbl[2], cfg_tbl[3]) 
        elseif ui.type(tab) == "textbox" then
            if cfg_tbl ~= nil and type(cfg_tbl) == "string" and string.len(cfg_tbl) > 0 then
                ui.set(tab, cfg_tbl)
            end
        elseif ui.type(tab) == "checkbox" then
            if type(cfg_tbl) ~= "boolean" then
                local v = cfg_tbl
                if type(v) == "string" then
                    v = (v == "true" or v == "True" or v == "on" or v == "On" or v == "1")
                elseif type(v) == "number" then
                    v = v ~= 0
                else
                    v = not not v
                end
                ui.set(tab, v)
            else
                ui.set(tab, cfg_tbl)
            end
        elseif ui.type(tab) == "combobox" then
            local v = cfg_tbl
            if type(v) == "table" then v = v[1] end
            if v ~= nil then pcall(ui.set, tab, v) end
        elseif ui.type(tab) == "multiselect" then
            local list = {}
            if type(cfg_tbl) == "table" then
                for _, v in ipairs(cfg_tbl) do list[#list+1] = v end
            elseif type(cfg_tbl) == "string" then
                for s in string.gmatch(cfg_tbl, "([^,]+)") do
                    local trimmed = (s:gsub("^%s+", ""):gsub("%s+$", ""))
                    if trimmed ~= "" then list[#list+1] = trimmed end
                end
            end
            if #list > 0 then pcall(ui.set, tab, list) end
        elseif ui.type(tab) == "slider" then
            local v = cfg_tbl
            if type(v) == "table" then v = v[1] end
            if type(v) == "string" then v = tonumber(v) end
            if type(v) == "number" then pcall(ui.set, tab, v) end
        elseif ui.type(tab) ~= "listbox" then
            local function _try_set(v)
                return pcall(ui.set, tab, v)
            end
            if not _try_set(cfg_tbl) then
                if type(cfg_tbl) == "string" then
                    local num = tonumber(cfg_tbl)
                    if num ~= nil then
                        _try_set(num)
                    else
                        local t = {}
                        for s in string.gmatch(cfg_tbl, "([^,]+)") do
                            t[#t+1] = (s:gsub("^%s+", ""):gsub("%s+$", ""))
                        end
                        if #t > 0 then
                            _try_set(t)
                        end
                    end
                elseif type(cfg_tbl) == "number" or type(cfg_tbl) == "table" or type(cfg_tbl) == "boolean" then
                    _try_set(cfg_tbl)
                end
            end
        end
    elseif type(tab) == "table" and tab ~= tabs["Configs"] and tab ~= tabs["Main"] then
        for key, val in pairs(tab) do
            local next_cfg = nil
            if type(cfg_tbl) == "table" then
                if type(key) == "number" and cfg_tbl[key] == nil then
                    next_cfg = cfg_tbl[tostring(key)]
                else
                    next_cfg = cfg_tbl[key]
                end
            end
            if next_cfg ~= nil then
                utils.set_cfg(next_cfg, val)
            end
        end
    end
end
cfg.import = function()
	local function trim(s)
  		return type(s) == "string" and (s:gsub("^%s+", ""):gsub("%s+$", "")) or s
	end
  	local function extract_payload(s)
			if type(s) ~= "string" then return nil end
			s = trim(s)
			local payload = s:match("osmanhook:([%w+/=_-]+)")
			if not payload then
				local _, ind = s:find(":")
				if ind then payload = s:sub(ind + 1) end
			end
			if not payload then return nil end
			payload = payload:gsub("%s", "")
			payload = payload:match("^([%w+/=_-]+)")
			return payload
		end

	local rawcfg = clipboard.get()
	local payload = extract_payload(rawcfg)
	-- fallback to textbox content if clipboard doesn't contain payload and textbox has it
	if not payload then
		local tb = ui.get(tabs["Configs"].textbox)
		payload = extract_payload(tb)
	end

	if not payload then
		utils.printr(colors.red, "Invalid Config")
		return
	end

	payload = payload:gsub("-", "+"):gsub("_", "/")
	local m = #payload % 4
	if m > 0 then payload = payload .. string.rep("=", 4 - m) end
	local ok_dec, decoded = pcall(base64.decode, payload)
	if not ok_dec or not decoded then
		utils.printr(colors.red, "Failed to parse config")
		return
	end
	local success, parsedcfg = pcall(json.parse, decoded)
	if not success or not parsedcfg then
		utils.printr(colors.red, "Failed to parse config")
		return
	end
	if parsedcfg["Version"] ~= _VER then
		utils.printr(colors.red, "CFG Version mismatch current version: %s cfg version: %s", _VER, parsedcfg["Version"])
		return
	end
	local sel = tabs["Configs"].onlyload and ui.get(tabs["Configs"].onlyload) or {}
	local load_all = false
	for _, v in ipairs(sel) do if v == "All" then load_all = true break end end
	if load_all then
		utils.set_cfg(parsedcfg)
		utils.keypos = parsedcfg["utils.keypos"]
		utils.specpos = parsedcfg["utils.specpos"]
	else
		if #sel == 0 then
			utils.printr(colors.red, "Select categories in 'Only load' before importing.")
			return
  		end
  		for _, cat in ipairs(sel) do
  			if cat == "Anti-Aim" then
  				utils.set_cfg(parsedcfg["Anti-Aimbot"], tabs["Anti-Aimbot"])
  			elseif cat == "Visuals" then
  				utils.set_cfg(parsedcfg["Visuals"], tabs["Visuals"])
  			elseif cat == "Misc" then
  				utils.set_cfg(parsedcfg["Misc"], tabs["Misc"])
  			elseif cat == "Rage" then
  				utils.set_cfg(parsedcfg["Rage"], tabs["Rage"])
  			end
  		end
  	end
  	utils.printr(colors.skeet_logs, "Succesfuly loaded config by %s", parsedcfg["User"])
  end
 
local experimentalcfg = "YA3A3gIAAADxXcqSBAADAMImoll/AQAAAQABAHYT06QBBAADAOAnunACAAAAAQABANpHb5EBCAAHAP81QTxsAAAAAAAAAAQAAwCBDinFAQAAAAEAAQDrojetAQEAAQA4CJdTAQEAAQBwtrQlAQQABAC8xcK4n8OzxwEAAQAp78CWAQQAAwByEV9tAgAAAAQAAwDzCNTyAQAAAAQAAwDGiG1NAQAAAAQAAwDm0L2fDAAAACoBDAByOg0hYA3A3gIAAADxXcqSCAAHAJp/HoYCAAAAAAAAAAQAAwAiY+hlBgAAAAQAAwBUCJBb/gIAAAQAAwCgtKu/zgAAAAQAAwC6KVCiZAAAAAQAAwBTVV4/TQAAAAQAAwC+5sAYZAAAAAEAAQC0AwO4AQgABwBCobN+RgEAAAIAAAAEAAMA/hPEfQcAAAABAAEAOwug9QEEAAMANNG77PYCAAAEAAMAhRrJFg8AAAAIAAcAdJb1AlIAAAABAAAAAQABAOpIvZsBAQABAMzYb8ABBAADANlaGREdAAAAAQABAJ+TiQgBCAAHAG2YyWcYAAAAAwAAAAQAAwDd1+IxAQAAAAQAAwB8wWk/AAAAAAQAAwBI4FYrAQAAAAQAAwDm0L2fCAAAAAEAAQB2LiueAQkBDAAK4ZmVYA3A3gIAAADxXcqSAQABAMUOBiMBCAAHAJp/HoYCAAAAAAAAAAQAAwAiY+hlAwAAAAQAAwBUCJBbzgIAAAQAAwCgtKu/DgAAAAQAAwC6KVCiUwAAAAQAAwC+5sAYHQAAAAEAAQC0AwO4AQgABwBCobN+FgAAAAIAAAAEAAMA/hPEfQcAAAAEAAMAhRrJFg8AAAAIAAcAdJb1Am4AAAABAAAAAQABAMzYb8ABBAADANlaGRGcAAAAAQABAJ+TiQgBCAAHAG2YyWcYAAAAAgAAAAQAAwDd1+IxAQAAAAQAAwB8wWk/AAAAAAQAAwBI4FYrAQAAAAQAAwDm0L2fCAAAAAEAAQB2LiueARIBDACU1LGtYA3A3gIAAADxXcqSAQABAMUOBiMBCAAHAJp/HoZuAAAAAAAAAAQAAwAiY+hlAgAAAAQAAwBUCJBbzgIAAAQAAwCgtKu/DgAAAAQAAwC6KVCiUAAAAAQAAwC+5sAYDAAAAAEAAQC0AwO4AQgABwBCobN+IAEAAAIAAAAEAAMA/hPEfQcAAAABAAEAOwug9QEEAAMAhRrJFg8AAAAIAAcAdJb1Am4AAAABAAAAAQABAMzYb8ABBAADANlaGRGdAAAAAQABAJ+TiQgBCAAHAG2YyWdQAAAAAgAAAAQAAwDd1+IxAQAAAAQAAwB8wWk/AAAAAAQAAwBI4FYrAQAAAAQAAwDm0L2fDAAAAAEAAQB2LiueATMBDABjzMy9YA3A3gIAAADxXcqSAQABAMUOBiMBCAAHAJp/HoZuAAAAAAAAAAQAAwAiY+hlAgAAAAQAAwBUCJBbzgIAAAQAAwCgtKu/zgAAAAQAAwC6KVCiWAAAAAQAAwBTVV4/LgAAAAQAAwC+5sAYGwAAAAEAAQC0AwO4AQgABwBCobN+YAEAAAIAAAAEAAMA/hPEfQUAAAABAAEAOwug9QEEAAMANNG77AIAAAAEAAMAhRrJFgoAAAAIAAcAdJb1AkYBAAACAAAAAQABAOpIvZsBAQABAMzYb8ABBAADANlaGREcAAAAAQABAJ+TiQgBCAAHAG2YyWcYAAAAAQAAAAQAAwDd1+IxAQAAAAQAAwB8wWk/AAAAAAQAAwBI4FYrAQAAAAQAAwDm0L2fDAAAAAEAAQB2LiueAQkBDABXLLkrYA3A3gIAAADxXcqSAQABAMUOBiMBCAAHAJp/HoZuAAAAAAAAAAQAAwAiY+hlAgAAAAQAAwBUCJBb/gIAAAQAAwCgtKu/DgAAAAQAAwC6KVCiGQAAAAQAAwC+5sAYGAAAAAEAAQC0AwO4AQgABwBCobN+FAAAAAIAAAAEAAMA/hPEfQcAAAAEAAMAhRrJFg8AAAAIAAcAdJb1AlIAAAACAAAAAQABAMzYb8ABBAADANlaGRGdAAAAAQABAJ+TiQgBCAAHAG2YyWcYAAAAAwAAAAQAAwDd1+IxAQAAAAQAAwB8wWk/AAAAAAQAAwBI4FYrAQAAAAQAAwDm0L2fCAAAAAEAAQB2LiueAR4BDACApFyTYA3A3gIAAADxXcqSAQABAMUOBiMBCAAHAJp/HoZuAAAAAAAAAAQAAwAiY+hlAgAAAAQAAwBUCJBbzgAAAAQAAwCgtKu/DgAAAAQAAwC6KVCiGAAAAAQAAwBTVV4/KAAAAAQAAwC+5sAYDgAAAAEAAQC0AwO4AQgABwBCobN+EAAAAAEAAAAEAAMA/hPEfQEAAAABAAEAOwug9QEEAAMAhRrJFg8AAAAIAAcAdJb1Am4AAAABAAAAAQABAMzYb8ABBAADANlaGRGdAAAAAQABAJ+TiQgBCAAHAG2YyWcYAQAAAgAAAAQAAwDd1+IxAQAAAAQAAwB8wWk/MwAAAAQAAwBI4FYrAQAAAAQAAwDm0L2fDAAAAAEAAQB2LiueASEBDADBJz8sYA3A3gIAAADxXcqSCAAHAJp/HoZuAAAAAAAAAAQAAwAiY+hlAwAAAAQAAwBUCJBbzgIAAAQAAwCgtKu/DgAAAAQAAwC6KVCiZAAAAAQAAwBTVV4/SAAAAAQAAwC+5sAYMAAAAAEAAQC0AwO4AQgABwBCobN+FAAAAAIAAAAEAAMA/hPEfQcAAAABAAEAOwug9QEEAAMANNG77PwCAAABAAEAjVRUKwEEAAMAhRrJFgIAAAAIAAcAdJb1Am4AAAABAAAAAQABAMzYb8ABBAADANlaGREcAAAAAQABAJ+TiQgBCAAHAG2YyWcYAAAAAwAAAAQAAwDd1+IxAQAAAAQAAwB8wWk/MwAAAAQAAwBI4FYrAQAAAAQAAwDm0L2fDAAAACcBDADBaEENYA3A3gIAAADxXcqSAQABAMUOBiMBCAAHAJp/HoYCAAAAAAAAAAQAAwAiY+hlAgAAAAQAAwBUCJBb/gIAAAQAAwCgtKu/zgAAAAQAAwC6KVCiRgAAAAQAAwC+5sAYZAAAAAEAAQC0AwO4AQgABwBCobN+FAAAAAIAAAAEAAMA/hPEfQcAAAABAAEAOwug9QEEAAMANNG77PYCAAAEAAMAhRrJFg8AAAAIAAcAdJb1AlIAAAABAAAAAQABAOpIvZsBAQABAMzYb8ABBAADANlaGREdAAAAAQABAJ+TiQgBCAAHAG2YyWcaAAAAAwAAAAQAAwDd1+IxAQAAAAQAAwB8wWk/AAAAAAQAAwBI4FYrAQAAAAQAAwDm0L2fCAAAAAEAAQB2LiueATMBDABPTm8FYA3A3gIAAADxXcqSAQABAMUOBiMBCAAHAJp/HoYCAAAAAAAAAAQAAwAiY+hlBgAAAAQAAwBUCJBb/gIAAAQAAwCgtKu/zgAAAAQAAwC6KVCiSwAAAAQAAwBTVV4/TQAAAAQAAwC+5sAYZAAAAAEAAQC0AwO4AQgABwBCobN+RAEAAAIAAAAEAAMA/hPEfQcAAAABAAEAOwug9QEEAAMANNG77PYCAAAEAAMAhRrJFg8AAAAIAAcAdJb1AlIAAAABAAAAAQABAOpIvZsBAQABAMzYb8ABBAADANlaGREdAAAAAQABAJ+TiQgBCAAHAG2YyWcaAAAAAwAAAAQAAwDd1+IxAQAAAAQAAwB8wWk/AAAAAAQAAwBI4FYrAQAAAAQAAwDm0L2fCAAAAAEAAQB2LiueATwBDADF/vhFYA3A3gIAAADxXcqSAQABAMUOBiMBCAAHAJp/HoYCAAAAAAAAAAQAAwAiY+hlBgAAAAQAAwBUCJBbzgIAAAQAAwCgtKu/zgAAAAQAAwC6KVCiUAAAAAQAAwBTVV4/IgAAAAQAAwC+5sAYMgAAAAEAAQC0AwO4AQgABwBCobN+RAEAAAIAAAAEAAMA/hPEfQUAAAABAAEAOwug9QEEAAMANNG77MICAAABAAEAjVRUKwEEAAMAhRrJFgoAAAAIAAcAdJb1AlIAAAABAAAAAQABAOpIvZsBAQABAMzYb8ABBAADANlaGREcAAAAAQABAJ+TiQgBCAAHAG2YyWcYAAAAAwAAAAQAAwDd1+IxAQAAAAQAAwB8wWk/AAAAAAQAAwBI4FYrAQAAAAQAAwDm0L2fDAAAAAEAAQB2LiueATMBDABKFdOFYA3A3gIAAADxXcqSAQABAMUOBiMBCAAHAJp/HoZuAAAAAAAAAAQAAwAiY+hlAgAAAAQAAwBUCJBbzgIAAAQAAwCgtKu/DgAAAAQAAwC6KVCiRwAAAAQAAwBTVV4/PQAAAAQAAwC+5sAYZAAAAAEAAQC0AwO4AQgABwBCobN+FAAAAAIAAAAEAAMA/hPEfQIAAAABAAEAOwug9QEEAAMANNG77DICAAAEAAMAhRrJFgcAAAAIAAcAdJb1AlIAAAABAAAAAQABAOpIvZsBAQABAMzYb8ABBAADANlaGRGcAAAAAQABAJ+TiQgBCAAHAG2YyWcYAAAAAwAAAAQAAwDd1+IxAQAAAAQAAwB8wWk/AAAAAAQAAwBI4FYrAQAAAAQAAwDm0L2fCAAAAAEAAQB2LiueAfgADADOf4prYA3A3gIAAADxXcqSAQABAMUOBiMBCAAHAJp/HoYCAAAAAAAAAAQAAwAiY+hlAgAAAAQAAwBUCJBbDAAAAAQAAwC6KVCiGQAAAAQAAwC+5sAYZAAAAAgABwBCobN+FAAAAAIAAAAEAAMA/hPEfQgAAAABAAEAOwug9QEIAAcAvh08M2wAAAAAAAAABAADADTRu+zyAgAACAAHAHSW9QJuAAAAAAAAAAEAAQDM2G/AAQQAAwDZWhkRQAAAAAEAAQCfk4kIAQgABwBtmMlnGgAAAAMAAAAEAAMA3dfiMQEAAAAEAAMAfMFpPxkAAAAEAAMASOBWKwEAAAABAAEAek2z/QEBAAEAXLgNYgEBAAEAUcRi3AEBAAEAtetBSAEBAAEASKRxDAEBAAEAF6qB2QEBAAEAFw2E9gEBAAEAjXHh5gEBAAEAC+nSDwEBAAEAugS2UAEBAAEAbtT5nAEBAAEAPDO1mgEBAAEAe+y7+QEIAAcAUBjTd2wAAAACAAAAAQABAIdbytABCAAHAKfSPtL0AgAAAgAAAAgABwBOIrtbFAEAAAEAAAAIAAcAKt6TckAAAAABAAAAAQABACE3HUYBAQABACE+TiYBCAAHAOP8hTYSAAAAAgAAAAEAAQBAhV/TAQEAAQCugQeOAQEAAQBAXHFkAQEAAQAqIb1ZAQQAAwBUCJBbzgIAAAQAAwA00bvswgIAAAEAAQA7C6D1AQgABwCafx6GAgAAAAAAAAAIAAcAdJb1AlIAAAABAAAAAQABAMUOBiMBAQABABfjv4YBAQABAGAAZmMBAQABAMzYb8ABBAADANlaGREcAAAAAQABAI1UVCsBBAADAIUayRYKAAAABAADAHzBaT8AAAAAAQABAHYuK54BAQABAIe8R9MBAQABACCj8tQBBAADAGmpveAEAAAABAADAMq2xLMDAAAAAQABAAhJYw0BAQABACd0RrIBCAAHAJE8T48UAAAAAgAAAAQAAwBI4FYrAQAAAAgABwBXIneubAAAAAEAAAABAAEAn5OJCAEIAAcAbZjJZxoAAAADAAAABAADAN3X4jEBAAAABAADAE9aIvxsAAAABAADAO35gMooAAAAAQABAPW8hlABCAAHAPDM/+J4AwAAAQAAAAEAAQCGE6Y3AQEAAQC5G0zcAQQABAD5+CiEn8OysQQABAAfHGHCut55swEAAQBBo72FAQEAAQAf756WAQEAAQDpievyAQQAAwCbzGpvAwAAAAQAAwALX0zJMgAAAAEAAQDRSua1AQgABwA2GSxxeAMAAAMAAAAIAAcAd55JK3oDAAABAAAAAQABAKFyIdsBAQABAMp40kwBAQABAP+U800BAQABAKvaP/4BAQABAAnBE4wBAQABADeQHBQBCAAHACmAF+xIAAAAAQAAAAQAAwAz/GdPAQAAAAQABABLvvzJ/wAA/wQAAwCq5LhMmQAAAAQAAwD81XEqAgAAAAQAAwAR73/xBwAAAAQABADHXE5uo/+5AAQAAwBTVV4/IgAAAAQAAwAiY+hlBgAAAAQAAwC+5sAYMgAAAAEAAQC0AwO4AQgABwBCobN+RAEAAAIAAAAEAAMA/hPEfQUAAAAEAAMAuilQolAAAAAEAAMAoLSrv84AAAAEAAMAte1GQwQAAAABAAEA9ZVQUwEEAAQAVeFRdOUAAM4BAAEA6ki9mwEBAAEAJuBdPQEIAAcA3sI8R0oBAAABAAAAAQABAO4JWXoBAQABAOJMMS4BBAADAJt1Qx0BAAAABAADAJK2pNz2////EAAGAL1U/Y0BAAAAAAAAACMAAAA8AAAAGAAGAE2XSf4AAAAA8f///7QAAADt////4v///8v///8IAAcAUIB+aQIAAAAAAAAABAADAHFPBEwFAAAABAADAB547YsyAAAABAAEAPMNCyolIiL/AQABAHATMqgBAQABAD0NHsUBBAAEAB00Bv7///9HAQABAOV9tvYBBAAEAEWSadT/////BAADAJVwTwQGAAAABAAEAORA8p9PS0f/BAAEABzJ7ywyMjIABAAEADiJrQT///8ABAAEAO3nAZKhy/l5BAADAOWwKDsBAAAAAQABAFglDl4BBAAEAKTw28IAAAD/BAADABq5xRcGAAAABAAEAJIjEovl5eX/BAADAI+0BxoyAAAABAAEAJD0k1oAAAAAAQABAFgdQdoBBAAEAKRoqHUQEBD/BAADABqhHyoEAAAABAAEAJKLZxxHSE//AQABAFyI+GcBAQABANnq/OoBAQABAL0cStUBAQABAPLUO2IBAQABAADtHhcBAQABAKaFUjoBBAAEAN5HX2PVzf//CAAHAJiiAEdsAAAAAAAAAAEAAQCt6/nPAQEAAQA8PXNJAQEAAQChUsGhAQEAAQAsS4dqAQEAAQAzi0oIAQEAAQBoL/BDAQEAAQALG83XAQEAAQB5N2I4AQQAAwAzaD1tAwAAAAQABAAHxA2hcXFx/wEAAQCrYKaVAQQAAwDHv2RFHgAAAAQAAwCu7csJDwAAAAEAAQDceJ9VAQEAAQAHfpPyAQQABAAbSNoqAAAAAAEAAQDTxRDEARAEBgDsjyG2AAAAAGQAAAAAAAAAAAAAAAEAAABkAAAAAAAAACUAAAABAAAAZAAAAAAAAADSAwAAAAAAAGQAAAAAAAAAigMAAAEAAABkAAAAAAAAAGEBAAAAAAAAZAAAAAAAAAAAAAAAAAAAAGQAAAAAAAAAAAAAAAEAAABkAAAAAAAAAA4AAAAAAAAAZAAAAAAAAAAAAAAAAQAAAGQAAADDAAAAMwAAAAEAAABkAAAAAAAAAJcDAAABAAAAYgAAAAAAAAClAgAAAAAAAGQAAAAAAAAAAAAAAAEAAABkAAAAAAAAAI4BAAAAAAAAZAAAAAAAAAAAAAAAAAAAAGQAAAAAAAAAAAAAAAAAAABkAAAAAAAAAAAAAAAAAAAAZAAAAAAAAAAAAAAAAAAAAGQAAAAAAAAAAAAAAAAAAABkAAAAAAAAAAAAAAAAAAAAZAAAAAAAAAAAAAAAAAAAAGQAAAAAAAAAAAAAAAAAAABkAAAAAAAAAAAAAAABAAAAZAAAAAAAAADOAwAAAAAAAGQAAAAAAAAAAAAAAAEAAABkAAAAAAAAAI4CAAAAAAAAZAAAAAAAAAAAAAAAAQAAAGQAAAAAAAAAFwIAAAEAAABkAAAAAAAAAGkBAAAAAAAAZAAAAAAAAAAAAAAAAQAAAGQAAAAAAAAAIQEAAAEAAABkAAAAAAAAAFgBAAABAAAAZAAAAAAAAABlAQAAAAAAAGQAAAAAAAAAAAAAAAEAAABkAAAAAAAAAG4BAAAAAAAAZAAAAAAAAAAAAAAAAAAAAGQAAAAAAAAAAAAAAAAAAABkAAAAAAAAAAAAAAABAAAAZAAAAAAAAABVAgAAAAAAAGQAAAAAAAAAAAAAAAEAAABkAAAAAAAAAP0AAAAAAAAAZAAAAAAAAAAAAAAAAAAAAGQAAADoAwAAawIAAAAAAABkAAAAAAAAAAAAAAABAAAAZAAAAAAAAAAAAAAAAAAAAGQAAAAAAAAAAAAAAAEAAABkAAAAAAAAAFgBAAAAAAAAZAAAAAAAAAAAAAAAAAAAAGQAAAAAAAAAAAAAAAEAAABkAAAAAAAAAAAAAAAAAAAAZAAAAAAAAAAAAAAAAAAAAGQAAAAAAAAAAAAAAAAAAABkAAAAAAAAAAAAAAAAAAAAZAAAAAAAAAAAAAAAAAAAAGQAAAAAAAAAAAAAAAAAAABkAAAAAAAAAAAAAAAAAAAAZAAAAAAAAAAAAAAAAAAAAGQAAAAAAAAAAAAAAAAAAABkAAAAAAAAAAAAAAAAAAAAZAAAAAAAAAA7AAAAAAAAAGQAAAAAAAAAAAAAAAEAAABkAAAAAAAAAFMBAAAAAAAAZAAAAAAAAAAAAAAAAAAAAGQAAAAAAAAAAAAAAAEAAABkAAAAegEAACUAAAABAAEAB/mOOgEBAAEAoJwk5QEEAAMAteg5dKkTAAAEAAMAflMBUakTAAAEAAMA4GE/4UQnAAAEAAMAEQD9fEQnAAAEAAMAIsWPWAMAAAAEAAMA03oJggUAAAABAAEAMkivbAEEAAMAC/KzPgsAAAAEAAMAvNmRgRMAAAAIAAcAhNZ0cWwAAAADAAAAAQABAOfP4DABAQABABnVUdMBAQABAIy4ehcBAQABAOFI0m4BAQABALXtXCQBAQABAKUydB4BAQABAJHf6lIBAQABADu9LMgBBAADAEee58ACAAAAAQABAHv7yzoAAQABAJQACeMBCAAHAJQACeMAAAAAAQAAAAQAAwAWSDQkAQAAAAQAAwDgnL6KSwAAAAQAAwC0er5BCgAAAAQAAwDycN9IRgAAAAQAAwDaw0uPAQAAAAQAAwABkFs0SwAAAAQAAwBFJ0QbAQAAAAQAAwCFvCr/RgAAAAQAAwBBS3WqAQAAAAQAAwB40QiKSwAAAAQAAwAsA6W+AQAAAAQAAwB22a5kRgAAAAQAAwA2RZLhAQAAAAQAAwCYzwC7SwAAAAQAAwBMUeE1CgAAAAEAAQDB3m23AAgABwBQp3lTBgAAAAEAAAAEAAMAu2BG3wAAAAAEAAMAIPVFKxgBAAAEAAMAOBwhrSADAAABAAEA5FD/QAAIAAcA5FD/QAYAAAABAAAABAADAEoYF38BAAAABAADAI8R2YX/////BAADAHWW5awEAAAABAADALjVI8L/////BAADADRBaN7/////BAADAAXz86oZAAAABAADAKlIWnf/////BAADAEf+sEn/////AQABAGmIPXABCAAHAGmIPXAkAQAAAQAAAAQAAwDPTVIcBgAAAAQAAwAmi+CvAAAAAAQAAwBMvQR1RAAAAAQAAwBTML2lUAAAAAQAAwDvKGipMgAAAAQAAwD8uChPNwAAAAQAAwBwUfFcMgAAAAQAAwBerWQ1AAAAAAEAAQDjWyI8AQQAAwCN5YD/AAAAAAEAAQB1XnEsAQEAAQDGZSz8AQEAAQBThBlBAAQAAwAy3inFRgAAAAQAAwCg/hO+UAAAAAQAAwBum+f8UAAAAAQAAwBAkcGfSwAAAAQAAwDvAnUNRgAAAAQAAwBk6QkMUAAAAAQAAwBD0MRDRgAAAAQAAwApTjiiRgAAAAQAAwCDnd7hQQAAAAQAAwCFkr3pRgAAAAQAAwBdV5eYPAAAAAQAAwBYnGKpPAAAAAQAAwC7HhN8QQAAAAQAAwD8XWZCRgAAAAQAAwDw2ZPfPAAAAAQAAwDmqjoLPAAAAAQAAwBInEtyPAAAAAQAAwAWhrflPAAAAAQAAwDxIIEcPAAAAAQAAwBqmPUdPAAAAAQAAwBBRqwzPAAAAAEAAQBsdB8FAQQAAwDRbjmzAwAAAAEAAQCVbSXRAAgABwAMhEKyBgAAAAEAAAAIAAcA/0xQVAAAAAABAAAAAQABABe2Uc4AAQABAE5ZGvkABAADACkXC2wAAAAABAADAATzH9QAAAAABAADAOTPJ7AEAAAABAADAJPXMVYFAAAABAADANY95+MAAAAAAQABAPJjqUwBBAADAMB9ie0AAAAAAQABABFRiJMABAADAGoY8rAAAAAABAADAMdwIaMGAAAACAAHAHzgmIMYAQAAAQAAAAgABwCqS7WMrAEAAAEAAAAIAAcAbsAd1UoAAAABAAAACAAHAB6eXNgAAAAAAQAAAAgABwALYQf0AAAAAAEAAAAEAAMAX/NG5QEAAAABAAEATea36AEIAAcAiyLa8GoBAAABAAAACAAHALZSNOMOAQAAAQAAAAgABwDzIvd/UAAAAAEAAAABAAEAv01QrAAIAAcArR9bTwYAAAABAAAABAADALkyBvxuAAAABAADAM+XgPlQAAAAAQABAC1x/JgABAADALSdXc0AAAAABAADANXk5YYAAAAABAADAL0osg4AAAAABAADAIg9/HsAAAAABAADAANNi58AAAAABAADAPvbCacAAAAABAADAPcIXgAAAAAABAADAG8U+BsAAAAABAADAFExs8sAAAAABAADANKVG9MOAAAABAADAHJpJyIAAAAABAADAFc8q+cAAAAABAADAFwe/sMAAAAABAADADqGuesAAAAABAADANU9xSAAAAAABAADANbgOKMAAAAABAADAFhm9TsAAAAABAADAH6P3oEAAAAABAADACCm1j4AAAAABAADAECjS3QAAAAABAADAI80Ne0OAAAABAADAK2zbW0AAAAAAQABALtkL7YBBAAEAJBCOk+Ztf//BAADAM8l1tIDAAAABAADADXTcbYEAAAAAQABANfKo/8ABAAEANTd7xb/////AQABAJ854n8AAQABAEq+H1YAAQABAE0JJNIABAADAJ3cXxYBAAAAAQABAMwCEFwBBAADAFrBwaIBAAAABAAEAHgD1C7////TBAAEAM1BgHEAyP//BAADAIOmm4YoAAAABAADADqTZk4KAAAAAQABAOJ+++sBAQABAIR8a3oAAQABABgXLskABAAEAGxcdKL/////BAAEAEp8K93///8ABAADANPokUcAAAAABAADADbJgNAFAAAABAADAERdc+ojAAAABAADABOF7h4BAAAAAQABAGtgtwIABAADAF6QTTIAAAAAAQABAEXPQXYBBAADAPNgqlcCAAAAAQABAKGixC4BBAADAPNW0bkDAAAABAADAPp7xmMDAAAABAADAEBZXLoCAAAABAAEAGdHWYg+nvr/BAAEAF6hXvL9LUz/BAAEAFpHKsPGwMCAAQABAJdgTbMBBAADAPsYiCEtAAAAAQABAGzeKMwAAQABAJ8l2XcBAQABAGvOo60BAQABADyY1WEBAQABAEalz68ABAAEAEalz6//////AQABAPmBGl0ABAAEAPmBGl3/////AQABAMSYNiUABAAEAMSYNiX/////BAADAHb2VkADAAAAAQABAAHTSecABAADABtv9ccAAAAABAADAFrL80syAAAABAADAFTxinwFAAAAAQABAOrPBk0ABAADABvvXzAAAAAAAQABAAdy3FMAAQABAKRHvMoABAADACjKV3kAAAAAAQABAGuQ/L8ABAADAEXAXPIAAAAAAQABAHFJSW8ABAAEAGapVhpaWlr/BAAEAGBPjgPS0tL/BAAEAECTt4Gnp6f/AQABAGwU7kIBBAADAGTtH7l/AAAABAADADHyihw/AAAAAQABAA6dZ1UABAAEAA6dZ1X/////AQABAJpUMUcBBAADAIi/9mRkAAAAAQABAAYU4wsBBAADAJzPu/B9AAAAAQABAMGzT2MBBAADAFZ+Q3lDAgAABAADAGUGnRQAAAAABAADANYAnRUFAAAABAADAEsDnRr2////AQABABd2/eUABAADAJmzBxpkAAAAAQABAPnGMy0ABAADAGNHbjsBAAAABAADAAX/l7UUAAAAAQABAL5F7lEBAQABAEdbu9kBAQABAKu0olwAAQABABw0EwgBAQABAJWiihcBCAAHAFCQ9ToGAAAAAQAAAAEAAQAvQ5lIAQEAAQBdA97NAQQAAwChU0iJAwAAAAQAAwCGQyACAAAAAAQAAwCu5EDwAAAAAAQAAwBGLAHdAAAAAAQAAwC2eCLfAAAAAAEAAQBs75OpAAQAAwAdZY3mAAAAAAQAAwAM/WAiAAAAAAEAAQBw9d4tAQQAAwDWBevHAwAAAAQAAwDM7EA+DwAAAAQABADeNaMqn8or/wQABAAZF+Ii/0dH/wQABADieGOnpqDc/wEAAQDZXHcFAAQAAwCvQLMhAQAAAAQAAwAB+MfzAQAAAAEAAQDIGFqLAQQAAwATAgpGAQAAAAQAAwD/uesdAAAAAAQAAwDahucdfwAAAAQAAwD+53daBAAAAAEAAQCPqeh+AQQABAD+53danLj/KwEAAQDU09KhAAQAAwAUG3UZAAAAAAEAAQAf62E/AAQAAwCyOF+HAgAAAAEAAQBUTHumAAQAAwBj1NeBAQAAAAQAAwDxfhngBAAAAAQAAwBq4lNuDgAAAAQAAwARUSDwCAAAAAQAAwB46GNOAAAAAAQAAwBaogBPAAAAAAQAAwDE3jgiZAAAAAQAAwAa8PE3CgAAAAQAAwA1044aCQAAAAQAAwD/PB3zBwAAAAQAAwCcbDG/AgAAAAQAAwBtj2GdAAAAAAQAAwBo1XjjAQAAAAQAAwAVm+m6BQAAAAQAAwAZcKRdAAAAAAQAAwBc95E1AAAAAAQAAwAJBLuhAAAAAAQAAwC+W6nH4P///wQAAwC3lmdjJAAAAAQAAwCyPJOeAAAAAAQAAwCwSELt8f///wQAAwB5TULuEQAAAAQAAwCnbRhsAgAAAAQAAwDrc7aqAAAAAAQAAwD/o5glAAAAAAQAAwARCxmHAAAAAAQAAwCfU6MKAwAAAAQAAwDFByc2CgAAAAQAAwB8VGJXAAAAAAQAAwC/9ySGAAAAAAQAAwCXHiTMAwAAAAQAAwBOcjtvAAAAAAQAAwAiwru8AQAAAAQAAwCyIptSAAAAAAQAAwDM16wkAAAAAAQAAwDlY2wmZAAAAAQAAwCRyvryAQAAAAQAAwDsbURnAAAAAAQAAwAvuixZAAAAAAQAAwCWkrYYAAAAAAQAAwCCMmk0IAAAAAQAAwCHN/TFAAAAAAQAAwD9zORGAgAAAAQAAwDYgZeQAAAAAAQAAwCtr9teAAAAAAQAAwBbaSgtAQAAAAQAAwA/KzrpAgAAAAQAAwAG7TJ7AAAAAAQAAwAJeFuQPAAAAAQAAwAAjuokAAAAAAQAAwAOKv5aAAAAAAQAAwC+ipVPAQAAAAQAAwCmQ5RePAAAAAQAAwBHndzjAgAAAAQAAwDSMA2XAAAAAAQAAwAHGARCDgAAAAQAAwBDbRCtPAAAAAQAAwBKakGUAwAAAAQAAwDzRJemAAAAAAEAAQDL9hShAAQAAwA8iXwQAAAAAAEAAQCR1eZxAAQAAwB54J09AAAAAAQAAwBoQSgsAAAAAAQAAwAVtvKpAAAAAAQAAwBX1IbbAAAAAAEAAQAlTVJnAAQAAwCUfWVfAAAAAAQAAwBdRmVYAAAAAAQAAwD5hoLEMgAAAAQAAwCqVaGNAAAAAAQAAwAfVKGyAAAAAAQAAwDvkLscAAAAAAQAAwCC1ggUAAAAAAQAAwA8s88AAAAAAAQAAwAQ4KjGAAAAAAQAAwBz+g2rAAAAAAQAAwC+1LbQAAAAAAQAAwAT17bRAAAAAAQAAwATs6kRMgAAAAQAAwBz3zs9AAAAAAQAAwAe3Ts8AAAAAAQAAwASCBRYWgAAAAQAAwA9GZZ7AAAAAAQAAwB0FJZ+AAAAAAQAAwBMwe8KAAAAAAQAAwDHG43tAAAAAAEAAQABHwGoAAQAAwDulx/ZAQAAAAEAAQAwDEO+AAEAAQDlPncUAAQAAwAcjn4eAAAAAAQAAwClkOLdDgAAAAQAAwDmPF7lAAAAAAQAAwCnACGKAAAAAAQAAwDJzNhjAAAAAAQAAwCDDNtBAAAAAAQAAwBrxpCYAAAAAAQAAwBAtpNEAQAAAAQAAwC+6iX1AQAAAAQAAwBhPADYAAAAAAQAAwCWXDbwAAAAAAQAAwDz/pkQAAAAAAQAAwC0XDK2AAAAAAQAAwBo5240AAAAAAQAAwALnY3UAAAAAAQAAwDaPWs/AAAAAAQAAwDhNIUdAAAAAAQAAwAaKzSnAAAAAAQAAwBBaRHZAAAAAAQAAwDLWlzYAAAAAAQAAwBWWFzbAAAAAAQAAwB2At3UAQAAAAQAAwCUtG42AAAAAAQAAwCk7aaWAAAAAAQAAwDmROfgAAAAAAQAAwCknXiUAwAAAAQAAwDSIEkUCgAAAAQAAwCxJP6NAAAAAAQAAwBM8l9MAAAAAAQAAwBSZOafAwAAAAQAAwBlCvO7AAAAAAQAAwAtXy28AQAAAAQAAwCVxD0jAAAAAAQAAwDXasFSAAAAAAQAAwCSrdemZAAAAAQAAwDU+Ha1AQAAAAQAAwCt+mNKAAAAAAQAAwA4VRFvAAAAAAQAAwAj7XwqAAAAAAQAAwCfzbJlAAAAAAQAAwDUvVbEAAAAAAQAAwD8e+hnAQAAAAQAAwBJJbiNAAAAAAQAAwBOMSXuAAAAAAQAAwD2iQbjAQAAAAQAAwCkY2MZAAAAAAQAAwABJr2yAAAAAAQAAwBCFK6VAAAAAAQAAwCbzwYoAAAAAAQAAwARdCpWAAAAAAQAAwB5LDkaAQAAAAQAAwBLU/9IAAAAAAQAAwCyKgoeAQAAAAQAAwCNaLpbAAAAAAQAAwAWgdbmDgAAAAQAAwCSdL2LAAAAAAQAAwArkEBGAQAAAAQAAwCiBybhAAAAAAEAAQD+J5b7AAQAAwBFWJnmAAAAAAEAAQD6iK9NAAQAAwBUQ9hhAAAAAAQAAwCDmWeNAAAAAAQAAwAid647AAAAAAQAAwDciL0tAAAAAAEAAQDq8Yr3AAQAAwDpMpYTAAAAAAQAAwAgLpYWAAAAAAQAAwC6AcIaMgAAAAQAAwAhB2gfAAAAAAQAAwB4AmgCAAAAAAQAAwCAdTfsAAAAAAQAAwDjeRzsAAAAAAQAAwBdc1F2AAAAAAQAAwCBlMU8AAAAAAQAAwAEwbEGAAAAAAQAAwCv4WXIAAAAAAQAAwA652XLAAAAAAQAAwCgDhJlMgAAAAQAAwAuguZpAAAAAAQAAwCDvOZuAAAAAAQAAwB9pknsWgAAAAQAAwC2ME90AAAAAAQAAwArM091AAAAAAQAAwCHL1x4AAAAAAQAAwBak+RoAAAAAAEAAQDyjvC6AAQAAwAB2AtoAQAAAAEAAQBFd/LMAAEAAQCz4x5VAAQAAwDyGzY6AAAAAAQAAwCXXf1sDgAAAAQAAwDU6TUIAAAAAAQAAwDV1T+TAAAAAAQAAwBPC80xAAAAAAQAAwBZNNstAAAAAAQAAwB9Ew5OAAAAAAQAAwCm+jPCAQAAAAQAAwDUGUp7AQAAAAQAAwAPV9GaAAAAAAQAAwAEXr1hAAAAAAQAAwDleuNUAAAAAAQAAwCiu7iBAAAAAAQAAwCKZE27AAAAAAQAAwCx8n+CAAAAAAQAAwDMs1FqAAAAAAQAAwDXeiNZAAAAAAQAAwDw2wa4AAAAAAQAAwAnAMSTAAAAAAQAAwDxxN0bAAAAAAQAAwBIwN0eAAAAAAQAAwC0ImMWAQAAAAQAAwDOxm+KAAAAAAQAAwB6j9zzAAAAAAQAAwCQvbbJAAAAAAQAAwDWtOIJAwAAAAQAAwCAKjXdCgAAAAQAAwA3lcteAAAAAAQAAwD+O7tCAAAAAAQAAwA06RNKAwAAAAQAAwDrqjczAAAAAAQAAwBb5gE9AQAAAAQAAwBT4+iiAAAAAAQAAwC5ScWIAAAAAAQAAwB4IgklZAAAAAQAAwBS3KmxAQAAAAQAAwDP6ZyyAAAAAAQAAwAiPhgVAAAAAAQAAwDF4NhKAAAAAAQAAwDZYkTaAAAAAAQAAwAeq46zAAAAAAQAAwAmMQXbAQAAAAQAAwDHoK+qAAAAAAQAAwBcIMADAAAAAAQAAwBkY6hyAQAAAAQAAwDWxYdFAAAAAAQAAwB/Bdh0AAAAAAQAAwD4HvnLAAAAAAQAAwD9boPFAAAAAAQAAwCvnP/3AAAAAAQAAwArwaZBAQAAAAQAAwBBpsV2AAAAAAQAAwDcMd59AQAAAAQAAwBrW0g0AAAAAAQAAwBUFUtbDgAAAAQAAwDc3WV+AAAAAAQAAwCB4qWsAQAAAAQAAwAcRyNQAAAAAAEAAQAUwqgIAAQAAwDPhGJqAAAAAAEAAQBQlMmVAAQAAwD68FvNAAAAAAQAAwABQW85AAAAAAQAAwAcMv1fAAAAAAQAAwBib+glAAAAAAEAAQBkdGy1AAQAAwBbLPGfAAAAAAQAAwDmLfGeAAAAAAQAAwAECnL5MgAAAAQAAwDjabE+AAAAAAQAAwCOb7E5AAAAAAQAAwCG3jaWAAAAAAQAAwCZiKMKAAAAAAQAAwBL/AIrAAAAAAQAAwBjp/u/AAAAAAQAAwDC7NV5AAAAAAQAAwBpuHWAAAAAAAQAAwCgt3WHAAAAAAQAAwA6cjjRMgAAAAQAAwD0UfWwAAAAAAQAAwC9WvWNAAAAAAQAAwDXAEfyWgAAAAQAAwA4ldm2AAAAAAQAAwDhmdmzAAAAAAQAAwBVR36eAAAAAAQAAwDg0T8bAAAAAAEAAQCkeGQmAAQAAwD/RRAgAQAAAAEAAQDL7uaSAAEAAQAtKvpjAQQAAwAUg9PVAAAAAAQAAwCdIfF+DgAAAAQAAwBOIDXfAAAAAAQAAwDffs8MAAAAAAQAAwBRx3nbAAAAAAQAAwDLFKOXAAAAAAQAAwAjqqRhAAAAAAQAAwBIdBC3AQAAAAQAAwCGG0lUAQAAAAQAAwCpykhEAgAAAAQAAwBOzBW3AAAAAAQAAwA79lXzAQAAAAQAAwCswrIFBAAAAAQAAwAgugN0AAAAAAQAAwBDxiBDAAAAAAQAAwCyBKs6AAAAAAQAAwB5BUtJ0f///wQAAwAy9cqYMQAAAAQAAwDZUM7fHAAAAAQAAwDz3/2nAAAAAAQAAwCe3f2mAAAAAAQAAwCePvqyAQAAAAQAAwBcwE6gAAAAAAQAAwDsWBZDAAAAAAQAAwDuYmFBAAAAAAQAAwDcQpWgAwAAAAQAAwD62rvECgAAAAQAAwCZCFm6AAAAAAQAAwAUmH9tAAAAAAQAAwBax765AwAAAAQAAwDdmdMCAAAAAAQAAwClEpZzAQAAAAQAAwCtAJlnAAAAAAQAAwC/5PVxAAAAAAQAAwA6mGYeZAAAAAQAAwCsbbD+AQAAAAQAAwDV9rpBAAAAAAQAAwCAKWguAAAAAAQAAwBLy+DkAAAAAAQAAwD30DRdAAAAAAQAAwAMYR8BAAAAAAQAAwC0gsQCAQAAAAQAAwCBIpGBAAAAAAQAAwCGRO7lAAAAAAQAAwCO3W/VAQAAAAQAAwCMBxpiBAAAAAQAAwBJC3BSAAAAAAQAAwC6DpFkMAAAAAQAAwCTuzbBAAAAAAQAAwD5YSOvAAAAAAQAAwDBFdAJAQAAAAQAAwAzU1esAAAAAAQAAwC6uKC4AQAAAAQAAwDVAYrCAAAAAAQAAwD+iCFXDgAAAAQAAwB6wh7TAAAAAAQAAwBzN6gnAQAAAAQAAwDaFyYLAAAAAAEAAQDGFdG7AAQAAwAd2/sEAAAAAAEAAQByZrXmAAQAAwA8f0waAAAAAAQAAwCbOpHJAAAAAAQAAwAa1oQ5AAAAAAQAAwAke/FTAAAAAAEAAQCiMvP0AAQAAwBxAfLWAAAAAAQAAwDIPPLVAAAAAAQAAwDCfFXNMgAAAAQAAwDJ+Us4AAAAAAQAAwAA9Us/AAAAAAQAAwDI0/E6AAAAAAQAAwBrD6sqAAAAAAQAAwC1FEJtAAAAAAQAAwD5IFX9AAAAAAQAAwB8yoLTAAAAAAQAAwAnPa1zAAAAAAQAAwCyAq1yAAAAAAQAAwA4lYkcMgAAAAQAAwDWDs4SAAAAAAQAAwBLCc4TAAAAAAQAAwBFbBxdWgAAAAQAAwDOkIaUAAAAAAQAAwAjk4aVAAAAAAQAAwC/8xiQAAAAAAQAAwBSi09qAAAAAAEAAQB6yUorAAQAAwAZrisfAQAAAAEAAQC9+YiCAAEAAQA7Oc9gAQQAAwBKoTFVBQAAAAQAAwDvqPtRDgAAAAQAAwAcwAUCAAAAAAQAAwDNEnFAAAAAAAQAAwC3oY69AAAAAAQAAwChZywcRgAAAAQAAwC1HSG8AAAAAAQAAwAutaKEAQAAAAQAAwDc9aAOBgAAAAQAAwA3dQ/oAgAAAAQAAwB89lY9AAAAAAQAAwBt3Z2xAQAAAAQAAwAaYxYCBAAAAAQAAwCC2ZeqAAAAAAQAAwDpZIxdAAAAAAQAAwBEoVmUAAAAAAQAAwCPcrk03P///wQAAwDIgIBMJAAAAAQAAwAfSHqvAAAAAAQAAwCZViVmEAAAAAQAAwDQTSVl5////wQAAwCc/of1AQAAAAQAAwAWhp1sAAAAAAQAAwBix9pMAAAAAAQAAwA4/WbNAAAAAAQAAwDOIDKWAwAAAAQAAwCoe1EZCgAAAAQAAwD/mB/5AAAAAAQAAwBG2PwzAAAAAAQAAwD8pxLfAwAAAAQAAwCDPgJZAAAAAAQAAwDTrq/rAQAAAAQAAwCrT6cmAAAAAAQAAwCBKkoMAAAAAAQAAwCgVdb+ZAAAAAQAAwDqW9ytAQAAAAQAAwDXWSBCAAAAAAQAAwCqrESHAAAAAAQAAwANqQuiAAAAAAQAAwBRmgWbJgAAAAQAAwBWmVR0AAAAAAQAAwC+GPFsAwAAAAQAAwBfhE86AAAAAAQAAwAUOI57AAAAAAQAAwA8CWtUAQAAAAQAAwD+xHCMBAAAAAQAAwDHvQZKHgAAAAQAAwAQLpMPIwAAAAQAAwA1mWbRAAAAAAQAAwB3PwrDAAAAAAQAAwAzOx3AAQAAAAQAAwBpdPSoAAAAAAQAAwAEmlK+AQAAAAQAAwATCUn6AAAAAAQAAwD8SMOfDgAAAAQAAwCk2hGnHgAAAAQAAwCJiIlVAQAAAAQAAwC0J1w3AAAAAAEAAQA8eabZAAQAAwCn+qpVAgAAAAEAAQColkLNAQQAAwACIcIrAQAAAAQAAwCZCn+8AAAAAAQAAwD0xbruAAAAAAQAAwCKn08UAAAAAAEAAQA8INoiAAQAAwAjFOlEAAAAAAQAAwDOFelHAAAAAAQAAwDs8HjXMgAAAAQAAwCLgyVsAAAAAAQAAwAWgSVvAAAAAAQAAwDukZavAAAAAAQAAwChHdBDAAAAAAQAAwCDeruJAwAAAAQAAwAb/8DNAAAAAAQAAwCaHglLHAAAAAQAAwDBIZ44Yv///wQAAwAY3Z4/kAAAAAQAAwBSch4IZAAAAAQAAwCcC+ktAAAAAAQAAwBFDOkuAAAAAAQAAwBfAq7VWgAAAAQAAwDwlwWZAAAAAAQAAwC5mAWaAAAAAAQAAwAtJDMjAAAAAAQAAwDYxc09AAAAAAEAAQBMaZv4AAQAAwBXw2YjAQAAAAEAAQCjaneyAAEAAQD22MMNAAQAAwB3UByxAAAAAAQAAwAkhyt4DgAAAAQAAwC36SMVAAAAAAQAAwBOYRdIAAAAAAQAAwDINU4YAAAAAAQAAwDi/kzDAAAAAAQAAwDs9idhAAAAAAQAAwDL5tk5AQAAAAQAAwAlVd93AQAAAAQAAwCyo3i8AAAAAAQAAwBDxgSUAAAAAAQAAwC6mhAuAAAAAAQAAwAzUFOsAAAAAAQAAwCrjMgDAAAAAAQAAwBqkEvYAAAAAAQAAwCDfjI1AAAAAAQAAwDMlL4LAAAAAAQAAwD9axRbAAAAAAQAAwCQtb/4AAAAAAQAAwCO0KVfAAAAAAQAAwDj0qVcAAAAAAQAAwAttd8nAQAAAAQAAwA9WibEAAAAAAQAAwCNcCVuAAAAAAQAAwBbHBHwAAAAAAQAAwA5ycvqAwAAAAQAAwBbULMUCgAAAAQAAwA6rfjJAAAAAAQAAwB5X86tAAAAAAQAAwDpWeKVAwAAAAQAAwAMX7+LAAAAAAQAAwBYfT/pAQAAAAQAAwBw5i3MAAAAAAQAAwDenTbCAAAAAAQAAwCjEdenZAAAAAQAAwBHJM0jAQAAAAQAAwCO5WwoAAAAAAQAAwAJ7SlPAAAAAAQAAwC4KxDAAAAAAAQAAwBEtpzFAAAAAAQAAwDRBo8WAAAAAAQAAwD/+pBfAQAAAAQAAwC28s9zAAAAAAQAAwAzbgFIAAAAAAQAAwBJ+S/1AQAAAAQAAwChJ+4fAAAAAAQAAwDcnZYvAAAAAAQAAwBPH4I5AAAAAAQAAwA6vM6LAAAAAAQAAwBEtCW8AAAAAAQAAwAQ9PdEAQAAAAQAAwDUdKj2AAAAAAQAAwC5YJ9EAQAAAAQAAwD4VwtZAAAAAAQAAwCNBxvIDgAAAAQAAwC10qgqAAAAAAQAAwC4G2qXAQAAAAQAAwCV5JiOAAAAAAEAAQCZUGIYAAQAAwDGyS4OAAAAAAEAAQDnfFRgAAQAAwAnifeHAAAAAAQAAwAm0XSFAAAAAAQAAwD/S58JAAAAAAQAAwC9uPUfAAAAAAEAAQBXw+n2AAQAAwBOrkUbAAAAAAQAAwCjqEUYAAAAAAQAAwCjzQUfMgAAAAQAAwB8PnT8AAAAAAQAAwAlA3T5AAAAAAQAAwAlBpdJAAAAAAQAAwDwxCttAAAAAAQAAwDKgWoGAAAAAAQAAwASg+a9AAAAAAQAAwD5rG5iAAAAAAQAAwAAaVsSAAAAAAQAAwDJbVvvAAAAAAQAAwDNfonNMgAAAAQAAwDRpE7CAAAAAAQAAwAooE7BAAAAAAQAAwAMgkzhWgAAAAQAAwAXwICNAAAAAAQAAwCiwYCMAAAAAAQAAwAyiJWzAAAAAAQAAwA9EokFAAAAAAEAAQBT4om6AAQAAwDMx6laAQAAAAEAAQD+tSQ+AAEAAQChGJB5AQQAAwBoWBGlAwAAAAQAAwABvPX3DgAAAAQAAwBSJiPyAAAAAAQAAwCrTsvsAAAAAAQAAwD97FYuAAAAAAQAAwB/vm3LAAAAAAQAAwBf0gPFIgAAAAQAAwCUhk2lAQAAAAQAAwDaiC/aAQAAAAQAAwBlafN3AgAAAAQAAwCys7spAAAAAAQAAwDnkqrmAQAAAAQAAwDY90VqBAAAAAQAAwB0rbVmAAAAAAQAAwAX5UaCAAAAAAQAAwCWGAVAAAAAAAQAAwA9vro/0////wQAAwDu2JL4LQAAAAQAAwCtsSToAAAAAAQAAwA3MFYX8////wQAAwDCMVYWEgAAAAQAAwByjhlQAwAAAAQAAwAI7eWIAAAAAAQAAwAQWIDyAAAAAAQAAwAaXq+/AAAAAAQAAwDw9VWBAwAAAAQAAwDm6xagCgAAAAQAAwDlqqugKAAAAAQAAwAQRvSoAAAAAAQAAwAOP83cAwAAAAQAAwAZRyvYAAAAAAQAAwC5JMRuAQAAAAQAAwCJ7W2HAAAAAAQAAwAjB3G5AAAAAAQAAwAe2gX1ZAAAAAQAAwDotHdaAQAAAAQAAwBJxgAAAAAAAAQAAwC8YkmpAAAAAAQAAwAfYV/VAAAAAAQAAwB7hV2RFgAAAAQAAwBYcG7nAAAAAAQAAwDgwTBOAQAAAAQAAwCNoEgfAAAAAAQAAwBqYpPSAAAAAAQAAwBSJaZGAQAAAAQAAwAgzuHbBAAAAAQAAwC1yQZMAAAAAAQAAwDOmtW1KgAAAAQAAwCHhRKS3v///wQAAwDVFyZgJgAAAAQAAwDNT3iHAQAAAAQAAwBPz3dqAAAAAAQAAwDeyo8jAQAAAAQAAwDpR2+5AAAAAAQAAwDS4oIFDgAAAAQAAwCOm+LWPAAAAAQAAwAvhbpIAQAAAAQAAwCWwnQgAAAAAAEAAQBSbq1rAAQAAwDh6uiFAgAAAAEAAQDmK3nHAQQAAwDAOI8/BwAAAAQAAwAnGUY/AAAAAAQAAwD+NNi73////wQAAwDwmDSEEAAAAAEAAQBe6R+0AQQAAwD9zUgT2P///wQAAwA0yUgWFgAAAAQAAwA2ar3GOgAAAAQAAwDVCREJAAAAAAQAAwAsBREMAAAAAAQAAwAckb65AAAAAAQAAwDXLvq7AAAAAAQAAwAZhV0fAwAAAAQAAwDFqVKWKQAAAAQAAwBovmWP7f///wQAAwDLVv2VTP///wQAAwBWVP2UtAAAAAQAAwB0+L8nZAAAAAQAAwBS/nT3AAAAAAQAAwDH+HT0AAAAAAQAAwBJJ/Z0WgAAAAQAAwC6ZJUJAAAAAAQAAwAvZ5UOAAAAAAQAAwAjXSNhAAAAAAQAAwAOlm8RAAAAAAEAAQAWQXzgAAQAAwDVYTv9AwAAAAEAAQDJxxCHAAEAAQAcFAGzAQQAAwCt2PToAwAAAAQAAwCWEYS5DgAAAAQAAwDty/YFAAAAAAQAAwB8JS1XAAAAAAQAAwCutJSEAAAAAAQAAwCw2bGdAAAAAAQAAwBuSACfHgAAAAQAAwAJtfxLAQAAAAQAAwD7RwArAQAAAAQAAwDQw9JAAgAAAAQAAwCZUoGqAAAAAAQAAwAc0rwyAQAAAAQAAwDprDFmBAAAAAQAAwA18HzlAAAAAAQAAwAYO+QbAAAAAAQAAwC1MaAJAAAAAAQAAwDqUCgn2P///wQAAwD7PsclKAAAAAQAAwBu6xeBCAAAAAQAAwAccxAW0P///wQAAwDFdxATLgAAAAQAAwAjLfP3AQAAAAQAAwDvPQ4TAAAAAAQAAwDra3JUAAAAAAQAAwAlgS3gAAAAAAQAAwCL0iZNAwAAAAQAAwApxhmvCgAAAAQAAwDwIXCTAAAAAAQAAwCjJd2NAAAAAAQAAwBjXHFuBwAAAAQAAwCihGQFHgAAAAQAAwAe5ksHAwAAAAQAAwCGhs53KwAAAAQAAwDIJNJhUAAAAAQAAwBRjB0iZAAAAAQAAwC1Y/IDAQAAAAQAAwAoMQkOAAAAAAQAAwDziMcbAAAAAAQAAwDC1jRWAAAAAAQAAwDeoTaXKAAAAAQAAwD7bI57AAAAAAQAAwAx41PiCAAAAAQAAwD8X+PAAAAAAAQAAwDpUZ40AAAAAAQAAwB3tPbUAQAAAAQAAwBr2W7XBAAAAAQAAwBagdp7AAAAAAQAAwAFO3/aKgAAAAQAAwB8qcoZAAAAAAQAAwDCFyfmAAAAAAQAAwDCaJcIAQAAAAQAAwBqGEPkAAAAAAQAAwAjScIsAQAAAAQAAwCeRQ+TAAAAAAQAAwCDvz6YDgAAAAQAAwD/ODMpPAAAAAQAAwBO9U7JAgAAAAQAAwDXiFGBAAAAAAEAAQBfHBu8AAQAAwC4Q/C7AgAAAAEAAQBtN1c/AQQAAwBVr1NYBwAAAAQAAwDsLA9UAAAAAAQAAwCxw9Ak7P///wQAAwDbZM1eEQAAAAEAAQDpNkAGAAQAAwAY+qmep////wQAAwDB/qmbAAAAAAQAAwBFy36sMgAAAAQAAwC+TnWzAAAAAAQAAwATSXWwAAAAAAQAAwD7xXEEAAAAAAQAAwCmGjKlAAAAAAQAAwAIwCJQAwAAAAQAAwBEk/xqkf///wQAAwCnVKTfIAAAAAQAAwB6GUilTP///wQAAwDvG0iqtAAAAAQAAwCnTyOGSQAAAAQAAwBHwrhYAAAAAAQAAwDSw7hbAAAAAAQAAwAeLynXWgAAAAQAAwDBeRjtMAAAAAQAAwAYdRgQlP///wQAAwCIURkkAAAAAAQAAwAr32gIAAAAAAEAAQBlK6Y/AAQAAwCSbhxqAQAAAAEAAQB0NevyAAEAAQDSzSMoAAQAAwCTt14JAAAAAAQAAwBgS+L/DgAAAAQAAwAztvvGAAAAAAQAAwDCqDn9AAAAAAQAAwAc3DhMAAAAAAQAAwDuyiOUAAAAAAQAAwBAgAa7AAAAAAQAAwA/grMnAQAAAAQAAwCxe9MuAQAAAAQAAwB2uqKSAAAAAAQAAwDv9Hl/AAAAAAQAAwBOb3eLAAAAAAQAAwAHF4+yAAAAAAQAAwA3dGm6AAAAAAQAAwAmuaEyAAAAAAQAAwAv+GszAAAAAAQAAwB4WYBkAAAAAAQAAwCRKnwzAAAAAAQAAwAclMG/AAAAAAQAAwBq/rLmAAAAAAQAAwDf+LLnAAAAAAQAAwDpWwHyAQAAAAQAAwAh1/JpAAAAAAQAAwCpFy/RAAAAAAQAAwAfuh1HAAAAAAQAAwAV/PTxAwAAAAQAAwDfisQLCgAAAAQAAwCeUdMBAAAAAAQAAwC939SFAAAAAAQAAwA1BQv3AwAAAAQAAwBgS8QhAAAAAAQAAwDEAbIIAQAAAAQAAwBECznZAAAAAAQAAwA6E8KkAAAAAAQAAwDvPuTiZAAAAAQAAwCLC1cmAQAAAAQAAwA6MnAuAAAAAAQAAwB99XlRAAAAAAQAAwBU98M9AAAAAAQAAwDQ/F4IAAAAAAQAAwCFIUNPAAAAAAQAAwBz4h8eAQAAAAQAAwDavuAPAAAAAAQAAwBfiLSpAAAAAAQAAwA1h2jQAQAAAAQAAwAdvBz/AAAAAAQAAwAg9mRIAAAAAAQAAwCrooZ3AAAAAAQAAwC2b9u+AAAAAAQAAwBYwO6IAAAAAAQAAwCUvBOkAQAAAAQAAwBYV53uAAAAAAQAAwDl3xu9AQAAAAQAAwBUEpvTAAAAAAQAAwCJvStDDgAAAAQAAwDxFNx+AAAAAAQAAwCMjk1+AQAAAAQAAwDJJHVAAAAAAAEAAQDtVsIbAAQAAwCyI46dAAAAAAEAAQCD1hnOAAQAAwCji5blAAAAAAQAAwCacOiSAAAAAAQAAwBbFxu8AAAAAAQAAwDRvy6qAAAAAAEAAQDLQuo0AAQAAwCSwVXvAAAAAAQAAwAHwFXsAAAAAAQAAwCfVCdcMgAAAAQAAwDQ1o71AAAAAAQAAwCZ2472AAAAAAQAAwCBh49jAAAAAAQAAwAUii3vAAAAAAQAAwDG296SAAAAAAQAAwDmfJ5GAAAAAAQAAwANj8VdAAAAAAQAAwA8RceeAAAAAAQAAwDlScebAAAAAAQAAwAh7eqLMgAAAAQAAwDl8fG4AAAAAAQAAwA87fG/AAAAAAQAAwCYdNKyWgAAAAQAAwA7JK/tAAAAAAQAAwDGJa/sAAAAAAQAAwC+ScQ0AAAAAAQAAwAxP01oAAAAAAEAAQC3zWCHAAQAAwBgQLf7AQAAAAEAAQByVMa+AAEAAQCRnjsSAAQAAwAYr7HSAAAAAAQAAwARk+4hDgAAAAQAAwDC4NTLAAAAAAQAAwD7qthjAAAAAAQAAwBtfm7gAAAAAAQAAwBvooVGAAAAAAQAAwDvi+38AAAAAAQAAwCkC+ruAQAAAAQAAwDKtYhdAQAAAAQAAwA1YkP0AAAAAAQAAwBCIiiVAAAAAAQAAwB3iU7gAAAAAAQAAwDoAdXgAAAAAAQAAwBkT29pAAAAAAQAAwAHsdyRAAAAAAQAAwAmIfmjAAAAAAQAAwDNinKZAAAAAAQAAwB+grBsAAAAAAQAAwA9L5viAAAAAAQAAwCHuhg2AAAAAAQAAwASuBgxAAAAAAQAAwDiyER0AQAAAAQAAwCYF2HOAAAAAAQAAwBAVRJQAAAAAAQAAwBKIBkWAAAAAAQAAwAgmApcAwAAAAQAAwD2gAOJCgAAAAQAAwB1/oryAAAAAAQAAwAgGP/HAAAAAAQAAwBeBYi7AwAAAAQAAwDJl2w8AAAAAAQAAwAJ92QHAQAAAAQAAwCZXu+cAAAAAAQAAwCTJvKWAAAAAAQAAwAuCK31ZAAAAAQAAwC4rO//AQAAAAQAAwC59LcEAAAAAAQAAwCsYQT8AAAAAAQAAwCPLQ3DAAAAAAQAAwCrev62AAAAAAQAAwAIOh+rAAAAAAQAAwAwNAvKAQAAAAQAAwB92kqfAAAAAAQAAwBaAQuDAAAAAAQAAwDiSQd2AQAAAAQAAwAwsL+4AAAAAAQAAwAFgtJmAAAAAAQAAwCePS/oAAAAAAQAAwAXte3GAAAAAAQAAwAF0fH0AAAAAAQAAwBdUP0nAQAAAAQAAwBfBWyNAAAAAAQAAwCuWGZTAQAAAAQAAwD5VQ8mAAAAAAQAAwCCmiq/DgAAAAQAAwA+zscZAAAAAAQAAwBf+8KuAQAAAAQAAwBGPcCyAAAAAAEAAQDi5x42AAEAAQCXPrS8AAQAAwAmf9HVAAAAAAQAAwDrh6qIDgAAAAQAAwCYQlY6AAAAAAQAAwDxBYypAAAAAAQAAwArNodUAAAAAAQAAwAtl7wVAAAAAAQAAwCJ/4PEAAAAAAQAAwAyVsw+AQAAAAQAAwCYIWrRAQAAAAQAAwDbp2hrAAAAAAQAAwBYD7l+AAAAAAQAAwAxRh9vAAAAAAQAAwDOEVHyAAAAAAQAAwBO4F10AAAAAAQAAwAVWlkXAAAAAAQAAwCgQOXCAAAAAAQAAwBrkroLAAAAAAQAAwAcw0mRAAAAAAQAAwCrmRf5AAAAAAQAAwCF3ICQAAAAAAQAAwDc24CXAAAAAAQAAwC4Qdu7AQAAAAQAAwBK7az/AAAAAAQAAwAOe0zEAAAAAAQAAwAc6w6sAAAAAAQAAwCaZQpmAwAAAAQAAwAcwhA3CgAAAAQAAwDzHFuFAAAAAAQAAwAaWpOqAAAAAAQAAwDI1/wYAwAAAAQAAwCnxzuKAAAAAAQAAwBvXebuAQAAAAQAAwA/w0UzAAAAAAQAAwD9XLYBAAAAAAQAAwBskecjZAAAAAQAAwBOe0EhAQAAAAQAAwBDTHKOAAAAAAQAAwB+VGuwAAAAAAQAAwAJdHnHAAAAAAQAAwCtwhNqAAAAAAQAAwAKjZSlAAAAAAQAAwByImG7AQAAAAQAAwBTQVO1AAAAAAQAAwCwbpjEAAAAAAQAAwAYtHqYAQAAAAQAAwAqML/ZAAAAAAQAAwCLM+y0AAAAAAQAAwCc9beMAAAAAAQAAwCB6u84AAAAAAQAAwALQtgyAAAAAAQAAwA3n124AQAAAAQAAwBdpcjCAAAAAAQAAwAAcVCoAQAAAAQAAwAvoa8fAAAAAAQAAwAYhbUnDgAAAAQAAwAAU6fYAAAAAAQAAwCNj9nsAQAAAAQAAwD4dEvAAAAAAAEAAQDg5GvHAAQAAwCuMvbbAwAAAAQAAwAb5k/MAAAAAAQAAwDw5wuZAAAAAA=="
cfg.load_experimental = function()
    local _, ind = string.find(experimentalcfg, ":")
    local payload = ind and string.sub(experimentalcfg, ind + 1) or experimentalcfg
    if not payload or #payload == 0 then
        utils.printr(colors.red, "Invalid Experimental Config Format")
        return
    end
    payload = payload:gsub("%s", "")
    payload = payload:gsub("-", "+"):gsub("_", "/")
    local m = #payload % 4
    if m > 0 then payload = payload .. string.rep("=", 4 - m) end
    local ok_dec, decoded = pcall(base64.decode, payload)
    if not ok_dec or not decoded then
        utils.printr(colors.red, "Failed to parse config")
        return
    end
    local success, parsedcfg = pcall(json.parse, decoded)
    if not success or not parsedcfg then
        utils.printr(colors.red, "Failed to parse config")
        return
    end
    if parsedcfg["Version"] ~= _VER then
        utils.printr(colors.red, "CFG Version mismatch current version: %s cfg version: %s", _VER, parsedcfg["Version"])
        return
    end
    local sel = tabs["Configs"].onlyload and ui.get(tabs["Configs"].onlyload) or {}
    local load_all = (#sel == 0)
    for _, v in ipairs(sel) do if v == "All" then load_all = true break end end
    if load_all then
        utils.set_cfg(parsedcfg)
        utils.keypos = parsedcfg["utils.keypos"]
        utils.specpos = parsedcfg["utils.specpos"]
    else
        for _, cat in ipairs(sel) do
            if cat == "Anti-Aim" then
                utils.set_cfg(parsedcfg["Anti-Aimbot"], tabs["Anti-Aimbot"])
            elseif cat == "Visuals" then
                utils.set_cfg(parsedcfg["Visuals"], tabs["Visuals"])
            elseif cat == "Misc" then
                utils.set_cfg(parsedcfg["Misc"], tabs["Misc"])
            elseif cat == "Rage" then
                utils.set_cfg(parsedcfg["Rage"], tabs["Rage"])
            end
        end
    end
    utils.printr(colors.skeet_logs, "Succesfuly loaded config by %s", parsedcfg["User"])
end

cfg.save = function()
    local cfgname = ui.get(tabs["Configs"].textbox)
    if cfgname == nil or string.len(table.concat(utils.split(cfgname))) < 1 then
        local sel = ui.get(tabs["Configs"].configbox)
        if sel ~= nil then
            if type(sel) == "number" then
                cfgname = cfg.names[sel + 1]
            elseif type(sel) == "string" then
                if string.find(sel, "Default") then cfgname = "Default"
                elseif string.find(sel, "Experimental #2") then cfgname = "Experimental #2"
                elseif string.find(sel, "Experimental") then cfgname = "Experimental"
                else cfgname = sel end
            end
        end
    end
    if cfgname == nil or string.len(table.concat(utils.split(cfgname))) < 1 then
        utils.printr(colors.red, "Select Configs or Enter Config Name")
        return
    end
    local cofg = utils.get_config(tabs)
    if not utils.in_table(cfg.names, cfgname) then
        table.insert(cfg.names, cfgname)
        cfg.update_listbox()
        database.write("expensive::cfg_names", cfg.names)
    end
    writefile(string.format("%s31415926535.cfg", cfgname), "osmanhook:"..base64.encode(cofg))
    utils.printr(colors.skeet_logs, "Config Saved")
end
cfg.export = function()
    clipboard.set("osmanhook:"..base64.encode(utils.get_config(tabs)))
    utils.printr(colors.skeet_logs, "Config Exported To Clipboard")
end
cfg.restore = function()
    local cfgname = ui.get(tabs["Configs"].textbox)
    if cfgname == nil or string.len(table.concat(utils.split(cfgname))) < 1 then
        local sel = ui.get(tabs["Configs"].configbox)
        if sel ~= nil then
            if type(sel) == "number" then
                cfgname = cfg.names[sel + 1]
            elseif type(sel) == "string" then
                if string.find(sel, "Default") then cfgname = "Default"
                elseif string.find(sel, "Experimental #2") then cfgname = "Experimental #2"
                elseif string.find(sel, "Experimental") then cfgname = "Experimental"
                else cfgname = sel end
            end
        end
    end
    if cfgname == nil or cfgname == "Default" or string.len(table.concat(utils.split(cfgname))) < 1 then
        utils.printr(colors.red, "Select Configs or Enter Config Name")
        return
    end
    if not utils.in_table(cfg.names, cfgname) then
        if readfile(string.format("%s31415926535.cfg", cfgname)) then
            table.insert(cfg.names, cfgname)
            cfg.update_listbox()
            database.write("expensive::cfg_names", cfg.names)
        else
            utils.printr(colors.red, "No Config To Restore")
        end
    end
end
cfg.delete = function()
    local cfgname = ui.get(tabs["Configs"].textbox)
    if cfgname == nil or string.len(table.concat(utils.split(cfgname))) < 1 then
        local sel = ui.get(tabs["Configs"].configbox)
        if sel ~= nil then
            if type(sel) == "number" then
                cfgname = cfg.names[sel + 1]
            elseif type(sel) == "string" then
                if string.find(sel, "Default") then cfgname = "Default"
                elseif string.find(sel, "Experimental #2") then cfgname = "Experimental #2"
                elseif string.find(sel, "Experimental") then cfgname = "Experimental"
                else cfgname = sel end
            end
        end
    end
    if not cfgname or string.len(table.concat(utils.split(cfgname))) < 1 then
        utils.printr(colors.red, "Select Configs or Enter Config Name")
        return
    end
    if utils.in_table(cfg.names, cfgname) then
        -- Remove from names list
        for i, name in ipairs(cfg.names) do
            if name == cfgname then
                table.remove(cfg.names, i)
                break
            end
        end
        -- update
        cfg.update_listbox()
        database.write("osmanhook::cfg_names", cfg.names)
        -- delete file 
        local file_path = string.format("%s31415926535.cfg", cfgname)
        if readfile(file_path) then
            writefile(file_path, "")
        end
        utils.printr(colors.skeet_logs, "Config '%s' deleted successfully", cfgname)
    else
        utils.printr(colors.red, "Config not found")
    end
end
cfg.load = function()
    do
        local cfgname = ui.get(tabs["Configs"].textbox)
        if cfgname == nil or string.len(table.concat(utils.split(cfgname))) < 1 then
            utils.printr(colors.red, "Select Configs or Enter Config Name")
            return
        end
        local rawcfg = readfile(string.format("%s31415926535.cfg", cfgname))
        if not rawcfg or type(rawcfg) ~= "string" then
            utils.printr(colors.red, "No Config To Load")
            return
        end
        local _, ind = string.find(rawcfg, ":")
        local payload = ind and string.sub(rawcfg, ind + 1) or rawcfg
        if not payload or #payload == 0 then
            utils.printr(colors.red, "Invalid Config")
            return
        end
        payload = payload:gsub("%s", "")
        payload = payload:gsub("[^%w%+/%=_%-%s]", "")
        payload = payload:gsub("-", "+"):gsub("_", "/")
        local m = #payload % 4
        if m > 0 then payload = payload .. string.rep("=", 4 - m) end
        local ok_dec, decoded = pcall(base64.decode, payload)
        local parsedcfg
        if ok_dec and decoded then
            local ok_json, res = pcall(json.parse, decoded)
            if ok_json and type(res) == "table" then
                parsedcfg = res
            elseif ok_json and type(res) == "string" then
                local ok_json2, res2 = pcall(json.parse, res)
                if ok_json2 and type(res2) == "table" then parsedcfg = res2 end
            end
        end
        if not parsedcfg then
            local ok_json_raw, res_raw = pcall(json.parse, payload)
            if ok_json_raw and type(res_raw) == "table" then
                parsedcfg = res_raw
            else
                local unquoted = payload:gsub('^%s*"', ""):gsub('"%s*$', "")
                local ok_json_unq, res_unq = pcall(json.parse, unquoted)
                if ok_json_unq and type(res_unq) == "table" then
                    parsedcfg = res_unq
                else
                    utils.printr(colors.red, "Failed to parse config")
                    return
                end
            end
        end
        if parsedcfg["Version"] ~= _VER then
            utils.printr(colors.red, "CFG Version mismatch current version: %s cfg version: %s", _VER, parsedcfg["Version"])
            return
        end
        local sel = tabs["Configs"].onlyload and ui.get(tabs["Configs"].onlyload) or {}
        local load_all = (#sel == 0)
        for _, v in ipairs(sel) do if v == "All" then load_all = true break end end
        if load_all then
            utils.set_cfg(parsedcfg)
            utils.keypos = parsedcfg["utils.keypos"]
            utils.specpos = parsedcfg["utils.specpos"]
        else
            for _, cat in ipairs(sel) do
                if cat == "Anti-Aim" then
                    utils.set_cfg(parsedcfg["Anti-Aimbot"], tabs["Anti-Aimbot"])
                elseif cat == "Visuals" then
                    utils.set_cfg(parsedcfg["Visuals"], tabs["Visuals"])
                elseif cat == "Misc" then
                    utils.set_cfg(parsedcfg["Misc"], tabs["Misc"])
                elseif cat == "Rage" then
                    utils.set_cfg(parsedcfg["Rage"], tabs["Rage"])
                end
            end
        end
        utils.set_cfg(parsedcfg)
        utils.keypos = parsedcfg["utils.keypos"]
        utils.specpos = parsedcfg["utils.specpos"]
        utils.printr(colors.skeet_logs, "Succesfuly loaded config by %s", parsedcfg["User"])
        return
    end
    local filename
    if cfgname == "Default" then
        filename = "Default31415926535.cfg"
    elseif cfgname == "Experimental" then
        filename = "experimental31415926535.cfg"
    elseif cfgname == "Experimental #2" then
        filename = "experimental231415926535.cfg"
    else
        filename = string.format("%s31415926535.cfg", cfgname)
    end
    local rawcfg
    if cfgname == "Experimental #2" then
        rawcfg = "osmanhook:eyJWaXN1YWxzIjp7Im5pbWJ1cyI6W2ZhbHNlLFsyNTUsMjU1LDI1NSwyNTVdXSwic2lkZW1hcmsiOltmYWxzZSwiTGVmdCJdLCJwcm9maWxlX3BpY3R1cmUiOltmYWxzZSwiTGVmdCJdLCJzY29wZWxpbmVzIjpbdHJ1ZSxmYWxzZSxmYWxzZSwiU2NvcGUgRmlyc3QgQ29sb3IiLFsyNTUsMjU1LDI1NSwyNTVdLCJTY29wZSBTZWNvbmQgQ29sb3IiLFsyNTUsMjU1LDI1NSwwXSwiRGVmYXVsdCIsNSwzNSwxXSwid2F0ZXJtYXJrIjpbdHJ1ZV0sInRyYWNlciI6W2ZhbHNlLFsyNTUsMjU1LDI1NSwyNTVdLDNdLCJmcHNib29zdCI6W3RydWUsWyIzZCBza3kiLCJmb2ciLCJzaGFkb3dzIiwiYmxvb2QiLCJkZWNhbHMiLCJibG9vbSIsIm90aGVyIl1dLCJjb25jb2wiOltmYWxzZSxbMjU1LDI1NSwyNTUsMjU1XV0sImluZGljYXRvcnMiOlt0cnVlLFsxNTMsMTgxLDI1NSwyNTVdLCJQaXhpZXMiLFsiU2NvcGUiXV0sInZlbHdhciI6W2ZhbHNlLFsyNTUsMjU1LDI1NSwyNTVdXSwiYWx0dWlfaWNvbl9jb2xvcnMiOltmYWxzZSwiVGFiIEljb24gQ29sb3IgKERlZmF1bHQpIixbOTAsOTAsOTAsMjU1XSwiVGFiIEljb24gQ29sb3IgKFNlbGVjdGVkKSIsWzIxMCwyMTAsMjEwLDI1NV0sIlRhYiBJY29uIENvbG9yIChIb3ZlcmVkKSIsWzE2NywxNjcsMTY3LDI1NV1dLCJkZWZpbmQiOltmYWxzZSxbMjU1LDI1NSwyNTUsMjU1XV0sImJldHRlcm5hZGUiOnsiMSI6dHJ1ZSwiMiI6WyJTbW9rZSIsIkZpcmUiXSwiMyI6WyJSYWRpdXMiLCJTbW9rZSBUaW1lciJdLCI0IjpbIklnbm9yZSBoYXJtbGVzcyBtb2xvdG92Il0sIjUiOiJTbW9rZSBUaW1lciBDb2xvciIsIjYiOlsxOTgsMTkyLDE5MiwxMjhdLCJzbW9rZSI6WyJTbW9rZSBDb2xvciIsWzYyLDE1OCwyNTAsMjU1XV0sImZpcmUiOlsiRmlyZSBDb2xvciIsWzI1Myw0NSw3NiwyNTVdXX0sInByZWRpY3Rib3giOlt0cnVlLFsiVGFyZ2V0Il1dLCJhcnJvd3MiOlt0cnVlLCJDUzIiLCJNYW51YWwgQ29sb3IiLFsyNTUsMjU1LDI1NSwyMTFdLCJEZXN5bmMgU2lkZSBDb2xvciIsWzAsMjAwLDI1NSwyNTVdLDQwLDEwXSwia2V5YmluZHMiOlt0cnVlXSwiYWRkaW5kIjpbWyJGb3JjZSBIZWFkIiwiRG9ybWFudCIsIkp1bXBzaG90IiwiSGl0Y2hhbmNlIiwiQ2hhcmdlIiwiVGFyZ2V0Il1dLCJzcGVjdGF0b3JzIjpbdHJ1ZSx0cnVlXSwib3V0X29mX2ZvdiI6W2ZhbHNlLHt9LDUwLDVdLCJjcm9zc2RhbWFnZSI6W2ZhbHNlLGZhbHNlLGZhbHNlLCJSaWdodC1Cb3R0b20iXX0sIk1pc2MiOnsidHBlcnNvbiI6W3RydWUsMTAwXSwidHJhc2h0YWxrIjpbZmFsc2UsWyJLaWxsIl0sWyJJbnN0YW50Il1dLCJ0YWdzcGFtZXIiOlt0cnVlXSwidmlld21vZGVsIjpbdHJ1ZSw1NzksMCw1LC0xMF0sInNjb3Bldmlld21vZGVsIjpbZmFsc2VdLCJsZWZ0aGFuZCI6W3RydWVdLCJhc3BlY3RyYXRpbyI6W3RydWUsMTI1XSwidHJhbnNjb3BlIjpbZmFsc2UsWyJTY29wZWQiXSwyMF0sImR1Y2FyaWd5bSI6W2ZhbHNlLDEwMF0sImFuaW1icmVhayI6W3RydWUsdHJ1ZSwiU3RhdGljIExlZ3MiLCJEaXNhYmxlZCIsIkRpc2FibGVkIix7fSwiRmxhc2hlZCJdLCJmYXN0bGFkZGVyIjpbdHJ1ZV0sImF1dG9zbW9rZSI6W3RydWUsW2ZhbHNlLDEsMF1dLCJidXlib3QiOlt0cnVlLCJTY291dCIsIkRlYWdsZVwvUjgiLFsiS2V2bGFyIiwiSGVsbWV0IiwiRGVmdXNlciIsIlpldXMiLCJGaXJlIiwiSEUiLCJTbW9reSJdXSwiZHVtYmFzc19mZWF0dXJlcyI6W2ZhbHNlLCJQdXNoLVVwcyIse31dLCJsb2dzIjpbdHJ1ZSxbIkNvbnNvbGUiLCJTY3JlZW4iXSxbIk9uIEhpdCIsIk9uIE1pc3MiLCJPbiBIdXJ0IiwiT24gRmlyZSJdLCJPbiBIaXQgQ29sb3IiLFsxNTksMjAyLDQzLDI1NV0sIk9uIE1pc3MgQ29sb3IiLFsyNTUsNzEsNzEsMjU1XSwiT24gSHVydCBDb2xvciIsWzE2NiwxNjAsMjIwLDI1NV1dfSwiVmVyc2lvbiI6Mjk3LCJ1dGlscy5zcGVjcG9zIjp7InkiOjE1MywieCI6MjExfSwiQW50aS1BaW1ib3QiOnsiMSI6dHJ1ZSwiQ3JvdWNoIjp7ImRlZl9mbGljayI6W2ZhbHNlXSwicGl0Y2giOiJEb3duIiwiZmFrZWxhZ2xpbWl0IjoxNCwiZmFrZWxhZyI6IlJhbmRvbSIsImJvZHlfeWF3X2ZyZWVzdGFuZCI6ZmFsc2UsInBpdGNoYyI6WzBdLCJ5YXdfaml0dGVyIjoiT2ZmIiwiZGVmZW5zaXZlIjp7ImVuYWJsZSI6dHJ1ZSwieWF3YyI6eyJTcGluIjoyOCwiUmFuZG9tIjpbMCwwXSwiTCZSIjpbMCwwXSwiT3Bwb3NpdGUiOjkwLCJKaXR0ZXIiOlswLDBdLCJTcGluIHYyIjpbLTE1OCwxNDQsMTAwXSwiMTgwIjowfSwicGl0Y2hjIjp7IkN1c3RvbSI6MCwiTCZSIjpbMCwwXSwiUmFuZG9tIHYyIjpbMCwwXSwiSml0dGVyIjpbMCwwXSwiRmx1Y3RhdGUiOltmYWxzZSwwLDAsNTBdfSwidGljayI6MSwieWF3IjoiU3BpbiB2MiIsInBpdGNoIjoiVXAifSwib3ZlcnJpZGUiOnRydWUsInlhd19iYXNlIjoiQXQgdGFyZ2V0cyIsImZvcmNlX2RlZiI6IkFsd2F5cyIsInlhdyI6IkwmUiIsImJvZHlfeWF3YyI6eyJTd2F5IjpbMCwwLDFdLCJTdGF0aWMgdjIiOjAsIkN1c3RvbSBKaXR0ZXIiOlswLDEsMCwxNF0sIkppdHRlciI6MzUsIlN0YXRpYyI6MzAsIkppdHRlciB2MiI6WzMwLDFdfSwieWF3YyI6eyJTcGluIjowLCJMJlIiOlstMzYsMzYsMF0sIlN0YXRpYyI6MCwiRGVsYXllZCI6WzE2LC0yNSwxXSwiMTgwIjowfSwiZmFrZWxhZ2MiOnsiRHluYW1pYyI6WzBdLCJGbHVjdHVhdGUiOlswXSwiUmFuZG9tIjpbNzBdLCJGbHVjdHVhdGUgdjIiOlswLDFdLCJNYXhpbXVtIjpbMF0sIkppdHRlciI6WzZdfSwiYm9keV95YXciOiJKaXR0ZXIiLCJ5YXdfaml0dGVyYyI6eyJDZW50ZXIiOjIwLCJNaW5cL01heCBDZW50ZXIiOlswLDAsMTAwLDFdLCJDdXN0b20gT2Zmc2V0IjpbMCwwLDFdLCJPZmZzZXQiOjAsIlNraXR0ZXIiOjAsIlJhbmRvbSI6MCwiQ3VzdG9tIENlbnRlciI6WzM4LDAsM10sIkwmUiBDZW50ZXIiOlswLDAsMF0sIk53YXkiOlszLDAsMV19fSwiTW92aW5nIjp7ImRlZl9mbGljayI6W2ZhbHNlXSwicGl0Y2giOiJPZmYiLCJmYWtlbGFnbGltaXQiOjE0LCJmYWtlbGFnIjoiTWF4aW11bSIsImJvZHlfeWF3X2ZyZWVzdGFuZCI6ZmFsc2UsInBpdGNoYyI6WzBdLCJ5YXdfaml0dGVyIjoiT2ZmIiwiZGVmZW5zaXZlIjp7ImVuYWJsZSI6ZmFsc2UsInlhd2MiOnsiU3BpbiI6MCwiUmFuZG9tIjpbMCwwXSwiTCZSIjpbMCwwXSwiT3Bwb3NpdGUiOjkwLCJKaXR0ZXIiOlswLDBdLCJTcGluIHYyIjpbMCwwLDUwXSwiMTgwIjowfSwicGl0Y2hjIjp7IkN1c3RvbSI6MCwiTCZSIjpbMCwwXSwiUmFuZG9tIHYyIjpbMCwwXSwiSml0dGVyIjpbMCwwXSwiRmx1Y3RhdGUiOltmYWxzZSwwLDAsNTBdfSwidGljayI6MSwieWF3IjoiRGVmYXVsdCIsInBpdGNoIjoiRGVmYXVsdCJ9LCJvdmVycmlkZSI6ZmFsc2UsInlhd19iYXNlIjoiTG9jYWwgdmlldyIsImZvcmNlX2RlZiI6Ik9mZiIsInlhdyI6Ik9mZiIsImJvZHlfeWF3YyI6eyJTd2F5IjpbMCwwLDFdLCJTdGF0aWMgdjIiOjAsIkN1c3RvbSBKaXR0ZXIiOlswLDEsMCwxNF0sIkppdHRlciI6MCwiU3RhdGljIjowLCJKaXR0ZXIgdjIiOlswLDFdfSwieWF3YyI6eyJTcGluIjowLCJMJlIiOlswLDAsMF0sIlN0YXRpYyI6MCwiRGVsYXllZCI6WzAsMCwxXSwiMTgwIjowfSwiZmFrZWxhZ2MiOnsiRHluYW1pYyI6WzBdLCJGbHVjdHVhdGUiOlswXSwiUmFuZG9tIjpbMF0sIkZsdWN0dWF0ZSB2MiI6WzAsMV0sIk1heGltdW0iOlswXSwiSml0dGVyIjpbMV19LCJib2R5X3lhdyI6Ik9mZiIsInlhd19qaXR0ZXJjIjp7IkNlbnRlciI6MCwiTWluXC9NYXggQ2VudGVyIjpbMCwwLDEwMCwxXSwiQ3VzdG9tIE9mZnNldCI6WzAsMCwxXSwiT2Zmc2V0IjowLCJTa2l0dGVyIjowLCJSYW5kb20iOjAsIkN1c3RvbSBDZW50ZXIiOlswLDAsMV0sIkwmUiBDZW50ZXIiOlswLDAsMF0sIk53YXkiOlszLDAsMV19fSwiY29uZGl0aW9uIjoiQWlyLUNyb3VjaCIsIlNoYXJlZCI6eyJkZWZfZmxpY2siOltmYWxzZV0sInlhd19iYXNlIjoiQXQgdGFyZ2V0cyIsInBpdGNoIjoiRG93biIsImZvcmNlX2RlZiI6Ik9mZiIsImZha2VsYWdsaW1pdCI6MTQsImJvZHlfeWF3IjoiT3Bwb3NpdGUiLCJ5YXciOiJEZWxheWVkIiwiYm9keV95YXdjIjp7IlN3YXkiOlswLDAsMV0sIlN0YXRpYyB2MiI6MCwiQ3VzdG9tIEppdHRlciI6WzYwLDIsMCwxNF0sIkppdHRlciI6NjAsIlN0YXRpYyI6MCwiSml0dGVyIHYyIjpbNjAsM119LCJib2R5X3lhd19mcmVlc3RhbmQiOmZhbHNlLCJwaXRjaGMiOlswXSwieWF3YyI6eyJTcGluIjowLCJMJlIiOlstMzIsMzYsMF0sIlN0YXRpYyI6MCwiRGVsYXllZCI6Wy0xNSwxNywyXSwiMTgwIjowfSwiZmFrZWxhZ2MiOnsiRHluYW1pYyI6WzBdLCJGbHVjdHVhdGUiOlswXSwiUmFuZG9tIjpbMTAwXSwiRmx1Y3R1YXRlIHYyIjpbMTAsOV0sIk1heGltdW0iOls4XSwiSml0dGVyIjpbN119LCJ5YXdfaml0dGVyIjoiT2ZmIiwiZGVmZW5zaXZlIjp7ImVuYWJsZSI6ZmFsc2UsInlhd2MiOnsiU3BpbiI6MCwiUmFuZG9tIjpbMCwwXSwiTCZSIjpbMCwwXSwiT3Bwb3NpdGUiOjkwLCJKaXR0ZXIiOlswLDBdLCJTcGluIHYyIjpbMCwwLDUwXSwiMTgwIjowfSwicGl0Y2hjIjp7IkN1c3RvbSI6MCwiTCZSIjpbMCwwXSwiUmFuZG9tIHYyIjpbMCwwXSwiSml0dGVyIjpbMCwwXSwiRmx1Y3RhdGUiOltmYWxzZSwwLDAsNTBdfSwidGljayI6MSwieWF3IjoiRGVmYXVsdCIsInBpdGNoIjoiRGVmYXVsdCJ9LCJ5YXdfaml0dGVyYyI6eyJDZW50ZXIiOjYyLCJNaW5cL01heCBDZW50ZXIiOlswLDAsMTAwLDFdLCJDdXN0b20gT2Zmc2V0IjpbMCwwLDFdLCJPZmZzZXQiOjAsIlNraXR0ZXIiOjAsIlJhbmRvbSI6MCwiQ3VzdG9tIENlbnRlciI6WzMyLDAsMl0sIkwmUiBDZW50ZXIiOlswLDAsMF0sIk53YXkiOlszLDAsMV19LCJmYWtlbGFnIjoiSml0dGVyIn0sIk9uLVVzZSI6eyJkZWZfZmxpY2siOltmYWxzZV0sInBpdGNoIjoiT2ZmIiwiZmFrZWxhZ2xpbWl0IjoxNCwiZmFrZWxhZyI6Ik1heGltdW0iLCJib2R5X3lhd19mcmVlc3RhbmQiOmZhbHNlLCJwaXRjaGMiOlswXSwieWF3X2ppdHRlciI6Ik9mZiIsImRlZmVuc2l2ZSI6eyJlbmFibGUiOmZhbHNlLCJ5YXdjIjp7IlNwaW4iOjAsIlJhbmRvbSI6WzAsMF0sIkwmUiI6WzAsMF0sIk9wcG9zaXRlIjo5MCwiSml0dGVyIjpbMCwwXSwiU3BpbiB2MiI6WzAsMCw1MF0sIjE4MCI6MH0sInBpdGNoYyI6eyJDdXN0b20iOjAsIkwmUiI6WzAsMF0sIlJhbmRvbSB2MiI6WzAsMF0sIkppdHRlciI6WzAsMF0sIkZsdWN0YXRlIjpbZmFsc2UsMCwwLDUwXX0sInRpY2siOjEsInlhdyI6IkRlZmF1bHQiLCJwaXRjaCI6IkRlZmF1bHQifSwib3ZlcnJpZGUiOmZhbHNlLCJ5YXdfYmFzZSI6IkxvY2FsIHZpZXciLCJmb3JjZV9kZWYiOiJPZmYiLCJ5YXciOiJPZmYiLCJib2R5X3lhd2MiOnsiU3dheSI6WzAsMCwxXSwiU3RhdGljIHYyIjowLCJDdXN0b20gSml0dGVyIjpbMCwxLDAsMTRdLCJKaXR0ZXIiOjAsIlN0YXRpYyI6MCwiSml0dGVyIHYyIjpbMCwxXX0sInlhd2MiOnsiU3BpbiI6MCwiTCZSIjpbMCwwLDBdLCJTdGF0aWMiOjAsIkRlbGF5ZWQiOlswLDAsMV0sIjE4MCI6MH0sImZha2VsYWdjIjp7IkR5bmFtaWMiOlswXSwiRmx1Y3R1YXRlIjpbMF0sIlJhbmRvbSI6WzBdLCJGbHVjdHVhdGUgdjIiOlswLDFdLCJNYXhpbXVtIjpbMF0sIkppdHRlciI6WzFdfSwiYm9keV95YXciOiJPZmYiLCJ5YXdfaml0dGVyYyI6eyJDZW50ZXIiOjAsIk1pblwvTWF4IENlbnRlciI6WzAsMCwxMDAsMV0sIkN1c3RvbSBPZmZzZXQiOlswLDAsMV0sIk9mZnNldCI6MCwiU2tpdHRlciI6MCwiUmFuZG9tIjowLCJDdXN0b20gQ2VudGVyIjpbMCwwLDFdLCJMJlIgQ2VudGVyIjpbMCwwLDBdLCJOd2F5IjpbMywwLDFdfSwiZmFrZWxhZ2xpbWl0IjoxNH0sIkFpciI6eyJkZWZfZmxpY2siOltmYWxzZV0sInBpdGNoIjoiRG93biIsImZha2VsYWdsaW1pdCI6MTQsImZha2VsYWciOiJGbHVjdHVhdGUgdjIiLCJib2R5X3lhd19mcmVlc3RhbmQiOmZhbHNlLCJwaXRjaGMiOlswXSwieWF3X2ppdHRlciI6Ik9mZiIsImRlZmVuc2l2ZSI6eyJlbmFibGUiOnRydWUsInlhd2MiOnsiU3BpbiI6LTE5LCJSYW5kb20iOlswLDBdLCJMJlIiOlswLDBdLCJPcHBvc2l0ZSI6OTAsIkppdHRlciI6WzAsMF0sIlNwaW4gdjIiOlstMTgwLDE4MCwxMDBdLCIxODAiOjQxfSwicGl0Y2hjIjp7IkN1c3RvbSI6MCwiTCZSIjpbMCwwXSwiUmFuZG9tIHYyIjpbLTMzLDE2XSwiSml0dGVyIjpbMCwwXSwiRmx1Y3RhdGUiOlt0cnVlLC00MCwyMiw1OF19LCJ0aWNrIjozLCJ5YXciOiJTcGluIHYyIiwicGl0Y2giOiJaZXJvIn0sIm92ZXJyaWRlIjp0cnVlLCJ5YXdfYmFzZSI6IkF0IHRhcmdldHMiLCJmb3JjZV9kZWYiOiJBbHdheXMiLCJ5YXciOiJMJlIiLCJib2R5X3lhd2MiOnsiU3dheSI6Wy0zNCwzOCwxXSwiU3RhdGljIHYyIjowLCJDdXN0b20gSml0dGVyIjpbMCwxLDAsMTRdLCJKaXR0ZXIiOjQyLCJTdGF0aWMiOjAsIkppdHRlciB2MiI6WzYwLDFdfSwieWF3YyI6eyJTcGluIjowLCJMJlIiOlstNDUsNDUsMF0sIlN0YXRpYyI6MCwiRGVsYXllZCI6Wy0xMywxOCwzXSwiMTgwIjowfSwiZmFrZWxhZ2MiOnsiRHluYW1pYyI6WzBdLCJGbHVjdHVhdGUiOlswXSwiUmFuZG9tIjpbMF0sIkZsdWN0dWF0ZSB2MiI6WzM0LDFdLCJNYXhpbXVtIjpbMF0sIkppdHRlciI6WzFdfSwiYm9keV95YXciOiJKaXR0ZXIiLCJ5YXdfaml0dGVyYyI6eyJDZW50ZXIiOjUwLCJNaW5cL01heCBDZW50ZXIiOlswLDAsMTAwLDFdLCJDdXN0b20gT2Zmc2V0IjpbMCwwLDFdLCJPZmZzZXQiOjAsIlNraXR0ZXIiOjQwLCJSYW5kb20iOjAsIkN1c3RvbSBDZW50ZXIiOlsyMiwwLDFdLCJMJlIgQ2VudGVyIjpbMCwwLDBdLCJOd2F5IjpbMywwLDFdfX0sIlNsb3d3YWxrIjp7ImRlZl9mbGljayI6W2ZhbHNlXSwicGl0Y2giOiJEb3duIiwiZmFrZWxhZ2xpbWl0IjoxNCwiZmFrZWxhZyI6Ik1heGltdW0iLCJib2R5X3lhd19mcmVlc3RhbmQiOmZhbHNlLCJwaXRjaGMiOlswXSwieWF3X2ppdHRlciI6Ik9mZiIsImRlZmVuc2l2ZSI6eyJlbmFibGUiOmZhbHNlLCJ5YXdjIjp7IlNwaW4iOjAsIlJhbmRvbSI6WzAsMF0sIkwmUiI6WzAsMF0sIk9wcG9zaXRlIjo5MCwiSml0dGVyIjpbMCwwXSwiU3BpbiB2MiI6WzAsMCw1MF0sIjE4MCI6MH0sInBpdGNoYyI6eyJDdXN0b20iOjAsIkwmUiI6WzAsMF0sIlJhbmRvbSB2MiI6WzAsMF0sIkppdHRlciI6WzAsMF0sIkZsdWN0YXRlIjpbZmFsc2UsMCwwLDUwXX0sInRpY2siOjEsInlhdyI6IkRlZmF1bHQiLCJwaXRjaCI6IkRlZmF1bHQifSwib3ZlcnJpZGUiOnRydWUsInlhd19iYXNlIjoiQXQgdGFyZ2V0cyIsImZvcmNlX2RlZiI6Ik9mZiIsInlhdyI6IkwmUiIsImJvZHlfeWF3YyI6eyJTd2F5IjpbMCwwLDFdLCJTdGF0aWMgdjIiOjAsIkN1c3RvbSBKaXR0ZXIiOlswLDEsMCwxNF0sIkppdHRlciI6NDgsIlN0YXRpYyI6MCwiSml0dGVyIHYyIjpbMCwxXX0sInlhd2MiOnsiU3BpbiI6MCwiTCZSIjpbLTQ3LDQ5LDI4XSwiU3RhdGljIjowLCJEZWxheWVkIjpbMCwwLDFdLCIxODAiOjB9LCJmYWtlbGFnYyI6eyJEeW5hbWljIjpbMF0sIkZsdWN0dWF0ZSI6WzBdLCJSYW5kb20iOlswXSwiRmx1Y3R1YXRlIHYyIjpbMCwxXSwiTWF4aW11bSI6WzBdLCJKaXR0ZXIiOlsxXX0sImJvZHlfeWF3IjoiSml0dGVyIiwieWF3X2ppdHRlcmMiOnsiQ2VudGVyIjowLCJNaW5cL01heCBDZW50ZXIiOlswLDAsMTAwLDFdLCJDdXN0b20gT2Zmc2V0IjpbMCwwLDFdLCJPZmZzZXQiOjAsIlNraXR0ZXIiOjAsIlJhbmRvbSI6MCwiQ3VzdG9tIENlbnRlciI6WzAsMCwxXSwiTCZSIENlbnRlciI6WzAsMCwwXSwiTndheSI6WzMsMCwxXX19LCJBaXItQ3JvdWNoIjp7ImRlZl9mbGljayI6W2ZhbHNlXSwicGl0Y2giOiJEb3duIiwiZmFrZWxhZ2xpbWl0IjoxNCwiZmFrZWxhZyI6IkZsdWN0dWF0ZSB2MiIsImJvZHlfeWF3X2ZyZWVzdGFuZCI6ZmFsc2UsInBpdGNoYyI6WzBdLCJ5YXdfaml0dGVyIjoiT2ZmIiwiZGVmZW5zaXZlIjp7ImVuYWJsZSI6dHJ1ZSwieWF3YyI6eyJTcGluIjozMiwiUmFuZG9tIjpbMCwwXSwiTCZSIjpbMCwwXSwiT3Bwb3NpdGUiOjkwLCJKaXR0ZXIiOls0OCwtMTA4XSwiU3BpbiB2MiI6Wy0xODAsMTgwLDczXSwiMTgwIjotMTExfSwicGl0Y2hjIjp7IkN1c3RvbSI6MCwiTCZSIjpbMCwwXSwiUmFuZG9tIHYyIjpbLTIwLDE3XSwiSml0dGVyIjpbMCwwXSwiRmx1Y3RhdGUiOltmYWxzZSwtODksMCw1MF19LCJ0aWNrIjoxLCJ5YXciOiJTcGluIHYyIiwicGl0Y2giOiJGbHVjdGF0ZSJ9LCJvdmVycmlkZSI6dHJ1ZSwieWF3X2Jhc2UiOiJBdCB0YXJnZXRzIiwiZm9yY2VfZGVmIjoiQWx3YXlzIiwieWF3IjoiTCZSIiwiYm9keV95YXdjIjp7IlN3YXkiOlswLDAsMV0sIlN0YXRpYyB2MiI6MCwiQ3VzdG9tIEppdHRlciI6WzAsMSwwLDE0XSwiSml0dGVyIjo0MiwiU3RhdGljIjowLCJKaXR0ZXIgdjIiOls2MCwyXX0sInlhd2MiOnsiU3BpbiI6MCwiTCZSIjpbLTQwLDQwLDhdLCJTdGF0aWMiOjAsIkRlbGF5ZWQiOlstNDgsNDYsMV0sIjE4MCI6MH0sImZha2VsYWdjIjp7IkR5bmFtaWMiOlswXSwiRmx1Y3R1YXRlIjpbMF0sIlJhbmRvbSI6WzBdLCJGbHVjdHVhdGUgdjIiOlszMCwxXSwiTWF4aW11bSI6WzBdLCJKaXR0ZXIiOlsxXX0sImJvZHlfeWF3IjoiSml0dGVyIiwieWF3X2ppdHRlcmMiOnsiQ2VudGVyIjo0MCwiTWluXC9NYXggQ2VudGVyIjpbNDMsODAsMTAwLDFdLCJDdXN0b20gT2Zmc2V0IjpbMCwwLDFdLCJPZmZzZXQiOjAsIlNraXR0ZXIiOjAsIlJhbmRvbSI6MCwiQ3VzdG9tIENlbnRlciI6WzQwLDAsOF0sIkwmUiBDZW50ZXIiOlswLDAsMF0sIk53YXkiOls3LDMwLDNdfX19LCJJRCI6MTc2MDk1NzM1OSwiTWFuaXB1bGF0aW9ucyI6eyJ1aXN0eWxlIjpbIkFzdHJhbCIsdHJ1ZSxbMTU2LDE4NCwyNTUsNDNdLGZhbHNlXSwia2V5bmFtZXMiOltudWxsLCJDdXJyZW50IG5hbWU6IERvdWJsZSBUYXAiXX0sIlJhZ2UiOnsidW5zYWZlX2NoYXJnZSI6W3RydWUsWyJBaXIiLCJHcm91bmQiXV0sImp1bXBzaG90IjpbZmFsc2UsW2ZhbHNlLDEsMF0se30sMjgwLDgwMF0sInJlc29sdmVyIjpbZmFsc2UsZmFsc2UsImRlZmF1bHQiLHt9LDQsNSwwXSwiZG9ybWFudCI6eyIxIjp0cnVlLCIyIjpbZmFsc2UsMSw1XSwiMyI6IlNTRyAwOCIsInRibCI6eyJEZXNlcnQgRWFnbGUiOls3MCwxXSwiR2xvYmFsIjpbNzUsMTBdLCJSOCBSZXZvbHZlciI6Wzc1LDFdLCJHM1NHMSBcLyBTQ0FSLTIwIjpbNzAsMV0sIlBpc3RvbCI6Wzc1LDEwXSwiQVdQIjpbNzUsMV0sIlNTRyAwOCI6WzcwLDFdfX0sImxldGhhbCI6eyIxIjp0cnVlLCIyIjpbZmFsc2UsMSw3M10sIjMiOiJQaXN0b2wiLCJ0YmwiOnsiRGVzZXJ0IEVhZ2xlIjo1MCwiR2xvYmFsIjowLCJSOCBSZXZvbHZlciI6NTUsIkczU0cxIFwvIFNDQVItMjAiOjUwLCJQaXN0b2wiOjAsIkFXUCI6ODAsIlNTRyAwOCI6Njh9fSwiZGVsYXlfc2hvdCI6W1tmYWxzZSwxLDBdXSwiaGl0Y2hhbmNlIjp7IjEiOmZhbHNlLCIyIjpbZmFsc2UsMSw4NF0sIjMiOiJTU0cgMDgiLCJ0YmwiOnsiRGVzZXJ0IEVhZ2xlIjotMSwiR2xvYmFsIjotMSwiUjggUmV2b2x2ZXIiOjI1LCJHM1NHMSBcLyBTQ0FSLTIwIjotMSwiUGlzdG9sIjotMSwiQVdQIjotMSwiU1NHIDA4Ijo0fX0sIm9ubHlocyI6W2ZhbHNlLFtmYWxzZSwxLDBdXSwibXBvaW50cyI6eyIxIjp0cnVlLCIyIjoiU1NHIDA4IiwiZW5ibCI6eyJBV1AiOnRydWUsIlI4IFJldm9sdmVyIjpmYWxzZSwiU1NHIDA4Ijp0cnVlfSwidGJsIjp7IkFXUCI6WzcwLDY1LDcwLDYwLDYwLDY1LDcwXSwiUjggUmV2b2x2ZXIiOls2MCw2MCw2MCw2MCw2MCw2MCw2MF0sIlNTRyAwOCI6WzcwLDgwLDgwLDc1LDcwLDgwLDcwXX19fSwidXRpbHMua2V5cG9zIjp7InkiOjIyNCwieCI6MTA0fSwiVXNlciI6ImFkbWluIn0="
    else
        rawcfg = readfile(filename)
    end
    if cfgname == "Experimental" then
        rawcfg = "osmanhook:eyJWaXN1YWxzIjp7Im5pbWJ1cyI6W2ZhbHNlLFsyNTUsMjU1LDI1NSwyNTVdXSwic2lkZW1hcmsiOltmYWxzZSwiTGVmdCJdLCJwcm9maWxlX3BpY3R1cmUiOltmYWxzZSwiTGVmdCJdLCJzY29wZWxpbmVzIjpbdHJ1ZSxmYWxzZSxmYWxzZSwiU2NvcGUgRmlyc3QgQ29sb3IiLFsyNTUsMjU1LDI1NSwyNTVdLCJTY29wZSBTZWNvbmQgQ29sb3IiLFsyNTUsMjU1LDI1NSwwXSwiRGVmYXVsdCIsNSwzNSwxXSwid2F0ZXJtYXJrIjpbdHJ1ZV0sInRyYWNlciI6W2ZhbHNlLFsyNTUsMjU1LDI1NSwyNTVdLDNdLCJmcHNib29zdCI6W3RydWUsWyIzZCBza3kiLCJmb2ciLCJzaGFkb3dzIiwiYmxvb2QiLCJkZWNhbHMiLCJibG9vbSIsIm90aGVyIl1dLCJjb25jb2wiOltmYWxzZSxbMjU1LDI1NSwyNTUsMjU1XV0sImluZGljYXRvcnMiOlt0cnVlLFsxNTMsMTgxLDI1NSwyNTVdLCJQaXhpZXMiLFsiU2NvcGUiXV0sInZlbHdhciI6W2ZhbHNlLFsyNTUsMjU1LDI1NSwyNTVdXSwiYWx0dWlfaWNvbl9jb2xvcnMiOltmYWxzZSwiVGFiIEljb24gQ29sb3IgKERlZmF1bHQpIixbOTAsOTAsOTAsMjU1XSwiVGFiIEljb24gQ29sb3IgKFNlbGVjdGVkKSIsWzIxMCwyMTAsMjEwLDI1NV0sIlRhYiBJY29uIENvbG9yIChIb3ZlcmVkKSIsWzE2NywxNjcsMTY3LDI1NV1dLCJkZWZpbmQiOltmYWxzZSxbMjU1LDI1NSwyNTUsMjU1XV0sImJldHRlcm5hZGUiOnsiMSI6dHJ1ZSwiMiI6WyJTbW9rZSIsIkZpcmUiXSwiMyI6WyJSYWRpdXMiLCJTbW9rZSBUaW1lciJdLCI0IjpbIklnbm9yZSBoYXJtbGVzcyBtb2xvdG92Il0sIjUiOiJTbW9rZSBUaW1lciBDb2xvciIsIjYiOlsxOTgsMTkyLDE5MiwxMjhdLCJzbW9rZSI6WyJTbW9rZSBDb2xvciIsWzYyLDE1OCwyNTAsMjU1XV0sImZpcmUiOlsiRmlyZSBDb2xvciIsWzI1Myw0NSw3NiwyNTVdXX0sInByZWRpY3Rib3giOlt0cnVlLFsiVGFyZ2V0Il1dLCJhcnJvd3MiOlt0cnVlLCJDUzIiLCJNYW51YWwgQ29sb3IiLFsyNTUsMjU1LDI1NSwyMTFdLCJEZXN5bmMgU2lkZSBDb2xvciIsWzAsMjAwLDI1NSwyNTVdLDQwLDEwXSwia2V5YmluZHMiOlt0cnVlXSwiYWRkaW5kIjpbWyJGb3JjZSBIZWFkIiwiRG9ybWFudCIsIkp1bXBzaG90IiwiSGl0Y2hhbmNlIiwiQ2hhcmdlIiwiVGFyZ2V0Il1dLCJzcGVjdGF0b3JzIjpbdHJ1ZSx0cnVlXSwib3V0X29mX2ZvdiI6W2ZhbHNlLHt9LDUwLDVdLCJjcm9zc2RhbWFnZSI6W2ZhbHNlLGZhbHNlLGZhbHNlLCJSaWdodC1Cb3R0b20iXX0sIk1pc2MiOnsidHBlcnNvbiI6W3RydWUsMTAwXSwidHJhc2h0YWxrIjpbZmFsc2UsWyJLaWxsIl0sWyJJbnN0YW50Il1dLCJ0YWdzcGFtZXIiOlt0cnVlXSwidmlld21vZGVsIjpbdHJ1ZSw1NzksMCw1LC0xMF0sInNjb3Bldmlld21vZGVsIjpbZmFsc2VdLCJsZWZ0aGFuZCI6W3RydWVdLCJhc3BlY3RyYXRpbyI6W3RydWUsMTI1XSwidHJhbnNjb3BlIjpbZmFsc2UsWyJTY29wZWQiXSwyMF0sImR1Y2FyaWd5bSI6W2ZhbHNlLDEwMF0sImFuaW1icmVhayI6W3RydWUsdHJ1ZSwiU3RhdGljIExlZ3MiLCJEaXNhYmxlZCIsIkRpc2FibGVkIix7fSwiRmxhc2hlZCJdLCJmYXN0bGFkZGVyIjpbdHJ1ZV0sImF1dG9zbW9rZSI6W3RydWUsW2ZhbHNlLDEsMF1dLCJidXlib3QiOlt0cnVlLCJTY291dCIsIkRlYWdsZVwvUjgiLFsiS2V2bGFyIiwiSGVsbWV0IiwiRGVmdXNlciIsIlpldXMiLCJGaXJlIiwiSEUiLCJTbW9reSJdXSwiZHVtYmFzc19mZWF0dXJlcyI6W2ZhbHNlLCJQdXNoLVVwcyIse31dLCJsb2dzIjpbdHJ1ZSxbIkNvbnNvbGUiLCJTY3JlZW4iXSxbIk9uIEhpdCIsIk9uIE1pc3MiXSx7fV0sIlZlcnNpb24iOjI5NywidXRpbHMuc3BlY3BvcyI6eyJ5IjoyMTYsIngiOjE5Mn0sIkFudGktQWltYm90Ijp7IjEiOnRydWUsIkNyb3VjaCI6eyJkZWZfZmxpY2siOltmYWxzZV0sInBpdGNoIjoiRG93biIsImZha2VsYWdsbGltaXQiOjE0LCJmYWtlbGFnIjoiUmFuZG9tIiwiYm9keV95YXdfZnJlZXN0YW5kIjpmYWxzZSwicGl0Y2hjIjpbMF0sInlhd19qaXR0ZXIiOiJPZmYiLCJkZWZlbnNpdmUiOnsiZW5hYmxlIjp0cnVlLCJ5YXdjIjp7IlNwaW4iOjI4LCJSYW5kb20iOlswLDBdLCJMJlIiOlswLDBdLCJPcHBvc2l0ZSI6OTAsIkppdHRlciI6WzAsMF0sIlNwaW4gdjIiOlstMTU4LDE0NCwxMDBdLCIxODAiOjB9LCJwaXRjaGMiOnsiQ3VzdG9tIjowLCJMJlIiOlswLDBdLCJSYW5kb20gdjIiOlswLDBdLCJKaXR0ZXIiOlswLDBdLCJGbHVjdGF0ZSI6W2ZhbHNlLDAsMCw1MF19LCJ0aWNrIjoxLCJ5YXciOiJTcGluIHYyIiwicGl0Y2giOiJVcCJ9LCJvdmVycmlkZSI6dHJ1ZSwieWF3X2Jhc2UiOiJBdCB0YXJnZXRzIiwiZm9yY2VfZGVmIjoiQWx3YXlzIiwieWF3IjoiTCZSIiwiYm9keV95YXciOnsiU3dheSI6WzAsMCwxXSwiU3RhdGljIHYyIjowLCJDdXN0b20gSml0dGVyIjpbMCwxLDAsMTRdLCJKaXR0ZXIiOjM1LCJTdGF0aWMiOjAsIkppdHRlciB2MiI6WzMwLDFdfSwieWF3YyI6eyJTcGluIjowLCJMJlIiOlstMzYsMzYsMF0sIlN0YXRpYyI6MCwiRGVsYXllZCI6WzE2LC0yNSwxXSwiMTgwIjowfSwiZmFrZWxhZ2MiOnsiRHluYW1pYyI6WzBdLCJGbHVjdHVhdGUiOlswXSwiUmFuZG9tIjpbNzBdLCJGbHVjdHVhdGUgdjIiOlswLDFdLCJNYXhpbXVtIjpbMF0sIkppdHRlciI6WzZdfSwiYm9keV95YXciOiJKaXR0ZXIiLCJ5YXdfaml0dGVyYyI6eyJDZW50ZXIiOjIwLCJNaW5cL01heCBDZW50ZXIiOlswLDAsMTAwLDFdLCJDdXN0b20gT2Zmc2V0IjpbMCwwLDFdLCJPZmZzZXQiOjAsIlNraXR0ZXIiOjAsIlJhbmRvbSI6MCwiQ3VzdG9tIENlbnRlciI6WzM4LDAsM10sIkwmUiBDZW50ZXIiOlswLDAsMF0sIk53YXkiOlszLDAsMV19fSwiTW92aW5nIjp7ImRlZl9mbGljayI6W2ZhbHNlXSwicGl0Y2giOiJPZmYiLCJmYWtlbGFnbGltaXQiOjE0LCJmYWtlbGFnIjoiTWF4aW11bSIsImJvZHlfeWF3X2ZyZWVzdGFuZCI6ZmFsc2UsInBpdGNoYyI6WzBdLCJ5YXdfaml0dGVyIjoiT2ZmIiwiZGVmZW5zaXZlIjp7ImVuYWJsZSI6ZmFsc2UsInlhd2MiOnsiU3BpbiI6MCwiUmFuZG9tIjpbMCwwXSwiTCZSIjpbMCwwXSwiT3Bwb3NpdGUiOjkwLCJKaXR0ZXIiOlswLDBdLCJTcGluIHYyIjpbMCwwLDUwXSwiMTgwIjowfSwicGl0Y2hjIjp7IkN1c3RvbSI6MCwiTCZSIjpbMCwwXSwiUmFuZG9tIHYyIjpbMCwwXSwiSml0dGVyIjpbMCwwXSwiRmx1Y3RhdGUiOltmYWxzZSwwLDAsNTBdfSwidGljayI6MSwieWF3IjoiRGVmYXVsdCIsInBpdGNoIjoiRGVmYXVsdCJ9LCJvdmVycmlkZSI6ZmFsc2UsInlhd19iYXNlIjoiTG9jYWwgdmlldyIsImZvcmNlX2RlZiI6Ik9mZiIsInlhdyI6Ik9mZiIsImJvZHlfeWF3YyI6eyJTd2F5IjpbMCwwLDFdLCJTdGF0aWMgdjIiOjAsIkN1c3RvbSBKaXR0ZXIiOlswLDEsMCwxNF0sIkppdHRlciI6MCwiU3RhdGljIjowLCJKaXR0ZXIgdjIiOlswLDFdfSwieWF3YyI6eyJTcGluIjowLCJMJlIiOlswLDAsMF0sIlN0YXRpYyI6MCwiRGVsYXllZCI6WzAsMCwxXSwiMTgwIjowfSwiZmFrZWxhZ2MiOnsiRHluYW1pYyI6WzBdLCJGbHVjdHVhdGUiOlswXSwiUmFuZG9tIjpbMF0sIkZsdWN0dWF0ZSB2MiI6WzAsMV0sIk1heGltdW0iOlswXSwiSml0dGVyIjpbMV19LCJib2R5X3lhdyI6Ik9mZiIsInlhd19qaXR0ZXJjIjp7IkNlbnRlciI6MCwiTWluXC9NYXggQ2VudGVyIjpbMCwwLDEwMCwxXSwiQ3VzdG9tIE9mZnNldCI6WzAsMCwxXSwiT2Zmc2V0IjowLCJTa2l0dGVyIjowLCJSYW5kb20iOjAsIkN1c3RvbSBDZW50ZXIiOlswLDAsMV0sIkwmUiBDZW50ZXIiOlswLDAsMF0sIk53YXkiOlszLDAsMV19fSwiY29uZGl0aW9uIjoiQ3JvdWNoIiwiU2hhcmVkIjp7ImRlZl9mbGljayI6W2ZhbHNlXSwieWF3X2Jhc2UiOiJBdCB0YXJnZXRzIiwicGl0Y2giOiJEb3duIiwiZm9yY2VfZGVmIjoiT2ZmIiwiZmFrZWxhZ2xpbWl0IjoxNCwiYm9keV95YXciOiJPcHBvc2l0ZSIsInlhdyI6IkRlbGF5ZWQiLCJib2R5X3lhd2MiOnsiU3dheSI6WzAsMCwxXSwiU3RhdGljIHYyIjowLCJDdXN0b20gSml0dGVyIjpbNjAsMiwwLDE0XSwiSml0dGVyIjo2MCwiU3RhdGljIjowLCJKaXR0ZXIgdjIiOls2MCwzXX0sImJvZHlfeWF3X2ZyZWVzdGFuZCI6ZmFsc2UsInBpdGNoYyI6WzBdLCJ5YXdjIjp7IlNwaW4iOjAsIkwmUiI6Wy0zMiwzNiwwXSwiU3RhdGljIjowLCJEZWxheWVkIjpbLTE1LDE3LDJdLCIxODAiOjB9LCJmYWtlbGFnYyI6eyJEeW5hbWljIjpbMF0sIkZsdWN0dWF0ZSI6WzBdLCJSYW5kb20iOlsxMDBdLCJGbHVjdHVhdGUgdjIiOlsxMCw5XSwiTWF4aW11bSI6WzhdLCJKaXR0ZXIiOls3XX0sInlhd19qaXR0ZXIiOiJPZmYiLCJkZWZlbnNpdmUiOnsiZW5hYmxlIjp0cnVlLCJ5YXdjIjp7IlNwaW4iOjAsIlJhbmRvbSI6WzAsMF0sIkwmUiI6WzAsMF0sIk9wcG9zaXRlIjo5MCwiSml0dGVyIjpbMCwwXSwiU3BpbiB2MiI6WzAsMCw1MF0sIjE4MCI6MH0sInBpdGNoYyI6eyJDdXN0b20iOjAsIkwmUiI6WzAsMF0sIlJhbmRvbSB2MiI6WzAsMF0sIkppdHRlciI6WzAsMF0sIkZsdWN0YXRlIjpbZmFsc2UsMCwwLDUwXX0sInRpY2siOjEsInlhdyI6IkRlZmF1bHQiLCJwaXRjaCI6IkRlZmF1bHQifSwib3ZlcnJpZGUiOmZhbHNlLCJ5YXdfYmFzZSI6IkxvY2FsIHZpZXciLCJmb3JjZV9kZWYiOiJPZmYiLCJ5YXciOiJPZmYiLCJib2R5X3lhd2MiOnsiU3dheSI6WzAsMCwxXSwiU3RhdGljIHYyIjowLCJDdXN0b20gSml0dGVyIjpbMCwxLDAsMTRdLCJKaXR0ZXIiOjAsIlN0YXRpYyI6MCwiSml0dGVyIHYyIjpbMCwxXX0sInlhd2MiOnsiU3BpbiI6MCwiTCZSIjpbMCwwLDBdLCJTdGF0aWMiOjAsIkRlbGF5ZWQiOlswLDAsMV0sIjE4MCI6MH0sImZha2VsYWdjIjp7IkR5bmFtaWMiOlswXSwiRmx1Y3R1YXRlIjpbMF0sIlJhbmRvbSI6WzBdLCJGbHVjdHVhdGUgdjIiOlswLDFdLCJNYXhpbXVtIjpbMF0sIkppdHRlciI6WzFdfSwiYm9keV95YXciOiJPZmYiLCJ5YXdfaml0dGVyYyI6eyJDZW50ZXIiOjAsIk1pblwvTWF4IENlbnRlciI6WzAsMCwxMDAsMV0sIkN1c3RvbSBPZmZzZXQiOlswLDAsMV0sIk9mZnNldCI6MCwiU2tpdHRlciI6MCwiUmFuZG9tIjowLCJDdXN0b20gQ2VudGVyIjpbMCwwLDFdLCJMJlIgQ2VudGVyIjpbMCwwLDBdLCJOd2F5IjpbMywwLDFdfX0="
    end
    if cfgname == "Experimental" then
        rawcfg = experimentalcfg
    end
    -- Prefer database-stored payload for Experimental #2, if present
    if cfgname == "Experimental #2" then
        local dbraw = database.read("osmanhook::experimental2cfg")
        if type(dbraw) == "string" and dbraw:find("osmanhook:") then
            rawcfg = dbraw
        end
    end
    if not rawcfg then
        utils.printr(colors.red, "No Config To Load")
        return
    end
    local _, ind = string.find(rawcfg, ":")
    local payload = ind and string.sub(rawcfg, ind + 1) or rawcfg
    if not payload or #payload == 0 then
        utils.printr(colors.red, "Invalid Config")
        return
    end
    payload = payload:gsub("%s", "")
    payload = payload:gsub("[^%w%+/%=_%-%s]", "")
    payload = payload:gsub("-", "+"):gsub("_", "/")
    local m = #payload % 4
    if m > 0 then payload = payload .. string.rep("=", 4 - m) end
    local ok_dec, decoded = pcall(base64.decode, payload)
    local parsedcfg
    if ok_dec and decoded then
        local ok_json, res = pcall(json.parse, decoded)
        if ok_json and type(res) == "table" then
            parsedcfg = res
        elseif ok_json and type(res) == "string" then
            local ok_json2, res2 = pcall(json.parse, res)
            if ok_json2 and type(res2) == "table" then parsedcfg = res2 end
        end
    end
    if not parsedcfg then
        local ok_json_raw, res_raw = pcall(json.parse, payload)
        if ok_json_raw and type(res_raw) == "table" then
            parsedcfg = res_raw
        else
            local unquoted = payload:gsub('^%s*"', ""):gsub('"%s*$', "")
            local ok_json_unq, res_unq = pcall(json.parse, unquoted)
            if ok_json_unq and type(res_unq) == "table" then
                parsedcfg = res_unq
            else
                utils.printr(colors.red, "Failed to parse config")
                return
            end
        end
    end
    if parsedcfg["Version"] ~= _VER then
        utils.printr(colors.red, "CFG Version mismatch current version: %s cfg version: %s", _VER, parsedcfg["Version"])
        return
    end
    local sel = tabs["Configs"].onlyload and ui.get(tabs["Configs"].onlyload) or {}
    local load_all = (#sel == 0)
    for _, v in ipairs(sel) do if v == "All" then load_all = true break end end
    if load_all then
        utils.set_cfg(parsedcfg)
        utils.keypos = parsedcfg["utils.keypos"]
        utils.specpos = parsedcfg["utils.specpos"]
    else
        for _, cat in ipairs(sel) do
            if cat == "Anti-Aim" then
                utils.set_cfg(parsedcfg["Anti-Aimbot"], tabs["Anti-Aimbot"])
            elseif cat == "Visuals" then
                utils.set_cfg(parsedcfg["Visuals"], tabs["Visuals"])
            elseif cat == "Misc" then
                utils.set_cfg(parsedcfg["Misc"], tabs["Misc"])
            elseif cat == "Rage" then
                utils.set_cfg(parsedcfg["Rage"], tabs["Rage"])
            end
        end
    end
    utils.printr(colors.skeet_logs, "Succesfuly loaded config by %s", parsedcfg["User"])
end
ui.set_callback(tabs["Configs"].configbox, function(id)
    local sel = ui.get(id)
    local name = nil
    if type(sel) == "number" then
        name = cfg.names[sel + 1]
    elseif type(sel) == "string" then
        for i, n in ipairs(cfg.names) do
            if sel == n or sel == (cfg_colored_name and cfg_colored_name(n) or n) then
                name = n
                break
            end
        end
    end
    if name then
        ui.set(tabs["Configs"].textbox, name)
    end
end)
    for key, val in pairs(cfg.names) do
        local fname
        if val == "Default" then
            fname = "Default31415926535.cfg"
        elseif val == "Experimental" then
            fname = "experimental31415926535.cfg"
        elseif val == "Experimental #2" then
            fname = "experimental231415926535.cfg"
        else
            fname = string.format("%s31415926535.cfg", val)
        end
        if (val ~= "Default" and val ~= "Experimental" and val ~= "Experimental #2") and not readfile(fname) then
            table.remove(cfg.names, key)
            database.write("osmanhook::cfg_names", cfg.names)
        end
    end
    -- default/experimental cfgs cant be deleted
    local defaultcfg = "osmanhook:"..base64.encode(utils.get_config(tabs))
    local function ensure_cfg(name, cfgstr, filename)
        if not readfile(filename) and type(cfgstr) == "string" then
            writefile(filename, cfgstr)
        end
        local present = false
        for _, n in ipairs(cfg.names) do
            if n == name then present = true break end
        end
        if not present then
            local pos = name == "Default" and 1 or (name == "Experimental" and 2 or (name == "Experimental #2" and 3 or 4))
            table.insert(cfg.names, pos, name)
            database.write("osmanhook::cfg_names", cfg.names)
        end
    end
    ensure_cfg("Default", defaultcfg, "Default31415926535.cfg")
    ensure_cfg("Experimental", nil, "experimental31415926535.cfg")
    ensure_cfg("Experimental #2", nil, "experimental231415926535.cfg")
    -- reorder so that the default is #1, experimental is #2, and experimental #2 is #3
    local defIndex, expIndex, exp2Index
    for i, n in ipairs(cfg.names) do
        if n == "Default" then defIndex = i end
        if n == "Experimental" then expIndex = i end
        if n == "Experimental #2" then exp2Index = i end
    end
    if defIndex and defIndex ~= 1 then
        table.remove(cfg.names, defIndex)
        table.insert(cfg.names, 1, "Default")
    end
    -- refresh indices after potential move
    defIndex, expIndex, exp2Index = nil, nil, nil
    for i, n in ipairs(cfg.names) do
        if n == "Default" then defIndex = i end
        if n == "Experimental" then expIndex = i end
        if n == "Experimental #2" then exp2Index = i end
    end
    if expIndex and expIndex ~= 2 then
        table.remove(cfg.names, expIndex)
        table.insert(cfg.names, 2, "Experimental")
    end
    -- refresh indices again after experimental move
    defIndex, expIndex, exp2Index = nil, nil, nil
    for i, n in ipairs(cfg.names) do
        if n == "Default" then defIndex = i end
        if n == "Experimental" then expIndex = i end
        if n == "Experimental #2" then exp2Index = i end
    end
    if exp2Index and exp2Index ~= 3 then
        table.remove(cfg.names, exp2Index)
        table.insert(cfg.names, 3, "Experimental #2")
    end
    database.write("osmanhook::cfg_names", cfg.names)
    cfg.update_listbox()

    local experimental2cfg = "osmanhook:eyJWaXN1YWxzIjp7Im5pbWJ1cyI6W2ZhbHNlLFsyNTUsMjU1LDI1NSwyNTVdXSwic2lkZW1hcmsiOltmYWxzZSwiTGVmdCJdLCJzY29wZWxpbmVzIjpbdHJ1ZSxmYWxzZSxmYWxzZSwiU2NvcGUgRmlyc3QgQ29sb3IiLFsyNTUsMjU1LDI1NSwyNTVdLCJTY29wZSBTZWNvbmQgQ29sb3IiLFsyNTUsMjU1LDI1NSwwXSwiRGVmYXVsdCIsNSwzNSwxXSwiYXJyb3dzIjpbdHJ1ZSwiVGVhbVNrZWV0IiwiTWFudWFsIENvbG9yIixbMjU1LDI1NSwyNTUsMjExXSwiRGVzeW5jIFNpZGUgQ29sb3IiLFswLDIwMCwyNTUsMjU1XSw0MCwxMF0sInRyYWNlciI6W2ZhbHNlLFsyNTUsMjU1LDI1NSwyNTVdLDNdLCJmcHNib29zdCI6W3RydWUsWyIzZCBza3kiLCJmb2ciLCJzaGFkb3dzIiwiYmxvb2QiLCJkZWNhbHMiLCJibG9vbSIsIm90aGVyIl1dLCJ3YXRlcm1hcmsiOlt0cnVlLFsiTmFtZSIsIlRpY2tzIiwiUGluZyIsIlRpbWUiXSwiRGlzcGxheSBOYW1lIl0sImluZGljYXRvcnMiOlt0cnVlLFsxNTMsMTgxLDI1NSwyNTVdLCJQaXhpZXMiLFsiU2NvcGUiXV0sImNvbmNvbCI6W2ZhbHNlLFsyNTUsMjU1LDI1NSwyNTVdXSwiZGVmaW5kIjpbZmFsc2UsWzI1NSwyNTUsMjU1LDI1NV1dLCJiZXR0ZXJuYWRlIjp7IjEiOnRydWUsIjIiOlsiU21va2UiLCJGaXJlIl0sIjMiOlsiUmFkaXVzIiwiU21va2UgVGltZXIiXSwiNCI6WyJJZ25vcmUgaGFybWxlc3MgbW9sb3RvdiJdLCI1IjoiU21va2UgVGltZXIgQ29sb3IiLCI2IjpbMTk4LDE5MiwxOTIsMTI4XSwic21va2UiOlsiU21va2UgQ29sb3IiLFs2MiwxNTgsMjUwLDI1NV1dLCJmaXJlIjpbIkZpcmUgQ29sb3IiLFsyNTMsNDUsNzYsMjU1XV19LCJwcmVkaWN0Ym94IjpbdHJ1ZSxbIlRhcmdldCJdXSwiYWRkaW5kIjpbe31dLCJrZXliaW5kcyI6W3RydWVdLCJvdXRfb2ZfZm92IjpbZmFsc2Use30sNTAsNV0sInZlbHdhciI6W3RydWUsWzI1NSwyNTUsMjU1LDI1NV1dLCJzcGVjdGF0b3JzIjpbdHJ1ZSx0cnVlXSwiY3Jvc3NkYW1hZ2UiOlt0cnVlLGZhbHNlLHRydWUsIlJpZ2h0LVRvcCJdfSwiTWlzYyI6eyJ0cGVyc29uIjpbdHJ1ZSwzMF0sInRyYXNodGFsayI6W2ZhbHNlLHt9LHt9XSwidGFnc3BhbWVyIjpbZmFsc2VdLCJ2aWV3bW9kZWwiOlt0cnVlLDYwMCwtMywtODMsLTEwXSwic2NvcGV2aWV3bW9kZWwiOltmYWxzZV0sImxlZnRoYW5kIjpbdHJ1ZV0sImFzcGVjdHJhdGlvIjpbZmFsc2UsMTI1XSwidHJhbnNjb3BlIjpbZmFsc2UsWyJHcmVuYWRlIl0sMjBdLCJkdWNhcmlneW0iOltmYWxzZSwxMDBdLCJhbmltYnJlYWsiOlt0cnVlLHRydWUsIlN0YXRpYyBMZWdzIiwiSml0dGVyIiwiRGlzYWJsZWQiLHt9LCJGbGFzaGVkIl0sImZhc3RsYWRkZXIiOlt0cnVlXSwiYXV0b3Ntb2tlIjpbZmFsc2UsW2ZhbHNlLDEsMF1dLCJidXlib3QiOlt0cnVlLCJTY291dCIsIkRlYWdsZVwvUjgiLFsiS2V2bGFyIiwiSGVsbWV0IiwiRGVmdXNlciIsIlpldXMiLCJGaXJlIiwiSEUiLCJTbW9rZSJdXSwiZmlmdGVlbmsiOlt0cnVlLCIxNUsgSW5pdGlhbCIsIlN1cnZpdmFsIl0sImRpZmYiOlt0cnVlXSwidGFnZ2VyIjpbZmFsc2VdLCJza3lkb21lIjpbZmFsc2UsIkF1dG8iXSwibW9sbyI6W2ZhbHNlLFsiT24gQWlyIl0sIk5vcm1hbCJdLCJkZWZjdXN0b20iOlt7fSx7fSx7fSx7fSx7fV0sImxvZ3MiOlt0cnVlLFsiRXZlbnQgbG9nIiwiQ29uc29sZSJdLFsiT24gSGl0IiwiT24gTWlzcyIsIk9uIEh1cnQiXSx0cnVlLHRydWUsdHJ1ZSx0cnVlLHRydWUsdHJ1ZV0sInByZXNldCI6W2ZhbHNlLCJEb3VibGUgVGFwIGhlYWQiXX0sIlJhZ2UiOnsianVtcHNob3QiOlt0cnVlLHRydWUsW10sMCwwXSwiaGl0Y2hhbmNlIjpbdHJ1ZSx0cnVlLCJBZGFwdGl2ZSIse31dLCJsZXRoYWwiOlt0cnVlLFsiSGl0Y2hhbmNlIl0sW11dLCJkb3JtYW50IjpbZmFsc2UsZmFsc2UsIkFkYXB0aXZlIix7fV19LCJBbnRpLUFpbWJvdCI6eyIxIjp0cnVlLCJjb25kaXRpb24iOiJTdGFuZGluZyIsImJ1aWxkZXIiOmZhbHNlLCJleHRlcCI6dHJ1ZSwiaW52ZXJ0ZXIiOnsibW9kZSI6IkFsdCBLZXkiLCJob3RrZXkiOlsiT24gaG90a2V5IiwweDEyXX0sInNpZGVfc3BlY2lmaWNfZW5hYmxlZCI6ZmFsc2UsInNpZGVfc3BlY2lmaWNfdGVhbSI6IlQiLCJjb3B5X3RvX29wcG9zaXRlX3RlYW0iOmZhbHNlLCJTaGFyZWQiOnsicGl0Y2giOiJPZmYiLCJwaXRjaGMiOnt9LCJ5YXdfc3dheSI6MCwieWF3IjoiMTgwIiwieWF3YyI6eyJEZWZhdWx0IjoweX0sInlhd19qaXR0ZXIiOiJPZmYiLCJ5YXdfaml0dGVyYyI6e30sImJvZHlfeWF3IjoiT2ZmIiwiYm9keV95YXdjIjp7fSwiZmFrZWxhZyI6IkFsd2F5cyBvbiIsImZha2VsYWdjIjp7IkFsd2F5cyBvbiI6MTR9LCJkZWZlbnNpdmUiOnsiZW5hYmxlIjpmYWxzZSwicGl0Y2giOiJEZWZhdWx0IiwicGl0Y2hjIjp7fSwieWF3IjoiRGVmYXVsdCIsInlhd2MiOnt9LCJ0aWNrIjoxNX0sImRlZl9mbGljayI6W2ZhbHNlLDAuNSxbXV19LCJTdGFuZGluZyI6eyJvdmVycmlkZSI6ZmFsc2UsInBpdGNoIjoiT2ZmIiwicGl0Y2hjIjp7fSwieWF3X3N3YXkiOjAsInlhdyI6IjE4MCIsInlhd2MiOnsiRGVmYXVsdCI6MH0sInlhd19qaXR0ZXIiOiJPZmYiLCJ5YXdfaml0dGVyYyI6e30sImJvZHlfeWF3IjoiT2ZmIiwiYm9keV95YXdjIjp7fSwiZmFrZWxhZyI6IkFsd2F5cyBvbiIsImZha2VsYWdjIjp7IkFsd2F5cyBvbiI6MTR9LCJkZWZlbnNpdmUiOnsiZW5hYmxlIjpmYWxzZSwicGl0Y2giOiJEZWZhdWx0IiwicGl0Y2hjIjp7fSwieWF3IjoiRGVmYXVsdCIsInlhd2MiOnt9LCJ0aWNrIjoxNX0sImRlZl9mbGljayI6W2ZhbHNlLDAuNSxbXV19LCJNb3ZpbmciOnsib3ZlcnJpZGUiOmZhbHNlLCJwaXRjaCI6Ik9mZiIsInBpdGNoYyI6e30sInlhd19zd2F5IjowLCJ5YXciOiIxODAiLCJ5YXdjIjp7IkRlZmF1bHQiOjB9LCJ5YXdfaml0dGVyIjoiT2ZmIiwieWF3X2ppdHRlcmMiOnt9LCJib2R5X3lhdyI6Ik9mZiIsImJvZHlfeWF3YyI6e30sImZha2VsYWciOiJBbHdheXMgb24iLCJmYWtlbGFnYyI6eyJBbHdheXMgb24iOjE0fSwiZGVmZW5zaXZlIjp7ImVuYWJsZSI6ZmFsc2UsInBpdGNoIjoiRGVmYXVsdCIsInBpdGNoYyI6e30sInlhdyI6IkRlZmF1bHQiLCJ5YXdjIjp7fSwidGljayI6MTV9LCJkZWZfZmxpY2siOltmYWxzZSwwLjUsW11dfSwiU2xvdy1XYWxraW5nIjp7Im92ZXJyaWRlIjpmYWxzZSwicGl0Y2giOiJPZmYiLCJwaXRjaGMiOnt9LCJ5YXdfc3dheSI6MCwieWF3IjoiMTgwIiwieWF3YyI6eyJEZWZhdWx0IjowfSwieWF3X2ppdHRlciI6Ik9mZiIsInlhd19qaXR0ZXJjIjp7fSwiYm9keV95YXciOiJPZmYiLCJib2R5X3lhd2MiOnt9LCJmYWtlbGFnIjoiQWx3YXlzIG9uIiwiZmFrZWxhZ2MiOnsiQWx3YXlzIG9uIjoxNH0sImRlZmVuc2l2ZSI6eyJlbmFibGUiOmZhbHNlLCJwaXRjaCI6IkRlZmF1bHQiLCJwaXRjaGMiOnt9LCJ5YXciOiJEZWZhdWx0IiwieWF3YyI6e30sInRpY2siOjE1fSwiZGVmX2ZsaWNrIjpbZmFsc2UsMC41LFtdXX0sIkR1Y2tpbmciOnsib3ZlcnJpZGUiOmZhbHNlLCJwaXRjaCI6Ik9mZiIsInBpdGNoYyI6e30sInlhd19zd2F5IjowLCJ5YXciOiIxODAiLCJ5YXdjIjp7IkRlZmF1bHQiOjB9LCJ5YXdfaml0dGVyIjoiT2ZmIiwieWF3X2ppdHRlcmMiOnt9LCJib2R5X3lhdyI6Ik9mZiIsImJvZHlfeWF3YyI6e30sImZha2VsYWciOiJBbHdheXMgb24iLCJmYWtlbGFnYyI6eyJBbHdheXMgb24iOjE0fSwiZGVmZW5zaXZlIjp7ImVuYWJsZSI6ZmFsc2UsInBpdGNoIjoiRGVmYXVsdCIsInBpdGNoYyI6e30sInlhdyI6IkRlZmF1bHQiLCJ5YXdjIjp7fSwidGljayI6MTV9LCJkZWZfZmxpY2siOltmYWxzZSwwLjUsW11dfSwiSW4tQWlyIjp7Im92ZXJyaWRlIjpmYWxzZSwicGl0Y2giOiJPZmYiLCJwaXRjaGMiOnt9LCJ5YXdfc3dheSI6MCwieWF3IjoiMTgwIiwieWF3YyI6eyJEZWZhdWx0IjowfSwieWF3X2ppdHRlciI6Ik9mZiIsInlhd19qaXR0ZXJjIjp7fSwiYm9keV95YXciOiJPZmYiLCJib2R5X3lhd2MiOnt9LCJmYWtlbGFnIjoiQWx3YXlzIG9uIiwiZmFrZWxhZ2MiOnsiQWx3YXlzIG9uIjoxNH0sImRlZmVuc2l2ZSI6eyJlbmFibGUiOmZhbHNlLCJwaXRjaCI6IkRlZmF1bHQiLCJwaXRjaGMiOnt9LCJ5YXciOiJEZWZhdWx0IiwieWF3YyI6e30sInRpY2siOjE1fSwiZGVmX2ZsaWNrIjpbZmFsc2UsMC41LFtdXX0sIkluLUFpci1kdWNraW5nIjp7Im92ZXJyaWRlIjpmYWxzZSwicGl0Y2giOiJPZmYiLCJwaXRjaGMiOnt9LCJ5YXdfc3dheSI6MCwieWF3IjoiMTgwIiwieWF3YyI6eyJEZWZhdWx0IjowfSwieWF3X2ppdHRlciI6Ik9mZiIsInlhd19qaXR0ZXJjIjp7fSwiYm9keV95YXciOiJPZmYiLCJib2R5X3lhd2MiOnt9LCJmYWtlbGFnIjoiQWx3YXlzIG9uIiwiZmFrZWxhZ2MiOnsiQWx3YXlzIG9uIjoxNH0sImRlZmVuc2l2ZSI6eyJlbmFibGUiOmZhbHNlLCJwaXRjaCI6IkRlZmF1bHQiLCJwaXRjaGMiOnt9LCJ5YXciOiJEZWZhdWx0IiwieWF3YyI6e30sInRpY2siOjE1fSwiZGVmX2ZsaWNrIjpbZmFsc2UsMC41LFtdXX0sIm1hbnVhbHMiOlt0cnVlLHRydWUsW2ZhbHNlLDB4NDVdLFtmYWxzZSwweDQ2XV0sImxieV9icmVha2VyIjpbZmFsc2UsW10sW11dLCJsYWdyYW5kb20iOltmYWxzZSx0cnVlLDBdLCJmcmVlc3RhbmQiOlt0cnVlLFtmYWxzZSwweDYxXV0sImVkZ2V5YXciOlt0cnVlXSwib3RoZXIiOlt0cnVlLHRydWUsdHJ1ZSxmYWxzZV19LCJVc2VyIjoiYWRtaW4iLCJWZXJzaW9uIjoyOTcsInV0aWxzLmtleXBvcyI6e30sInV0aWxzLnNwZWNwb3MiOnt9fQ=="
    local experimentalcfg = "osmanhook:eyJWaXN1YWxzIjp7Im5pbWJ1cyI6W2ZhbHNlLFsyNTUsMjU1LDI1NSwyNTVdXSwic2lkZW1hcmsiOltmYWxzZSwiTGVmdCJdLCJzY29wZWxpbmVzIjpbdHJ1ZSxmYWxzZSxmYWxzZSwiU2NvcGUgRmlyc3QgQ29sb3IiLFsyNTUsMjU1LDI1NSwyNTVdLCJTY29wZSBTZWNvbmQgQ29sb3IiLFsyNTUsMjU1LDI1NSwwXSwiRGVmYXVsdCIsNSwzNSwxXSwiYXJyb3dzIjpbdHJ1ZSwiVGVhbVNrZWV0IiwiTWFudWFsIENvbG9yIixbMjU1LDI1NSwyNTUsMjExXSwiRGVzeW5jIFNpZGUgQ29sb3IiLFswLDIwMCwyNTUsMjU1XSw0MCwxMF0sInRyYWNlciI6W2ZhbHNlLFsyNTUsMjU1LDI1NSwyNTVdLDNdLCJmcHNib29zdCI6W3RydWUsWyIzZCBza3kiLCJmb2giLCJzaGFkb3dzIiwiYmxvb2QiLCJkZWNhbHMiLCJibG9vbSIsIm90aGVyIl1dLCJ3YXRlcm1hcmsiOlt0cnVlLFsiTmFtZSIsIlRpY2tzIiwiUGluZyIsIlRpbWUiXSwiRGlzcGxheSBOYW1lIl0sImluZGljYXRvcnMiOlt0cnVlLFsxNTMsMTgxLDI1NSwyNTVdLCJQaXhpZXMiLFsiU2NvcGUiXV0sImNvbmNvbCI6W2ZhbHNlLFsyNTUsMjU1LDI1NSwyNTVdXSwiZGVmaW5kIjpbZmFsc2UsWzI1NSwyNTUsMjU1LDI1NV1dLCJiZXR0ZXJuYWRlIjp7IjEiOnRydWUsIjIiOlsiU21va2UiLCJGaXJlIl0sIjMiOlsiUmFkaXVzIiwiU21va2UgVGltZXIiXSwiNCI6WyJJZ25vcmUgaGFybWxlc3MgbW9sb3RvdiJdLCI1IjoiU21va2UgVGltZXIgQ29sb3IiLCI2IjpbMTk4LDE5MiwxOTIsMTI4XSwic21va2UiOlsiU21va2UgQ29sb3IiLFs2MiwxNTgsMjUwLDI1NV1dLCJmaXJlIjpbIkZpcmUgQ29sb3IiLFsyNTMsNDUsNzYsMjU1XV19LCJwcmVkaWN0Ym94IjpbdHJ1ZSxbIlRhcmdldCJdXSwiYWRkaW5kIjpbe31dLCJrZXliaW5kcyI6W3RydWVdLCJvdXRfb2ZfZm92IjpbZmFsc2Use30sNTAsNV0sInZlbHdhciI6W3RydWUsWzI1NSwyNTUsMjU1LDI1NV1dLCJzcGVjdGF0b3JzIjpbdHJ1ZSx0cnVlXSwiY3Jvc3NkYW1hZ2UiOlt0cnVlLGZhbHNlLHRydWUsIlJpZ2h0LVRvcCJdfSwiTWlzYyI6eyJ0cGVyc29uIjpbdHJ1ZSwzMF0sInRyYXNodGFsayI6W2ZhbHNlLHt9LHt9XSwidGFnc3BhbWVyIjpbZmFsc2VdLCJ2aWV3bW9kZWwiOlt0cnVlLDYwMCwtMywtODMsLTEwXSwic2NvcGV2aWV3bW9kZWwiOltmYWxzZV0sImxlZnRoYW5kIjpbdHJ1ZV0sImFzcGVjdHJhdGlvIjpbZmFsc2UsMTI1XSwidHJhbnNjb3BlIjpbZmFsc2UsWyJHcmVuYWRlIl0sMjBdLCJkdWNhcmlneW0iOltmYWxzZSwxMDBdLCJhbmltYnJlYWsiOlt0cnVlLHRydWUsIlN0YXRpYyBMZWdzIiwiSml0dGVyIiwiRGlzYWJsZWQiLHt9LCJGbGFzaGVkIl0sImZhc3RsYWRkZXIiOlt0cnVlXSwiYXV0b3Ntb2tlIjpbZmFsc2UsW2ZhbHNlLDEsMF1dLCJidXlib3QiOlt0cnVlLCJTY291dCIsIkRlYWdsZVwvUjgiLFsiS2V2bGFyIiwiSGVsbWV0IiwiRGVmdXNlciIsIlpldXMiLCJGaXJlIiwiSEUiLCJTbW9reSJdXSwiZHVtYmFzc19mZWF0dXJlcyI6W2ZhbHNlLCJQdXNoLVVwcyIse31dLCJsb2dzIjpbdHJ1ZSxbIkNvbnNvbGUiXSxbIk9uIEhpdCIsIk9uIE1pc3MiLCJPbiBIdXJ0Il0sIk9uIEhpdCBDb2xvciIsWzE1OSwyMDIsNDMsMjU1XSwiT24gTWlzcyBDb2xvciIsWzI1NSw3MSw3MSwyNTVdLCJPbiBIdXJ0IENvbG9yIixbMTY2LDE2MCwyMjAsMjU1XV19LCJWZXJzaW9uIjoyOTcsInV0aWxzLnNwZWNwb3MiOnsieSI6MTUzLCJ4IjoyMTF9LCJBbnRpLUFpbWJvdCI6eyIxIjp0cnVlLCJDcm91Y2giOnsiZGVmX2ZsaWNrIjpbZmFsc2VdLCJwaXRjaCI6IkRvd24iLCJmYWtlbGFnbGltaXQiOjE0LCJmYWtlbGFnIjoiUmFuZG9tIiwiYm9keV95YXdfZnJlZXN0YW5kIjpmYWxzZSwicGl0Y2hjIjpbMF0sInlhd19qaXR0ZXIiOiJPZmYiLCJkZWZlbnNpdmUiOnsiZW5hYmxlIjpmYWxzZSwieWF3YyI6eyJTcGluIjowLCJSYW5kb20iOlswLDBdLCJMJlIiOlswLDBdLCJPcHBvc2l0ZSI6OTAsIkppdHRlciI6WzAsMF0sIlNwaW4gdjIiOlswLDAsNTBdLCIxODAiOjB9LCJwaXRjaGMiOnsiQ3VzdG9tIjowLCJMJlIiOlswLDBdLCJSYW5kb20gdjIiOlswLDBdLCJKaXR0ZXIiOlswLDBdLCJGbHVjdGF0ZSI6W2ZhbHNlLDAsMCw1MF19LCJ0aWNrIjoxLCJ5YXciOiJEZWZhdWx0IiwicGl0Y2giOiJEZWZhdWx0In0sIm92ZXJyaWRlIjp0cnVlLCJ5YXdfYmFzZSI6IkF0IHRhcmdldHMiLCJmb3JjZV9kZWYiOiJPZmYiLCJ5YXciOiJMJlIiLCJib2R5X3lhd2MiOnsiU3dheSI6WzAsMCwxXSwiU3RhdGljIHYyIjowLCJDdXN0b20gSml0dGVyIjpbMCwxLDAsMTRdLCJKaXR0ZXIiOjM1LCJTdGF0aWMiOjMwLCJKaXR0ZXIgdjIiOlszMCwxXX0sInlhd2MiOnsiU3BpbiI6MCwiTCZSIjpbLTM2LDM2LDBdLCJTdGF0aWMiOjAsIkRlbGF5ZWQiOlsxNiwtMjUsMV0sIjE4MCI6MH0sImZha2VsYWdjIjp7IkR5bmFtaWMiOlswXSwiRmx1Y3R1YXRlIjpbMF0sIlJhbmRvbSI6WzcwXSwiRmx1Y3R1YXRlIHYyIjpbMCwxXSwiTWF4aW11bSI6WzBdLCJKaXR0ZXIiOls2XX0sImJvZHlfeWF3IjoiSml0dGVyIiwieWF3X2ppdHRlcmMiOnsiQ2VudGVyIjoyMCwiTWluXC9NYXggQ2VudGVyIjpbMCwwLDEwMCwxXSwiQ3VzdG9tIE9mZnNldCI6WzAsMCwxXSwiT2Zmc2V0IjowLCJTa2l0dGVyIjowLCJSYW5kb20iOjAsIkN1c3RvbSBDZW50ZXIiOlszOCwwLDNdLCJMJlIgQ2VudGVyIjpbMCwwLDBdLCJOd2F5IjpbMywwLDFdfX0sIk1vdmluZyI6eyJkZWZfZmxpY2siOltmYWxzZV0sInBpdGNoIjoiT2ZmIiwiZmFrZWxhZ2xpbWl0IjoxNCwiZmFrZWxhZyI6Ik1heGltdW0iLCJib2R5X3lhd19mcmVlc3RhbmQiOmZhbHNlLCJwaXRjaGMiOlswXSwieWF3X2ppdHRlciI6Ik9mZiIsImRlZmVuc2l2ZSI6eyJlbmFibGUiOmZhbHNlLCJ5YXdjIjp7IlNwaW4iOjAsIlJhbmRvbSI6WzAsMF0sIkwmUiI6WzAsMF0sIk9wcG9zaXRlIjo5MCwiSml0dGVyIjpbMCwwXSwiU3BpbiB2MiI6WzAsMCw1MF0sIjE4MCI6MH0sInBpdGNoYyI6eyJDdXN0b20iOjAsIkwmUiI6WzAsMF0sIlJhbmRvbSB2MiI6WzAsMF0sIkppdHRlciI6WzAsMF0sIkZsdWN0YXRlIjpbZmFsc2UsMCwwLDUwXX0sInRpY2siOjEsInlhdyI6IkRlZmF1bHQiLCJwaXRjaCI6IkRlZmF1bHQifSwib3ZlcnJpZGUiOmZhbHNlLCJ5YXdfYmFzZSI6IkxvY2FsIHZpZXciLCJmb3JjZV9kZWYiOiJPZmYiLCJ5YXciOiJPZmYiLCJib2R5X3lhd2MiOnsiU3dheSI6WzAsMCwxXSwiU3RhdGljIHYyIjowLCJDdXN0b20gSml0dGVyIjpbMCwxLDAsMTRdLCJKaXR0ZXIiOjAsIlN0YXRpYyI6MCwiSml0dGVyIHYyIjpbMCwxXX0sInlhd2MiOnsiU3BpbiI6MCwiTCZSIjpbMCwwLDBdLCJTdGF0aWMiOjAsIkRlbGF5ZWQiOlswLDAsMV0sIjE4MCI6MH0sImZha2VsYWdjIjp7IkR5bmFtaWMiOlswXSwiRmx1Y3R1YXRlIjpbMF0sIlJhbmRvbMI6WzBdLCJGbHVjdHVhdGUgdjIiOlswLDFdLCJNYXhpbXVtIjpbMF0sIkppdHRlciI6WzFdfSwiYm9keV95YXciOiJPZmYiLCJ5YXdfaml0dGVyYyI6eyJDZW50ZXIiOjAsIk1pblwvTWF4IENlbnRlciI6WzAsMCwxMDAsMV0sIkN1c3RvbSBPZmZzZXQiOlswLDAsMV0sIk9mZnNldCI6MCwiU2tpdHRlciI6MCwiUmFuZG9tIjowLCJDdXN0b20gQ2VudGVyIjpbMCwwLDFdLCJMJlIgQ2VudGVyIjpbMCwwLDBdLCJOd2F5IjpbMywwLDFdfX0sImNvbmRpdGlvbiI6IkFpci1Dcm91Y2giLCJTaGFyZWQiOnsiZGVmX2ZsaWNrIjpbZmFsc2VdLCJ5YXdfYmFzZSI6IkF0IHRhcmdldHMiLCJwaXRjaCI6IkRvd24iLCJmb3JjZV9kZWYiOiJPZmYiLCJmYWtlbGFnbGltaXQiOjE0LCJib2R5X3lhdyI6Ik9wcG9zaXRlIiwieWF3IjoiRGVsYXllZCIsImJvZHlfeWF3YyI6eyJTd2F5IjpbMCwwLDFdLCJTdGF0aWMgdjIiOjAsIkN1c3RvbSBKaXR0ZXIiOls2MCwyLDAsMTRdLCJKaXR0ZXIiOjYwLCJTdGF0aWMiOjAsIkppdHRlciB2MiI6WzYwLDNdfSwiYm9keV95YXdfZnJlZXN0YW5kIjpmYWxzZSwicGl0Y2hjIjpbMF0sInlhd2MiOnsiU3BpbiI6MCwiTCZSIjpbLTMyLDM2LDBdLCJTdGF0aWMiOjAsIkRlbGF5ZWQiOlstMTUsMTcsMl0sIjE4MCI6MH0sImZha2VsYWdjIjp7IkR5bmFtaWMiOlswXSwiRmx1Y3R1YXRlIjpbMF0sIlJhbmRvbMI6WzEwMF0sIkZsdWN0dWF0ZSB2MiI6WzEwLDldLCJNYXhpbXVtIjpbOF0sIkppdHRlciI6WzddfSwieWF3X2ppdHRlciI6Ik9mZiIsImRlZmVuc2l2ZSI6eyJlbmFibGUiOmZhbHNlLCJ5YXdjIjp7IlNwaW4iOjAsIlJhbmRvbMI6WzAsMF0sIkwmUiI6WzAsMF0sIk9wcG9zaXRlIjo5MCwiSml0dGVyIjpbMCwwXSwiU3BpbiB2MiI6WzAsMCw1MF0sIjE4MCI6MH0sInBpdGNoYyI6eyJDdXN0b20iOjAsIkwmUiI6WzAsMF0sIlJhbmRvbMI6WzAsMF0sIkppdHRlciI6WzAsMF0sIkZsdWN0YXRlIjpbZmFsc2UsMCwwLDUwXX0sInRpY2siOjEsInlhdyI6IkRlZmF1bHQiLCJwaXRjaCI6IkRlZmF1bHQifSwieWF3X2ppdHRlcmMiOnsiQ2VudGVyIjo2MiwiTWluXC9NYXggQ2VudGVyIjpbMCwwLDEwMCwxXSwiQ3VzdG9tIE9mZnNldCI6WzAsMCwxXSwiT2Zmc2V0IjowLCJTa2l0dGVyIjowLCJSYW5kb20iOjAsIkN1c3RvbSBDZW50ZXIiOlszMiwwLDJdLCJMJlIgQ2VudGVyIjpbMCwwLDBdLCJOd2F5IjpbMywwLDFdfSwiZmFrZWxhZyI6IkppdHRlciJ9LCJPbi1Vc2UiOnsiZGVmX2ZsaWNrIjpbZmFsc2VdLCJwaXRjaCI6Ik9mZiIsImZha2VsYWdsaW1pdCI6MTQsImZha2VsYWciOiJNYXhpbXVtIiwiYm9keV95YXdfZnJlZXN0YW5kIjpmYWxzZSwicGl0Y2hjIjpbMF0sInlhd19qaXR0ZXIiOiJPZmYiLCJkZWZlbnNpdmUiOnsiZW5hYmxlIjpmYWxzZSwieWF3YyI6eyJTcGluIjowLCJSYW5kb20iOlswLDBdLCJMJlIiOlswLDBdLCJPcHBvc2l0ZSI6OTAsIkppdHRlciI6WzAsMF0sIlNwaW4gdjIiOlswLDAsNTBdLCIxODAiOjB9LCJwaXRjaGMiOnsiQ3VzdG9tIjowLCJMJlIiOlswLDBdLCJSYW5kb20gdjIiOlswLDBdLCJKaXR0ZXIiOlswLDBdLCJGbHVjdGF0ZSI6W2ZhbHNlLDAsMCw1MF19LCJ0aWNrIjoxLCJ5YXciOiJEZWZhdWx0IiwicGl0Y2giOiJEZWZhdWx0In0sIm92ZXJyaWRlIjpmYWxzZSwieWF3X2Jhc2UiOiJMb2NhbCB2aWV3IiwiZm9yY2VfZGVmIjoiT2ZmIiwieWF3IjoiT2ZmIiwiYm9keV95YXdjIjp7IlN3YXkiOlswLDAsMV0sIlN0YXRpYyB2MiI6MCwiQ3VzdG9tIEppdHRlciI6WzAsMSwwLDE0XSwiSml0dGVyIjowLCJTdGF0aWMiOjAsIkppdHRlciB2MiI6WzAsMV19LCJ5YXdjIjp7IlNwaW4iOjAsIkwmUiI6WzAsMCwwXSwiU3RhdGljIjowLCJEZWxheWVkIjpbMCwwLDFdLCIxODAiOjB9LCJmYWtlbGFnYyI6eyJEeW5hbWljIjpbMF0sIkZsdWN0dWF0ZSI6WzBdLCJSYW5kb20iOlswXSwiRmx1Y3R1YXRlIHYyIjpbMCwxXSwiTWF4aW11bMI6WzBdLCJKaXR0ZXIiOlsxXX0sImJvZHlfeWF3IjoiT2ZmIiwieWF3X2ppdHRlcmMiOnsiQ2VudGVyIjowLCJNaW5cL01heCBDZW50ZXIiOlswLDAsMTAwLDFdLCJDdXN0b20gT2Zmc2V0IjpbMCwwLDFdLCJPZmZzZXQiOjAsIlNraXR0ZXIiOjAsIlJhbmRvbMI6MCwiQ3VzdG9tIENlbnRlciI6WzAsMCwxXSwiTCZSIENlbnRlciI6WzAsMCwwXSwiTndheSI6WzMsMCwxXX19LCJTdGFuZGluZyI6eyJkZWZfZmxpY2siOltmYWxzZV0sInBpdGNoIjoiRG93biIsImZha2VsYWdsaW1pdCI6MTUsImZha2VsYWciOiJSYW5kb20iLCJib2R5X3lhd19mcmVlc3RhbmQiOmZhbHNlLCJwaXRjaGMiOlswXSwieWF3X2ppdHRlciI6IkwmUiBDZW50ZXIiLCJkZWZlbnNpdmUiOnsiZW5hYmxlIjpmYWxzZSwieWF3YyI6eyJTcGluIjowLCJSYW5kb20iOlswLDBdLCJMJlIiOlswLDBdLCJPcHBvc2l0ZSI6OTAsIkppdHRlciI6WzAsMF0sIlNwaW4gdjIiOlswLDAsNTBdLCIxODAiOjB9LCJwaXRjaGMiOnsiQ3VzdG9tIjowLCJMJlIiOlswLDBdLCJSYW5kb20gdjIiOlswLDBdLCJKaXR0ZXIiOlswLDBdLCJGbHVjdGF0ZSI6W2ZhbHNlLDAsMCw1MF19LCJ0aWNrIjoxLCJ5YXciOiJEZWZhdWx0IiwicGl0Y2giOiJEZWZhdWx0In0sIm92ZXJyaWRlIjp0cnVlLCJ5YXdfYmFzZSI6IkF0IHRhcmdldHMiLCJmb3JjZV9kZWYiOiJPZmYiLCJ5YXciOiIxODAiLCJib2R5X3lhd2MiOnsiU3dheSI6WzAsMCwxXSwiU3RhdGljIHYyIjowLCJDdXN0b20gSml0dGVyIjpbMCwxLDAsMTRdLCJKaXR0ZXIiOjAsIlN0YXRpYyI6NjAsIkppdHRlciB2MiI6WzAsMV19LCJ5YXdjIjp7IlNwaW4iOjAsIkwmUiI6WzAsMCwwXSwiU3RhdGljIjowLCJEZWxheWVkIjpbMCwwLDFdLCIxODAiOjB9LCJmYWtlbGFnYyI6eyJEeW5hbWljIjpbMF0sIkZsdWN0dWF0ZSI6WzBdLCJSYW5kb20iOlsxMDBdLCJGbHVjdHVhdGUgdjIiOlswLDFdLCJNYXhpbXVtIjpbMF0sIkppdHRlciI6WzFdfSwiYm9keV95YXciOiJTdGF0aWMiLCJ5YXdfaml0dGVyYyI6eyJDZW50ZXIiOjAsIk1pblwvTWF4IENlbnRlciI6WzAsMCwxMDAsMV0sIkN1c3RvbSBPZmZzZXQiOlswLDAsMV0sIk9mZnNldCI6MCwiU2tpdHRlciI6MCwiUmFuZG9tIjowLCJDdXN0b20gQ2VudGVyIjpbMCwwLDFdLCJMJlIgQ2VudGVyIjpbLTEwLDEwLDBdLCJOd2F5IjpbMywwLDFdfX0sImJ1aWxkZXIiOiJnYW1lc2Vuc2UiLCJpbnZlcnRlciI6W1tmYWxzZSwyLDcwXV0sImxieV9icmVha2VyIjpbZmFsc2UsW3RydWUsMiw3M10sMTEwXSwib3RoZXIiOltbIkFudGktQmFja3N0YWIiLCJTYWZlIG9uIGtuaWZlIiwiU3RhdGljIG9uIG1hbnVhbHMiLCJMb2NhbCB2aWV3IG9uIG1hbnVhbHMiLCJEaXNhYmxlIGZha2VsYWdzIG9uIG9zIl1dLCJEdWNrcGVlayI6eyJ5YXdfYmFzZSI6IkxvY2FsIHZpZXciLCJwaXRjaCI6Ik9mZiIsImJvZHlfeWF3IjoiT2ZmIiwieWF3YyI6eyJTcGluIjowLCJMJlIiOlswLDAsMF0sIlN0YXRpYyI6MCwiRGVsYXllZCI6WzAsMCwxXSwiMTgwIjowfSwieWF3IjoiT2ZmIiwiZmFrZWxhZyI6Ik1heGltdW0iLCJib2R5X3lhd19mcmVlc3RhbmQiOmZhbHNlLCJvdmVycmlkZSI6ZmFsc2UsInBpdGNoYyI6WzBdLCJmYWtlbGFnYyI6eyJEeW5hbWljIjpbMF0sIkZsdWN0dWF0ZSI6WzBdLCJSYW5kb20iOlswXSwiRmx1Y3R1YXRlIHYyIjpbMCwxXSwiTWF4aW11bMI6WzBdLCJKaXR0ZXIiOlsxXX0sInlhd19qaXR0ZXIiOiJPZmYiLCJib2R5X3lhd2MiOnsiU3dheSI6WzAsMCwxXSwiU3RhdGljIHYyIjowLCJDdXN0b20gSml0dGVyIjpbMCwxLDAsMTRdLCJKaXR0ZXIiOjAsIlN0YXRpYyI6MCwiSml0dGVyIHYyIjpbMCwxXX0sInlhd19qaXR0ZXJjIjp7IkNlbnRlciI6MCwiTWluXC9NYXggQ2VudGVyIjpbMCwwLDEwMCwxXSwiQ3VzdG9tIE9mZnNldCI6WzAsMCwxXSwiT2Zmc2V0IjowLCJTa2l0dGVyIjowLCJSYW5kb20iOjAsIkN1c3RvbSBDZW50ZXIiOlswLDAsMV0sIkwmUiBDZW50ZXIiOlswLDAsMF0sIk53YXkiOlszLDAsMV19LCJmYWtlbGFnbGltaXQiOjE0fSwibWFudWFscyI6W3RydWUsW2ZhbHNlLDIsOTBdLFt0cnVlLDIsNjddLFt0cnVlLDIsMjBdXSwiQ3JvdWNoLU1vdmluZyI6eyJkZWZfZmxpY2siOltmYWxzZV0sInBpdGNoIjoiRG93biIsImZha2VsYWdsaW1pdCI6MTIsImZha2VsYWciOiJKaXR0ZXIiLCJib2R5X3lhd19mcmVlc3RhbmQiOmZhbHNlLCJwaXRjaGMiOlswXSwieWF3X2ppdHRlciI6Ik9mZiIsImRlZmVuc2l2ZSI6eyJlbmFibGUiOmZhbHNlLCJ5YXdjIjp7IlNwaW4iOjAsIlJhbmRvbMI6WzAsMF0sIkwmUiI6WzAsMF0sIk9wcG9zaXRlIjo5MCwiSml0dGVyIjpbMCwwXSwiU3BpbiB2MiI6WzAsMCw1MF0sIjE4MCI6MH0sInBpdGNoYyI6eyJDdXN0b20iOjAsIkwmUiI6WzAsMF0sIlJhbmRvbMI6WzAsMF0sIkppdHRlciI6WzAsMF0sIkZsdWN0YXRlIjpbZmFsc2UsMCwwLDUwXX0sInRpY2siOjEsInlhdyI6IkRlZmF1bHQiLCJwaXRjaCI6IkRlZmF1bHQifSwib3ZlcnJpZGUiOnRydWUsInlhd19iYXNlIjoiQXQgdGFyZ2V0cyIsImZvcmNlX2RlZiI6Ik9mZiIsInlhdyI6IkwmUiIsImJvZHlfeWF3YyI6eyJTd2F5IjpbMCwwLDFdLCJTdGF0aWMgdjIiOjAsIkN1c3RvbSBKaXR0ZXIiOlswLDEsMCwxNF0sIkppdHRlciI6MzUsIlN0YXRpYyI6MCwiSml0dGVyIHYyIjpbMCwxXX0sInlhd2MiOnsiU3BpbiI6MCwiTCZSIjpbLTM2LDM2LDBdLCJTdGF0aWMiOjAsIkRlbGF5ZWQiOlswLDAsMV0sIjE4MCI6MH0sImZha2VsYWdjIjp7IkR5bmFtaWMiOlswXSwiRmx1Y3R1YXRlIjpbMF0sIlJhbmRvbMI6WzBdLCJGbHVjdHVhdGUgdjIiOlszMCwxXSwiTWF4aW11bMI6WzBdLCJKaXR0ZXIiOls1XX0sImJvZHlfeWF3IjoiSml0dGVyIiwieWF3X2ppdHRlcmMiOnsiQ2VudGVyIjoyOSwiTWluXC9NYXggQ2VudGVyIjpbMCwwLDEwMCwxXSwiQ3VzdG9tIE9mZnNldCI6WzAsMCwxXSwiT2Zmc2V0IjowLCJTa2l0dGVyIjowLCJSYW5kb20iOjAsIkN1c3RvbSBDZW50ZXIiOlswLDAsMV0sIkwmUiBDZW50ZXIiOlswLDAsMF0sIk53YXkiOlszLDAsMV19fSwiQWlyLUNyb3VjaCI6eyJkZWZfZmxpY2siOltmYWxzZV0sInBpdGNoIjoiRG93biIsImZha2VsYWdsaW1pdCI6MTQsImZha2VsYWciOiJGbHVjdHVhdGUgdjIiLCJib2R5X3lhd19mcmVlc3RhbmQiOmZhbHNlLCJwaXRjaGMiOlswXSwieWF3X2ppdHRlciI6Ik9mZiIsImRlZmVuc2l2ZSI6eyJlbmFibGUiOmZhbHNlLCJ5YXdjIjp7IlNwaW4iOjAsIlJhbmRvbMI6WzAsMF0sIkwmUiI6WzAsMF0sIk9wcG9zaXRlIjo5MCwiSml0dGVyIjpbMCwwXSwiU3BpbiB2MiI6WzAsMCw1MF0sIjE4MCI6MH0sInBpdGNoYyI6eyJDdXN0b20iOjAsIkwmUiI6WzAsMF0sIlJhbmRvbMI6WzAsMF0sIkppdHRlciI6WzAsMF0sIkZsdWN0YXRlIjpbZmFsc2UsMCwwLDUwXX0sInRpY2siOjEsInlhdyI6IkRlZmF1bHQiLCJwaXRjaCI6IkRlZmF1bHQifSwib3ZlcnJpZGUiOnRydWUsInlhd19iYXNlIjoiQXQgdGFyZ2V0cyIsImZvcmNlX2RlZiI6Ik9mZiIsInlhdyI6IkwmUiIsImJvZHlfeWF3YyI6eyJTd2F5IjpbMCwwLDFdLCJTdGF0aWMgdjIiOjAsIkN1c3RvbSBKaXR0ZXIiOlswLDEsMCwxNF0sIkppdHRlciI6NDIsIlN0YXRpYyI6MCwiSml0dGVyIHYyIjpbNjAsMl19LCJ5YXdjIjp7IlNwaW4iOjAsIkwmUiI6Wy0yNywzNiwwXSwiU3RhdGljIjowLCJEZWxheWVkIjpbLTQ4LDQ2LDFdLCIxODAiOjB9LCJmYWtlbGFnYyI6eyJEeW5hbWljIjpbMF0sIkZsdWN0dWF0ZSI6WzBdLCJSYW5kb20iOlswXSwiRmx1Y3R1YXRlIHYyIjpbMzAsMV0sIk1heGltdW0iOlswXSwiSml0dGVyIjpbMV19LCJib2R5X3lhdyI6IkppdHRlciIsInlhd19qaXR0ZXJjIjp7IkNlbnRlciI6NDAsIk1pblwvTWF4IENlbnRlciI6WzQzLDgwLDEwMCwxXSwiQ3VzdG9tIE9mZnNldCI6WzAsMCwxXSwiT2Zmc2V0IjowLCJTa2l0dGVyIjowLCJSYW5kb20iOjAsIkN1c3RvbSBDZW50ZXIiOls0MCwwLDhdLCJMJlIgQ2VudGVyIjpbMCwwLDBdLCJOd2F5IjpbNywzMCwzXX19LCJleHR0ZXAiOltbZmFsc2UsMSwwXSxbZmFsc2UsMSwwXSwxXSwiZWRnZXlhdyI6W1tmYWxzZSwyLDEwN11dLCJGYWtlbGFncyI6eyJ5YXdfYmFzZSI6IkxvY2FsIHZpZXciLCJwaXRjaCI6Ik9mZiIsImJvZHlfeWF3IjoiT2ZmIiwieWF3YyI6eyJTcGluIjowLCJMJlIiOlswLDAsMF0sIlN0YXRpYyI6MCwiRGVsYXllZCI6WzAsMCwxXSwiMTgwIjowfSwieWF3IjoiT2ZmIiwiZmFrZWxhZyI6Ik1heGltdW0iLCJib2R5X3lhd19mcmVlc3RhbmQiOmZhbHNlLCJvdmVycmlkZSI6ZmFsc2UsInBpdGNoYyI6WzBdLCJmYWtlbGFnYyI6eyJEeW5hbWljIjpbMF0sIkZsdWN0dWF0ZSI6WzBdLCJSYW5kb20iOlswXSwiRmx1Y3R1YXRlIHYyIjpbMCwxXSwiTWF4aW11bMI6WzBdLCJKaXR0ZXIiOlsxXX0sInlhd19qaXR0ZXIiOiJPZmYiLCJib2R5X3lhd2MiOnsiU3dheSI6WzAsMCwxXSwiU3RhdGljIHYyIjowLCJDdXN0b20gSml0dGVyIjpbMCwxLDAsMTRdLCJKaXR0ZXIiOjAsIlN0YXRpYyI6MCwiSml0dGVyIHYyIjpbMCwxXX0sInlhd19qaXR0ZXJjIjp7IkNlbnRlciI6MCwiTWluXC9NYXggQ2VudGVyIjpbMCwwLDEwMCwxXSwiQ3VzdG9tIE9mZnNldCI6WzAsMCwxXSwiT2Zmc2V0IjowLCJTa2l0dGVyIjowLCJSYW5kb20iOjAsIkN1c3RvbSBDZW50ZXIiOlswLDAsMV0sIkwmUiBDZW50ZXIiOlswLDAsMF0sIk53YXkiOlszLDAsMV19LCJmYWtlbGFnbGltaXQiOjE0fSwiZnJlZXN0YW5kIjpbW2ZhbHNlLDEsMF1dLCJTbG93d2FsayI6eyJkZWZfZmxpY2siOltmYWxzZV0sInBpdGNoIjoiT2ZmIiwiZmFrZWxhZ2xpbWl0IjoxNCwiZmFrZWxhZyI6Ik1heGltdW0iLCJib2R5X3lhd19mcmVlc3RhbmQiOmZhbHNlLCJwaXRjaGMiOlswXSwieWF3X2ppdHRlciI6Ik9mZiIsImRlZmVuc2l2ZSI6eyJlbmFibGUiOmZhbHNlLCJ5YXdjIjp7IlNwaW4iOjAsIlJhbmRvbMI6WzAsMF0sIkwmUiI6WzAsMF0sIk9wcG9zaXRlIjo5MCwiSml0dGVyIjpbMCwwXSwiU3BpbiB2MiI6WzAsMCw1MF0sIjE4MCI6MH0sInBpdGNoYyI6eyJDdXN0b20iOjAsIkwmUiI6WzAsMF0sIlJhbmRvbMI6WzAsMF0sIkppdHRlciI6WzAsMF0sIkZsdWN0YXRlIjpbZmFsc2UsMCwwLDUwXX0sInRpY2siOjEsInlhdyI6IkRlZmF1bHQiLCJwaXRjaCI6IkRlZmF1bHQifSwib3ZlcnJpZGUiOmZhbHNlLCJ5YXdfYmFzZSI6IkxvY2FsIHZpZXciLCJmb3JjZV9kZWYiOiJPZmYiLCJ5YXciOiJPZmYiLCJib2R5X3lhd2MiOnsiU3dheSI6WzAsMCwxXSwiU3RhdGljIHYyIjowLCJDdXN0b20gSml0dGVyIjpbMCwxLDAsMTRdLCJKaXR0ZXIiOjAsIlN0YXRpYyI6MCwiSml0dGVyIHYyIjpbMCwxXX0sInlhd2MiOnsiU3BpbiI6MCwiTCZSIjpbMCwwLDBdLCJTdGF0aWMiOjAsIkRlbGF5ZWQiOlswLDAsMV0sIjE4MCI6MH0sImZha2VsYWdjIjp7IkR5bmFtaWMiOlswXSwiRmx1Y3R1YXRlIjpbMF0sIlJhbmRvbMI6WzBdLCJGbHVjdHVhdGUgdjIiOlswLDFdLCJNYXhpbXVtIjpbMF0sIkppdHRlciI6WzFdfSwiYm9keV95YXciOiJPZmYiLCJ5YXdfaml0dGVyYyI6eyJDZW50ZXIiOjAsIk1pblwvTWF4IENlbnRlciI6WzAsMCwxMDAsMV0sIkN1c3RvbSBPZmZzZXQiOlswLDAsMV0sIk9mZnNldCI6MCwiU2tpdHRlciI6MCwiUmFuZG9tIjowLCJDdXN0b20gQ2VudGVyIjpbMCwwLDFdLCJMJlIgQ2VudGVyIjpbMCwwLDBdLCJOd2F5IjpbMywwLDFdfX0sIkFpciI6eyJkZWZfZmxpY2siOltmYWxzZV0sInBpdGNoIjoiRG93biIsImZha2VsYWdsaW1pdCI6MTQsImZha2VsYWciOiJGbHVjdHVhdGUgdjIiLCJib2R5X3lhd19mcmVlc3RhbmQiOmZhbHNlLCJwaXRjaGMiOlswXSwieWF3X2ppdHRlciI6IkN1c3RvbSBDZW50ZXIiLCJkZWZlbnNpdmUiOnsiZW5hYmxlIjpmYWxzZSwieWF3YyI6eyJTcGluIjowLCJSYW5kb20iOlswLDBdLCJMJlIiOlswLDBdLCJPcHBvc2l0ZSI6OTAsIkppdHRlciI6WzAsMF0sIlNwaW4gdjIiOlswLDAsNTBdLCIxODAiOjB9LCJwaXRjaGMiOnsiQ3VzdG9tIjowLCJMJlIiOlswLDBdLCJSYW5kb20gdjIiOlswLDBdLCJKaXR0ZXIiOlswLDBdLCJGbHVjdGF0ZSI6W2ZhbHNlLDAsMCw1MF19LCJ0aWNrIjoxLCJ5YXciOiJEZWZhdWx0IiwicGl0Y2giOiJEZWZhdWx0In0sIm92ZXJyaWRlIjp0cnVlLCJ5YXdfYmFzZSI6IkF0IHRhcmdldHMiLCJmb3JjZV9kZWYiOiJPZmYiLCJ5YXciOiIxODAiLCJib2R5X3lhd2MiOnsiU3dheSI6Wy0zNCwzOCwxXSwiU3RhdGljIHYyIjowLCJDdXN0b20gSml0dGVyIjpbMCwxLDAsMTRdLCJKaXR0ZXIiOjYwLCJTdGF0aWMiOjAsIkppdHRlciB2MiI6WzYwLDFdfSwieWF3YyI6eyJTcGluIjowLCJMJlIiOlswLDAsMF0sIlN0YXRpYyI6MCwiRGVsYXllZCI6Wy0xMywxOCwzXSwiMTgwIjowfSwiZmFrZWxhZ2MiOnsiRHluYW1pYyI6WzBdLCJGbHVjdHVhdGUiOlswXSwiUmFuZG9tIjpbMF0sIkZsdWN0dWF0ZSB2MiI6WzM0LDFdLCJNYXhpbXVtIjpbMF0sIkppdHRlciI6WzFdfSwiYm9keV95YXciOiJPcHBvc2l0ZSIsInlhd19qaXR0ZXJjIjp7IkNlbnRlciI6NTAsIk1pblwvTWF4IENlbnRlciI6WzAsMCwxMDAsMV0sIkN1c3RvbSBPZmZzZXQiOlswLDAsMV0sIk9mZnNldCI6MCwiU2tpdHRlciI6NDAsIlJhbmRvbMI6MCwiQ3VzdG9tIENlbnRlciI6WzM1LDAsMV0sIkwmUiBDZW50ZXIiOlswLDAsMF0sIk53YXkiOlszLDAsMV19fX0sIklEIjoxNzUxOTg4MTE1LCJNYW5pcHVsYXRpb25zIjp7InVpc3R5bGUiOlsiTWV0aGFtb2QiLGZhbHNlLFsxNTYsMTg0LDI1NSw0M10sZmFsc2VdLCJrZXluYW1lcyI6W251bGwsIkN1cnJlbnQgbmFtZTogRG91YmxlIHRhcCJdfSwiUmFnZSI6eyJtcG9pbnRzIjp7IjEiOnRydWUsIjIiOiJTU0cgMDgiLCJlbmJsIjp7IkFXUCI6dHJ1ZSwiUjggUmV2b2x2ZXIiOmZhbHNlLCJTU0cgMDgiOnRydWV9LCJ0YmwiOnsiQVdQIjpbNzAsNjUsNzAsNjAsNjAsNjUsNzBdLCJSOCBSZXZvbHZlciI6WzYwLDYwLDYwLDYwLDYwLDYwLDYwXSwiU1NHIDA4IjpbNzAsODAsODAsNzUsNzAsODAsNzBdfX0sImRvcm1hbnQiOnsiMSI6ZmFsc2UsIjIiOlt0cnVlLDAsMF0sIjMiOiJHbG9iYWwiLCJ0YmwiOnsiRGVzZXJ0IEVhZ2xlIjpbNzAsMV0sIkdsb2JhbCI6Wzc1LDEwXSwiUjggUmV2b2x2ZXIiOls3NSwxXSwiRzNTRzEgXC8gU0NBUi0yMCI6WzcwLDFdLCJQaXN0b2wiOls3NSwxMF0sIkFXUCI6Wzc1LDFdLCJTU0cgMDgiOls3MCwxXX19LCJsZXRoYWwiOnsiMSI6dHJ1ZSwiMiI6W3RydWUsMyw3M10sIjMiOiJQaXN0b2wiLCJ0YmwiOnsiRGVzZXJ0IEVhZ2xlIjo1MCwiR2xvYmFsIjowLCJSOCBSZXZvbHZlciI6NTUsIkczU0cxIFwvIFNDQVItMjAiOjUwLCJQaXN0b2wiOjAsIkFXUCI6ODAsIlNTRyAwOCI6Njh9fSwiZGVsYXlfc2hvdCI6W1tmYWxzZSwxXV0sImhpdGNoYW5jZCI6eyIxIjpmYWxzZSwiMiI6W3RydWUsMiwxMTRdLCIzIjoiR2xvYmFsIiwidGJsIjp7IkRlc2VydCBFYWdsZSI6LTEsIkdsb2JhbCI6LTEsIlI4IFJldm9sdmVyIjoyNSwiRzNTRzEgXC8gU0NBUi0yMCI6LTEsIlBpc3RvbCI6LTEsIkFXUCI6LTEsIlNTRyAwOCI6LTF9fSwianVtcHNob3QiOltmYWxzZSxbZmFsc2UsMSwwXSx7fSwyODAsODAwXSwib25seWhzIjpbZmFsc2UsW2ZhbHNlLDEsMF1dLCJ1bnNhZmVfY2hhcmdlIjpbZmFsc2UsWyJBaXIiLCJHcm91bmQiXV19LCJ1dGlscy5rZXlwb3MiOnsieSI6MjI0LCJ4IjoxMDR9LCJVc2VyIjoiYWRtaW4ifQ=="
    if not readfile("experimental31415926535.cfg") then
        writefile("experimental31415926535.cfg", experimentalcfg)
    else
        local rawcfg = readfile("experimental31415926535.cfg")
        local _, ind = string.find(rawcfg, ":")
        if ind then
            local success, parsedcfg = pcall(json.parse, base64.decode(string.sub(rawcfg, ind + 1, #rawcfg)))
            if success and parsedcfg and _VER ~= parsedcfg["Version"] then
                writefile("experimental31415926535.cfg", experimentalcfg)
            elseif not success then
                writefile("experimental31415926535.cfg", experimentalcfg)
            end
        else
            writefile("experimental31415926535.cfg", experimentalcfg)
        end
    end
    if not readfile("experimental231415926535.cfg") then
        writefile("experimental231415926535.cfg", experimental2cfg)
    else
        local rawcfg = readfile("experimental231415926535.cfg")
        local _, ind = string.find(rawcfg, ":")
        if ind then
            local success, parsedcfg = pcall(json.parse, base64.decode(string.sub(rawcfg, ind + 1, #rawcfg)))
            if success and parsedcfg and _VER ~= parsedcfg["Version"] then
                writefile("experimental231415926535.cfg", experimental2cfg)
            elseif not success then
                writefile("experimental231415926535.cfg", experimental2cfg)
            end
        else
            writefile("experimental231415926535.cfg", experimental2cfg)
        end
    end
    -- Ensure DB-provided Experimental #2 payload replaces any old file content
    do
        local dbraw = database.read("osmanhook::experimental2cfg")
        if type(dbraw) == "string" and dbraw:find("osmanhook:") then
            writefile("experimental231415926535.cfg", dbraw)
        end
    end
    for key, val in pairs(cfg.names) do
        if (val ~= "Default" and val ~= "Experimental" and val ~= "Experimental #2") and not readfile(string.format("%s31415926535.cfg", val)) then
            table.remove(cfg.names, key)
            database.write("osmanhook::cfg_names", cfg.names)
        end
    end
    cfg.update_listbox()
ui.set_callback(tabs["Configs"].importcfg, cfg.import)
ui.set_callback(tabs["Configs"].loadcfg, cfg.load)
ui.set_callback(tabs["Configs"].savecfg, cfg.save)
ui.set_callback(tabs["Configs"].deletecfg, cfg.delete)
ui.set_callback(tabs["Configs"].exportcfg, cfg.export)
ui.set_callback(tabs["Configs"].restorecfg, cfg.restore)
--region @cfg end

--region @utils
utils.cmd_ticks = function(cmd)
    local dt = ui.get(skeetgui.ragegui.aimbot.double_tap[1]) and ui.get(skeetgui.ragegui.aimbot.double_tap[2])
    local hs = not dt and ui.get(skeetgui.aagui.other.on_shot_antiaim[1]) and ui.get(skeetgui.aagui.other.on_shot_antiaim[2])
    local fakelagoffset = (hs and 1 or ui.get(dt and skeetgui.ragegui.aimbot.double_tap_lag_limit or skeetgui.aagui.fakelag.limit)) + 1
    if cmd ~= nil and cmd.chokedcommands > 0 then
        fakelagoffset = cmd.chokedcommands
    end
    return utils.round(globals.tickcount()/fakelagoffset)
end
utils.multi_parse = function(multiselect, val)
    return utils.in_table(ui.get(multiselect), val)
end
utils.combo_parse = function(combo, ...)
    args = {...}
    return utils.in_table(args, combo)
end
utils.visibleparse = function(tables, bool)
    if type(tables) == "number" then
        if bool == false then
            hide[tables] = tables
        end
        ui.set_visible(tables, bool)
    else 
        for _, t in pairs(tables) do
            utils.visibleparse(t, bool)
        end
    end
end
utils.set_visibleA = function(tables, val, bol)
    for k, v in pairs(tables) do
        if k == val then
            utils.visibleparse(v, bol == nil and ui.get(tabs["Anti-Aimbot"][1]) or bol)
        else
            utils.visibleparse(v, false)
        end
    end
end
utils.checkbox_visible = function(tab, bool)
    for _, val in pairs(tab) do
        if val == tab[1] then
            ui.set_visible(tab[1], true and (bool ~= nil and bool or true))
        else 
            ui.set_visible(val, ui.get(tab[1]) and (bool ~= nil and bool or true))
        end
    end
end

utils.visible_misc = function(tab)
    for k, v in pairs(tab) do
        if v == tab.animbreak then
            ui.set_visible(v[1], true)
            local enable = ui.get(v[1])
            for _, val in pairs(v) do
                if val ~= tab.animbreak[1] then
                    if val == tab.animbreak[7] then
                        ui.set_visible(val, #ui.get(v[6]) > 0 and enable)
                    else
                        ui.set_visible(val, enable)
                    end
                end
            end
        elseif v == tab.logs then
            local enable = ui.get(v[1])
            local onhit = utils.multi_parse(v[3], "On Hit")
            local onmiss = utils.multi_parse(v[3], "On Miss")
            local onhurt = utils.multi_parse(v[3], "On Hurt")
            local is2 = #ui.get(v[2]) > 0
            local ens2 = enable and is2
            ui.set_visible(v[1], true)
            ui.set_visible(v[2], enable)
            ui.set_visible(v[3], ens2)
            ui.set_visible(v[4], ens2 and onhit)
            ui.set_visible(v[5], ens2 and onhit)
            ui.set_visible(v[6], ens2 and onmiss)
            ui.set_visible(v[7], ens2 and onmiss)
            ui.set_visible(v[8], ens2 and onhurt)
            ui.set_visible(v[9], ens2 and onhurt)
        else
            utils.checkbox_visible(v)
        end
    end
end

utils.visible_aa = function(tab)
    local enabled =  ui.get(tab[1])
    local cond = ui.get(tab.condition)
    ui.set_visible(tab[1], true)
    ui.set_visible(tab.condition, enabled)
    ui.set_visible(tab.builder, enabled)
    
    ui.set_visible(tab.side_specific_enabled, enabled)
    local side_specific_enabled = ui.get(tab.side_specific_enabled)
    ui.set_visible(tab.side_specific_team, enabled and side_specific_enabled)
    ui.set_visible(tab.copy_to_opposite_team, enabled and side_specific_enabled)
    
    for k, v in pairs(tab) do
        if v ~= tab[1] and v ~= tab.condition and v ~= tab.builder and v ~= tab.side_specific_enabled and v ~= tab.side_specific_team and v ~= tab.copy_to_opposite_team then
            if k == cond then
                local is_g = cond == "Shared"
                local ng = not is_g and enabled and ui.get(v.override)
                for key, value in pairs(v) do
                    if type(value) == "number" then
                        if not is_g and value ~= v.override then
                            ui.set_visible(value, enabled and ui.get(v.override))
                        else
                            ui.set_visible(value, enabled)
                        end
                    elseif value == tab[cond].fakelagc then
                        local fltype = ui.get(tab[cond].fakelag)
                        utils.set_visibleA(value, (enabled and is_g) and fltype or (ng and enabled) and fltype)
                    elseif value == tab[cond].pitchc then
                        local ptype = ui.get(tab[cond].pitch)
                        ui.set_visible(value[1], (enabled and is_g) and utils.combo_parse(ptype, "Custom") or (ng and enabled) and utils.combo_parse(ptype, "Custom"))
                    elseif value == tab[cond].yaw_jitterc then
                        local yaw_jtype = ui.get(tab[cond].yaw_jitter)
                        if yaw_jtype ~= "Off" then
                            utils.set_visibleA(value, (enabled and is_g) and yaw_jtype or (ng and enabled) and yaw_jtype)
                        else
                            utils.visibleparse(value, false)
                        end
                    elseif value == tab[cond].yawc then
                        local yaw_type = ui.get(tab[cond].yaw)
                        if not utils.combo_parse(yaw_type, "Off") then
                            utils.set_visibleA(value, (enabled and is_g) and yaw_type or (ng and enabled) and yaw_type)
                        else
                            utils.visibleparse(value, false)
                        end
                    elseif value == tab[cond].body_yawc then
                        local body_ytype = ui.get(tab[cond].body_yaw)
                        if not utils.combo_parse(body_ytype, "Off", "Opposite") then
                            utils.set_visibleA(value, (enabled and is_g) and body_ytype or (ng and enabled) and body_ytype)
                        else
                            utils.visibleparse(value, false)
                        end
                    elseif value == tab[cond].defensive then
                        if not ui.get(tab[cond].def_flick[1]) then
                            local defen = ui.get(value.enable)
                            local ptich = ui.get(value.pitch)
                            local gdef = is_g and defen
                            local ngdef = ng and defen
                            ui.set_visible(value.enable, is_g and enabled or ng and enabled)
                            ui.set_visible(value.pitch, (gdef or ngdef) and enabled)
                            utils.set_visibleA(value.pitchc, ptich, (gdef or ngdef) and enabled)
                            local p180 = ui.get(value.point_180)
                            ui.set_visible(value.yaw, (gdef and enabled or ngdef and enabled) and not p180)
                            if not p180 then
                                utils.set_visibleA(value.yawc, ((gdef or ngdef) and enabled) and ui.get(value.yaw))
                            else
                                utils.visibleparse(value.yawc, false)
                            end
                            ui.set_visible(value.point_180, (gdef or ngdef) and enabled and ui.get(value.yaw) == "180")
                            ui.set_visible(value.tick, gdef and enabled or ngdef and enabled)
                        else
                            utils.visibleparse(value, false)
                        end
                    elseif value == tab[cond].def_flick then
                        ui.set_visible(value[1], enabled and not ui.get(tab[cond].defensive.enable))
                    else
                        utils.visibleparse(value, enabled)
                    end
                end
            elseif v == tab.manuals or v == tab.lby_breaker or v == tab.lagrandom then
                utils.checkbox_visible(v, enabled)
            elseif v == tab.other or v == tab.inverter or v == tab.edgeyaw or v == tab.freestand or v == tab.exttep then
                utils.visibleparse(v, enabled)
            else
                utils.visibleparse(v, false)
            end
        end
    end
end
utils.visible_visuals = function(tab)
    for k, v in pairs(tab) do
        if v == tab.watermark then
            ui.set_visible(v[1], true)
            if v[2] then ui.set_visible(v[2], ui.get(v[1])) end
            if v[3] and v[2] then ui.set_visible(v[3], utils.multi_parse(v[2], "Name") and ui.get(v[1])) end
            if v[4] and v[2] then ui.set_visible(v[4], utils.multi_parse(v[2], "Name") and ui.get(v[1])) end
        elseif v == tab.altui_icon_colors then
            ui.set_visible(v[1], true)
            local enabled = ui.get(v[1])
            ui.set_visible(v[2], enabled)
            ui.set_visible(v[3], enabled)
            ui.set_visible(v[4], enabled)
            ui.set_visible(v[5], enabled)
            ui.set_visible(v[6], enabled)
            ui.set_visible(v[7], enabled)
        elseif v == tab.simple_watermark then
            ui.set_visible(v[1], true)
            local enabled = ui.get(v[1])
            ui.set_visible(v[2], enabled)
            ui.set_visible(v[3], enabled)
            ui.set_visible(v[4], enabled)
            ui.set_visible(v[5], enabled)
        elseif v == tab.betternade then
            ui.set_visible(v[1], true)
            local enabled = ui.get(v[1])
            ui.set_visible(v[2], enabled)
            local enb = enabled and #ui.get(v[2]) > 0
            ui.set_visible(v[3], enabled and #ui.get(v[2]) > 0)
            ui.set_visible(v[4], enb and utils.multi_parse(v[3], "Radius"))
            utils.visibleparse(v.smoke, enabled and utils.multi_parse(v[2], "Smoke") and utils.multi_parse(v[3], "Radius"))
            utils.visibleparse(v.fire, enabled and utils.multi_parse(v[2], "Fire") and utils.multi_parse(v[3], "Radius"))
            ui.set_visible(v[5], enb and utils.multi_parse(v[3], "Smoke Timer"))
            ui.set_visible(v[6], enb and utils.multi_parse(v[3], "Smoke Timer"))
        elseif v == tab.arms_skin then
            -- Show master toggle always; child controls only when enabled
            ui.set_visible(v[1], true)
            local enabled = ui.get(v[1])
            ui.set_visible(v[2], enabled)
            ui.set_visible(v[3], enabled)
            ui.set_visible(v[4], enabled)
            ui.set_visible(v[5], enabled)
        else
            utils.checkbox_visible(v)
        end
    end
end
utils.visible_rage = function(tab)
    for k, v in pairs(tab) do
        if v == tab.jumpshot then
            ui.set_visible(v[1], true)
            local enb = ui.get(v[1])
            ui.set_visible(v[2], enb)
            ui.set_visible(v[3], enb)
            ui.set_visible(v[4], enb and utils.multi_parse(v[3], "R8"))
            ui.set_visible(v[5], enb and utils.multi_parse(v[3], "Scout"))
        elseif v == tab.hitchance or v == tab.dormant then
            ui.set_visible(v[1], true)
            local enb = ui.get(v[1])
            ui.set_visible(v[2], enb)
            ui.set_visible(v[3], enb)
            utils.set_visibleA(v.tbl, ui.get(v[3]), enb)
        elseif v == tab.lethal then
            ui.set_visible(v[1], true)
            local enb = ui.get(v[1])
            ui.set_visible(v[2], enb)
            ui.set_visible(v[3], enb)
            utils.set_visibleA(v.tbl, ui.get(v[3]), enb)
        elseif v == tab.mpoints then
            ui.set_visible(v[1], true)
            local enabled = ui.get(v[1])
            ui.set_visible(v[2], enabled)
            local cwp = ui.get(v[2])
            utils.set_visibleA(v.enbl, cwp, enabled)
            utils.set_visibleA(v.tbl, cwp, enabled and ui.get(v.enbl[cwp]))
        else
            utils.checkbox_visible(v)
        end
    end
end
utils.visible_manipulations = function(tab)
    for _, v in pairs(tab) do
        if v == tab.uistyle then
            ui.set_visible(v[1], true)
            ui.set_visible(v[2], ui.get(v[1]) == "Skeet")
            ui.set_visible(v[3], ui.get(v[1]) == "晨花" or ui.get(v[1]) == "Methamod")
            ui.set_visible(v[4], ui.get(v[1]) == "晨花")
        else
            utils.visibleparse(v, true)
        end
    end
end
utils.visible_tabs = function(tables)
    tables = tables ~= nil and tables or tabs
    if type(tables) == "table" then
        for k, v in pairs(tables) do
            if ui.get(switch) == k then
                if k == "Manipulations" then
                    utils.visible_manipulations(v)
                elseif k == "Rage" then
                    utils.visible_rage(v)
                elseif k == "Misc" then
                    utils.visible_misc(v)
                elseif k == "Visuals" then
                    utils.visible_visuals(v)
                elseif k == "Anti-Aimbot" then
                    utils.visible_aa(v)
                else
                    utils.visibleparse(v, true)
                end
            else
                utils.visibleparse(v, false)
            end
        end
    end
end
utils.is_altui = database.read("osmanhook::altuienabled") or false
utils.oldchosen = nil
utils.is_intab = ffi.cast("int*", 0x43479A10)[0] == 1
ui.set_visible(altuibutton, not utils.is_altui)
ui.set_visible(altuibutton1, utils.is_altui)
ui.set_callback(altuibutton, function(id)
    utils.is_altui = true
    ui.set_visible(altuibutton, not utils.is_altui)
    ui.set_visible(altuibutton1, utils.is_altui)
end)
ui.set_callback(altuibutton1, function()
    utils.is_altui = false
    ui.set_visible(altuibutton1, utils.is_altui)
    ui.set_visible(altuibutton, not utils.is_altui)
    utils.oldchosen = nil
end)
utils.findui = function(tabl, searched)
    local tsl = {}
    if type(tabl) == "table" then
        for k, v in pairs(tabl) do
            if type(v) == "table" then
                local find = utils.findui(v, searched)
                for _, val in pairs(find) do
                    table.insert(tsl, val)
                end
            else
                local cname = ui.name(v):lower()
                if cname and string.find(cname, searched) then
                    table.insert(tsl, v)
                end
            end
        end
    else
        local cname = ui.name(tabl):lower()
        if string.find(cname, searched) then
            return ui.name(tabl)
        else
            return
        end
    end
    return tsl
end
utils.table_visibleparse = function(tabl, tabl1)
    if type(tabl) == "table" then
        for _, v in pairs(tabl) do utils.table_visibleparse(v, tabl1) end
    else
       ui.set_visible(tabl, utils.in_table(tabl1, tabl))
    end
end
utils.is_insearch = false
utils.defaulttab = false
utils.searchui = function()
    if not ui.is_menu_open() then return end
    local tab = ui.get(switch)
    utils.visibleparse(search, tab ~= "Main" and tab ~= "Configs" and not utils.defaulttab)
    if utils.defaulttab then return end
    local gtab = tabs[tab]
    local searcht = ui.get(search[2]):lower()
    if oldtab ~= tab then
        if oldtab == "Main" or oldtab == "Configs" then
            utils.visibleparse(tabs[oldtab], false)
        end
        oldtab = tab
    end
    if string.len(searcht) > 0 and tab ~= "Main" and tab ~= "Configs" then
        if not searcht:find("[%^%$%(%)%%%.%[%]%*%+-%?]") then
            local finded = utils.findui(gtab, searcht)
            utils.table_visibleparse(gtab, finded)
            utils.is_insearch = true
        else
            utils.is_insearch = false
        end
    else
        utils.is_insearch = false
    end
end
ui.set_visible(defaultabbutton1, utils.defaulttab)
ui.set_callback(defaultabbutton, function()
    utils.defaulttab = true
    ui.set_visible(defaultabbutton1, utils.defaulttab)
    ui.set_visible(defaultabbutton, not utils.defaulttab)
    ui.set_visible(discordbutton, not utils.defaulttab)
    ui.set_visible(altuibutton, not utils.defaulttab)
    ui.set_visible(altuibutton1, not utils.defaulttab)
    utils.visibleparse(tabs, not utils.defaulttab)
    utils.visibleparse(skeetgui.aagui, utils.defaulttab)
end)
ui.set_callback(defaultabbutton1, function()
    utils.defaulttab = false
    ui.set_visible(defaultabbutton1, utils.defaulttab)
    ui.set_visible(defaultabbutton, not utils.defaulttab)
    ui.set_visible(discordbutton, not utils.defaulttab)
    ui.set_visible(altuibutton, not utils.is_altui)
    ui.set_visible(altuibutton1, utils.is_altui)
    utils.visibleparse(skeetgui.aagui, utils.defaulttab)
end)
local function menu_visible()
    utils.is_intab = ffi.cast("int*", 0x43479A10)[0] == 1
    if not ui.is_menu_open() or not utils.is_intab then return end
    if not utils.is_insearch and not utils.defaulttab then
        utils.visible_tabs()
    end
    ui.set_visible(switch, not utils.is_altui and not utils.defaulttab)
    if not utils.defaulttab then utils.visibleparse(skeetgui.aagui, false) end
end
--region @utils end

--region @hitlogger
hitlogger.entries = {}
hitlogger.max_entries = 8
hitlogger.duration = 5
hitlogger.animations = {}
hitlogger.x = 300
hitlogger.y = 100
hitlogger.dragging = false
hitlogger.drag_offset_x = 0
hitlogger.drag_offset_y = 0

hitlogger.add_entry = function(event_type, target_name, damage, hitgroup, weapon, reason)
    local entry = {
        event_type = event_type,
        target_name = target_name or "Unknown",
        damage = damage or 0,
        hitgroup = hitgroup or 0,
        weapon = weapon or "Unknown",
        reason = reason or nil,
        timestamp = globals.curtime(),
        alpha = 255,
        y_offset = 0
    }
    
    table.insert(hitlogger.entries, 1, entry)
    
    while #hitlogger.entries > hitlogger.max_entries do
        table.remove(hitlogger.entries)
    end
end

hitlogger.update_animations = function()
    local curtime = globals.curtime()
    
    for i, entry in ipairs(hitlogger.entries) do
        local age = curtime - entry.timestamp
        local max_age = hitlogger.duration
        
        if age > max_age then
            table.remove(hitlogger.entries, i)
        else
            -- fade out
            local fade_start = max_age * 0.7
            if age > fade_start then
                local fade_progress = (age - fade_start) / (max_age - fade_start)
                entry.alpha = math.floor(255 * (1 - fade_progress))
            end
            
            -- slide in
            local slide_duration = 0.3
            if age < slide_duration then
                local slide_progress = age / slide_duration
                entry.y_offset = math.floor(20 * (1 - slide_progress))
            else
                entry.y_offset = 0
            end
        end
    end
end

hitlogger.get_hitgroup_name = function(hitgroup)
    local hitgroups = {
        [0] = "Generic",
        [1] = "Head",
        [2] = "Chest",
        [3] = "Stomach",
        [4] = "Left Arm",
        [5] = "Right Arm",
        [6] = "Left Leg",
        [7] = "Right Leg",
        [8] = "Neck",
        [9] = "Generic",
        [10] = "Generic"
    }
    return hitgroups[hitgroup] or "Generic"
end

hitlogger.get_weapon_name = function(weapon_class)
    if not weapon_class then return "Unknown" end
    
    local weapon_names = {
        ["CWeaponAK47"] = "AK-47",
        ["CWeaponM4A1"] = "M4A4",
        ["CWeaponM4A1Silencer"] = "M4A1-S",
        ["CWeaponAWP"] = "AWP",
        ["CWeaponSSG08"] = "SSG 08",
        ["CWeaponAUG"] = "AUG",
        ["CWeaponSG556"] = "SG 553",
        ["CWeaponGalil"] = "Galil AR",
        ["CWeaponFamas"] = "FAMAS",
        ["CWeaponG3SG1"] = "G3SG1",
        ["CWeaponSCAR20"] = "SCAR-20",
        ["CWeaponAWP"] = "AWP",
        ["CWeaponSSG08"] = "SSG 08",
        ["CWeaponGlock"] = "Glock-18",
        ["CWeaponUSP"] = "USP-S",
        ["CWeaponP250"] = "P250",
        ["CWeaponTec9"] = "Tec-9",
        ["CWeaponFiveSeven"] = "Five-SeveN",
        ["CWeaponCZ75"] = "CZ75-Auto",
        ["CWeaponDeagle"] = "Desert Eagle",
        ["CWeaponR8"] = "R8 Revolver",
        ["CWeaponP2000"] = "P2000",
        ["CWeaponElite"] = "Dual Berettas",
        ["CWeaponMP9"] = "MP9",
        ["CWeaponMAC10"] = "MAC-10",
        ["CWeaponMP7"] = "MP7",
        ["CWeaponUMP45"] = "UMP-45",
        ["CWeaponP90"] = "P90",
        ["CWeaponBizon"] = "PP-Bizon",
        ["CWeaponMP5"] = "MP5-SD",
        ["CWeaponNova"] = "Nova",
        ["CWeaponXM1014"] = "XM1014",
        ["CWeaponSawedoff"] = "Sawed-Off",
        ["CWeaponM249"] = "M249",
        ["CWeaponNegev"] = "Negev",
        ["CKnife"] = "Knife",
        ["CWeaponTaser"] = "Zeus x27"
    }
    
    return weapon_names[weapon_class] or weapon_class
end

hitlogger.render_astral = function()
    -- only render if aimbot logs if enabled
    if not ui.get(tabs["Misc"].logs[1]) then return end
    if not utils.multi_parse(tabs["Misc"].logs[2], "Screen") then return end
    
    local style = ui.get(tabs["Manipulations"].uistyle[1])
    
    -- render all of em boi
    
    local screen = utils.get_screen()
    
    -- update settings
    hitlogger.max_entries = 8
    hitlogger.duration = 5
    
    -- update animations
    hitlogger.update_animations()
    
    -- handle dragging
    hitlogger.handle_drag(screen)
    
    -- render entries
    if #hitlogger.entries > 0 then
        if style == "Skeet" then
            hitlogger.render_skeet_style(screen)
        elseif style == "Methamod" then
            hitlogger.render_methamod_style(screen)
        elseif style == "Stasis" then
            hitlogger.render_stasis_style(screen)
        elseif style == "晨花" then
            hitlogger.render_chinese_style(screen)
        else
            hitlogger.render_astral_style(screen)
        end
    end
end

hitlogger.handle_drag = function(screen)
    if not ui.is_menu_open() then return end
    
    local mouse_x, mouse_y = ui.mouse_position()
    local is_clicking = client.key_state(0x01)
    
    local base_x = screen.x - hitlogger.x
    local base_y = hitlogger.y
    
    -- draw
    local preview_text = "Hit Enemy in the Head for 67 damage"
    local w, h = renderer.measure_text("b", preview_text)
    local bg_width = w + 12
    local bg_height = h + 10
    local radius = 3
    
    -- draw background
    rounded_rect(base_x, base_y, bg_width, bg_height, 54, 61, 74, 200, radius)
    
    -- gradient
    local gradient_height = 2
    local gradient_y = base_y + radius
    local gradient_width = bg_width - (radius * 2)
    renderer.gradient(base_x + radius, gradient_y, gradient_width, gradient_height, 159, 161, 240, 255, 187, 145, 236, 255, true)
    
    -- preview
    local label_r, label_g, label_b = 163, 166, 176
    local value_r, value_g, value_b = 157, 156, 218
    local damage_r, damage_g, damage_b = 0, 255, 0  -- green for hit damage
    
    local colored_text = string.format(
        "\a%02x%02x%02x%02xHit \a%02x%02x%02x%02xEnemy \a%02x%02x%02x%02xin the \a%02x%02x%02x%02xHead \a%02x%02x%02x%02xfor \a%02x%02x%02x%02x97 \a%02x%02x%02x%02xdamage",
        label_r, label_g, label_b, 255,
        value_r, value_g, value_b, 255,
        label_r, label_g, label_b, 255,
        value_r, value_g, value_b, 255,
        label_r, label_g, label_b, 255,
        damage_r, damage_g, damage_b, 255,
        label_r, label_g, label_b, 255
    )
    
    renderer.text(base_x + 6, base_y + gradient_height + radius + 2, 255, 255, 255, 255, "b", 0, colored_text)
    
    -- check if mouse is over hitlogger
    local is_hovering = mouse_x >= base_x and mouse_x <= base_x + bg_width and
                       mouse_y >= base_y and mouse_y <= base_y + bg_height
    
    if is_clicking then
        if not hitlogger.dragging and is_hovering then
            hitlogger.dragging = true
            hitlogger.drag_offset_x = mouse_x - base_x
            hitlogger.drag_offset_y = mouse_y - base_y
        end
        
        if hitlogger.dragging then
            hitlogger.x = screen.x - (mouse_x - hitlogger.drag_offset_x)
            hitlogger.y = mouse_y - hitlogger.drag_offset_y
            -- save position to database
            database.write("osmanhook::hitlogger_x", hitlogger.x)
            database.write("osmanhook::hitlogger_y", hitlogger.y)
        end
    else
        hitlogger.dragging = false
    end
end

hitlogger.render_astral_style = function(screen)
    local base_x = screen.x - hitlogger.x
    local base_y = hitlogger.y
    
    for i, entry in ipairs(hitlogger.entries) do
        if i > hitlogger.max_entries then break end
        
        local y = base_y + (i - 1) * 35 + entry.y_offset
        
        -- astral watermark colors
        local label_r, label_g, label_b = 163, 166, 176
        local value_r, value_g, value_b = 157, 156, 218
        
        -- get event color based on type (using default aimbot log colors)
        local event_color = {value_r, value_g, value_b}
        if entry.event_type == "hurt" then
            event_color = {255, 165, 0}
        elseif entry.event_type == "hit" then
            event_color = {0, 255, 0}
        elseif entry.event_type == "miss" then
            event_color = {255, 0, 0}
        elseif entry.event_type == "hurt_by" then
            event_color = {255, 100, 100} 
        end
        
        local weapon_name = hitlogger.get_weapon_name(entry.weapon)
        local hitgroup_name = hitlogger.get_hitgroup_name(entry.hitgroup)
        
        local colored_text
        if entry.event_type == "miss" then
            colored_text = string.format(
                "\a%02x%02x%02x%02xMissed \a%02x%02x%02x%02x%s \a%02x%02x%02x%02xat \a%02x%02x%02x%02x%s \a%02x%02x%02x%02xfor \a%02x%02x%02x%02x%s",
                label_r, label_g, label_b, entry.alpha,
                value_r, value_g, value_b, entry.alpha, entry.target_name,
                label_r, label_g, label_b, entry.alpha,
                value_r, value_g, value_b, entry.alpha, hitgroup_name,
                label_r, label_g, label_b, entry.alpha,
                event_color[1], event_color[2], event_color[3], entry.alpha, entry.reason or "unknown"
            )
        elseif entry.event_type == "hurt_by" then
            colored_text = string.format(
                "\a%02x%02x%02x%02xHurt by \a%02x%02x%02x%02x%s \a%02x%02x%02x%02xin the \a%02x%02x%02x%02x%s \a%02x%02x%02x%02xfor \a%02x%02x%02x%02x%d \a%02x%02x%02x%02xdamage",
                label_r, label_g, label_b, entry.alpha,
                value_r, value_g, value_b, entry.alpha, entry.target_name,
                label_r, label_g, label_b, entry.alpha,
                value_r, value_g, value_b, entry.alpha, hitgroup_name,
                label_r, label_g, label_b, entry.alpha,
                event_color[1], event_color[2], event_color[3], entry.alpha, entry.damage,
                label_r, label_g, label_b, entry.alpha
            )
        else
            colored_text = string.format(
                "\a%02x%02x%02x%02xHit \a%02x%02x%02x%02x%s \a%02x%02x%02x%02xin the \a%02x%02x%02x%02x%s \a%02x%02x%02x%02xfor \a%02x%02x%02x%02x%d \a%02x%02x%02x%02xdamage",
                label_r, label_g, label_b, entry.alpha,
                value_r, value_g, value_b, entry.alpha, entry.target_name,
                label_r, label_g, label_b, entry.alpha,
                value_r, value_g, value_b, entry.alpha, hitgroup_name,
                label_r, label_g, label_b, entry.alpha,
                event_color[1], event_color[2], event_color[3], entry.alpha, entry.damage,
                label_r, label_g, label_b, entry.alpha
            )
        end
        
        local plain_text
        if entry.event_type == "miss" then
            plain_text = string.format("Missed %s at %s for %s", entry.target_name, hitgroup_name, entry.reason or "unknown")
        elseif entry.event_type == "hurt_by" then
            plain_text = string.format("Hurt by %s in the %s for %d damage", entry.target_name, hitgroup_name, entry.damage)
        else
            plain_text = string.format("Hit %s in the %s for %d damage", entry.target_name, hitgroup_name, entry.damage)
        end
        local w, h = renderer.measure_text("b", plain_text)
    
        local bg_width = w + 12
        local bg_height = h + 10
        local radius = 3
        
        local bg_y = y
        local bg_x = base_x
        
        y = bg_y + radius
        renderer.circle(bg_x + radius, y, 54, 61, 74, entry.alpha, radius, 180, 0.25)
        renderer.circle(bg_x + bg_width - radius, y, 54, 61, 74, entry.alpha, radius, 90, 0.25)
        renderer.circle(bg_x + radius, y + bg_height - radius * 2, 54, 61, 74, entry.alpha, radius, 270, 0.25)
        renderer.circle(bg_x + bg_width - radius, y + bg_height - radius * 2, 54, 61, 74, entry.alpha, radius, 0, 0.25)
        
        renderer.rectangle(bg_x + radius, y, bg_width - radius * 2, bg_height - radius * 2, 54, 61, 74, entry.alpha)
        renderer.rectangle(bg_x + radius, y - radius, bg_width - radius * 2, radius, 54, 61, 74, entry.alpha)
        renderer.rectangle(bg_x + radius, y + bg_height - radius * 2, bg_width - radius * 2, radius, 54, 61, 74, entry.alpha)
        renderer.rectangle(bg_x, y, radius, bg_height - radius * 2, 54, 61, 74, entry.alpha)
        renderer.rectangle(bg_x + bg_width - radius, y, radius, bg_height - radius * 2, 54, 61, 74, entry.alpha)
        
        y = bg_y -- Reset y
        
        local gradient_height = 2
        local gradient_y = y + radius
        local gradient_width = bg_width - (radius * 2)
        renderer.gradient(base_x + radius, gradient_y, gradient_width, gradient_height, 159, 161, 240, entry.alpha, 187, 145, 236, entry.alpha, true)
        
        local text_x = base_x + 6
        local text_y = y + gradient_height + radius + 2
        renderer.text(text_x, text_y, 255, 255, 255, 255, "b", 0, colored_text)
    end
end

hitlogger.render_skeet_style = function(screen)
    local x = screen.x - hitlogger.x
    local y = hitlogger.y
    local entry_height = 20
    local padding = 3
    
    for i, entry in ipairs(hitlogger.entries) do
        if i > hitlogger.max_entries then break end
        
        local entry_y = y + (i - 1) * (entry_height + padding) + entry.y_offset
        local width = 280
        local height = entry_height
        
        local color = {255, 255, 255, entry.alpha}
        if entry.event_type == "hit" then
            color = {0, 255, 0, entry.alpha}
        elseif entry.event_type == "hurt" then
            color = {255, 165, 0, entry.alpha} 
        elseif entry.event_type == "miss" then
            color = {255, 0, 0, entry.alpha} 
        end
        
        local bg_color = {15, 15, 15, math.floor(entry.alpha * 0.9)}
        renderer.rectangle(x - width, entry_y, width, height, bg_color[1], bg_color[2], bg_color[3], bg_color[4])
        
        local text_x = x - width + 8
        local text_y = entry_y + height / 2
        
        local event_text = string.upper(entry.event_type)
        renderer.text(text_x, text_y, color[1], color[2], color[3], color[4], "c", 0, event_text)
        
        local name_x = text_x + 40
        renderer.text(name_x, text_y, color[1], color[2], color[3], color[4], "c", 0, entry.target_name)
        
        if entry.damage > 0 then
            local damage_x = text_x + 120
            renderer.text(damage_x, text_y, color[1], color[2], color[3], math.floor(color[4] * 0.8), "c", 0, tostring(entry.damage))
        end
    end
end

hitlogger.render_methamod_style = function(screen)
    local x = screen.x - hitlogger.x
    local y = hitlogger.y
    local entry_height = 20
    local padding = 3
    local color = {ui.get(tabs["Manipulations"].uistyle[3])}
    for i, entry in ipairs(hitlogger.entries) do
        if i > hitlogger.max_entries then break end
        local entry_y = y + (i - 1) * (entry_height + padding) + entry.y_offset
        local width = 300
        local bg_a = math.floor(entry.alpha * 0.9)
        renderer.rectangle(x - width, entry_y, width, entry_height, 15, 15, 15, bg_a)
        renderer.rectangle(x - width, entry_y, width, 2, color[1], color[2], color[3], 255)
        local text = string.format("%s: %s %s %d", string.upper(entry.event_type), entry.target_name, hitlogger.get_hitgroup_name(entry.hitgroup), entry.damage)
        renderer.text(x - width + 8, entry_y + entry_height / 2, 255, 255, 255, entry.alpha, "c", 0, text)
    end
end

hitlogger.render_stasis_style = function(screen)
    local x = screen.x - hitlogger.x
    local y = hitlogger.y
    local entry_height = 20
    local padding = 3
    for i, entry in ipairs(hitlogger.entries) do
        if i > hitlogger.max_entries then break end
        local entry_y = y + (i - 1) * (entry_height + padding) + entry.y_offset
        local width = 300
        renderer.rectangle(x - width, entry_y, width, entry_height, 0, 0, 0, math.floor(entry.alpha * 0.5))
        local text = string.format("%s %s %s %d", entry.event_type, entry.target_name, hitlogger.get_hitgroup_name(entry.hitgroup), entry.damage)
        renderer.text(x - width + 8, entry_y + entry_height / 2, 255, 255, 255, entry.alpha, "c", 0, text)
    end
end

hitlogger.render_chinese_style = function(screen)
    local base_x = screen.x - hitlogger.x
    local base_y = hitlogger.y
    local color = {ui.get(tabs["Manipulations"].uistyle[3])}
    for i, entry in ipairs(hitlogger.entries) do
        if i > hitlogger.max_entries then break end
        local y = base_y + (i - 1) * 28 + entry.y_offset
        local text = string.format("%s %s %s %d", entry.event_type, entry.target_name, hitlogger.get_hitgroup_name(entry.hitgroup), entry.damage)
        local w, h = renderer.measure_text("b", text)
        rounded_rect(base_x - w - 14, y - 2, w + 12, h + 6, color[1], color[2], color[3], math.floor(entry.alpha * 0.25), 5)
        renderer.text(base_x - w - 8, y + 1, 240, 240, 240, entry.alpha, nil, 0, text)
    end
end

--region @hitlogger end

--region @rage
rage.alive_players = {}
rage.paint = function()
    local lplayer = entity.get_local_player()
    if lplayer == nil or not entity.is_alive(lplayer) then return end
    --local gmrules = entity.get_player_resource()
    rage.target = client.current_threat()
    rage.target_weapon = entity.get_classname(entity.get_player_weapon(rage.target))
    rage.weapon = entity.get_classname(entity.get_player_weapon(lplayer))
    rage.exploits = ui.get(skeetgui.ragegui.aimbot.double_tap[1]) and ui.get(skeetgui.ragegui.aimbot.double_tap[2]) or ui.get(skeetgui.aagui.other.on_shot_antiaim[1]) and ui.get(skeetgui.aagui.other.on_shot_antiaim[2])
    if rage.weapon ~= nil and ui.get(skeetgui.ragegui.aimbot.double_tap[1]) and ui.get(skeetgui.ragegui.aimbot.double_tap[2]) then
        local next_attack = entity.get_prop(lplayer, "m_flNextAttack") + 0.01
        local checkcheck = entity.get_prop(entity.get_player_weapon(lplayer), "m_flNextPrimaryAttack")
        if checkcheck ~= nil then
            local next_primary_attack = checkcheck ~= nil and checkcheck + 0.01
            if next_attack ~= nil and next_primary_attack ~= nil then
                rage.dt = next_attack - globals.curtime() < 0 and next_primary_attack - globals.curtime() < 0
            else
                rage.dt = false
            end
        end
    else
        rage.dt = false
    end
    local lpos = vector(entity.get_origin(lplayer))
    local tpos = rage.target ~= nil and vector(entity.get_origin(rage.target))
    rage.distance = rage.target ~= nil and utils.distance(lpos, tpos) or 0
    rage.zdelta = rage.distance > 0 and lpos.z - tpos.z
    rage.alive_players = {}
    for i=1, globals.maxplayers() do
        if entity.is_alive(i) and entity.is_enemy(i) then
            table.insert(rage.alive_players, i)
        end
    end
    rage.isnoenemy = #rage.alive_players == 0
    if rage.isnoenemy then
        rage.hittable = false
        return
    end
    for i, ent in ipairs(rage.alive_players) do
        if not entity.is_dormant(ent) then
            local flag = entity.get_esp_data(ent).flags or 0
            if bit.band(flag, bit.lshift(1, 11)) ~= 0 then
                rage.hittable = true
            else
                rage.hittable = false
            end
        else
            rage.hittable = false
        end
    end
end
rage.jumpshot = function(cmd)
    if not ui.get(tabs["Rage"].jumpshot[1]) then return end
    local lplayer = entity.get_local_player()
    if lplayer == nil or not entity.is_alive(lplayer) then return end
    local cweapon = entity.get_player_weapon(lplayer)
    if cweapon == nil then return end
    local anst = get_animstate(lplayer)
    local iscout = rage.weapon == "CWeaponSSG08" and (cmd.in_jump == 1 or not anst.on_ground)
    local isr8 = csgo_weapons(cweapon).is_revolver
    local ir8 =  isr8 and (cmd.in_jump == 1 or not anst.on_ground)
    local nexts = entity.get_prop(lplayer, "m_flNextAttack")
    local nextp = globals.curtime() >= (isr8 and nexts or math.max(entity.get_prop(cweapon, "m_flNextPrimaryAttack"), nexts))
    rage.jumpshoting = false
    if not nextp then return end
    if not rage.hittable then return end
    if ui.get(tabs["Rage"].jumpshot[2]) then
        if utils.multi_parse(tabs["Rage"].jumpshot[3], "R8") and ir8 then
            if rage.distance > ui.get(tabs["Rage"].jumpshot[4])  then return end
            cmd.in_jump = 0
        end
        if utils.multi_parse(tabs["Rage"].jumpshot[3], "Scout") and iscout then
            if rage.distance > ui.get(tabs["Rage"].jumpshot[5])  then return end
            cmd.in_jump = 0
        end
    end
end
function expind()
    local inds = ui.get(tabs["Visuals"].addind[1])
    if #inds == 0 then return end
    if utils.in_table(inds, "Jumpshot") and ui.get(tabs["Rage"].jumpshot[1]) and ui.get(tabs["Rage"].jumpshot[2]) and #ui.get(tabs["Rage"].jumpshot[3]) > 0 then
        renderer.indicator(255, 255, 255, 255, "JUMPSHOT")
    end
    if utils.in_table(inds, "Charge") and rage.unsafe_charging then
        renderer.indicator(255, 0, 0, 255, "CHARGE")
    end
    if utils.in_table(inds, "Force Head") and rage.onlyhs then
        renderer.indicator(255, 255, 255, 255, "HEAD AIM")
    end
    if utils.in_table(inds, "Hitchance") and rage.htch_override then
        renderer.indicator(255, 255, 255, 255, "HITCHANCE")
    end
    if utils.in_table(inds, "Dormant") and ui.get(tabs["Rage"].dormant[1]) and ui.get(tabs["Rage"].dormant[2]) then
        renderer.indicator(255, 255, 255, 255, "DA")
    end
    if utils.in_table(inds, "Target") then
        if antiaims.current_cond and tabs["Anti-Aimbot"][antiaims.current_cond] then
            local target = ui.get(tabs["Anti-Aimbot"][antiaims.current_cond].yaw_base) == "Closest enemy" and antiaims.target or client.current_threat()
            local name = entity.get_player_name(target)
            if name and name ~= "unknown" then
                renderer.indicator(255, 255, 255, 255, "Target: "..name)
            end
        end
    end
end

local hitbx, hitch = {}, {}
local ogwp = ui.get(skeetgui.ragegui.weapon.weapon_type)
do
    for _, val in ipairs(utils.weapgroup) do
        ui.set(skeetgui.ragegui.weapon.weapon_type, val)
        hitbx[val] = {ui.get(skeetgui.ragegui.aimbot.hitboxes), ui.get(skeetgui.ragegui.aimbot.prefer_body_aim)}
        if utils.in_table(rage.weaponstweaks, val) then
            hitch[val] = ui.get(skeetgui.ragegui.aimbot.hitchance)
        end
    end
    ui.set(skeetgui.ragegui.weapon.weapon_type, ogwp)
end
rage.forcehead = function()
    if not ui.get(tabs["Rage"].onlyhs[1]) then return end
    local lplayer = entity.get_local_player()
    if lplayer == nil or not entity.is_alive(lplayer) then return end
    ogwp = cwp
    cwp = ui.get(skeetgui.ragegui.weapon.weapon_type)
    if cwp == "Zeus" or ogwp == "Zeus" then return end
    if ogwp ~= cwp and rage.onlyhs then
        ui.set(skeetgui.ragegui.weapon.weapon_type, ogwp)
        ui.set(skeetgui.ragegui.aimbot.hitboxes, hitbx[ogwp][1])
        ui.set(skeetgui.ragegui.aimbot.prefer_body_aim, hitbx[ogwp][2])
        ui.set(skeetgui.ragegui.weapon.weapon_type, cwp)
    end
    if ui.get(tabs["Rage"].onlyhs[2]) then
        ui.set(skeetgui.ragegui.aimbot.hitboxes, {"Head"})
        rage.onlyhs = true
    elseif rage.onlyhs then
        ui.set(skeetgui.ragegui.aimbot.hitboxes, hitbx[cwp][1])
        ui.set(skeetgui.ragegui.aimbot.prefer_body_aim, hitbx[cwp][2])
        rage.onlyhs = false
    end
end
rage.hitchance = function(reset)
    local preset = ui.get(skeetgui.ragegui.weapon.weapon_type)
    if utils.in_table(rage.weaponstweaks, preset) then
        if reset then
            ui.set(skeetgui.ragegui.aimbot.hitchance, hitch[preset])
            rage.htch_override = false
            return
        end
        local hitchance = ui.get(tabs["Rage"].hitchance.tbl[preset])
        if hitchance < 0 then return end
        if ui.get(tabs["Rage"].hitchance[2]) then
            ui.set(skeetgui.ragegui.aimbot.hitchance, hitchance)
            rage.htch_override = true
        elseif rage.htch_override then
            ui.set(skeetgui.ragegui.aimbot.hitchance, hitch[preset])
            rage.htch_override = false
        end
    end
end
ui.set_callback(tabs["Rage"].hitchance[1], function(id)
    if ui.get(id) then
        client.set_event_callback("paint", rage.hitchance)
    else
        client.unset_event_callback("paint", rage.hitchance)
    end
end)
ui.set_callback(skeetgui.ragegui.aimbot.hitchance, function(id)
    if (not ui.get(tabs["Rage"].hitchance[1]) or not ui.get(tabs["Rage"].hitchance[2])) and not rage.htch_override then
        local preset = ui.get(skeetgui.ragegui.weapon.weapon_type)
        if utils.in_table(rage.weaponstweaks, preset) then
            hitch[preset] = ui.get(id)
        end
    end
end)

rage.unsafe_charging = false
rage.unsafe_charge = function(cmd)
    if cmd == true then 
            ui.set(skeetgui.ragegui.aimbot.enabled[1], true)
            rage.unsafe_charging = false
        return
    end
    local isdt = ui.get(skeetgui.ragegui.aimbot.double_tap[1]) and ui.get(skeetgui.ragegui.aimbot.double_tap[2])
    if not isdt then 
        if rage.unsafe_charging or not ui.get(skeetgui.ragegui.aimbot.enabled[1]) then
            ui.set(skeetgui.ragegui.aimbot.enabled[1], true)
            rage.unsafe_charging = false
        end
    else
        local lplayer = entity.get_local_player()
        local state = get_animstate(lplayer)
        local on_air = utils.multi_parse(tabs["Rage"].unsafe_charge[2], "Air") and (cmd.in_jump == 1 or not state.on_ground)
        local on_ground = utils.multi_parse(tabs["Rage"].unsafe_charge[2], "Ground") and cmd.in_jump == 0 and state.on_ground
        if not rage.unsafe_charging and rage.hittable and ticks.tickbase_diff ~= nil and afunc.get_tickbase_shifting() == 0 and ticks.tickbase_diff == 1 and (on_ground or on_air) then
            ui.set(skeetgui.ragegui.aimbot.enabled[1], rage.unsafe_charging)
            rage.unsafe_charging = true
        elseif not ui.get(skeetgui.ragegui.aimbot.enabled[1]) and rage.unsafe_charging and (afunc.get_tickbase_shifting() > 1 or ticks.tickbase_diff < 0)then
            ui.set(skeetgui.ragegui.aimbot.enabled[1], rage.unsafe_charging)
            rage.unsafe_charging = false
        end
    end
end
ui.set_callback(tabs["Rage"].unsafe_charge[1], function(id)
    if ui.get(id) then
        client.set_event_callback("setup_command", rage.unsafe_charge)
    else
        client.unset_event_callback("setup_command", rage.unsafe_charge)
        rage.unsafe_charge(true)
    end
end)
rage.forcebody_lethal = function(reset)
    local lplayer = entity.get_local_player()
    if lplayer == nil or not entity.is_alive(lplayer) then return end
    local preset = ui.get(skeetgui.ragegui.weapon.weapon_type)
    if reset then
        for _, ent in ipairs(rage.alive_players) do
            plist.set(ent, "Override prefer body aim", "-")
        end
        return
    end
    if utils.in_table(rage.weaponstweaks, preset) and ui.get(tabs["Rage"].lethal[2]) then
        for _, ent in ipairs(rage.alive_players) do
            local goalhp = ui.get(tabs["Rage"].lethal.tbl[preset])
            local hp = entity.get_prop(ent, "m_iHealth")
            local islethal = hp <= goalhp
            plist.set(ent, "Override prefer body aim", islethal and "Force" or "-")
        end
    else
        for _, ent in ipairs(rage.alive_players) do
            plist.set(ent, "Override prefer body aim", "-")
        end
    end
end
ui.set_callback(tabs["Rage"].lethal[1], function(id)
    if ui.get(id) then
        client.set_event_callback("paint", rage.forcebody_lethal)
    else
        client.unset_event_callback("paint", rage.forcebody_lethal)
        rage.forcebody_lethal(true)
    end
end)
rage.cond_mpoints = function(cmd)
    if not ui.get(tabs["Rage"].mpoints[1]) then return end
    local tb = tabs["Rage"].mpoints.tbl
    local lplayer = entity.get_local_player()
    if lplayer == nil or not entity.is_alive(lplayer) then return end
    local cwp = ui.get(skeetgui.ragegui.weapon.weapon_type)
    if not utils.in_table(rage.mpoints, cwp) or not ui.get(tabs["Rage"].mpoints.enbl[cwp]) then return end
    local flags = entity.get_prop(lplayer, 'm_fFlags')
	local m_vecVelocity = { entity.get_prop(lplayer, 'm_vecVelocity') }
    local is_crouching = bit.band(flags, bit.lshift(1, 1)) ~= 0
    local on_ground = bit.band(flags, bit.lshift(1, 0)) ~= 0
    local standing = math.abs(m_vecVelocity[1]) + math.abs(m_vecVelocity[2]) < 2
    local slowwalking = ui.get(skeetgui.aagui.other.slow_motion[1]) and ui.get(skeetgui.aagui.other.slow_motion[2])
    local is_jumping = cmd.in_jump == 1
    local duckpeek = ui.get(skeetgui.ragegui.other.duck_peek_assist)
    if standing and on_ground and not is_jumping and not slowwalking and not duckpeek and not is_crouching then
        ui.set(skeetgui.ragegui.aimbot.multipoint_scale, ui.get(tb[cwp][1]))
    end
    if not standing and on_ground and not is_jumping and not slowwalking and not duckpeek and not is_crouching then
        ui.set(skeetgui.ragegui.aimbot.multipoint_scale, ui.get(tb[cwp][2]))
    end
    if slowwalking and on_ground and not is_jumping and not duckpeek and not is_crouching then
        ui.set(skeetgui.ragegui.aimbot.multipoint_scale, ui.get(tb[cwp][3]))
    end
    if (not on_ground or is_jumping) and not is_crouching then
        ui.set(skeetgui.ragegui.aimbot.multipoint_scale, ui.get(tb[cwp][4]))
    end
    if (not on_ground or is_jumping) and is_crouching then
        ui.set(skeetgui.ragegui.aimbot.multipoint_scale, ui.get(tb[cwp][5]))
    end
    if is_crouching and on_ground and not is_jumping and not duckpeek then
        ui.set(skeetgui.ragegui.aimbot.multipoint_scale, ui.get(tb[cwp][6]))
    end
    if duckpeek and on_ground and not is_jumping then
        ui.set(skeetgui.ragegui.aimbot.multipoint_scale, ui.get(tb[cwp][7]))
    end
end
local function modify_velocity(cmd, goalspeed)
	local minspeed = math.sqrt((cmd.forwardmove * cmd.forwardmove) + (cmd.sidemove * cmd.sidemove))
	if goalspeed <= 0 or minspeed <= 0 then
		return
	end

	if cmd.in_duck == 1 then
		goalspeed = goalspeed * 2.94117647
	end

	if minspeed <= goalspeed then
		return
	end

	local speedfactor = goalspeed / minspeed
	cmd.forwardmove = cmd.forwardmove * speedfactor
	cmd.sidemove = cmd.sidemove * speedfactor
end
local player_info_prev = {}
local roundStarted = 0
client.set_event_callback("round_prestart", function()
	local to_invalidate = (cvar.mp_freezetime:get_float() + 1) / globals.tickinterval()

	roundStarted = globals.tickcount() + to_invalidate
end)
local dormantselection = {
    ["Head"] = {0, 1},
    ["Chest"] = {4, 5, 6},
    ["Stomach"] = {2, 3},
    ["Legs"] = {7, 8, 9, 10},
    ["Feet"] = {11, 12},
    ["Arms"] = {13, 14, 15, 16, 17, 18},
}
rage.dormant = function(cmd)
    if not ui.get(tabs["Rage"].dormant[1]) or not ui.get(tabs["Rage"].dormant[2]) then return end
	local lplayer = entity.get_local_player()
	local my_weapon = entity.get_player_weapon(lplayer)
	if not my_weapon then
		return
	end
	local ent = native_GetClientEntity1(my_weapon)
	if ent == nil or not native_IsWeapon(ent) then
		return
	end

	local inaccuracy = native_GetInaccuracy(ent)
	if inaccuracy == nil then		return
	end

	local tickcount = globals.tickcount()
	local player_resource = entity.get_player_resource()
	local eyepos = vector(client.eye_position())
	local simtime = entity.get_prop(lplayer, "m_flSimulationTime")
	local curtime = globals.curtime()
	local weapon = csgo_weapons(my_weapon)
	local scoped = entity.get_prop(lplayer, "m_bIsScoped") == 1
	local onground = bit.band(entity.get_prop(lplayer, 'm_fFlags'), bit.lshift(1, 0))
    local cwp = ui.get(skeetgui.ragegui.weapon.weapon_type)
    if not utils.in_table(rage.weaponstweaks, cwp) then return end
    local goaldmg = ui.get(tabs["Rage"].dormant.tbl[cwp][2])
    if goaldmg < 1 then
        local ismindmg = ui.get(skeetgui.ragegui.aimbot.minimum_damage_override[1]) and ui.get(skeetgui.ragegui.aimbot.minimum_damage_override[2])
        goaldmg = ismindmg and ui.get(skeetgui.ragegui.aimbot.minimum_damage_override[3]) or ui.get(skeetgui.ragegui.aimbot.minimum_damage)
    end
    local goalacurate = ui.get(tabs["Rage"].dormant.tbl[cwp][1])*0.01
	if tickcount < roundStarted then return end -- to prevent shooting at ghost dormant esp @ the beginning of round
	local can_shoot;
    local nading;
    if weapon.is_revolver then
        can_shoot = curtime > entity.get_prop(my_weapon, "m_flNextPrimaryAttack")
    elseif weapon.is_melee_weapon then
        can_shoot = curtime > math.max(entity.get_prop(lplayer, "m_flNextAttack"), entity.get_prop(my_weapon, "m_flNextPrimaryAttack"), entity.get_prop(my_weapon, "m_flNextSecondaryAttack")) - globals.tickinterval()
    elseif weapon.is_grenade then
        can_shoot = false
    else
        can_shoot = curtime > math.max(entity.get_prop(lplayer, "m_flNextAttack"), entity.get_prop(my_weapon, "m_flNextPrimaryAttack"), entity.get_prop(my_weapon, "m_flNextSecondaryAttack"))
    end
    if weapon.is_grenade and entity.get_prop(my_weapon, "m_fThrowTime") > 0 then nading = true end
    if cmd.in_attack == 1 and can_shoot or nading then return end

	-- new player info
	local player_info = {}

	-- loop through all players and continue if they're connected
	for _, player in ipairs(rage.alive_players) do
		if entity.get_prop(player_resource, "m_bConnected", player) == 1 then
			if plist.get(player, "Add to whitelist") then goto skip end
			if entity.is_dormant(player) then
				local can_hit

				local origin = vector(entity.get_origin(player))
				local x1, y1, x2, y2, alpha_multiplier = entity.get_bounding_box(player) -- grab alpha of the dormant esp
				
				if player_info_prev[player] ~= nil and origin.x ~= 0 and alpha_multiplier > 0 then -- if origin / dormant esp is valid
					local old_origin, old_alpha, old_hittable = unpack(player_info_prev[player])

					-- update check
					local dormant_accurate = alpha_multiplier >= goalacurate -- for debug purposes lower this to 0.1 | 0.795
                    --if not (alpha_multiplier < math.floor(goalacurate * 100) + 5) then
                    --    return
                    --end
					if dormant_accurate then
						local target = origin + vector(0, 0, 40)
						local pitch, yaw = eyepos:to(target):angles()
						local ent, dmg = client.trace_bullet(lplayer, eyepos.x, eyepos.y, eyepos.z, target.x, target.y, target.z, true)
						can_hit = (dmg >= goaldmg) and (not client.visible(target.x, target.y, target.z)) -- added visibility check to mitigate shooting at anomalies?
						if can_shoot and can_hit then
							modify_velocity(cmd, (scoped and weapon.max_player_speed_alt or weapon.max_player_speed)*0.33)

							-- autoscope
							if not scoped and weapon.type == "sniperrifle" and cmd.in_jump == 0 and onground == 1 then
								cmd.in_attack2 = 1
							end
							
							if inaccuracy < 0.009 and cmd.chokedcommands == 0 then
								cmd.pitch = pitch
								cmd.yaw = yaw
								cmd.in_attack = 1

								-- dont shoot again
								can_shoot = false
								--client_log(string_format('Taking a shot at: %s | tickcount: %d | predcited damage: %d | inaccuracy: %.3f | Alpha: %.3f', entity.get_player_name(player), tickcount, dmg, inaccuracy, alpha_multiplier))
							end
						end
					end
				end
				player_info[player] = {origin, alpha_multiplier, can_hit}
			end
		end
		::skip::
	end
	player_info_prev = player_info
end
rage.delayshot = function()
    ui.set(skeetgui.ragegui.other.delay_shot, ui.get(tabs["Rage"].delay_shot[1]))
end
--region @rage end
ui.set_callback(skeetgui.ragegui.aimbot.hitboxes, function(id)
    local cwp = ui.get(skeetgui.ragegui.weapon.weapon_type)
    if not utils.in_table(utils.weapgroup, cwp) then return end
    if ogwp == cwp and not rage.onlyhs and not ui.get(tabs["Rage"].onlyhs[2]) then
        hitbx[cwp][1] = ui.get(id)
    end
end)
ui.set_callback(skeetgui.ragegui.aimbot.prefer_body_aim, function(id)
    local cwp = ui.get(skeetgui.ragegui.weapon.weapon_type)
    if not utils.in_table(utils.weapgroup, cwp) then return end
    if ogwp == cwp and not rage.onlyhs and not ui.get(tabs["Rage"].onlyhs[2]) then 
        hitbx[cwp][2] = ui.get(id)
    end
end)
local dpi_scaling_y = { { 84, 149 }, { 100, 181 }, { 116, 213 }, { 132, 245 }, { 148, 277 } }
do
    local private_area = {
    ["power"]               = "",
    ["circle arc bold"]     = "",
    ["hollow heart"]        = "",
    ["broken heart"]        = "",
    ["heart"]               = "",
    ["check mark"]          = "",
    ["down arrows"]         = "",
    ["arrow upper"]         = "",
    ["left arrow"]          = "",
    ["monitors"]            = "",
    ["invalid arrows"]      = "",
    ["star"]                = "",
    ["backspace"]           = "",
    ["keyboard"]            = "",
    ["discard mark"]        = "",
    ["cicle dots"]          = "",
    ["cicle dots bold"]     = "",
    ["dots horizontal"]     = "",
    ["dots vertical"]       = "",
    ["circle cloud sun"]    = "",
    ["list"]                = "",
    ["list upper"]          = "",
    ["folder upper"]        = "",
    ["monitor body"]        = "",
    ["backplay"]            = "",
    ["forwardplay"]         = "",
    ["play"]                = "",
    ["pause"]               = "",
    ["pen"]                 = "",
    ["floppy"]              = "",
    ["trashcan"]            = "",
    ["-"]                   = "",
    ["+"]                   = "",
    ["house"]               = "",
    ["camera"]              = "",
    ["camera2"]             = "",
    ["gear"]                = "",
    ["swap"]                = "",
    ["download"]            = "",
    ["mail"]                = "",
    ["lens"]                = "",
    ["questionmark"]        = "",
    ["upload"]              = "",
    ["smileface"]           = "",
    ["send mail"]           = "",
    ["mail sended"]         = "",
    ["clock"]               = "",
    ["two body"]            = "",
    ["earth"]               = "",
    ["globe"]               = "",
    ["checkmark list"]      = "",
    ["body list"]           = "",
    ["tab"]                 = "",
    ["body"]                = "",
    ["dissasm xmark"]       = "",
    ["cycle right"]         = "",
    ["cycle left"]          = "",
    ["volume"]              = "",
    ["wrench"]              = "",
    ["funnel"]              = "",
    ["exclamark"]           = "",
    ["vertical tab"]        = "",
    ["list bold"]           = "",
    ["list upper bold"]     = "",
    ["body rect"]           = "",
    ["folder"]              = "",
    ["circle arc"]          = "",
    ["key"]                 = "",
    ["silence"]             = "",
    ["inner folder"]        = "",
    ["folder upper bold"]   = "",
    ["dislike like"]        = "",
    ["dislike"]             = "",
    ["like"]                = "",
    ["lens bold"]           = "",
    ["cycle rect"]          = "",
    ["nametag"]             = "",
    ["star bold"]           = "",
    ["star hollow bold"]    = "",
    ["calculator"]          = "",
    ["microphone"]          = "",
    ["increase"]            = "",
    ["decrease"]            = "",
    ["folder+"]             = "",
    ["shield"]              = "",
    ["folder cycle"]        = "",
    ["body stop"]           = "",
    ["body+"]               = "",
    ["ping0"]               = "",
    ["ping1"]               = "",
    ["ping2"]               = "",
    ["ping3"]               = "",
    ["ping4"]               = "",
    ["lock locked"]         = "",
    ["lock open"]           = "",
    ["like bold"]           = "",
    ["mail bold"]           = "",
    ["computer small"]      = "",
    ["play small"]          = "",
    ["pause small"]         = "",
    ["trashcan small"]      = "",
    ["discard mark small"]  = "",
    ["floppy small"]        = "",
    ["star small"]          = "",
    ["star hollow small"]   = "",
    ["decrease small"]      = "",
    ["increase small"]      = "",
    ["download small"]      = "",
    ["phone small"]         = "",
    ["stop small"]          = "",
    ["camera small"]        = "",
    ["sun"]                 = "",
    ["clouds"]              = "",
    ["cloud sun"]           = "",
    ["cloud wind"]          = "",
    ["cloud fog"]           = "",
    ["cloud light"]         = "",
    ["cloud snow"]          = "",
    ["snowflake"]           = "",
    ["right moon"]          = "",
    ["body upper"]          = "",
    ["pallete"]             = "",
    ["novolume small"]      = "",
    ["cardio heart small"]  = "",
    ["mouse small"]         = "",
    ["keyboard small"]      = "",
    ["dots cycle small"]    = "",
    ["gear small"]          = "",
    ["dots cycle"]          = "",
    }
    utils.altui = {private_area["dots cycle"], private_area["body+"], private_area["body stop"], private_area["pallete"], private_area["gear"], private_area["wrench"], private_area["list bold"]}
    private_area = nil
    collectgarbage("collect")
end
ishovered = {}
utils.altuialpha = 0
utils.menufade = false
utils.is_open = true
utils.attackhover = {}
--godbless Cheat Engine for freeing me from hardcoding ts
utils.menu_fademode = ffi.cast("int*", 0x43479A38)
utils.menu_fadespeed = 64 / ffi.cast("float*", 0x4346F920)[0]
utils.handle_altui = function()
    if not utils.is_altui or utils.defaulttab then return end
    if utils.menu_fademode[0] == 1 then
        utils.is_open = false
    elseif utils.menu_fademode[0] == 2 then
        utils.is_open = true
    end
    if not utils.is_open or not utils.is_intab then
        if utils.altuialpha > 0 then
            utils.altuialpha = utils.lerp(utils.altuialpha, 0, utils.menu_fadespeed)
        else
            return
        end
    end
    if utils.altuialpha < 1 and utils.is_open and utils.is_intab then
        utils.altuialpha = utils.lerp(utils.altuialpha, 1, utils.menu_fadespeed)
    end
    local x, y = ui.menu_position()
    local w, h = ui.menu_size()
    x = x+w + 90
    renderer.rectangle(x - 90, y, 90, h, g[1], g[2], g[3], 255 * utils.altuialpha) -- w + 18
    renderer.rectangle(x - 89, y + 1, 88, h - 2, a[1], a[2], a[3], 255 * utils.altuialpha)
    renderer.rectangle(x - 88, y + 2, 86, h - 4, b[1], b[2], b[3], 255 * utils.altuialpha)
    renderer.rectangle(x - 85, y + 5, 80, h - 10, a[1], a[2], a[3], 255 * utils.altuialpha)
    renderer.rectangle(x - 84, y + 7, 78, h - 13, 12, 12, 12, 255 * utils.altuialpha)
    renderer.gradient(x - 83, y + 8, 38, 2, g1[1], g1[2], g1[3], 200 * utils.altuialpha, g2[1], g2[2], g2[3], 200 * utils.altuialpha, true)
    renderer.gradient(x - 45, y + 8, 38, 2, g2[1], g2[2], g2[3], 200 * utils.altuialpha, g3[1], g3[2], g3[3], 200 * utils.altuialpha, true)
    local wh, hw = 80, h/#switchtb
    utils.attackhover[1] = utils.in_range_rect(cursor, {x = x - 90, y = y}, {90, h})
    for i=1, #switchtb do
        ishovered[i] = utils.in_range_rect(cursor, {x = x - 84, y = y + 7 + hw*(i-1)}, {wh, hw})
    end
    local chosen = utils.table_index(switchtb, ui.get(switch))
    for k, v in ipairs(ishovered) do
        if v and firstclick then
            chosen = k
        end
    end
    if utils.oldchosen ~= chosen then
        ui.set(switch, switchtb[chosen])
    end
    utils.oldchosen = chosen
    local hmod = 4
    for k, v in ipairs(utils.altui) do
        local use_custom_colors = ui.get(tabs["Visuals"].altui_icon_colors[1])
        color = use_custom_colors and {ui.get(tabs["Visuals"].altui_icon_colors[3])} or {90, 90, 90, 255}
        if chosen == k then
            color = use_custom_colors and {ui.get(tabs["Visuals"].altui_icon_colors[5])} or {210, 210, 210, 255}
            renderer.rectangle(x - 83, y + 9 + hmod + 2, 76, hw - 2, g[1], g[2], g[3], 255 * utils.altuialpha)
            renderer.rectangle(x - 83, y + 9 + hmod + 3, 76, hw - 4, b[1], b[2], b[3], 255 * utils.altuialpha)
            renderer.texture(jg, x - 83, y + 9 + hmod + 4, 76, hw - 6, 255, 255, 255, 255 * utils.altuialpha, "r")
        elseif ishovered[k] then
            color = use_custom_colors and {ui.get(tabs["Visuals"].altui_icon_colors[7])} or {167, 167, 167, 255}
        end
        local cw, ch = renderer.measure_text("+d", v)
        renderer.text(x - 84 + 36, y + 7 + hmod + hw*0.5, color[1], color[2], color[3], 255 * utils.altuialpha, "c+d", 0, v)
        hmod = hmod + hw*0.95
    end
end
--region @misc
utils.normalize_yaw = function(yaw)
    return (yaw + 180) % 360 - 180
end
misc.fastladder = function(cmd)
    if not ui.get(tabs["Misc"].fastladder[1]) then return end
    local lplayer = entity.get_local_player()
	if lplayer == nil then return end
    if entity.get_prop(lplayer, "m_MoveType") == 9 then 
        local forward = vector(entity.get_prop(lplayer, "m_vecLadderNormal"));
        if forward:lengthsqr() == 0 then return end

        local view = vector(client.camera_angles())
        local angle = vector(forward:angles())

        local delta_yaw = angle.y - view.y + 180
        local delta_pitch = angle.x - view.x

        delta_yaw = utils.normalize_yaw(delta_yaw)
        delta_pitch = utils.clamp(delta_pitch, -89, 89)

        local abs_yaw = math.abs(delta_yaw)

        local pitch = 89
        local yaw_offset = -90

        local is_looking_down = delta_pitch < -45
        local is_looking_to_right = delta_yaw > 0

        local is_sidemove = cmd.sidemove > 0
        local is_forwardmove = cmd.forwardmove > 0

            -- sideways
        if abs_yaw > 70 and abs_yaw < 135 then
            if cmd.forwardmove ~= 0 or cmd.sidemove == 0 then
                return;
            end

            if not is_looking_to_right then
                yaw_offset = -yaw_offset
            end

            if is_looking_to_right then
                is_sidemove = not is_sidemove
            end

            cmd.in_back = is_sidemove and 1 or 0
            cmd.in_forward = is_sidemove and 0 or 1

            if is_looking_to_right then
                is_sidemove = not is_sidemove
            end

            cmd.in_moveleft = is_sidemove and 1 or 0
            cmd.in_moveright = is_sidemove and 0 or 1

            cmd.pitch = pitch
            cmd.yaw = utils.normalize_yaw(angle.y + yaw_offset)

            return
        end

            -- straight
        if cmd.sidemove ~= 0 or cmd.forwardmove == 0 then
            return
        end

        if not is_looking_to_right then
            yaw_offset = -yaw_offset
        end

        if not is_looking_down then
            is_forwardmove = not is_forwardmove
        end

        cmd.in_back = is_forwardmove and 0 or 1
        cmd.in_forward = is_forwardmove and 1 or 0

        if not is_looking_to_right then
            is_forwardmove = not is_forwardmove
        end

        cmd.in_moveleft = is_forwardmove and 1 or 0
        cmd.in_moveright = is_forwardmove and 0 or 1

        cmd.pitch = pitch
        cmd.yaw = utils.normalize_yaw(angle.y + yaw_offset)
    end
end
misc.clantags = {
    "osmanhook",
    "osmanhoo",
    "osmanho",
    "osmanh",
    "osman",
    "osma",
    "osm",
    "os",
    "o",
    "os",
    "osm",
    "osma",
    "osman",
    "osmanh",
    "osmanho",
    "osmanhoo",
    "osmanhook",
}

misc.animtag = function()
    local tickcount = globals.tickcount() + toticks(client.latency())
    local i = tickcount / toticks(0.5)
    i = math.floor(i % #misc.clantags+1)
    return misc.clantags[i]
end
misc.tagspam_prev = false
misc.onpaint_tag = function(reset)
    if reset and misc.tagspam_prev then client.set_clan_tag("\0") return end
    if ui.get(tabs["Misc"].tagspamer[1]) then 
        if entity.get_prop(entity.get_game_rules(), "m_gamePhase") == 5 then client.set_clan_tag(misc.clantags[1]) return end
        local lplayer = entity.get_local_player()
        if lplayer ~= nil and not entity.is_alive(lplayer) and globals.tickcount() % 2 == 0 then
            client.set_clan_tag(misc.animtag())
        end
    elseif misc.tagspam_prev then
        client.set_clan_tag("\0")
    end
    misc.tagspam_prev = ui.get(tabs["Misc"].tagspamer[1])
end
misc.clantag_tick = 0
misc.onrun_tag = function(cmd)
    if not ui.get(tabs["Misc"].tagspamer[1]) then return end
    if entity.get_prop(entity.get_game_rules(), "m_gamePhase") == 5 then client.set_clan_tag(misc.clantags[1]) return end
    
    -- 16 ticks
    misc.clantag_tick = misc.clantag_tick + 1
    if misc.clantag_tick >= 16 then
        misc.clantag_tick = 0
        client.set_clan_tag(misc.animtag())
    end
end
misc.isinduck = false
misc.isinjump = false
misc.globalstates = function(cmd)
    misc.isinduck = cmd.in_duck == 1
    misc.isinjump = cmd.in_jump == 1
end
misc.acts = {
    ["AIM_MATRIX"] = {
        ["RESET"] = 0,
        ["TPOSE"] = 11,
        ["SELFKILL"] = 59,
        ["PIANO"] = 61,
        ["KNIFE_AFTER_TAB"] = 168,
        ["BACKHAND"] = 200,
        ["DEFUSING"] = 220,
        ["FLASHBANG_LIGHT"] = 224,
        ["FLASHBANG_MASSIVE"] = 225,
        ["SLOWDOWN"] = 255,
    },
    ["WEAPON_ACTION"] = {
        ["ENDGAME_POSE"] = 10,
        ["AEROBIC"] = 11,
        ["DEAGLE_SWITCH"] = 35,
        ["AK47_SWITCH"] = 37,
        ["SCOUT_SWITCH"] = 43,
        ["AK47_SWITCH"] = 52,
        ["SPIN"] = 60,
        ["FAST_RECHARGE"] = 163,
        ["REVERSED_BACKSTAB"] = 190,
        ["NADE_RANGED"] = 204,
        ["FLASHBANG_LIGHT"] = 224,
        ["FLASHBANG_MASSIVE"] = 225,
        ["SURRENDER"] = 232,
        ["KNEES"] = 262
    },
    ["MOVEMENT_MOVE"] = {
        ["ENDGAME_POSE"] = 10,
        ["CHAOS"] = 11,
        ["STAIRS"] = 13,
        ["SQUATS"] = 22,
        ["DEAGLE_SWITCH"] = 35,
        ["AK47_SWITCH"] = 37,
        ["SCOUT_SWITCH"] = 43,
        ["R8_SWITCH"] = 60,
        ["SILENCER_ON_USP"] = 100,
        ["RECHARGE_AUG"] = 114,
        ["SILENCER_OFF_M4"] = 115,
        ["KNIFE_TAB"] = 187,
        ["KNIFE_BACKSTAB"] = 190,
        ["DEFUSING"] = 220,
        ["C4_PLANT"] = 223,
        ["FLASHBANG_LIGHT"] = 224,
        ["FLASHBANG_MASSIVE"] = 225,
        ["SURRENDER"] = 232,
        ["KNEES"] = 262
    }
}
misc.animfucks = {
    ["Crab"] = {0.8, 7, "Never slide"},
    ["Static Legs"] = {1, 6},
    ["Zero Pitch"] = {0.5, 12},
    ["Allah"] = {0, 7, "Never slide"},
    ["Forwards"] = {0.5, 0, "Always slide"},
    ["Backwards"] = {1, 0, "Always slide"},
    ["Static"] = {6, 0, misc.acts["AIM_MATRIX"]["RESET"]},
    ["Old Fall"] = {4, 1},
    ["T-Pose"] = {12, misc.acts["AIM_MATRIX"]["TPOSE"]},
    ["Slowmo"] = {11, misc.acts["AIM_MATRIX"]["SLOWDOWN"]},
    ["Flashed"] = {0, misc.acts["AIM_MATRIX"]["FLASHBANG_LIGHT"]},
    ["Piano"] = {0, misc.acts["AIM_MATRIX"]["PIANO"]},
}
misc.animfuck = function()
    if not ui.get(tabs["Misc"].animbreak[1]) then return end
    local lplayer = entity.get_local_player()
    if lplayer == nil then return end
    if not entity.is_alive(lplayer) then return end
    local self_index = c_entity.new(lplayer)
    local self_anim_state = self_index:get_anim_state()
    if not self_anim_state then return end
    local self_anim_overlay = self_index:get_anim_overlay(6)
    local self_anim_overlay_lean = self_index:get_anim_overlay(12)
    local air_sel = ui.get(tabs["Misc"].animbreak[3])
    local ground_sel = ui.get(tabs["Misc"].animbreak[4])
    local move_sel = ui.get(tabs["Misc"].animbreak[5])
    local seq_cond = ui.get(tabs["Misc"].animbreak[7])
    local add_fuck = self_index:get_anim_overlay(misc.animfucks[seq_cond][1])
    if move_sel == "Full Lean" then
        self_anim_overlay_lean.weight = 1
    elseif move_sel == "No Lean" then
        self_anim_overlay_lean.weight = 0
    elseif move_sel == "Earthquake" then
        self_anim_overlay_lean.weight = client.random_float(0, 1)
    end
    if self_anim_state.on_ground and not misc.isinjump then
        if ui.get(tabs["Misc"].animbreak[2]) then
            if self_anim_state.hit_in_ground_animation and self_anim_state.head_from_ground_distance_standing < 1 then
                entity.set_prop(lplayer, "m_flPoseParameter", misc.animfucks["Zero Pitch"][1], misc.animfucks["Zero Pitch"][2])
            end
        end
        if utils.multi_parse(tabs["Misc"].animbreak[6], "Ground") then
            add_fuck.weight = 1
            add_fuck.sequence = misc.animfucks[seq_cond][2]
        end
        if not utils.combo_parse(ground_sel, "Disabled") then
            if utils.combo_parse(ground_sel, "Static", "T-Pose", "Slowmo") then
                ui.set(skeetgui.aagui.other.leg_movement, "Off")
                local groundfuck = self_index:get_anim_overlay(misc.animfucks[ground_sel][1])
                if misc.isinduck and utils.combo_parse(ground_sel, "T-Pose", "Slowmo") then return end
                if ground_sel ~= "Slowmo" then
                    groundfuck.weight = 1
                else
                    if ui.get(skeetgui.ragegui.other.duck_peek_assist) then return end -- slowmo fix
                    groundfuck.weight = (ground_sel == "Slowmo" and self_anim_state.m_velocity > 3) and 1 or 0
                end
                groundfuck.sequence = misc.animfucks[ground_sel][2]
            elseif utils.combo_parse(ground_sel, "Jitter") then
                entity.set_prop(lplayer, 'm_flPoseParameter', 1, globals.tickcount() % 4 > 1 and 0.5 or 1)
            elseif utils.combo_parse(ground_sel, "Jitter v2") then
                ui.set(skeetgui.aagui.other.leg_movement, "Always slide")
                entity.set_prop(lplayer, 'm_flPoseParameter', 0, globals.tickcount() % 6 >= 3 and 0.5 or 1)
            else 
                ui.set(skeetgui.aagui.other.leg_movement, misc.animfucks[ground_sel][3])
                entity.set_prop(lplayer, "m_flPoseParameter", misc.animfucks[ground_sel][1], misc.animfucks[ground_sel][2])
            end
        end
    else
        if utils.multi_parse(tabs["Misc"].animbreak[6], "Air") then
            add_fuck.weight = 1
            add_fuck.sequence = misc.animfucks[seq_cond][2]
        end
        if air_sel ~= "Disabled" then
            if not utils.combo_parse(air_sel, "Static Legs", "Jitter", "Old Fall") then
                self_anim_overlay.weight = 1
            end
            if utils.combo_parse(air_sel, "T-Pose", "Slowmo") then
                ui.set(skeetgui.aagui.other.leg_movement, "Off")
                local air_fuck = self_index:get_anim_overlay(misc.animfucks[air_sel][1])
                air_fuck.weight = 1
                air_fuck.sequence = misc.animfucks[air_sel][2]
            elseif not utils.combo_parse(air_sel, "Ground Animlayer", "Jitter", "Old Fall") then
                entity.set_prop(lplayer, "m_flPoseParameter", misc.animfucks[air_sel][1], misc.animfucks[air_sel][2])
            elseif air_sel == "Old Fall" then
                local air_fuck = self_index:get_anim_overlay(misc.animfucks[air_sel][1])
                air_fuck.cycle = misc.animfucks[air_sel][2]
            elseif air_sel == "Jitter" then
                entity.set_prop(lplayer, "m_flPoseParameter", client.random_float(0, 1), 6)
            end
        end
    end
end
misc.jitterfuck = function(cmd)
    if not ui.get(tabs["Misc"].animbreak[1]) then return end
    local lplayer = entity.get_local_player()
    if lplayer == nil then return end
    if utils.combo_parse(ui.get(tabs["Misc"].animbreak[4]), "Jitter") then
        ui.set(skeetgui.aagui.other.leg_movement, cmd.command_number % 3 == 0 and 'Off' or 'Always slide')
    end
end
misc.modify = 5
misc.cycs = 646
misc.dumbfuck = function()
    if not ui.get(tabs["Misc"].dumbass_features[1]) then return end
    local lplayer = entity.get_local_player()
    if lplayer == nil or not entity.is_alive(lplayer) then return end
    local self_index = c_entity.new(lplayer)
    local gamerules = entity.get_game_rules()
    local isfreezetime = entity.get_prop(gamerules, "m_bFreezePeriod") == 1
    if ui.get(tabs["Misc"].dumbass_features[2]) == "Push-Ups" and (utils.multi_parse(tabs["Misc"].dumbass_features[3], "No enemy") and rage.isnoenemy or utils.multi_parse(tabs["Misc"].dumbass_features[3], "Freezetime") and isfreezetime) then 
        local self_anim_overlay = self_index:get_anim_overlay(11)
        self_anim_overlay.weight = 1
        self_anim_overlay.sequence = 232
        self_anim_overlay.cycle = misc.cycs*0.001
        misc.cycs = misc.cycs + misc.modify
        misc.modify = (misc.cycs >= 730 or misc.cycs <= 646) and -misc.modify or misc.modify
    end
end
misc.aspect_change = function(reset)
    local ratio_slider = ui.get(tabs["Misc"].aspectratio[2])*0.01
    ratio_slider = 2 - ratio_slider
    local screen = utils.get_screen()
    local aspect_value = (screen.x*ratio_slider)/screen.y
    if ratio_slider == 1 then
		aspect_value = 0
	end
    if reset then aspect_value = 0 end
    client.set_cvar("r_aspectratio", tonumber(aspect_value))
end
ui.set_callback(tabs["Misc"].aspectratio[1], function(id)
    if ui.get(id) then
        client.set_event_callback("paint", misc.aspect_change)
    else
        client.unset_event_callback("paint", misc.aspect_change)
        misc.aspect_change(true)
    end
end)
misc.tpdist = function(reset)
    if reset then
        cvar.c_mindistance:set_int(cvardef.def_tdist)
        cvar.c_maxdistance:set_int(cvardef.def_tdist)
        return
    end
    cvar.c_mindistance:set_int(ui.get(tabs["Misc"].tperson[2]))
    cvar.c_maxdistance:set_int(ui.get(tabs["Misc"].tperson[2]))
end
ui.set_callback(tabs["Misc"].tperson[1], function(id)
    if ui.get(id) then
        client.set_event_callback("paint", misc.tpdist)
    else
        client.unset_event_callback("paint", misc.tpdist)
        misc.tpdist(true)
    end
end)
misc.viewmod = function(reset)
    if not ui.get(tabs["Misc"].viewmodel[1]) then return end
    local cvar_fov = cvar.viewmodel_fov
    local cvar_offset_x = cvar.viewmodel_offset_x
    local cvar_offset_y = cvar.viewmodel_offset_y 
    local cvar_offset_z = cvar.viewmodel_offset_z
    local fov, x, y, z
    if reset then
        fov = cvardef.default_view[1]
        x = cvardef.default_view[2]
        y = cvardef.default_view[3]
        z = cvardef.default_view[4]
        cvar_fov:set_raw_float(fov)
        cvar_offset_x:set_raw_float(x)
        cvar_offset_y:set_raw_float(y)
        cvar_offset_z:set_raw_float(z)
        return
    end
    fov = ui.get(tabs["Misc"].viewmodel[2])*0.1
    x = ui.get(tabs["Misc"].viewmodel[3])*0.1
    y = ui.get(tabs["Misc"].viewmodel[4])*0.1
    z = ui.get(tabs["Misc"].viewmodel[5])*0.1
    cvar_fov:set_raw_float(fov) 
    cvar_offset_x:set_raw_float(x)
    cvar_offset_y:set_raw_float(y)
    cvar_offset_z:set_raw_float(z)
end
ui.set_callback(tabs["Misc"].viewmodel[1], function(id)
    if ui.get(id) then
        client.set_event_callback("paint", misc.viewmod)
    else
        client.unset_event_callback("paint", misc.viewmod)
        misc.viewmod(true)
    end
end)
misc.scalemodel = function(reset)
    local lplayer = entity.get_local_player()
    if lplayer == nil then return end
    local scale = ui.get(tabs["Misc"].ducarigym[2]) * 0.01
    if reset then scale = 1 end
    entity.set_prop(lplayer, "m_flModelScale", scale, 0)
end
ui.set_callback(tabs["Misc"].ducarigym[1], function(id)
    if ui.get(id) then
        client.set_event_callback("pre_render", misc.scalemodel)
    else
        client.unset_event_callback("pre_render", misc.scalemodel)
        misc.scalemodel(true)
    end
end)
misc.chamscol = {ui.get(skeetgui.visualgui.colored_models.local_chams[2])}

ui.set_callback(skeetgui.visualgui.colored_models.local_chams[2], function(id)
    misc.chamscol = {ui.get(id)}
end)
misc.scopetransp = function(reset)
    local lplayer = entity.get_local_player()
    if lplayer == nil or not entity.is_alive(lplayer) then return end
    local chams_enable = ui.get(skeetgui.visualgui.colored_models.local_chams[1])
    local chams_type = ui.get(skeetgui.visualgui.colored_models.local_chams[3])
    local iscoped = (entity.get_prop(lplayer, "m_bIsScoped") == 1 or entity.get_prop(lplayer, "m_bResumeZoom") == 1) and utils.multi_parse(tabs["Misc"].transcope[2], "Scoped")
    local isgranade = rage.weapon ~= nil and (string.match(rage.weapon, "Grenade") or rage.weapon == "CFlashbang") and utils.multi_parse(tabs["Misc"].transcope[2], "Grenade") --stupid valve named flash granade CFlashbang instead of CFlashGrenade
    local alpha = misc.chamscol[4]
    local factor = ui.get(tabs["Misc"].transcope[3])*0.01
    --local weapon = entity.get_player_weapon(lplayer)
    --local weapon_model = entity.get_prop(weapon, "m_hWeaponWorldModel")
    --local weapon_model2 = entity.get_prop(lplayer, "m_hViewModel[0]")
    local material = materialsystem.get_model_materials(lplayer)
    if reset then
        if chams_enable then
            ui.set(skeetgui.visualgui.colored_models.local_chams[2], misc.chamscol[1], misc.chamscol[2], misc.chamscol[3], misc.chamscol[4])
        else
            for _, v in pairs(material) do
                v:alpha_modulate(255)
            end
        end
        return
    end
    if iscoped or isgranade then
        if chams_enable then
            ui.set(skeetgui.visualgui.colored_models.local_chams[2], misc.chamscol[1], misc.chamscol[2], misc.chamscol[3], alpha*factor)
        else
            for _, v in pairs(material) do 
                v:alpha_modulate(255*factor)
            end
        end
    else
        if chams_enable then
            ui.set(skeetgui.visualgui.colored_models.local_chams[2], misc.chamscol[1], misc.chamscol[2], misc.chamscol[3], alpha)
        else
            for _, v in pairs(material) do 
                v:alpha_modulate(255)
            end
        end
    end
end
ui.set_callback(tabs["Misc"].transcope[1], function(id)
    if ui.get(id) then
        client.set_event_callback("pre_render", misc.scopetransp)
    else
        client.unset_event_callback("pre_render", misc.scopetransp)
        misc.scopetransp(true)
    end
end)
--region @logger
logs.hitboxes = {
    [0] = "generic",
    [1] = "head",
    [2] = "chest",
    [3] = "stomach",
    [4] = "left arm",
    [5] = "right arm",
    [6] = "left leg",
    [7] = "right leg",
    [8] = "neck",
    [9] = "?",
    [10] = "gear"
}
utils.rgb_to_hex = function(color)
    return string.format("%02X%02X%02X%02X", color[1], color[2], color[3], color[4] or 255)
end
utils.rgb_to_archex = function(color)
    return string.format("%02X%02X%02X", color[1], color[2], color[3])
end
logs.printl = function(...)
    args = {...}
    for i=1, #args, 1 do
        arg = args[i]
        seg_col, segment = unpack(arg)
        if #args > i then
            segment = segment..'\0'
        end
        client.color_log(seg_col[1], seg_col[2], seg_col[3], segment)
    end
end
logs.get_safety = function(aim_data, target)
	local has_been_boosted = aim_data.boosted
	local plist_safety = plist.get(target, 'Override safe point')
	local ui_safety = { ui.get(skeetgui.ragegui.aimbot.prefer_safe_point), ui.get(skeetgui.ragegui.aimbot.force_safe_point) or plist_safety == 'On' }

	if not has_been_boosted then
		return "off"
	end

	if plist_safety == 'Off' or not (ui_safety[1] or ui_safety[2]) then
		return "off"
	end

	return ui_safety[2] and "force" or (ui_safety[1] and "prefer" or "false")
end

logs.gen_flags = function(flags)
    res = {}
    for i=1, #flags, 1 do
        if flags[i] ~= "" then
            table.insert(res, flags[i])
        end
    end
    return res
end
logs.screen_info = {}
logs.on_fire = function(e)
    if not ui.get(tabs["Misc"].logs[1]) then return end
    local lplayer = entity.get_local_player()
    local p_ent = e.target

	logs[e.id] = {
		original = e,
		dropped_packets = { },

		handle_time = globals.realtime(),
		self_choke = globals.chokedcommands(),

		flags = {
            e.teleported and "Teleported" or "",
            e.interpolated and "Interpolated" or "",
            e.extrapolated and "Extrapolated" or "",
            e.boosted and "Boosted" or "",
            e.high_priority and "High Priority" or ""
		},

		feet_yaw = entity.get_prop(p_ent, 'm_flPoseParameter', 11)*120-60,
		correction = plist.get(p_ent, 'Correction active'),

		safety = logs.get_safety(e, p_ent),
		shot_pos = vector(e.x, e.y, e.z),
		eye = vector(client.eye_position()),
		view = vector(client.camera_angles()),

		velocity_modifier = entity.get_prop(lplayer, 'm_flVelocityModifier'),
		total_hits = entity.get_prop(lplayer, 'm_totalHitsOnServer'),
		history = globals.tickcount() - e.tick > 0 and tostring(globals.tickcount() - e.tick).."t" or "predicted"
	}
    local info = 
    {
        name = entity.get_player_name(e.target),
        flags = string.format('%s', table.concat(logs.gen_flags(logs[e.id].flags), " | ")),
        aimed_hitgroup = logs.hitboxes[logs[e.id].original.hitgroup] or '?',
        aimed_hitchance = string.format('%d%%', math.floor(logs[e.id].original.hit_chance + 0.5)),
        correction = {string.format("%s", logs[e.id].correction and "on" or "off"), (logs[e.id].feet_yaw < 10 and logs[e.id].feet_yaw > -10) and 0 or logs[e.id].feet_yaw},
    }
    if utils.multi_parse(tabs["Misc"].logs[2], "Console") and utils.multi_parse(tabs["Misc"].logs[3], "On Fire") then
        logs.printl(
            {colors.dark_gray, "[?] "},
            {colors.gray, "fired at "},
            {colors.dark_gray, info.name},
            {colors.gray, "'s "},
            {colors.dark_gray, info.aimed_hitgroup},
            {colors.gray, " (dmg: "},
            {colors.dark_gray, logs[e.id].original.damage},
            {colors.gray, ", bt: " },
            {colors.dark_gray, logs[e.id].history}, 
            {colors.gray, ", hc: "},
            {colors.dark_gray, info.aimed_hitchance},
            {colors.gray, ", res: "}, 
            {colors.dark_gray, info.correction[1]}, 
            {colors.gray, ", °: "},
            {colors.dark_gray, string.format("%d", info.correction[2])}, 
            {colors.gray, ", safe: "},
            {colors.dark_gray, logs[e.id].safety},
            {colors.gray, ")"}
        )
    end
    if utils.multi_parse(tabs["Misc"].logs[2], "Screen") and utils.multi_parse(tabs["Misc"].logs[3], "On Fire") then
        info.alpha = -1
        info.time = globals.realtime() + 3
        info.col = colors.dark_gray
        info.string = {"Fired at ", info.name, "'s ", info.aimed_hitgroup, " for ", logs[e.id].original.damage, " hp hitchance: ", info.aimed_hitchance}
        table.insert(logs.screen_info, 1, info)
    end
end
logs.on_hit = function(e)
    if logs[e.id] == nil then return end
    if not ui.get(tabs["Misc"].logs[1]) then return end
    local info = 
    {
        col = {ui.get(tabs["Misc"].logs[5])},
        type = math.max(0, entity.get_prop(e.target, 'm_iHealth')) > 0,
        name = entity.get_player_name(e.target),
        hitgroup = logs.hitboxes[e.hitgroup] or '?',
        flags = string.format('%s', table.concat(logs.gen_flags(logs[e.id].flags), " | ")),
        aimed_hitgroup = logs.hitboxes[logs[e.id].original.hitgroup] or '?',
        aimed_hitchance = string.format('%d%%', math.floor(logs[e.id].original.hit_chance + 0.5)),
        mismatch = logs.hitboxes[logs[e.id].original.hitgroup] ~= logs.hitboxes[e.hitgroup] or logs[e.id].original.damage ~= e.damage,
        hp = math.max(0, entity.get_prop(e.target, 'm_iHealth')),
        correction = {string.format("%s", logs[e.id].correction and "on" or "off"), (logs[e.id].feet_yaw < 10 and logs[e.id].feet_yaw > -10) and 0 or logs[e.id].feet_yaw},
    }
    --logs.screen = info
    if utils.multi_parse(tabs["Misc"].logs[3], "On Hit") then
        if utils.multi_parse(tabs["Misc"].logs[2], "Console")  then 
            --utils.printr(info.col, '\0')
            logs.printl(
                {info.col, "[+] " --[["["..e.id.."] "]]},
                {colors.gray, info.type and "damaged " or info.mismatch and "mismatched " or "killed "},
                {info.col, info.name},
                {colors.gray, " in "},
                {info.col, info.hitgroup},
                {colors.gray, " ("},
                {colors.gray, info.mismatch and "exp: " or ""},
                {info.col, info.mismatch and string.format("%s-%s", info.aimed_hitgroup, logs[e.id].original.damage) or ""},
                {colors.gray, info.mismatch and ", dmg: " or "dmg: "},
                {info.col, e.damage},
                {colors.gray, ", bt: "},
                {info.col, logs[e.id].history},
                {colors.gray, ", hc: "},
                {info.col, info.aimed_hitchance},
                {colors.gray, ", res: "},
                {info.col, info.correction[1]},
                {colors.gray, ", °: "},
                {info.col, string.format("%d", info.correction[2])},
                {colors.gray, ", safe: "},
                {info.col, logs[e.id].safety},
                {colors.gray, ")"}
            )
        end
 
    end
end
logs.on_miss = function(e)
    if not ui.get(tabs["Misc"].logs[1]) then return end
    local lplayer = entity.get_local_player()
    local info = 
    {
        col = {ui.get(tabs["Misc"].logs[7])},
        name = entity.get_player_name(e.target),
        hitgroup = logs.hitboxes[e.hitgroup] or '?',
        flags = string.format('%s', table.concat(logs.gen_flags(logs[e.id].flags), " | ")),
        aimed_hitgroup = logs.hitboxes[logs[e.id].original.hitgroup] or '?',
        aimed_hitchance = string.format('%d%%', math.floor(logs[e.id].original.hit_chance + 0.5)),
        hp = math.max(0, entity.get_prop(e.target, 'm_iHealth')),
        reason = e.reason,
        correction = {string.format("%s", logs[e.id].correction and "on" or "off"), (logs[e.id].feet_yaw < 10 and logs[e.id].feet_yaw > -10) and 0 or logs[e.id].feet_yaw},
        dmg = logs[e.id].original.damage,
    }
    if info.reason == '?' then
        info.reason = "correction"
        if logs[e.id].total_hits ~= entity.get_prop(lplayer, 'm_totalHitsOnServer') then
            info.reason = 'damage rejection';
        end
    end
    if utils.multi_parse(tabs["Misc"].logs[3], "On Miss") then
        if utils.multi_parse(tabs["Misc"].logs[2], "Console") then
            --utils.printr(info.col, '\0')
            logs.printl(
                {info.col, "[-] "}, 
                {colors.gray, "missed at "}, 
                {info.col, info.name}, 
                {colors.gray, "'s "},
                {info.col, info.hitgroup},
                {colors.gray, " (reason: "},
                {info.col, info.reason},
                {colors.gray, ", dmg: "},
                {info.col, info.dmg},
                {colors.gray, ", bt: "},
                {info.col, logs[e.id].history}, 
                {colors.gray, ", hc: "}, 
                {info.col, info.aimed_hitchance},
                {colors.gray, ", res: "},
                {info.col, info.correction[1]}, 
                {colors.gray, ", °: "},
                {info.col, string.format("%d", info.correction[2])}, 
                {colors.gray, ", safe: "}, 
                {info.col, logs[e.id].safety},
                {colors.gray, ")"}
            )
        end
    end
end
logs.on_hurt = function(e)
    if not ui.get(tabs["Misc"].logs[1]) then return end
    local lplayer = entity.get_local_player()
    if client.userid_to_entindex(e.userid) ~= lplayer or client.userid_to_entindex(e.attacker) == lplayer then return end
    local info = 
    {
        col = {ui.get(tabs["Misc"].logs[9])},
        name = entity.get_player_name(client.userid_to_entindex(e.attacker)),
        hitgroup = logs.hitboxes[e.hitgroup] or '?',
        dmg = e.dmg_health,
    }
    if info.name == "unknown" and client.userid_to_entindex(e.attacker) == 0 then info.name = "world" end
    if utils.multi_parse(tabs["Misc"].logs[3], "On Hurt") then
        if utils.multi_parse(tabs["Misc"].logs[2], "Console") then
            --utils.printr(info.col, '\0')
            logs.printl(
                {info.col, "[!] "}, 
                {colors.gray, "taken damage from "}, 
                {info.col, info.name}, 
                {colors.gray, " in "},
                {info.col, info.hitgroup},
                {colors.gray, " (dmg: "},
                {info.col, info.dmg},
                {colors.gray, ")"}
            )
        end
    end
end
logs.hittype = {knife = 'Knifed ', inferno = 'Burned ', hegrenade = 'Naded '}
logs.hurthit = function(e)
    if not ui.get(tabs["Misc"].logs[1]) then return end
    local lplayer = entity.get_local_player()
    local attacker = client.userid_to_entindex(e.attacker)
    local target = client.userid_to_entindex(e.userid)
    if target == lplayer or attacker ~= lplayer then return end
    local info = 
    {
        col = {ui.get(tabs["Misc"].logs[5])},
        type = e.health > 0,
        name = entity.get_player_name(target),
        hitgroup = logs.hitboxes[e.hitgroup] or '?',
        hp = e.health,
        damage = e.dmg_health
    }
    if utils.multi_parse(tabs["Misc"].logs[2], "Screen") and utils.multi_parse(tabs["Misc"].logs[3], "On Hit") then
        info.alpha = -1
        info.time = globals.realtime() + 3
        info.string = {logs.hittype[e.weapon] or "Hit ", info.name, info.hitgroup ~= "generic" and " in " or '', info.hitgroup ~= "generic" and info.hitgroup or '', " for ", info.damage, " dmg (",  e.health, " health remaining)"}
        table.insert(logs.screen_info, 1, info)
    end
end
logs.lerp = function(x, v, t)
    local delta = v - x;

    if math.abs(delta) < 0.005 then
        return v
    end

    return x + delta * t
end
logs.screenp = {}
logs.anim = function(key, val, val1, speed, mode)
    logs.screenp[key] = logs.screenp[key] or val
    logs.screenp[key] = mode(utils.lerp(logs.screenp[key], val1, speed))
    return logs.screenp[key]
end
logs.screen_handler = function()
    if not ui.get(tabs["Misc"].logs[1]) or not utils.multi_parse(tabs["Misc"].logs[2], "Screen") then return end
    local lplayer = entity.get_local_player()
    local is_scoped = entity.get_prop(lplayer, "m_bIsScoped") == 1 or entity.get_prop(lplayer, "m_bResumeZoom") == 1
    if lplayer == nil then return end
	local center = {screen.x * 0.5, screen.y * 0.5 + 31}
    local logs_size = #logs.screen_info
    for key = logs_size, 1, -1 do
        local value = logs.screen_info[key]
        if value.alpha == 1 then
            table.remove(logs.screen_info, key)
            goto skip
        end
        local alpha = 1 - math.abs(value.alpha)
        local base_color = { value.col[1], value.col[2], value.col[3], value.col[4] * alpha }

        local base_hex = '\a' .. utils.rgb_to_hex(base_color)
        local alternative = '\a' .. utils.rgb_to_hex({255, 255, 255, 200 * alpha})
        local string = alternative

        for index, text in ipairs(value.string) do
            local temp = text
            if index % 2 == 0 then
                temp = base_hex .. temp .. alternative
            end
            string = string .. temp
        end
        local fullstr = table.concat(value.string, '')
		local w, h = renderer.measure_text('cd', fullstr)
        local x, y = center[1] - w*0.5, center[2] + screen.y*0.2
        if is_scoped then
            x = logs.anim(key, x, center[1] + 50, 0.5, math.ceil)
        else
            x = logs.anim(key, x, center[1] - w*0.5, 0.5, math.floor)
        end
        local gradient = ui.get(tabs["Manipulations"].uistyle[2])
        local style = ui.get(tabs["Manipulations"].uistyle[1])
        if style == "Skeet" then
            renderer.rectangle(x - 20, y-h*0.5+1, w + 40, h*2 + (gradient and 4 or 2), g[1], g[2], g[3], 255*alpha)
            renderer.rectangle(x - 19, y-h*0.5+2, w + 38, h*2 + (gradient and 2 or 0), a[1], a[2], a[3], 255*alpha)
            renderer.rectangle(x - 18, y-h*0.5+3, w + 36, h*2 - (gradient and 0 or 2), b[1], b[2], b[3], 255*alpha)
            renderer.rectangle(x - 16, y-h*0.5+5, w + 32, h*2 - (gradient and 4 or 6), a[1], a[2], a[3], 255*alpha)
            renderer.texture(jg, x - 15, y-h*0.5+6, w + 30, h*2 - (gradient and 6 or 8), 255, 255, 255, 255*alpha, "r")
            if gradient then
                renderer.gradient(x - 14, y-h*0.5+7, w/2 + 15.5, 1, g1[1], g1[2], g1[3], 255*alpha, g2[1], g2[2], g2[3], 255*alpha, true)
                renderer.gradient(x - 14 + w/2 + 15.5, y-h*0.5+7, w/2 + 13, 1, g2[1], g2[2], g2[3], 255*alpha, g3[1], g3[2], g3[3], 255*alpha, true)
                renderer.gradient(x - 14, y-h*0.5+8, w/2 + 15.5, 1, g1[1], g1[2], g1[3], 120*alpha, g2[1], g2[2], g2[3], 120*alpha, true)
                renderer.gradient(x - 14 + w/2 + 15.5, y-h*0.5+8, w/2 + 13, 1, g2[1], g2[2], g2[3], 120*alpha, true)
                renderer.gradient(x - 14, y-h*0.5+9, w/2 + 15.5, 1, g1[1], g1[2], g1[3], 60*alpha, g2[1], g2[2], g2[3], 60*alpha, true)
                renderer.gradient(x - 14 + w/2 + 15.5, y-h*0.5+9, w/2 + 13, 1, g2[1], g2[2], g2[3], 60*alpha, g3[1], g3[2], g3[3], 60*alpha, true)
            end
        elseif style == "晨花" then
            local color = {ui.get(tabs["Manipulations"].uistyle[3])}
            local glow = ui.get(tabs["Manipulations"].uistyle[4])
            if glow then utils.shadow(x - 4, y - 3, w + 6, h*1.5 + 2, 10, 8, {color[1], color[2], color[3], 50 * alpha}, {color[1], color[2], color[3], 50 * alpha}) end
            rounded_rect(x - 2, y - 2, w + 4, h*1.5, color[1], color[2], color[3], color[4] * alpha, 5)
        elseif style == "Methamod" then
            local color = {ui.get(tabs["Manipulations"].uistyle[3])}
            renderer.rectangle(x - 15, y-3, w + 30, h*1.6, 15, 15, 15, color[4]*alpha)
            renderer.rectangle(x - 15, y-3, w + 30, 2, color[1], color[2], color[3], 255*alpha)
        elseif style ~= "Astral" then
            renderer.rectangle(x - 15, y-3, w + 30, h*1.6, 0, 0, 0, math.floor(200*alpha))
        end
		renderer.text(x, y + (style == "Skeet" and (gradient and 3 or 1) or 0), 255, 255, 255, (style == "Methamod" and 255 or 200) * alpha, 'd', 0, string)

        local height = h*2 + (style == "Skeet" and (gradient and 6 or 4) or 0)
        height = height * alpha
        center[2] = center[2] + height
		
        if (globals.realtime() - value.time > 0) or (key > 6) then
            value.alpha = logs.lerp(value.alpha, 1, globals.frametime() * 12)
        else
            value.alpha = logs.lerp(value.alpha, 0, globals.frametime() * 12)
        end

        ::skip::
    end
end
--region @logger end
misc.trashmessages = {
    instant = {
        kill = {
            "𝕚𝕗 𝕚𝕞 𝕝𝕠𝕤𝕖 𝕞𝕪 𝕥𝕖𝕒𝕞𝕞𝕒𝕥𝕖𝕤 𝕒𝕣𝕖 𝕓𝟘𝕥𝕤",
            "𝐁𝐋𝐆𝐎𝐃𝐙.𝐋𝐔𝐀 𝐒𝐀𝐍𝐂𝐇𝐄𝐉𝐙: 𝐈𝐒 𝐓𝐇𝐀𝐓 𝐇𝐕𝐇 𝐁𝐎𝐒𝐒? [𝕠𝕤𝕙𝕠𝕞𝕓𝕣𝕖]",
            "𝕠𝕤𝕞𝕒𝕟𝕙𝕠𝕠𝕜 𝕕𝕖𝕤𝕥𝕣𝕠𝕪𝕤 𝕗𝕣𝕠𝕞 𝕣𝕖𝕝𝕖𝕒𝕤𝕖",
            "𝔻𝕆ℕ𝕋 𝕊𝔸𝕐 𝕆𝕊𝕄𝔸ℕℍ𝕆𝕆𝕂 𝕎ℍ𝔼ℕ 𝕐𝕆𝕌 𝕀𝕊 𝕏[𝕋𝕎𝕀𝕋𝕋𝔼ℝ ℝ𝔼ℕ𝔸𝕄𝔼] 𝕁𝕆𝕀ℕ𝔼ℝ",
            "𝕣𝕚𝕔𝕙 𝕝𝕚𝕗𝕖 𝕤𝕥𝕪𝕝𝕖 #𝓸𝓼𝓶𝓪𝓷𝓱𝓸𝓸𝓴",
            "+/- INTERCEPTED SPREAD SEED FROM SERVER 58/256",
            "𝐢𝐦 𝐰𝐢𝐧 𝐢𝐟 𝐢𝐦 𝐰𝐚𝐧𝐭 𝐭𝐨 𝐰𝐢𝐧 𝐢𝐦 𝐰𝐢𝐧 𝐚𝐥𝐥",
            "𝘪𝘮 𝘥𝘳𝘪𝘯𝘬 𝘢𝘭𝘭 𝘱𝘪𝘭𝘭𝘴 𝘢𝘯𝘥 𝘫𝘈𝘤𝘬 𝘥𝘢𝘯𝘪𝘦𝘭𝘴",
            "ａｎａｔｏｌｙ ｆａｋｅｙａｗ",
            "THIS IS 𝐄𝐗𝐏𝐋𝐎𝐎𝐎𝐎𝐎𝐎𝐎𝐎𝐎𝐈𝐓",
            "https://vk.com/avtopodborkazahstan",
            "𝕐𝕆𝕌 ℍ𝔸𝔻 𝔽𝕌ℕ 𝕌ℕ𝕋𝕀𝕃 𝕀 𝔹𝔸𝕀𝕄𝔼𝔻 𝕐𝕆𝕌",
            "𝕄𝔸𝕐 𝔾𝕆𝔻 𝔹𝕃𝔼𝕊𝕊 𝕄𝔼 𝕋𝕆 𝕎𝕀ℕ ℍ𝕍ℍ",
            "𝗜𝗙 𝗬𝗢𝗨 𝗕𝗔𝗜𝗠 𝗣𝗜𝗟𝗢𝗧 𝗖𝗥𝗔𝗦𝗛 𝗛𝗜𝗦 𝗣𝗟𝗔𝗡𝗘",
            "っ◔◡◔)っ 𝐸𝒵",
            "𝐄𝐍𝐉𝐎𝐘 𝐓𝐇𝐈𝐒 𝐃𝐃𝐎$$",
            "𝔾𝕝𝕠𝕓𝕒𝕝 𝕚𝕟 𝕄𝕄? ℕ𝕠! 𝕆𝕟 𝔼𝕩𝕡𝕚𝕕𝕠𝕣𝕤.ℝ𝕌",
            "𝙬𝙬𝙬.𝙘𝙪𝙩𝙚𝙞𝙣𝙩𝙚𝙧𝙣𝙚𝙩.𝙘𝙤𝙢",
            "𝐎𝐒𝐌𝐀𝐍𝐇𝐎𝐎𝐊 𝐌𝐄𝐈𝐍 𝐆𝐀𝐍𝐆 𝐕𝐒 𝐓𝐇𝐄 𝐖𝐎𝐑𝐋𝐃",
            "𝐄𝐈𝐓𝐇𝐄𝐑 𝐈 𝐖𝐀𝐋𝐊 𝐋𝐈𝐊𝐄 𝐀 𝐊𝐈𝐍𝐆 𝐎𝐑 𝐈 𝐃𝐎𝐍𝐓 𝐆𝐈𝐕𝐄 𝐀 𝐅𝐔𝐂𝐊 𝐖𝐇𝐎 𝐓𝐇𝐄 𝐊𝐈𝐍𝐆 𝐈𝐒",
            "ｈｔｔｐｓ://ｔ.ｍｅ/ｄｅｇｉｓｉｋｄｕｓｕｎｃｅｌｅｒｉｍ",
            "𝔸𝕃𝕃 𝔻𝕆𝔾𝕊 𝕃𝕆𝕊𝔼 𝕋𝕆 𝕆𝕊𝕄𝔸ℕℍ𝕆𝕆𝕂",
            "ｓｑｌ ｉｎｊｅｃｔｉｏｎ",
            "𝒏𝒐 𝒎𝒐𝒏𝒆𝒚 𝒇𝒐𝒓 𝒔𝒖𝒃 𝒔𝒐 𝒊𝒎 𝒅𝒖𝒑𝒆 𝒎𝒚 𝒅𝒓𝒂𝒈𝒐𝒏 𝒍𝒐𝒓𝒆",
            "𝙬𝙩𝙛 #𝘽𝙔𝙋𝘼𝙎𝙎",
            "Ａｎｄｒｅｗ Ｔａｔｅ Ｐｌａｙｓｔｙｌｅ",
            "ｔｕｒｋｉｓｈ ａｎｔｉ ａｉｍ ｔｅｃｈｎｏａｌａｇｙ ◣_◢",
            "I am ♛ you noob",
            "𝐦𝐞𝐦𝐛𝐞𝐫 𝐰𝐚𝐧𝐭 𝐩𝟏𝟎𝟎 𝐫𝐞𝐬𝐨𝐥𝐯𝐞𝐫 𝐢 𝐚𝐦 𝐬𝐚𝐲 𝐨𝐤",
            "𝙼𝚈 𝙱𝙾𝚃𝙽𝙴𝚃 𝙳𝙾𝙴𝚂𝙽𝚃 𝙲𝙰𝚁𝙴 𝙰𝙱𝙾𝚄𝚃 𝚈𝙾𝚄𝚁 𝙵𝙴𝙴𝙻𝙸𝙽𝙶𝚂",
            "(◣◢) osmanhook has always been and always will be the greatest lua of all time (◣◢)",
            "𝙤𝙨𝙢𝙖𝙣𝙝𝙤𝙤𝙠 𝕕𝕠𝕟𝕥 𝕟𝕖𝕖𝕕 𝕦𝕡𝕕𝕒𝕥 𝕕𝕠𝕘𝕤 𝕛𝕦𝕤𝕥 𝕓𝕒𝕕( ◣_◢ )",
            "♛osmanhook♛.CFG injecting",
            "♛ Ｆａｍｉｌｙ ｉｎ ｏｓｍａｎｈｏｏｋ♛",
            "𝕞𝕪 𝕣𝕖𝕝𝕚𝕘𝕚𝕠𝕟... 𝕠𝕤𝕞𝕒𝕟~𝕘𝕤. 𝔸𝕤-𝕊𝕒𝕝𝕒𝕞𝕦 𝔸𝕝𝕒𝕚𝕜𝕦𝕞 𝕨𝕒 ℝ𝕒𝕙𝕞𝕒𝕥𝕦𝕝𝕝𝕒𝕙",
            "çŤᵱẮχ çŤᵱẮχ çŤᵱẮχ çŤᵱẮχ çŤᵱẮχ çŤᵱẮχ",
            "Следующая остановка – голова",
            "ᵗᵠ ᵉᵇᵃⁿᵘˡˢʸᵃ?",
            "!!!!ОР ВЫШЕ ГОР!!!!",
            "-===≡≡≡( ͝° ͜ʖ͡°) сперма летит тебе в FACE",
            "(っ´ཀ`)っ  ⋃  соси!!1",
            "★А мНе ВсЁ пОфИг★",
            "ОРЕЛ-КАВКАЗА ЛЕТИТ ВЕРШИТЬ СУДЬБУ",
            "•ЯАШОТТЕБЕ~ХЭДШОТ•",
            "Ð•Ē•M•Ø•Ŋ KILLED YOU",
            "•Я_tOT_komy_HaBce||OX•",
            "༼ つ ◕_◕ ༽つ {лежи ннчик}",
            "4iTeRoc_Ha_SeRvErE",
            "ЂΣƊOŁ∆G∆",
            "АхТы?НеГодЯй!",
            "-n๏ȼąȼέʍȼя?",
            "OSMAN.TECH RELEASE ACTIVATED ....",
            "$name EB@NYHKA S CHITOM",
            "给这个亚洲人吹箫",
            "R ẴℕGỄŁ ༗ EбЛӥ",
            "ω ешь мои яйца",
            "تSøsŸ xYЙ",
            "8===D    ●",
            "(ര ‿ ര ) ⋃ ",
            "CFG BY ILYATRAXER",
            "VIP пуля от меня",
            "Я _MaTЬ_ ПyTuHa А Тbl Л0}{",
            "отдамся за 5 рублей",
            "royal hack owned",
            "ннчик лег",
            "эй бро у меня есть osmanhook.lua тебе дать?",
            "*DEAD* зафикси нищи ублюдок",
            "бро имажин ресолвинг ин гмод",
            "ПоСтоРониСь БаТя С КаЛаШоМ ИдЁт",
            "Лицом к стене! Это приказ, 1...2...3...",
            "найс паста мемевара",
            "[~оСтОрОжНо Я кУсАюСь~]",
            "(   ͜.人   ͜.)",
            "авхаыхаыхыах ну ты и упал прикольно",
            "аим включи уебище))",
            "*DEAD* пофикси нищ",
            "кринжаниум не вывез exec",
            "ХeT_SHОТ_ОТ BABKI",
            "LOOOOOOOL KEK $name остался без бошки xDDDDDDDDDDDDDDDDDDD",
            "⋃ PÉNIS¹4⁸⁸",
            "что у тебя за говночит? $name",
            "给这个亚洲人吹箫",
            "$name обоссан"
        },
        death = {
            "nice play dude",
            "you're a strong player",
            "nah go away",
            "look at him",
            "killed, enjoy while you can",
            "did your dad teach you to play?",
        },
        killer_death = {
            "one noob",
            "finally you died",
            "1",
            "and this killed me",
            "trash already died",
        },
    },
    sentence = {
        kill = {
            {1, "don't worry", 3, "next time your aim will work", 5, "shameful noob"},
            {1, "calm down dude", 4, "today you can limit yourself", 7, "yesterday you scratched me with your teeth"},
            {1, "hey people", 3, "buy osmanhook lua", 5, "but it's private"},
            {2, "you really got hit in the face", 4, "your beads are on the floor"},
            {1, "robinson for me", 3, "or robinovich", 5, "damn forgot"},
            {1, "what about whiskey cola", 3, "were you at school today kid?"},
            {1, "don't be sour friend", 4, "they knocked off your cap", 6, "it happens"},
            {3, "twennysixster hvh i smoke huge", 6, "on me now bitch sucks"},
            {1, "1e", 2, "1\\", 3, "1`", 5, "damn go away"},
        },
        death = {
            {1, "what is he doing", 3, "stupid die already", 4, "scum"},
            {2, "bro you're really a player", 4, "no wait, that was luck"},
            {2, "you're done for me kudinov will backup", 5, "now everyone lies face down", 8, "king of swat in action"},
            {1, "what a great day", 3, "did dad bring vodka already?"},
            {2, "go do homework whore", 4, "why are you sitting here"},
            {1, "today in good vibes...", 4, "fucked your mom triple"},
        },
        killer_death = {
            {1, "hahaha", 2, "1 trash"},
            {2, "how did you kill me", 4, "weak bot"},
            {1, "1", 2, "noob"},
            {2, "this is what killed me", 4, "1 shameful"},
            {1, "what a shame", 3, "how did you kill me at all"},
        },
    },
}
misc.killer = nil
misc.trashmsg = function(e)
    if not ui.get(tabs["Misc"].trashtalk[1]) then return end
    local lplayer = entity.get_local_player()
    local attacker = client.userid_to_entindex(e.attacker)
    local target = client.userid_to_entindex(e.userid)
    local inst_or_sent = #ui.get(tabs["Misc"].trashtalk[3]) > 1 and client.random_float(0, 1) or -1
    if utils.multi_parse(tabs["Misc"].trashtalk[2], "Kill") and attacker == lplayer and target ~= lplayer then
        if utils.multi_parse(tabs["Misc"].trashtalk[3], "Instant") and (inst_or_sent == -1 or inst_or_sent > 0 and inst_or_sent < 0.5) then
            client.exec(("say %s"):format(misc.trashmessages.instant.kill[client.random_int(1, #misc.trashmessages.instant.kill)]))
        end
        if utils.multi_parse(tabs["Misc"].trashtalk[3], "Sentences") and inst_or_sent == -1 or inst_or_sent >= 0.5  then
            local sent = misc.trashmessages.sentence.kill[client.random_int(1, #misc.trashmessages.sentence.kill)]
            for key, val in ipairs(sent) do
                if key%2 > 0 then goto skip end
                client.delay_call(sent[key-1], client.exec, "say "..val)
                ::skip::
            end
        end
    end
    if utils.multi_parse(tabs["Misc"].trashtalk[2], "Death") and target == lplayer and attacker ~= lplayer then
        if utils.multi_parse(tabs["Misc"].trashtalk[3], "Instant") and (inst_or_sent == -1 or inst_or_sent > 0 and inst_or_sent < 0.5) then
            client.exec(("say %s"):format(misc.trashmessages.instant.death[client.random_int(1, #misc.trashmessages.instant.death)]))
        end
        if utils.multi_parse(tabs["Misc"].trashtalk[3], "Sentences") and inst_or_sent == -1 or inst_or_sent >= 0.5  then
            local sent = misc.trashmessages.sentence.death[client.random_int(1, #misc.trashmessages.sentence.death)]
            for key, val in ipairs(sent) do
                if key%2 > 0 then goto skip end
                client.delay_call(sent[key-1], client.exec, "say "..val)
                ::skip::
            end
        end
    end
    if utils.multi_parse(tabs["Misc"].trashtalk[2], "Killer Death") then
        if target == lplayer and attacker ~= lplayer then
            misc.killer = attacker
        end
        if target == misc.killer then
            if utils.multi_parse(tabs["Misc"].trashtalk[3], "Instant") and (inst_or_sent == -1 or inst_or_sent > 0 and inst_or_sent < 0.5) then
                client.exec(("say %s"):format(misc.trashmessages.instant.killer_death[client.random_int(1, #misc.trashmessages.instant.killer_death)]))
            end
            if utils.multi_parse(tabs["Misc"].trashtalk[3], "Sentences") and inst_or_sent == -1 or inst_or_sent >= 0.5  then
                local sent = misc.trashmessages.sentence.killer_death[client.random_int(1, #misc.trashmessages.sentence.killer_death)]
                for key, val in ipairs(sent) do
                    if key%2 > 0 then goto skip end
                    client.delay_call(sent[key-1], client.exec, "say "..val)
                    ::skip::
                end
            end
        end
    end
end
misc.buylist = {
    ["AWP"] = "awp",
    ["Scout"] = "ssg08",
    ["Auto"] = "scar20",
    ["Deagle/R8"] = "deagle",
    ["FS/T-9"] = "fn57",
    ["FS/T-9"] = "tec9",
    ["P250"] = "p250",
    ["Berreta"] = "elite",
    ["Kevlar"] = "vest",
    ["Helmet"] = "vesthelm",
    ["Defuser"] = "defuser",
    ["Zeus"] = "taser",
    ["Fire"] = "molotov",
    ["HE"] = "hegrenade",
    ["Smoky"] = "smokegrenade",
}
misc.buybot = function(e)
    if not ui.get(tabs["Misc"].buybot[1]) then return end
    if client.userid_to_entindex(e.userid) ~= entity.get_local_player() then return end
    client.delay_call(0.1 + client.latency(), function ()
        local money = entity.get_prop(entity.get_local_player(), "m_iAccount")
        if money <= 1000 then return end

        local buy = ''
        local primary = ui.get(tabs["Misc"].buybot[2])
        local secondary = ui.get(tabs["Misc"].buybot[3])
        local tollie = ui.get(tabs["Misc"].buybot[4])

        buy = primary == 'None' and buy or buy..'buy '..misc.buylist[primary]..'; '
        buy = secondary == 'None' and buy or buy..'buy '..misc.buylist[secondary]..'; '

        for i = 1, #tollie do
            local item = misc.buylist[tollie[i]]
            buy = buy .."buy "..item.."; "
        end

        if buy == '' then return end
        client.exec(buy)
    end)
end
ui.set_callback(tabs["Misc"].scopeviewmodel[1], function(id)
    for k, v in pairs(csgo_weapons) do
        if v.schema.item_type_name == "#CSGO_Type_SniperRifle" then
            v.raw.hide_view_model_zoomed = not ui.get(id)
        end
    end
end)
misc.autosmoke = false
misc.autosmk = function(cmd)
    if not ui.get(tabs["Misc"].autosmoke[2]) then return end
    local lplayer = entity.get_local_player()
    if lplayer == nil or not entity.is_alive(lplayer) then return end
    local my_weapon = entity.get_player_weapon(lplayer)
    local simtime = entity.get_prop(lplayer, "m_flSimulationTime")
    local curtime = globals.curtime()
    local nading = false
    if my_weapon ~= nil then
        local weapon = csgo_weapons(my_weapon)
        if weapon.is_grenade and entity.get_prop(my_weapon, "m_fThrowTime") > 0 then nading = true end
    end
    local lpose = vector(entity.get_origin(lplayer))
    local nade_index = nil
    for i=0, 63 do
        local b = entity.get_prop(lplayer, "m_hMyWeapons", i)
        if entity.get_classname(b) == "CSmokeGrenade" then nade_index = b end
    end
    if nade_index == nil then return end
    local notinhand = entity.get_prop(lplayer, "m_hActiveWeapon") ~= nade_index
    local molys = entity.get_all("CInferno")
    local ff = cvar.mp_friendlyfire:get_int() == 0
    local lteam = entity.get_prop(lplayer, "m_iTeamNum")
    for _, v in pairs(molys) do
        local owner = entity.get_prop(v, "m_hOwnerEntity")
        local harmless = owner ~= lplayer and entity.get_prop(owner, "m_iTeamNum") == lteam and ff
        if not harmless then 
            local origvec = vector(entity.get_prop(v, "m_vecOrigin"))
            if client.trace_line(-1, lpose.x, lpose.y, lpose.z, origvec.x, origvec.y, origvec.z) < 1.0 then goto skip end
            local nearest;
            for i=0, 63 do
                local orig1 = origvec + vector(entity.get_prop(v, "m_fireXDelta", i), entity.get_prop(v, "m_fireYDelta", i), 0)
                local dist1 = lpose:dist(orig1)
                if not nearest or lpose:dist(nearest) > dist1 then
                    nearest = orig1
                end
            end
            --origvec = nearest
            local dist = lpose:dist(nearest)
            --local ptich, yaw = lpose:to(origvec):angles()
            lpose = vector(entity.hitbox_position(lplayer, 5))
            local pitch, yaw = lpose:to(origvec):angles()
            if dist <= 340 and not misc.autosmoke then
                cmd.weaponselect = notinhand and nade_index or 0
                cmd.in_attack = true
                misc.autosmoke = true
                --cmd.pitch = pitch
                --cmd.yaw = yaw
            elseif misc.autosmoke then
                client.delay_call(1, function() misc.autosmoke = false; cmd.in_attack = false; end)
            elseif nading then
                cmd.pitch = pitch
                cmd.yaw = yaw
            end
        end
        ::skip::
    end
end
ui.set_callback(tabs["Misc"].autosmoke[1], function(id)
    if ui.get(id) then
        client.set_event_callback("setup_command", misc.autosmk)
    else
        client.unset_event_callback("setup_command", misc.autosmk)
    end
end)
misc.rhand = cvar.cl_righthand
misc.leftknife = function(reset)
    if reset then
        misc.rhand:set_int(1)
        return
    end
    local lplayer = entity.get_local_player()
    if lplayer == nil or not entity.is_alive(lplayer) then return end
    local weapon = entity.get_player_weapon(lplayer)
    if weapon == nil then return end
    if entity.get_classname(weapon) == "CKnife" then
        misc.rhand:set_int(0)
    else
        misc.rhand:set_int(1)
    end
end
ui.set_callback(tabs["Misc"].lefthand[1], function(id)
    if ui.get(id) then
        client.set_event_callback("paint", misc.leftknife)
    else
        client.unset_event_callback("paint", misc.leftknife)
        misc.leftknife(true)
    end
end)
--region @misc end

--region @visuals
indicate.pos = {x = screen.x * 0.5, y = screen.y * 0.5 + 20}
indicate.posu = {x = screen.x * 0.5, y = screen.y * 0.5 + 24}
indicate.pos2 = indicate.pos
indicate._list, indicate._binds = {}, {}
indicate.animate = function(id, val, val2, speed, mode)
    indicate._list[id] = indicate._list[id] or val
    indicate._list[id] = {x = mode(utils.lerp(indicate._list[id].x, val2.x, speed)), y = mode(utils.lerp(indicate._list[id].y, val2.y, speed))}
    return indicate._list[id]
end
indicate.all_binds = {
    ["DT"] = skeetgui.ragegui.aimbot.double_tap,
    ["OS"] = skeetgui.aagui.other.on_shot_antiaim,
    ["FB"] = skeetgui.ragegui.aimbot.force_body_aim,
    ["MD"] = skeetgui.ragegui.aimbot.minimum_damage_override,
    ["SP"] = skeetgui.ragegui.aimbot.force_safe_point,
    ["QP"] = skeetgui.ragegui.other.quick_peek_assist,
    ["DP"] = skeetgui.ragegui.other.duck_peek_assist,
    ["FS"] = tabs["Anti-Aimbot"].freestand[1],
    ["HS"] = tabs["Rage"].onlyhs,
    ["JS"] = tabs["Rage"].jumpshot,
    ["HC"] = tabs["Rage"].hitchance,
    ["EY"] = tabs["Anti-Aimbot"].edgeyaw[1],
    ["DA"] = tabs["Rage"].dormant,
    ["LBY"] = tabs["Anti-Aimbot"].lby_breaker,
    ["DS"] = tabs["Rage"].delay_shot[1],
}
indicate.index = 0
indicate.get_binds = function()
    indicate._binds = {}
    for k, v in pairs(indicate.all_binds) do
        if type(v) == "number" then
            if ui.get(v) and not utils.in_table(indicate._binds, k) then
                table.insert(indicate._binds, k)
            end
        else
            if ui.get(v[1]) and ui.get(v[2]) and not utils.in_table(indicate._binds, k) then
                if k:lower() == "lby" and (ui.get(skeetgui.ragegui.aimbot.double_tap[1]) and ui.get(skeetgui.ragegui.aimbot.double_tap[2]) or ui.get(skeetgui.aagui.other.on_shot_antiaim[1]) and ui.get(skeetgui.aagui.other.on_shot_antiaim[2])) or (k == "hide" or k == "OS") and ui.get(skeetgui.ragegui.aimbot.double_tap[1]) and ui.get(skeetgui.ragegui.aimbot.double_tap[2]) then goto skiph end
                table.insert(indicate._binds, k)
            end
        end
        ::skiph::
    end
end
utils.text_fade_animation = function(x, y, speed, color1, color2, text, flag)
    local final_text = ''
    local curtime = globals.curtime()

    for i = 0, #text do
        local x_offset = i * 10
        local wave = math.cos(8 * speed * curtime + x_offset / 30)
        local color = string.format('%02x%02x%02x%02x',
            utils.lerp(color1[1], color2[1], utils.clamp(wave, 0, 1)),
            utils.lerp(color1[2], color2[2], utils.clamp(wave, 0, 1)),
            utils.lerp(color1[3], color2[3], utils.clamp(wave, 0, 1)),
            color1[4]
        )
        final_text = final_text .. '\a' .. color .. text:sub(i, i)
    end
    renderer.text(x, y, color1[1], color1[2], color1[3], color1[4], flag, nil, final_text)
end
utils.rec = function(x, y, w, h, radius, color)
    radius = math.min(x/2, y/2, radius)
    local r, g, b, a = unpack(color)
    renderer.rectangle(x, y + radius, w, h - radius*2, r, g, b, a)
    renderer.rectangle(x + radius, y, w - radius*2, radius, r, g, b, a)
    renderer.rectangle(x + radius, y + h - radius, w - radius*2, radius, r, g, b, a)
    renderer.circle(x + radius, y + radius, r, g, b, a, radius, 180, 0.25)
    renderer.circle(x - radius + w, y + radius, r, g, b, a, radius, 90, 0.25)
    renderer.circle(x - radius + w, y - radius + h, r, g, b, a, radius, 0, 0.25)
    renderer.circle(x + radius, y - radius + h, r, g, b, a, radius, -90, 0.25)
end
utils.rec_outline = function(x, y, w, h, radius, thickness, color)
    radius = math.min(w/2, h/2, radius)
    local r, g, b, a = unpack(color)
    if radius == 1 then
        renderer.rectangle(x, y, w, thickness, r, g, b, a)
        renderer.rectangle(x, y + h - thickness, w , thickness, r, g, b, a)
    else
        renderer.rectangle(x + radius, y, w - radius*2, thickness, r, g, b, a)
        renderer.rectangle(x + radius, y + h - thickness, w - radius*2, thickness, r, g, b, a)
        renderer.rectangle(x, y + radius, thickness, h - radius*2, r, g, b, a)
        renderer.rectangle(x + w - thickness, y + radius, thickness, h - radius*2, r, g, b, a)
        renderer.circle_outline(x + radius, y + radius, r, g, b, a, radius, 180, 0.25, thickness)
        renderer.circle_outline(x + radius, y + h - radius, r, g, b, a, radius, 90, 0.25, thickness)
        renderer.circle_outline(x + w - radius, y + radius, r, g, b, a, radius, -90, 0.25, thickness)
        renderer.circle_outline(x + w - radius, y + h - radius, r, g, b, a, radius, 0, 0.25, thickness)
    end
end
utils.shadow = function(x, y, w, h, width, rounding, accent, accent_inner)
    local thickness = 1
    local Offset = 1
    local r, g, b, a = unpack(accent)
    if accent_inner then
        utils.rec(x, y, w, h + 1, rounding, accent_inner)
    end
    for k = 0, width do
        if a * (k/width)^(1) > 5 then
            local accent = {r, g, b, a * (k/width)^(2)}
            utils.rec_outline(x + (k - width - Offset)*thickness, y + (k - width - Offset) * thickness, w - (k - width - Offset)*thickness*2, h + 1 - (k - width - Offset)*thickness*2, rounding + thickness * (width - k + Offset), thickness, accent)
        end
    end
end
misc.glowset = {
    ["DT"]  = "dt",
    ["OS"]  = "hide",
    ["FB"]  = "body",
    ["MD"]  = "dmg",
    ["SP"]  = "safe",
    ["QP"]  = "qpeek",
    ["DP"]  = "duck",
    ["FS"]  = "fstand",
    ["HS"]  = "head",
    ["JS"]  = "jump",
    ["HC"]  = "hitc",
    ["EY"]  = "edge",
    ["LBY"] = "lby",
    ["DS"]  = "delay",
}
misc.ripler = {
    ["Disabled"]        = "OFF",
    ["Shared"]          = "SHARED",
    ["Standing"]        = "STAND",
    ["Air"]             = "AIR",
    ["Air-Crouch"]      = "AIR+",
    ["Moving"]          = "MOVE",
    ["Crouch"]          = "CRAB",
    ["Crouch-Moving"]   = "CRAB+",
    ["Fakelags"]        = "FAKE",
    ["Duckpeek"]        = "DUCK",
    ["On-Use"]          = "LEGIT",
    ["Slowwalk"]        = "SLOW",
    ["DT"]              = "DT",
    ["OS"]              = "OSAA",
    ["FB"]              = "BODY",
    ["MD"]              = "DMG",
    ["SP"]              = "SAFE",
    ["QP"]              = "PEEK",
    ["DP"]              = "DUCK",
    ["FS"]              = "FS",
    ["JS"]              = "SHOT",
    ["HS"]              = "HEAD",
    ["HC"]              = "HITC",
    ["EY"]              = "EDGE",
    ["LBY"]             = "LBY",
    ["DS"]              = "DS",
}
indicate.cross = function()
    if not ui.get(tabs["Visuals"].indicators[1]) then return end
    local lplayer = entity.get_local_player()
    if lplayer == nil or not entity.is_alive(lplayer) then return end
    local is_scoped = utils.multi_parse(tabs["Visuals"].indicators[4], "Scope") and (entity.get_prop(lplayer, "m_bIsScoped") == 1 or entity.get_prop(lplayer, "m_bResumeZoom") == 1)
    local indcolor = {ui.get(tabs["Visuals"].indicators[2])}
    --local dt = afunc.get_double_tap()
    local anim = utils.multi_parse(tabs["Visuals"].indicators[4], "Animation")
    local shadowing = utils.multi_parse(tabs["Visuals"].indicators[4], "Shadow")
    
    if ui.get(tabs["Visuals"].indicators[3]) == "Default" then
        local weight, height = renderer.measure_text("-", "OSMANHOOK")
        local d = utils.round(math.abs(afunc.get_desync(entity.get_local_player())))/57
        local factor = d <= 1 and (weight - 2) * d or 0

        if is_scoped then
            indicate.pos = indicate.animate("EXPA", indicate.pos, {x = screen.x*0.5 + weight*0.5 + 2, y = indicate.pos.y}, 0.5, math.ceil)
            indicate.posu = indicate.animate("EXPA1", indicate.posu, {x = screen.x*0.5 + 2, y = indicate.posu.y}, 0.1, math.ceil)
        else
            indicate.pos = indicate.animate("EXPA", indicate.pos, {x = screen.x*0.5, y = indicate.pos.y}, 0.5, math.floor)
            indicate.posu = indicate.animate("EXPA1", indicate.posu, {x = screen.x*0.5, y = indicate.posu.y}, 0.1, math.floor)
        end
        if shadowing then utils.shadow(indicate.pos.x - weight*0.5 + 2, indicate.pos.y, weight - 3, 0, 10, 0, {indcolor[1], indcolor[2], indcolor[3], 50}, {indcolor[1], indcolor[2], indcolor[3], 50}) end

        if anim then
            local iswhite = indcolor[1] == indcolor[2] and indcolor[2] == indcolor[3]
            local seccol = iswhite and {55, 55, 55} or {indcolor[1] >= 50 and indcolor[1] - 50 or indcolor[1] + 50, indcolor[2] >= 50 and indcolor[2] - 50 or indcolor[2] + 50, indcolor[3] >= 50 and indcolor[3] - 50 or indcolor[3] + 50}
            utils.text_fade_animation(indicate.pos.x - 1, indicate.pos.y, -0.5, indcolor, seccol, "OSMANHOOK", "-c")
        else
            renderer.text(indicate.pos.x - 1, indicate.pos.y, indcolor[1], indcolor[2], indcolor[3], 255, "-c", 0, "OSMANHOOK")
        end
        renderer.rectangle(indicate.pos.x - weight*0.5, indicate.pos.y + height*0.5, weight, 4, 0, 0, 0, 255)
        renderer.rectangle(indicate.pos.x - weight*0.5 + 1, indicate.pos.y + height*0.5 + 1, factor, 2, indcolor[1], indcolor[2], indcolor[3], 255)
        indicate.posu.y = screen.y * 0.5 + 30
        for _, val in ipairs(indicate._binds) do
            local w, h = renderer.measure_text("-", val)
            renderer.text(indicate.posu.x - (is_scoped and 0 or w*0.5 + 1), indicate.posu.y, indcolor[1], indcolor[2], indcolor[3], (val == "DT" and not rage.dt) and 100 or 255, "-", 0, val)
            indicate.posu.y = indicate.posu.y + height
        end

    elseif ui.get(tabs["Visuals"].indicators[3]) == "GlowSet" then
        local weight, height = renderer.measure_text("b", "osmanhook")
        local w, h = renderer.measure_text("b", antiaims.current_cond:lower())

        if is_scoped then
            indicate.pos = indicate.animate("EXPE", indicate.pos, {x = screen.x*0.5 + weight*0.5 + 5, y = indicate.pos.y}, 0.5, math.ceil)
            indicate.pos2 =  indicate.animate("EXPE2", indicate.pos2, {x = screen.x*0.5 + w*0.5 + 5, y = indicate.pos2.y}, 0.5, math.ceil)
            indicate.posu = indicate.animate("EXPE1", indicate.posu, {x = screen.x*0.5 + weight*0.5, y = indicate.posu.y}, 0.5, math.ceil)
        else
            indicate.pos = indicate.animate("EXPE", indicate.pos, {x = screen.x*0.5, y = indicate.pos.y}, 0.5, math.floor)
            indicate.pos2 = indicate.animate("EXPE2", indicate.pos2, {x = screen.x*0.5, y = indicate.pos2.y}, 0.5, math.floor)
            indicate.posu = indicate.animate("EXPE1", indicate.posu, {x = screen.x*0.5, y = indicate.posu.y}, 0.5, math.floor)
        end
        if shadowing then utils.shadow(indicate.pos.x - weight*0.5 + 1, indicate.pos.y, weight - 2, 0, 10, 0, {indcolor[1], indcolor[2], indcolor[3], 50}, {indcolor[1], indcolor[2], indcolor[3], 50}) end

        if anim then
            local iswhite = indcolor[1] == indcolor[2] and  indcolor[2] == indcolor[3]
            local seccol = iswhite and {55, 55, 55} or {indcolor[1] >= 50 and indcolor[1] - 50 or indcolor[1] + 50, indcolor[2] >= 50 and indcolor[2] - 50 or indcolor[2] + 50, indcolor[3] >= 50 and indcolor[3] - 50 or indcolor[3] + 50}
            utils.text_fade_animation(indicate.pos.x, indicate.pos.y, -0.5, indcolor, seccol, "osmanhook", "cb")
        else
            renderer.text(indicate.pos.x, indicate.pos.y, indcolor[1], indcolor[2], indcolor[3], indcolor[4], "cb", 0, "osmanhook")
        end

        renderer.text(indicate.pos2.x - w*0.5, indicate.pos2.y + height*0.5, 255, 255, 255, 220, "b", 0, antiaims.current_cond:lower())
        for _, val in ipairs(indicate._binds) do
            local wh, hw = renderer.measure_text(nil, misc.glowset[val])
            indicate.posu.y = indicate.posu.y + height
            renderer.text(indicate.posu.x - (is_scoped and weight*0.5 - 5 or wh*0.5), indicate.posu.y + 2, 250, (val == "DT" and not rage.dt) and 91 or 250, (val == "DT" and not rage.dt) and 91 or 250, 250, nil, 0, misc.glowset[val])
        end
        indicate.posu.y = screen.y * 0.5 + 24
    elseif ui.get(tabs["Visuals"].indicators[3]) == "Rippler" then
        local text = ""
        local curtime = globals.curtime()
        local bloom = math.abs(math.sin(8 * 0.2 * curtime + 120 / 30)) - 0.2
        local color = string.format('\a%02x%02x%02x%02x',
            utils.lerp(245, 50, utils.clamp(bloom, 0, 1)),
            utils.lerp(200, 50, utils.clamp(bloom, 0, 1)),
            utils.lerp(95, 50, utils.clamp(bloom, 0, 1)),
            utils.lerp(255, 0, utils.clamp(bloom, 0, 1))
        )
        local t = ((math.cos(8 * 0.2 * curtime + 120 / 30) * -0.5) + 0.5)
        local anims = math.max(1, math.min(9, math.ceil(t * 10)))
        text = text..string.sub("OSMANHOOK", 1, anims)
        local weight, height = renderer.measure_text("-", "OSMANHOOK")
        local w, h = renderer.measure_text("-", misc.ripler[antiaims.current_cond])
        if is_scoped then
            indicate.pos = indicate.animate("EX", indicate.pos, {x = screen.x*0.5 + weight, y = indicate.pos.y}, 0.5, math.ceil)
            indicate.pos2 =  indicate.animate("EX2", indicate.pos2, {x = screen.x*0.5 + weight*0.5 + 3, y = indicate.pos2.y}, 0.5, math.ceil)
            indicate.posu = indicate.animate("EX1", indicate.posu, {x = screen.x*0.5 + weight*0.2, y = indicate.posu.y}, 0.5, math.ceil)
        else
            indicate.pos = indicate.animate("EX", indicate.pos, {x = screen.x*0.5, y = indicate.pos.y}, 0.5, math.floor)
            indicate.pos2 = indicate.animate("EX2", indicate.pos2, {x = screen.x*0.5, y = indicate.pos2.y}, 0.5, math.floor)
            indicate.posu = indicate.animate("EX1", indicate.posu, {x = screen.x*0.5, y = indicate.posu.y}, 0.5, math.floor)
        end
        if shadowing then
            local cw, ch = renderer.measure_text("-", text)
            if string.len(text) > 0 then
                utils.shadow(indicate.pos.x + weight*0.5 - 5 - cw, indicate.pos.y + height*0.5, cw, 0, 8, 0, {indcolor[1], indcolor[2], indcolor[3], 50}, {indcolor[1], indcolor[2], indcolor[3], 50})
            end
            utils.shadow(indicate.pos.x + weight*0.5 - 7, indicate.pos.y + height*0.5, 15, 0, 8, 0, {245, 200, 90, 50}, {245, 200, 90, 50})
        end
        if anim then
            local iswhite = indcolor[1] == indcolor[2] and  indcolor[2] == indcolor[3]
            local seccol = iswhite and {55, 55, 55} or {indcolor[1] >= 50 and indcolor[1] - 50 or indcolor[1] + 50, indcolor[2] >= 50 and indcolor[2] - 50 or indcolor[2] + 50, indcolor[3] >= 50 and indcolor[3] - 50 or indcolor[3] + 50}
            utils.text_fade_animation(indicate.pos.x + weight*0.5 - 7, indicate.pos.y, -0.8, indcolor, seccol, text, "r-")
        else
            renderer.text(indicate.pos.x + weight*0.5 - 7, indicate.pos.y, indcolor[1], indcolor[2], indcolor[3], indcolor[4], "r-", 0, text)
        end
        renderer.text(indicate.pos.x + 12, indicate.pos.y, indcolor[1], indcolor[2], indcolor[3], indcolor[4], "-", 0, color.."YAW")
        renderer.text(indicate.pos2.x - (is_scoped and weight*0.5 or w*0.5 + 7) + 7, indicate.pos2.y + height, 120, 120, 120, 250, "-", 0, misc.ripler[antiaims.current_cond])
        for _, val in ipairs(indicate._binds) do
            local wh, hw = renderer.measure_text(nil, misc.ripler[val])
            indicate.posu.y = indicate.posu.y + height
            renderer.text(indicate.posu.x - (is_scoped and 0 or wh*0.5)+2, indicate.posu.y, 250, (val == "DT" and not rage.dt) and 91 or 250, (val == "DT" and not rage.dt) and 91 or 250, 250, "-", 0, misc.ripler[val])
        end
        indicate.posu.y = screen.y * 0.5 + height*3
    elseif ui.get(tabs["Visuals"].indicators[3]) == "Pixies" then
        local weight, height = renderer.measure_text("-", "OSMANHOOK")
        local w, h = renderer.measure_text("-", misc.ripler[antiaims.current_cond])
        if is_scoped then
            indicate.pos = indicate.animate("EXI", indicate.pos, {x = screen.x*0.5 + weight, y = indicate.pos.y}, 0.5, math.ceil)
            indicate.pos2 =  indicate.animate("EXI2", indicate.pos2, {x = screen.x*0.5 + weight*0.5 + 4, y = indicate.pos2.y}, 0.5, math.ceil)
            indicate.posu = indicate.animate("EXI1", indicate.posu, {x = screen.x*0.5 + weight*0.2, y = indicate.posu.y}, 0.5, math.ceil)
        else
            indicate.pos = indicate.animate("EXI", indicate.pos, {x = screen.x*0.5, y = indicate.pos.y}, 0.5, math.floor)
            indicate.pos2 = indicate.animate("EXI2", indicate.pos2, {x = screen.x*0.5, y = indicate.pos2.y}, 0.5, math.floor)
            indicate.posu = indicate.animate("EXI1", indicate.posu, {x = screen.x*0.5, y = indicate.posu.y}, 0.5, math.floor)
        end
        if shadowing then
            utils.shadow(indicate.pos.x - weight*0.5 - 4, indicate.pos.y + height*0.5, weight - 4, 0, 8, 0, {indcolor[1], indcolor[2], indcolor[3], 100}, {indcolor[1], indcolor[2], indcolor[3], 100})
            utils.shadow(indicate.pos.x + weight*0.5 - 2, indicate.pos.y + height*0.5, 9, 0, 8, 0, {255, 160, 160, 100}, {255, 160, 160, 100})
        end
        if anim then
            local iswhite = indcolor[1] == indcolor[2] and  indcolor[2] == indcolor[3]
            local seccol = iswhite and {55, 55, 55} or {indcolor[1] >= 50 and indcolor[1] - 50 or indcolor[1] + 50, indcolor[2] >= 50 and indcolor[2] - 50 or indcolor[2] + 50, indcolor[3] >= 50 and indcolor[3] - 50 or indcolor[3] + 50}
            utils.text_fade_animation(indicate.pos.x + weight*0.5 - 15, indicate.pos.y, -0.8, indcolor, seccol, "OSMANHOOK", "r-")
        else
            renderer.text(indicate.pos.x + weight*0.5 - 15, indicate.pos.y, indcolor[1], indcolor[2], indcolor[3], indcolor[4], "r-", 0, "OSMANHOOK")
        end
        if _BETA then
            renderer.text(indicate.pos.x + weight*0.5 + 7, indicate.pos.y, 255, 160, 160, 255, "r-", 0, "  BETA")
        end
        renderer.text(indicate.pos2.x - (is_scoped and weight*0.5 or w*0.5 + 7) + 6, indicate.pos2.y + height, 255, 255, 255, 255, "-", 0, misc.ripler[antiaims.current_cond])
        local fb, dp, sp, fs = false, false, false, false
        for _, v in ipairs(indicate._binds) do
            if v == "DP" then dp = true; goto skip end
            if v == "FB" then fb = true; goto skip end
            if v == "SP" then sp = true; goto skip end
            if v == "FS" then fs = true; goto skip end
            indicate.posu.y = indicate.posu.y + height
            if v == "MD" then v = "DMG" end
            if v == "HC" then v = "HITC" end
            local wh, hw = renderer.measure_text("-", v)
            renderer.text(indicate.posu.x - (is_scoped and -2 or wh*0.5 + 1), indicate.posu.y, 255, 255, 255, 255, "-", 0, v)
            ::skip::
        end
        indicate.posu.y = indicate.posu.y + height
        if oldposu ~= nil and oldposu ~= indicate.posu.y then
            local tmp = utils.lerp(oldposu, indicate.posu.y, 0.5)
            indicate.posu.y = oldposu > indicate.posu.y and math.floor(tmp) or math.ceil(tmp)
        end
        renderer.text(indicate.pos.x - weight*0.7 + (is_scoped and -1 or 0), indicate.posu.y, 255, 255, 255, (fb and 255 or 160), "-", 0, "BAIM")
        renderer.text(indicate.pos.x - weight*0.7 + (is_scoped and 18 or 19) , indicate.posu.y, 255, 255, 255, (dp and 255 or 160), "-", 0, "DP")
        renderer.text(indicate.pos.x - weight*0.7 + (is_scoped and 29 or 30) , indicate.posu.y, 255, 255, 255, (sp and 255 or 160), "-", 0, "SP")
        renderer.text(indicate.pos.x - weight*0.7 + (is_scoped and 40 or 41), indicate.posu.y, 255, 255, 255, (fs and 255 or 160), "-", 0, "FS")
        oldposu = indicate.posu.y
        indicate.posu.y = screen.y * 0.5 + height*3
    end
end
renderer.world_circle = function(origin, size, color)
    if origin[1] == nil then return end
    local last_point = nil

    for i = 0, 360, 5 do
        local new_point = {
            origin[1] - (math.sin(math.rad(i))*size),
            origin[2] - (math.cos(math.rad(i))*size),
            origin[3]
        }

        if last_point ~= nil then
            local old_screen_point = {renderer.world_to_screen(last_point[1], last_point[2], last_point[3])}
            local new_screen_point = {renderer.world_to_screen(new_point[1], new_point[2], new_point[3])}

            if old_screen_point[1] ~= nil and new_screen_point[1] ~= nil then 
                renderer.line(old_screen_point[1], old_screen_point[2], new_screen_point[1], new_screen_point[2], color[1], color[2], color[3], color[4])
            end
        end

        last_point = new_point
    end
end
renderer.world_filled_circle = function(origin, size, color)
    if origin[1] == nil then return end

    local center_screen_point = {renderer.world_to_screen(origin[1], origin[2], origin[3])}
    if center_screen_point[1] == nil then return end 

    local last_point = nil

    for i = 0, 360, 5 do
        local new_point = {
            origin[1] - (math.sin(math.rad(i))*size),
            origin[2] - (math.cos(math.rad(i))*size),
            origin[3]
        }

        if last_point ~= nil then
            local new_screen_point = {renderer.world_to_screen(new_point[1], new_point[2], new_point[3])}
            local last_screen_point = {renderer.world_to_screen(last_point[1], last_point[2], last_point[3])}
            if new_screen_point[1] ~= nil and last_screen_point[1] ~= nil then
                renderer.triangle(center_screen_point[1], center_screen_point[2], last_screen_point[1], last_screen_point[2], new_screen_point[1], new_screen_point[2], color[1], color[2], color[3], color[4])
            end
        end

        last_point = new_point
    end
end
visuals.paint_nimb = function()
    local lplayer = entity.get_local_player()
    if not entity.is_alive(lplayer) or not ui.get(skeetgui.visualgui.effects.tperson[2]) then return end
    local pos = {entity.hitbox_position(lplayer, 0)}
    pos[3] = pos[3] + 8
    renderer.world_circle(pos, 5, {ui.get(tabs["Visuals"].nimbus[2])})
end
ui.set_callback(tabs["Visuals"].nimbus[1], function(id)
    if ui.get(id) then
        client.set_event_callback("paint", visuals.paint_nimb)
    else
        client.unset_event_callback("paint", visuals.paint_nimb)
    end
end)
indicate.crossdmg = function()
    if rage.weapon == nil or rage.weapon == "CKnife" or string.match(rage.weapon, "Grenade") or string.match(rage.weapon, "Flash") then return end
    local lplayer = entity.get_local_player()
    if lplayer == nil or not entity.is_alive(lplayer) then return end
    local posx, posy = screen.x * 0.5, screen.y * 0.5
    local ismindmg = ui.get(skeetgui.ragegui.aimbot.minimum_damage_override[1]) and ui.get(skeetgui.ragegui.aimbot.minimum_damage_override[2])
    local onlydmg = ui.get(tabs["Visuals"].crossdamage[2])
    local dmg = ismindmg and ui.get(skeetgui.ragegui.aimbot.minimum_damage_override[3]) or not ui.get(tabs["Visuals"].crossdamage[2]) and ui.get(skeetgui.ragegui.aimbot.minimum_damage) or nil
    local sides = ui.get(tabs["Visuals"].crossdamage[4])
    local flags = ui.get(tabs["Visuals"].crossdamage[3]) and (string.match(sides, "Left") and "-dr" or "-d") or (string.match(sides, "Left") and "dr" or "d")
    if dmg then
        dmg = dmg > 0 and dmg or (ui.get(tabs["Visuals"].crossdamage[3]) and "AUTO" or "auto")
        local sizex, sizey = renderer.measure_text(flags, dmg)
        if sides == "Right-Top" then
            posx = posx + 5 --* 0.7
            posy = posy - sizey - 5 --* 0.7
        elseif sides == "Left-Top" then
            posx = posx - 5 --* 1.2
            posy = posy - sizey - 5 --* 0.7
        elseif sides == "Right-Bottom" then
            posx = posx + 5 --* 0.7
            posy = posy + sizey*0.5 --* 0.7
        elseif sides == "Left-Bottom" then
            posx = posx - 5 --* 1.2
            posy = posy + sizey*0.5 --* 0.7
        end
        renderer.text(posx, posy, 255, 255, 255, 255, flags, 0, dmg)
    end
end
ui.set_callback(tabs["Visuals"].crossdamage[1], function(id)
    if ui.get(id) then
        client.set_event_callback("paint", indicate.crossdmg)
    else
        client.unset_event_callback("paint", indicate.crossdmg)
    end
end)
utils.fadecircl = function(x, y, radius, r, g, b, alpha0, alpha1, fade_speed, start_degrees, percentage)
    for i=radius, 1, -1 do
        alpha0 = alpha0 > alpha1 and math.floor(utils.lerp(alpha0, alpha1, fade_speed)) or math.ceil(utils.lerp(alpha0, alpha1, fade_speed))
        renderer.circle_outline(x, y, r, g, b, alpha0, i, start_degrees, percentage, 1)
    end
    renderer.rectangle(x-1, y-1, 2, 2, r, g, b, alpha0)
end
visuals.arrows = function()
    local lplayer = entity.get_local_player()
    if lplayer == nil or not entity.is_alive(lplayer) then return end
    local style = ui.get(tabs["Visuals"].arrows[2])
    local stdcol = {35, 35, 35, 150}
    local arrow_col = {ui.get(tabs["Visuals"].arrows[4])}
    local desync_col = {ui.get(tabs["Visuals"].arrows[6])}
    local gap = ui.get(tabs["Visuals"].arrows[7])
    local adding = ui.get(tabs["Visuals"].arrows[8])
    local left = antiaims.is_manual == 1 
    local right = antiaims.is_manual == 2
    local leftmcol = left and arrow_col or stdcol
    local rightmcol = right and arrow_col or stdcol
    if style == "TeamSkeet" then
        local leftdcol = not antiaims.current_side and desync_col or stdcol
        local rightdcol = antiaims.current_side and desync_col or stdcol
        renderer.rectangle(screen.x*0.5 - gap - 2, screen.y*0.5 - adding, 2, adding*2, leftdcol[1], leftdcol[2], leftdcol[3], leftdcol[4])
        renderer.rectangle(screen.x*0.5 + gap, screen.y*0.5 - adding, 2, adding*2, rightdcol[1], rightdcol[2], rightdcol[3], rightdcol[4])
        renderer.triangle(screen.x*0.5 + gap + 4, screen.y*0.5 - adding, screen.x*0.5 + gap + adding + 4, screen.y*0.5, screen.x*0.5 + gap + 4, screen.y*0.5 + adding, rightmcol[1], rightmcol[2], rightmcol[3], rightmcol[4])
        renderer.triangle(screen.x*0.5 - gap - 4, screen.y*0.5 - adding, screen.x*0.5 - gap - adding - 4, screen.y*0.5, screen.x*0.5 - gap - 4, screen.y*0.5 + adding, leftmcol[1], leftmcol[2], leftmcol[3], leftmcol[4])
    elseif style == "CS2" then
        if left then
            utils.fadecircl(screen.x*0.5 - gap, screen.y*0.5, adding, arrow_col[1], arrow_col[2], arrow_col[3], 0, 255, 0.1, 0, 1)
        end
        if right then
            utils.fadecircl(screen.x*0.5 + gap, screen.y*0.5, adding, arrow_col[1], arrow_col[2], arrow_col[3], 0, 255, 0.1, 0, 1)
        end
        --if not antiaims.current_side then
        --    utils.fadecircl(screen.x*0.5 - gap, screen.y*0.5, adding*0.5, desync_col[1], desync_col[2], desync_col[3], 0, 255, 0.1, 0, 1)
        --end
        --if antiaims.current_side then
        --    utils.fadecircl(screen.x*0.5 + gap, screen.y*0.5, adding*0.5, desync_col[1], desync_col[2], desync_col[3], 0, 255, 0.1, 0, 1)
        --end
    elseif style == "Triangle" then
        renderer.triangle(screen.x*0.5 + gap, screen.y*0.5 - adding*0.5, screen.x*0.5 + gap + adding*0.9, screen.y*0.5, screen.x*0.5 + gap, screen.y*0.5 + adding*0.5, rightmcol[1], rightmcol[2], rightmcol[3], rightmcol[4])
        renderer.triangle(screen.x*0.5 - gap, screen.y*0.5 - adding*0.5, screen.x*0.5 - gap - adding*0.9, screen.y*0.5, screen.x*0.5 - gap, screen.y*0.5 + adding*0.5, leftmcol[1], leftmcol[2], leftmcol[3], leftmcol[4])
    elseif style == "Arrows" then
        local w, h = renderer.measure_text("+", ">")
        if right then
            renderer.text(screen.x*0.5 + gap, screen.y*0.5 - h*0.5, arrow_col[1], arrow_col[2], arrow_col[3], arrow_col[4], "+", 0, ">")
        end
        if left then
            renderer.text(screen.x*0.5 - gap, screen.y*0.5 - h*0.5, arrow_col[1], arrow_col[2], arrow_col[3], arrow_col[4], "+", 0, "<")
        end
    end
end
ui.set_callback(tabs["Visuals"].arrows[1], function(id)
    if ui.get(id) then
        client.set_event_callback("paint", visuals.arrows)
    else
        client.unset_event_callback("paint", visuals.arrows)
    end
end)
visuals.sidemark = function()
    local left = ui.get(tabs["Visuals"].sidemark[2]) == "Left"
    local r2, g2, b2, a2 = 55,55,55, 255
    local highlight_fraction =  (globals.realtime() / 2 % 1.2 * 2) - 1.2
    local output = ""
    local text_to_draw = "osmanhook.lua"
    for idx = 1, #text_to_draw do
        local character = text_to_draw:sub(idx, idx)
        local character_fraction = idx / #text_to_draw
        local r1, g1, b1, a1 = 255, 255, 255, 255
        local delta = (character_fraction - highlight_fraction)
        if delta >= 0 and delta <= 1.4 then
            if delta > 0.7 then delta = 1.4 - delta end
            local rf, gf, bf, af = r2 - r1, g2 - g1, b2 - b1, a2 - a1
            r1 = r1 + rf * delta * 1.25
            g1 = g1 + gf * delta * 1.25
            b1 = b1 + bf * delta * 1.25
            a1 = a1 + af * delta * 1.25
        end
        output = output .. ('\a%02x%02x%02x%02x%s'):format(r1, g1, b1, 255, text_to_draw:sub(idx, idx))
    end
    output = output..('\a%02x%02x%02x%02x%s'):format(247, 171, 198, 255, _BETA and " [BETA]" or " [STABLE]")
    local textx, texty = renderer.measure_text("d", output)
	renderer.text(left and 20 or screen.x - textx - 20, screen.y*0.5, 255, 255, 255, a2, "d", 0, output)
end
ui.set_callback(tabs["Visuals"].sidemark[1], function(id)
    if ui.get(id) then
        client.set_event_callback("paint", visuals.sidemark)
    else
        client.unset_event_callback("paint", visuals.sidemark)
    end
end)
utils.buildpredbox = function(ent, pos)
    local minvec = utils.vecsum({ entity.get_prop(ent, 'm_vecMins') }, pos)
    local maxvec = utils.vecsum({ entity.get_prop(ent, 'm_vecMaxs') }, pos)
    local verts = { { minvec[1], minvec[2], minvec[3] }, { minvec[1], maxvec[2], minvec[3] }, { maxvec[1], maxvec[2], minvec[3] }, { maxvec[1], minvec[2], minvec[3] }, { minvec[1], minvec[2], maxvec[3] }, { minvec[1], maxvec[2], maxvec[3] }, { maxvec[1], maxvec[2], maxvec[3] }, { maxvec[1], minvec[2], maxvec[3] } }
    local points = { { 0, 1 }, { 1, 2 }, { 2, 3 }, { 3, 0 }, { 5, 6 }, { 6, 7 }, { 1, 4 }, { 4, 8 }, { 0, 4 }, { 1, 5 }, { 2, 6 }, { 3, 7 }, { 5, 8 }, { 7, 8 }, { 3, 4 } }
    for i = 1, #points do
        if verts[points[i][1]] ~= nil and verts[points[i][2]] ~= nil then
            local side = { renderer.world_to_screen(verts[points[i][1]][1], verts[points[i][1]][2], verts[points[i][1]][3]) }
            local side1 = { renderer.world_to_screen(verts[points[i][2]][1], verts[points[i][2]][2], verts[points[i][2]][3]) }
            renderer.line(side[1], side[2], side1[1], side1[2], 255, 255, 255, 255)
        end
    end
end

ticks.runc = function(cmd)
    ticks.current_cmd = cmd.command_number
end
ticks.tickcalc = function(cmd)
    if cmd.command_number == ticks.current_cmd then
        ticks.current_cmd = nil;
        local tbase = entity.get_prop(entity.get_local_player(), "m_nTickBase")
        if ticks.tickbase_max ~= nil then
            ticks.tickbase_diff = tbase - ticks.tickbase_max
        end
        ticks.tickbase_max = math.max(tbase, ticks.tickbase_max or 0)
    end
end
ticks.host_frameticks =  ffi.cast('uint32_t*', ffi.cast("char*", client.find_signature('engine.dll', '\x03\x05\xCC\xCC\xCC\xCC\x83\xCF\x10')) + 0x2)
ticks.host_currentframetick = ffi.cast('uint32_t*', ffi.cast("char*", client.find_signature('engine.dll', '\x2B\x05\xCC\xCC\xCC\xCC\x03\x05\xCC\xCC\xCC\xCC\x83\xCF\x10')) + 0x2)

--[[local function chokecalc()
    local enemy = entity.get_players(true)
    for _, v in pairs(enemy) do 
        local nlplayer = native_GetClientEntity(v)
        local m_flOldSimulationTime = ffi.cast('float*', ffi.cast('uintptr_t', nlplayer) + 0x26C)[0]
        local m_flSimulationTime = entity.get_prop(v, 'm_flSimulationTime')
        local delta = toticks(m_flSimulationTime - m_flOldSimulationTime) 
        local clock =  globals.servertickcount() - globals.tickcount()
        local predicted_server_tick = globals.tickcount() + clock
        if ticks.host_frameticks ~= nil and ticks.host_currentframetick ~= nil then
            local delta1 = ticks.host_frameticks[0] - ticks.host_currentframetick[0]
            local max_delta_for_tick_rate = math.floor(1 / globals.tickinterval()) / 8

            if delta1 > 0 and delta1 < max_delta_for_tick_rate then
                predicted_server_tick = predicted_server_tick + delta1
            end
        end
        local shift = toticks(m_flSimulationTime) - predicted_server_tick - 1
        rage.choking[v] = utils.clamp(delta - 1, 0, 15)
        rage.shifting[v] = shift < 0
    end
end]]
--rage.breaklc = {}
rage.choked, rage.ischoking, rage.shifting, rage.shiftticks = {}, {}, {}, {}
ticks.chokecalc = function()
    local enemy = entity.get_players(true)
    for _, v in pairs(enemy) do 
        local nlplayer = native_GetClientEntity(v)
        local m_flOldSimulationTime = ffi.cast('float*', ffi.cast('uintptr_t', nlplayer) + 0x26C)[0]
        local m_flSimulationTime = entity.get_prop(v, 'm_flSimulationTime')
        if m_flSimulationTime <= m_flOldSimulationTime then
            --rage.breaklc[v] == true
            goto non
        end
        local delta = toticks(m_flSimulationTime - m_flOldSimulationTime) -- - toticks(client.latency() - client.real_latency())
        local clock =  globals.servertickcount() - globals.tickcount()
        local predicted_server_tick = globals.tickcount() + clock
        if ticks.host_frameticks ~= nil and ticks.host_currentframetick ~= nil then
            local delta1 = ticks.host_frameticks[0] - ticks.host_currentframetick[0]
            local max_delta_for_tick_rate = math.floor(1 / globals.tickinterval()) / 8

            if delta1 > 0 and delta1 < max_delta_for_tick_rate then
                predicted_server_tick = predicted_server_tick + delta1
            end
        end
        local shift = toticks(m_flSimulationTime) - predicted_server_tick -- + toticks(client.latency() - client.real_latency()) 
        delta = utils.clamp(delta - 1, 0, 17)
        rage.choked[v] = delta
        rage.ischoking[v] = delta - 3 > 0
        rage.shifting[v] = shift < 0
        rage.shiftticks[v] = shift
        --rage.breaklc[v] == false
        --print("s: ", shift, " ch-3: ", delta - 3, " chkd: ", delta)
        ::non::
        --print(globals.chokedcommands())
    end
end
--credits: https://www.unknowncheats.me/forum/counterstrike-Shared-offensive/173989-math-hack-2-1-predicting-future-cs-application.html
utils.calcprediction = function(ent, dist)
    local ticki = globals.tickinterval()
    local G = cvar.sv_gravity:get_float() * ticki;
    local force = cvar.sv_jump_impulse:get_float() * ticki;
    local orig = {entity.get_origin(ent)}
    local oldorig = {entity.get_origin(ent)}
    local velocity = {entity.get_prop(ent, "m_vecVelocity")}
    local vec = velocity[3] > 0 and -G or force
    for i = 1, dist do
        oldorig = orig;
        orig = { orig[1] + velocity[1] * ticki, orig[2] + velocity[2] * ticki, orig[3] + (velocity[3] + vec) * ticki }
    end
    return orig
end

visuals.handlepredict = function()
    local lplayer = entity.get_local_player()
    if lplayer == nil or not entity.is_alive(lplayer) then return end
    local enemy = entity.get_players(true)
    if utils.multi_parse(tabs["Visuals"].predictbox[2], "Self") then
        local predicted = utils.calcprediction(lplayer, 14)
        utils.buildpredbox(lplayer, predicted)
    end
    if utils.multi_parse(tabs["Visuals"].predictbox[2], "Target") then
        if rage.target ~= nil and not entity.is_dormant(rage.target) then
            if rage.shifting[rage.target] and not rage.ischoking[rage.target] and vector(entity.get_prop(rage.target, "m_vecVelocity")):lengthsqr() > 1.1 then
                local predicted = utils.calcprediction(rage.target, 14)
                utils.buildpredbox(rage.target, predicted)
            end
        end
        --[[if #enemy > 0 then
            for _, v in pairs(enemy) do
                if rage.shifting[v] and not rage.ischoking[v] and vector(entity.get_prop(v, "m_vecVelocity")):lengthsqr() > 1.1 then
                    local predicted = utils.calcprediction(v, 14)
                    utils.buildpredbox(v, predicted)
                end
            end
        end]]
    end
end
ui.set_callback(tabs["Visuals"].predictbox[1], function(id)
    if ui.get(id) then
        client.set_event_callback("paint", visuals.handlepredict)
    else
        client.unset_event_callback("paint", visuals.handlepredict)
    end
end)
visuals.betternade = function()
    local lplayer = entity.get_local_player()
    if lplayer == nil then return end
    if utils.multi_parse(tabs["Visuals"].betternade[2], "Smoke") then
        local smke = entity.get_all("CSmokeGrenadeProjectile")
        local smokcolor = {ui.get(tabs["Visuals"].betternade.smoke[2])}
        local timecol = {ui.get(tabs["Visuals"].betternade[6])}
        for _, v in pairs(smke) do
            local origvec = {entity.get_prop(v, "m_vecOrigin")}
            if entity.get_prop(v, "m_bDidSmokeEffect") > 0 then
                if utils.multi_parse(tabs["Visuals"].betternade[3], "Radius") then
                    renderer.world_circle(origvec, 144, smokcolor)
                    if utils.multi_parse(tabs["Visuals"].betternade[4], "Fill radius") then
                        renderer.world_filled_circle(origvec, 144, {smokcolor[1], smokcolor[2], smokcolor[3], 120})
                    end
                end
                if utils.multi_parse(tabs["Visuals"].betternade[3], "Smoke Timer") then
                    local created_tick = entity.get_prop(v, "m_nSmokeEffectTickBegin")
                    if created_tick ~= nil then
                        local timesince = totime(globals.tickcount() - created_tick)
                        local tsc = {renderer.world_to_screen(origvec[1], origvec[2], origvec[3])}
                        local gtime = 18.04 - timesince
                        if tsc[1] ~= nil and gtime > 0 then
                            local gstime = string.format("%.1f", gtime)
                            local w, h = renderer.measure_text("-", gstime)
                            renderer.rectangle(tsc[1] - 13, tsc[2] - 4, 30, 8, 0, 0, 0, timecol[4] * (gtime <= 1 and gtime or 1))
                            renderer.rectangle(tsc[1] - 12, tsc[2] - 3, 28 * (1/18.04 * gtime), 6, timecol[1], timecol[2], timecol[3], timecol[4] * (gtime <= 1 and gtime or 1))
                            renderer.text(tsc[1] - w*0.4, tsc[2] - 14, timecol[1], timecol[2], timecol[3], timecol[4] * (gtime <= 1 and gtime or 1), "-", 0, gstime)
                        end
                    end
                end
            end
        end
    end
    if utils.multi_parse(tabs["Visuals"].betternade[2], "Fire") then
        local firee = entity.get_all("CInferno")
        local molcolor = {ui.get(tabs["Visuals"].betternade.fire[2])}
        local lteam = entity.get_prop(lplayer, "m_iTeamNum")
        local ff = cvar.mp_friendlyfire:get_int() == 0
        for _, v in pairs(firee) do
            local owner = entity.get_prop(v, "m_hOwnerEntity")
            local harmless = owner ~= lplayer and entity.get_prop(owner, "m_iTeamNum") == lteam and ff and utils.multi_parse(tabs["Visuals"].betternade[4], "Ignore harmless molotov")
            if not harmless then
                local origvec = {entity.get_prop(v, "m_vecOrigin")}
                if utils.multi_parse(tabs["Visuals"].betternade[3], "Radius") then
                    local deltay, deltax, deltaz = {}, {}, {}
                    local maxx, maxy;
                    for i=0, 63 do
                        table.insert(deltay, entity.get_prop(v, "m_fireYDelta", i))
                        table.insert(deltax, entity.get_prop(v, "m_fireXDelta", i))
                        table.insert(deltaz, entity.get_prop(v, "m_fireZDelta", i))
                    end
                    local maxz = math.max(unpack(deltaz))
                    local maxy = math.max(unpack(deltay))
                    local maxx = math.max(unpack(deltax))
                    local minz = math.min(unpack(deltaz))
                    local miny = math.min(unpack(deltay))
                    local minx = math.min(unpack(deltax))
                    local maxvec = {origvec[1]+maxx, origvec[2] + maxy, origvec[3]}
                    local minvec = {origvec[1]+minx, origvec[2] + miny, origvec[3]}
                    --renderer.world_circle(minvec, 5, {255, 255, 255, 255})
                    --renderer.world_circle(maxvec, 5, {255, 255, 255, 255})
                    local radius = math.sqrt((maxvec[1] - minvec[1])^2 + (maxvec[2] - minvec[2])^2)*0.5
                    origvec[1] = origvec[1] + (maxx + minx)*0.5
                    origvec[2] = origvec[2] + (maxy + miny)*0.5
                    renderer.world_circle(origvec, radius, molcolor)
                    if utils.multi_parse(tabs["Visuals"].betternade[4], "Fill radius") then
                        renderer.world_filled_circle(origvec, radius, {molcolor[1], molcolor[2], molcolor[3], 120})
                    end
                end
            end
        end
    end
end
ui.set_callback(tabs["Visuals"].betternade[1], function(id)
    if ui.get(id) then
        client.set_event_callback("paint", visuals.betternade)
    else
        client.unset_event_callback("paint", visuals.betternade)
    end
end)

-- Arms skin/sleeve integration
visuals.arms_tick = function()
    if not ui.get(tabs["Visuals"].arms_skin[1]) then return end
    local lplayer = entity.get_local_player()
    local team = lplayer and entity.get_prop(lplayer, "m_iTeamNum") or nil
    local t_no_sleeve = tabs["Visuals"].arms_skin[2]
    local t_skin = tabs["Visuals"].arms_skin[3]
    local ct_no_sleeve = tabs["Visuals"].arms_skin[4]
    local ct_skin = tabs["Visuals"].arms_skin[5]

    if team ~= 2 and team ~= 3 then return end

    -- Apply sleeve removal
    local no_sleeve_val = ui.get(team == 2 and t_no_sleeve or ct_no_sleeve)
    local materials = materialsystem.find_materials("sleeve")
    if materials ~= nil then
        for _, m in pairs(materials) do
            if m ~= nil then
                m:set_material_var_flag(2, no_sleeve_val)
            end
        end
    end

    -- Apply skin color via r_skin cvar
    local skin_combo = team == 2 and t_skin or ct_skin
    local selected_name = ui.get(skin_combo)
    local idx = nil
    for i, name in ipairs(visuals.arms_skin_colors) do
        if name == selected_name then idx = i - 1 break end
    end
    if idx ~= nil and visuals._arms_last_skin ~= idx then
        client.set_cvar("r_skin", idx)
        visuals._arms_last_skin = idx
    end
end

ui.set_callback(tabs["Visuals"].arms_skin[1], function(id)
    if ui.get(id) then
        client.set_event_callback("paint_ui", visuals.arms_tick)
    else
        client.unset_event_callback("paint_ui", visuals.arms_tick)
        -- reset sleeves visibility
        local materials = materialsystem.find_materials("sleeve")
        if materials ~= nil then
            for _, m in pairs(materials) do
                if m ~= nil then
                    m:set_material_var_flag(2, false)
                end
            end
        end
    end
end)

-- register if enabled on load
if ui.get(tabs["Visuals"].arms_skin[1]) then
    client.set_event_callback("paint_ui", visuals.arms_tick)
end
local _CONFIG = ui.get(skeetgui.configgui.presets.presets[1]) ~= nil and ui.get(skeetgui.configgui.presets.presets[1]) < 0 and ui.get(skeetgui.configgui.presets.presets[3]) or "Select Config"
ui.set_callback(skeetgui.configgui.presets.load, function(id)
    _CONFIG = ui.get(skeetgui.configgui.presets.presets[3])
end)
ui.set_callback(skeetgui.configgui.presets.save, function()
    _CONFIG = ui.get(skeetgui.configgui.presets.presets[3])
end)
utils.calcwtmk = function(tbl)
    local text = {"gamesense"}
    local lplayer = entity.get_local_player()
    if utils.in_table(tbl, "Name") then
        local cname = ui.get(tabs["Visuals"].watermark[4])
        local steam_username = panorama.open("CSGOHud").MyPersonaAPI.GetName()
        table.insert(text, cname == "" and steam_username or cname)
    end
    if utils.in_table(tbl, "Config") then
        table.insert(text, string.format("⚙%s", _CONFIG))
    end
    if utils.in_table(tbl, "Ticks") then
        table.insert(text, string.format("%d ticks", 1/globals.tickinterval()))
    end
    if utils.in_table(tbl, "Ping") and lplayer ~= nil then
        table.insert(text, string.format("%d ms", client.real_latency()*1000))
    end
    if utils.in_table(tbl, "FPS") then
        table.insert(text, string.format("%d fps", 1/globals.absoluteframetime()))
    end
    if utils.in_table(tbl, "Time") then
        local h, m, s = client.system_time()
        table.insert(text, string.format("%02d:%02d", h, m))
    end
    return text
end

visuals.watermark = function()
    local style = ui.get(tabs["Manipulations"].uistyle[1])
    
    local lplayer = entity.get_local_player()
    
    local display_name = ui.get(tabs["Visuals"].watermark[4])
    local steam_username = panorama.open("CSGOHud").MyPersonaAPI.GetName()
    local username = display_name == "" and steam_username or display_name
    
    local ping = 0
    if lplayer ~= nil then
        ping = client.latency() * 1000
    end
    ping = math.floor(ping)
    
    local hours, minutes = client.system_time()
    local time_str = string.format("%02d:%02d", hours, minutes)
    
    local info = ui.get(tabs["Visuals"].watermark[2]) or {}
    local text = utils.calcwtmk(info)
    local combined_text = table.concat(text, " | ")
    
    if style == "Astral" then
        local fps = math.floor(1/globals.absoluteframetime())

        -- respect Display toggles for Astral: Name/FPS/Ping/Time
        local info = ui.get(tabs["Visuals"].watermark[2]) or {}
        local show_user = utils.in_table(info, "Name")
        local show_fps = utils.in_table(info, "FPS")
        local show_ping = utils.in_table(info, "Ping")
        local show_time = utils.in_table(info, "Time")

        local label_r, label_g, label_b = 164, 168, 175
        local value_r, value_g, value_b = 157, 156, 218

        local colored_segments, plain_segments = {}, {}
        local function push(label, value)
            table.insert(colored_segments, string.format("\a%02x%02x%02xFF%s \a%02x%02x%02xFF%s", label_r, label_g, label_b, label, value_r, value_g, value_b, value))
            table.insert(plain_segments, string.format("%s %s", label, value))
        end
        if show_user then push("User", username) end
        if show_fps then push("FPS", tostring(fps)) end
        if show_ping then push("Ping", tostring(ping)) end
        if show_time then push("Time", time_str) end
        if #plain_segments == 0 then return end

        local astral_plain = table.concat(plain_segments, " ")
        local w, h = renderer.measure_text("b", astral_plain)
        
        local bg_width = w + 12
        local bg_height = h + 10
        local radius = 3
        local x = screen.x - bg_width - 10
        local y = 10
        
        rounded_rect(x, y, bg_width, bg_height, 54, 61, 74, 255, radius)
        
        local gradient_height = 2
        local gradient_y = y + radius
        local gradient_width = bg_width - (radius * 2)
        renderer.gradient(x + radius, gradient_y, gradient_width, gradient_height, 159, 161, 240, 255, 187, 145, 236, 255, true)
        
        local text_x = x + 6
        local text_y = y + gradient_height + radius + 2
        
        local colored_text = table.concat(colored_segments, " ")
        renderer.text(text_x, text_y, 255, 255, 255, 255, "b", 0, colored_text)
    elseif style == "Skeet" then
        local gradient = ui.get(tabs["Manipulations"].uistyle[2])
        local w, h = renderer.measure_text(nil, combined_text)
        if wtoldw ~= nil and wtoldw ~= w then
            w = logs.anim("WTW", wtoldw, w, 0.5, wtoldw > w and math.floor or math.ceil)
        end
        wtoldw = w
        wtoldw = wtoldw
        if wtoldw ~= wtoldw or w ~= w then
            wtoldw = 0
            w = 0
        end
        renderer.rectangle(screen.x - w - 24, 8, w + 18, h*2 + (gradient and 4 or 2), g[1], g[2], g[3], 255)
        renderer.rectangle(screen.x - w - 23, 9, w + 16, h*2 + (gradient and 2 or 0), a[1], a[2], a[3], 255)
        renderer.rectangle(screen.x - w - 22, 10, w + 14, h*2 - (gradient and 0 or 2), b[1], b[2], b[3], 255)
        renderer.rectangle(screen.x - w - 20, 12, w + 10, h*2 - (gradient and 4 or 6), a[1], a[2], a[3], 255)
        renderer.texture(jg, screen.x - w - 19, 13, w + 8, h*2 - (gradient and 6 or 8), 255, 255, 255, 255, "r")
        if gradient then
            renderer.gradient(screen.x - w - 18, 14, w/2 + 7.5, 1, g1[1], g1[2], g1[3], 255, g2[1], g2[2], g2[3], 255, true)
            renderer.gradient(screen.x - w - 18 + w/2 + 7.5, 14, w/2 - 1, 1, g2[1], g2[2], g2[3], 255, g3[1], g3[2], g3[3], 255, true)
            renderer.gradient(screen.x - w - 18, 15, w/2 + 7.5, 1, g1[1], g1[2], g1[3], 120, g2[1], g2[2], g2[3], 120, true)
            renderer.gradient(screen.x - w - 18 + w/2 + 7.5, 15, w/2 - 1, 1, g2[1], g2[2], g2[3], 120, g3[1], g3[2], g3[3], 120, true)
            renderer.gradient(screen.x - w - 18, 16, w/2 + 7.5, 1, g1[1], g1[2], g1[3], 60, g2[1], g2[2], g2[3], 60, true)
            renderer.gradient(screen.x - w - 18 + w/2 + 7.5, 16, w/2 - 1, 1, g2[1], g2[2], g2[3], 60, g3[1], g3[2], g3[3], 60, true)
        end
        renderer.text(screen.x - w*0.5 - 14, h + 6 + (gradient and 4 or 2), 255, 255, 255, 255, "c", 0, combined_text)
    elseif style == "晨花" then
        local glow = ui.get(tabs["Manipulations"].uistyle[4])
        local color = {ui.get(tabs["Manipulations"].uistyle[3])}
        local w, h = renderer.measure_text(nil, combined_text)
        if glow then utils.shadow(screen.x - w - 11, h, w + 4, h*1.5, 8, 8, {color[1], color[2], color[3], 50}, {color[1], color[2], color[3], 50}) end
        rounded_rect(screen.x - w - 10, h, w + 4, h*1.5, color[1], color[2], color[3], color[4], 5)
        renderer.text(screen.x - w - 8, h + 2, 240, 240, 240, 240, nil, 0, combined_text)
    elseif style == "Methamod" then
        local color = {ui.get(tabs["Manipulations"].uistyle[3])}
        local w, h = renderer.measure_text(nil, combined_text)
        if wtoldw ~= nil and wtoldw ~= w and wtoldw == wtoldw then
            w = logs.anim("WTW", wtoldw, w, 0.5, wtoldw > w and math.floor or math.ceil)
        end
        wtoldw = w
        renderer.rectangle(screen.x - w - 22, 10, w + 13, h*1.7, 15, 15, 15, color[4])
        renderer.rectangle(screen.x - w - 22, 10, w + 13, 2, color[1], color[2], color[3], 255)
        renderer.text(screen.x - w*0.5 - 15, h*0.85 + 10, 255, 255, 255, 255, "c", 0, combined_text)
    elseif style == "Stasis" then
        local color = {ui.get(tabs["Manipulations"].uistyle[3])}
        local w, h = renderer.measure_text(nil, combined_text)
        if wtoldw ~= nil and wtoldw ~= w and wtoldw == wtoldw then
            w = logs.anim("WTW", wtoldw, w, 0.5, wtoldw > w and math.floor or math.ceil)
        end
        wtoldw = w
        renderer.rectangle(screen.x - w - 22, 10, w + 13, h*1.7, 0, 0, 0, 50)
        --utils.shadow(screen.x - w - 22, 10, w + 13, h*1.7, 8, 8, {15, 15, 15, 200}, {15, 15, 15, 10}) really good loking shadow
        renderer.text(screen.x - w*0.5 - 15, h*0.85 + 10, 255, 255, 255, 255, "c", 0, combined_text)
    end
end


-- Watermark is now handled in main paint_ui callback

--utils.shadow(x, y, w, h, width, rounding, accent, accent_inner)
visuals.keyscode = {
    [0x01] = "M1",
    [0x02] = "M2",
    [0x03] = "Cancel",
    [0x04] = "M3",
    [0x05] = "M4",
    [0x06] = "M5",
    [0x08] = "Backspase",
    [0x09] = "Tab",
    [0x0C] = "Clear",
    [0x0D] = "Enter",
    [0x10] = "Shift",
    [0x11] = "Ctrl",
    [0x12] = "Alt",
    [0x13] = "Pause",
    [0x14] = "Caps",
    [0x1B] = "Esc",
    [0x20] = "Space",
    [0x21] = "PU",
    [0x22] = "PD",
    [0x23] = "END",
    [0x24] = "HM",
    [0x25] = "⮜",
    [0x26] = "⮝",
    [0x27] = "⮞",
    [0x28] = "⮟",
    [0x29] = "Select",
    [0x2A] = "Print",
    [0x2B] = "Exec",
    [0x2C] = "PS",
    [0x2D] = "Ins",
    [0x2E] = "Del",
    [0x2F] = "Help",
    [0x30] = 0,
    [0x31] = 1,
    [0x32] = 2,
    [0x33] = 3,
    [0x34] = 4,
    [0x35] = 5,
    [0x36] = 6,
    [0x37] = 7,
    [0x38] = 8,
    [0x39] = 9,
    [0x41] = "A",
    [0x42] = "B",
    [0x43] = "C",
    [0x44] = "D",
    [0x45] = "E",
    [0x46] = "F",
    [0x47] = "G",
    [0x48] = "H",
    [0x49] = "I",
    [0x4A] = "J",
    [0x4B] = "K",
    [0x4C] = "L",
    [0x4D] = "M",
    [0x4E] = "N",
    [0x4F] = "O",
    [0x50] = "P",
    [0x51] = "Q",
    [0x52] = "R",
    [0x53] = "S",
    [0x54] = "T",
    [0x55] = "U",
    [0x56] = "V",
    [0x57] = "W",
    [0x58] = "X",
    [0x59] = "Y",
    [0x5A] = "Z",
    [0x5B] = "Lwin",
    [0x5C] = "Rwin",
    [0x60] = "Num0",
    [0x61] = "Num1",
    [0x62] = "Num2",
    [0x63] = "Num3",
    [0x64] = "Num4",
    [0x65] = "Num5",
    [0x66] = "Num6",
    [0x67] = "Num7",
    [0x68] = "Num8",
    [0x69] = "Num9",
    [0x6A] = "*",
    [0x6B] = "+",
    [0x6C] = "Sep",
    [0x6D] = "-",
    [0x6F] = "/",
    [0x70] = "F1",
    [0x71] = "F2",
    [0x72] = "F3",
    [0x73] = "F4",
    [0x74] = "F5",
    [0x75] = "F6",
    [0x76] = "F7",
    [0x77] = "F8",
    [0x78] = "F9",
    [0x79] = "F10",
    [0x7A] = "F11",
    [0x7B] = "F12",
    [0x7C] = "F13",
    [0x7D] = "F14",
    [0x7E] = "F15",
    [0x7F] = "F16",
    [0x80] = "F17",
    [0x81] = "F18",
    [0x82] = "F19",
    [0x83] = "F20",
    [0x84] = "F21",
    [0x85] = "F22",
    [0x86] = "F23",
    [0x87] = "F24",
    [0x90] = "Numlk",
    [0x91] = "SL",
    [0xA0] = "Shift",
    [0xA1] = "RShift",
    [0xA2] = "Ctrl",
    [0xA3] = "RCtrl",
    [0xA4] = "Alt",
    [0xA5] = "RAlt",
    [0xBA] = ";",
    [0xBB] = "+",
    [0xBC] = ",",
    [0xBD] = "-",
    [0xBE] = ".",
    [0xBF] = "?",
    [0xC0] = "~",
    [0xDB] = "[",
    [0xDC] = "\\",
    [0xDD] = "]",
    [0xDE] = "'",
    [0xE2] = "<>",
}
visuals.keybinding = {
    {"Double tap", skeetgui.ragegui.aimbot.double_tap},
    {"Onshot anti-aimbot", skeetgui.aagui.other.on_shot_antiaim},
    {"Force body aim", skeetgui.ragegui.aimbot.force_body_aim},
    {"Damage override", skeetgui.ragegui.aimbot.minimum_damage_override},
    {"Force safe point", skeetgui.ragegui.aimbot.force_safe_point},
    {"Quick peek assist", skeetgui.ragegui.other.quick_peek_assist},
    {"Duck peek assist", skeetgui.ragegui.other.duck_peek_assist},
    {"Freestands", tabs["Anti-Aimbot"].freestand[1]},
    {"Force head aim", tabs["Rage"].onlyhs},
    {"Jumpshot", tabs["Rage"].jumpshot},
    {"Anti-aimbot inverted", tabs["Anti-Aimbot"].inverter[1]},
    {"Edgeyaw", tabs["Anti-Aimbot"].edgeyaw[1]},
    {"Ping spike", skeetgui.miscgui.misc.ping_spike},
    {"Hitchance override", tabs["Rage"].hitchance},
    {"Body on lethal", tabs["Rage"].lethal},
    {"Dormant aimbot", tabs["Rage"].dormant},
    {"Lower body yaw breaker", tabs["Anti-Aimbot"].lby_breaker},
    {"Delay shot", tabs["Rage"].delay_shot[1]},
    {"Free look", skeetgui.miscgui.misc.free_look},
    {"Auto smoke", tabs["Misc"].autosmoke},
}
visuals.dbknames = database.read("expensive::keynames") or {}
for k, v in pairs(visuals.dbknames) do
    visuals.keybinding[k][1] = v
end
visuals.currentkeyname = function()
    local kname = visuals.keybinding[ui.get(tabs["Manipulations"].keynames[1])+1][1]
    if kname == "Disabled" then
        kname = "\aFF0000FFDisabled"
    elseif kname ~= visuals.keynames[ui.get(tabs["Manipulations"].keynames[1])+1] then
        kname = "\aE6D349FF"..kname
    end
    ui.set(tabs["Manipulations"].keynames[2], "Current name: "..kname)
end
ui.set_callback(tabs["Manipulations"].keynames[1], visuals.currentkeyname)
visuals.setkeyname = function()
    local cname = ui.get(tabs["Manipulations"].keynames[3])
    if cname == nil or cname == "" then return end
    local key = ui.get(tabs["Manipulations"].keynames[1]) + 1
    if string.len(table.concat(utils.split(cname))) < 1 then
        ui.set(tabs["Manipulations"].keynames[3], "")
        visuals.keybinding[key][1] = "Disabled"
        visuals.dbknames[key] = "Disabled"
        goto updatestring
    end
    visuals.keybinding[key][1] = cname
    visuals.dbknames[key] = cname
    ui.set(tabs["Manipulations"].keynames[3], "")
    ::updatestring::
    visuals.currentkeyname()
end
visuals.restorekeyname = function()
    local key = ui.get(tabs["Manipulations"].keynames[1]) + 1
    visuals.dbknames[key] = nil
    visuals.keybinding[key][1] = visuals.keynames[key]
    visuals.currentkeyname()
end
ui.set_callback(tabs["Manipulations"].keynames[4], visuals.setkeyname)
ui.set_callback(tabs["Manipulations"].keynames[5], visuals.restorekeyname)
visuals.modes = {
    "holding",
    "toggled",
    "disabled",
    "~",
}
utils.menukey = {ui.get(skeetgui.miscgui.settings.menu_key)}
visuals.bindings = {}
utils.getlengst = function()
    local bind = ""
    for _, v in ipairs(visuals.bindings) do
        if ui.is_menu_open() then
            if bind == "Menu open" then
                if v[1] ~= "Menu open" and v[2] and v[3][2] > 0 then bind = v[1] end
            else
                if v[2] and v[3][2] > 0 then bind = utils.max(bind, v[1], renderer.measure_text, "c") end
            end
        elseif v[1] ~= "Menu open" then
            if v[2] and v[3][2] > 0 then bind = utils.max(bind, v[1], renderer.measure_text, "c") end
        end
        --if k ~= "Menu open" and v[1] and v[2][2] > 0 and ui.is_menu_open() then bind = utils.max(bind, k, renderer.measure_text, "c") end
    end
    return string.len(bind) > 0 and bind or nil
end
visuals.alphakeyb = {0, 0, 0, keys = { 0 }}
visuals.keyoldw = nil
visuals.keybinds = function()
    if not ui.get(tabs["Visuals"].keybinds[1]) or not entity.get_local_player() then
        if visuals.alphakeyb[1] > 0 then
            visuals.alphakeyb[1] = math.floor(utils.lerp(visuals.alphakeyb[1], 0, 0.095))
            visuals.alphakeyb[2] = math.floor(utils.lerp(visuals.alphakeyb[2], 0, 0.095))
            visuals.alphakeyb[3] = math.floor(utils.lerp(visuals.alphakeyb[3], 0, 0.095))
            for k, v in pairs(visuals.alphakeyb.keys) do
                visuals.alphakeyb.keys[k] = math.floor(utils.lerp(visuals.alphakeyb.keys[k], 0, 0.095))
            end
        else
            return
        end
    end
    (function()
        for k, v in ipairs(visuals.keybinding) do
            k = k + 1
            if v[2] == nil or v[1] == "Disabled" then goto skip end
            if type(v[2]) == "number" then
                visuals.bindings[k] = {v[1], ui.get(v[2]), {ui.get(v[2])}}
            else
                local enabled = ui.get(v[2][1])
                local bool, mode, key = ui.get(v[2][2])
                if mode == 3 then
                    visuals.bindings[k] = {v[1], enabled and not bool, {bool, mode, key}}
                else
                    visuals.bindings[k] = {v[1], enabled and bool, {bool, mode, key}}
                end
            end
            ::skip::
        end
    end)()
    local leng = utils.getlengst()
    visuals.bindings[1] = {"Menu open", (ui.get(tabs["Visuals"].keybinds[1]) and ui.is_menu_open() and (leng == "Menu open" or leng == nil)), {[2] = 4, [3] = utils.menukey[3]}}
    if visuals.bindings[1][2] then leng = "Menu open" end
    if leng == nil then
        visuals.alphakeyb[1] = math.floor(utils.lerp(visuals.alphakeyb[1], 0, 0.35))
        visuals.alphakeyb[2] = math.floor(utils.lerp(visuals.alphakeyb[2], 0, 0.35))
        visuals.alphakeyb[3] = math.floor(utils.lerp(visuals.alphakeyb[3], 0, 0.35))
    else
        visuals.alphakeyb[1] = math.ceil(utils.lerp(visuals.alphakeyb[1], 255, 0.35))
        visuals.alphakeyb[2] = math.ceil(utils.lerp(visuals.alphakeyb[2], 120, 0.35))
        visuals.alphakeyb[3] = math.ceil(utils.lerp(visuals.alphakeyb[3], 60, 0.35))
    end
    if visuals.alphakeyb[1] ~= visuals.alphakeyb[1] then
        visuals.alphakeyb[1] = 0
        visuals.alphakeyb[2] = 0
        visuals.alphakeyb[3] = 0
    end
    local style = ui.get(tabs["Manipulations"].uistyle[1])
    if style == "Skeet" then
        local w, h = renderer.measure_text(nil, leng)
        if visuals.keyoldw ~= nil and visuals.keyoldw ~= w then
            w = logs.anim("KEYW", visuals.keyoldw, w, 0.5, visuals.keyoldw > w and math.floor or math.ceil)
        end
        visuals.keyoldw = w
        if w < 0 or visuals.keyoldw < 0 then
            w = 0
            visuals.keyoldw = 0
        end
        if w % 2 == 1 then
            w = w + 1
        end
        local gradient = ui.get(tabs["Manipulations"].uistyle[2])
        --w: 42, h: 12
        renderer.rectangle(utils.keypos.x, utils.keypos.y, 110 + w*0.8, h*2 + (gradient and 4 or 2), g[1], g[2], g[3], visuals.alphakeyb[1]) -- w + 18
        renderer.rectangle(utils.keypos.x + 1, utils.keypos.y + 1, 110 + w*0.8 - 2, h*2 + (gradient and 2 or 0), a[1], a[2], a[3], visuals.alphakeyb[1])
        renderer.rectangle(utils.keypos.x + 2, utils.keypos.y + 2, 110 + w*0.8 - 4, h*2 - (gradient and 0 or 2), b[1], b[2], b[3], visuals.alphakeyb[1])
        renderer.rectangle(utils.keypos.x + 4, utils.keypos.y + 4, 110 + w*0.8 - 8, h*2 - (gradient and 4 or 6), a[1], a[2], a[3], visuals.alphakeyb[1])
        renderer.texture(jg, utils.keypos.x + 5, utils.keypos.y + 5, 110 + w*0.8 - 10, h*2 - (gradient and 6 or 8), 255, 255, 255, visuals.alphakeyb[1], "r")
        if gradient then
            renderer.gradient(utils.keypos.x + 6, utils.keypos.y + 6, (110 + w*0.8 - 10)*0.5, 1, g1[1], g1[2], g1[3], visuals.alphakeyb[1], g2[1], g2[2], g2[3], visuals.alphakeyb[1], true)
            renderer.gradient(utils.keypos.x + 6 + (110 + w*0.8 - 10)*0.5, utils.keypos.y + 6, (110 + w*0.8 - 10)*0.5 - (w%10 == 0 and 2 or 1), 1, g2[1], g2[2], g2[3], visuals.alphakeyb[1], g3[1], g3[2], g3[3], visuals.alphakeyb[1], true)
            renderer.gradient(utils.keypos.x + 6, utils.keypos.y + 7, (110 + w*0.8 - 10)*0.5, 1, g1[1], g1[2], g1[3], visuals.alphakeyb[2], g2[1], g2[2], g2[3], visuals.alphakeyb[2], true)
            renderer.gradient(utils.keypos.x + 6 + (110 + w*0.8 - 10)*0.5, utils.keypos.y + 7, (110 + w*0.8 - 10)*0.5 - (w%10 == 0 and 2 or 1), 1, g2[1], g2[2], g2[3], visuals.alphakeyb[2], g3[1], g3[2], g3[3], visuals.alphakeyb[2], true)
            renderer.gradient(utils.keypos.x + 6, utils.keypos.y + 8, (110 + w*0.8 - 10)*0.5, 1, g1[1], g1[2], g1[3], visuals.alphakeyb[3], g2[1], g2[2], g2[3], visuals.alphakeyb[3], true)
            renderer.gradient(utils.keypos.x + 6 + (110 + w*0.8 - 10)*0.5, utils.keypos.y + 8, (110 + w*0.8 - 10)*0.5 - (w%10 == 0 and 2 or 1), 1, g2[1], g2[2], g2[3], visuals.alphakeyb[3], g3[1], g3[2], g3[3], visuals.alphakeyb[3], true)
        end
        renderer.text(utils.keypos.x + (110 + w*0.8)*0.5, utils.keypos.y + h + (gradient and 3 or 1), 255, 255, 255, visuals.alphakeyb[1], "c", 0, "keybinds")
        local hmod = 0
        for _, v in ipairs(visuals.bindings) do
            local k = v[1]
            visuals.alphakeyb.keys[k] = visuals.alphakeyb.keys[k] or 0
            if v[2] and v[3][2] > 0 then
                visuals.alphakeyb.keys[k] = math.ceil(utils.lerp(visuals.alphakeyb.keys[k], 255, 0.9))
            else
                visuals.alphakeyb.keys[k] = math.floor(utils.lerp(visuals.alphakeyb.keys[k], 0, 0.9))
            end
            if visuals.alphakeyb.keys[k] ~= visuals.alphakeyb.keys[k] then visuals.alphakeyb.keys[k] = 0 end
            if visuals.alphakeyb.keys[k] > 0 then
                renderer.text(utils.keypos.x + 4, utils.keypos.y + h*2 + (gradient and 4 or 2) + hmod, 255, 255, 255, 255, "", 0, k)
                renderer.text(utils.keypos.x + 107 + w*0.8, utils.keypos.y + h*2 + (gradient and 4 or 2) + hmod, 255, 255, 255, visuals.alphakeyb.keys[k], "r", 0, "["..visuals.modes[v[3][2]].."]")
                hmod = hmod + h
            end
        end
    elseif style == "晨花" then
        local color = {ui.get(tabs["Manipulations"].uistyle[3])}
        local wh, hw = renderer.measure_text(nil, "keybinds")
        local glow = ui.get(tabs["Manipulations"].uistyle[4])
        if glow then utils.shadow(utils.keypos.x, utils.keypos.y, wh*1.5, hw*1.5, 10, 8, {color[1], color[2], color[3], 50 * visuals.alphakeyb[1]/255}, {color[1], color[2], color[3], 50 * visuals.alphakeyb[1]/255}) end
        rounded_rect(utils.keypos.x, utils.keypos.y, wh*1.5, hw*1.5, color[1], color[2], color[3], color[4] * visuals.alphakeyb[1]/255, 5)
        renderer.text(utils.keypos.x + wh*0.3 - 1, utils.keypos.y + hw*0.2, 255, 255, 255, visuals.alphakeyb[1], nil, 0, "keybinds")
        --renderer.text(utils.keypos.x + 4, utils.keypos.y + hw*0.3 - 1, 255, 255, 255, visuals.alphakeyb[1], "", 0, "")
        local hmod = 0
        for _, v in ipairs(visuals.bindings) do
            local k = v[1]
            visuals.alphakeyb.keys[k] = visuals.alphakeyb.keys[k] or 0
            if v[2] and v[3][2] > 0 then
                visuals.alphakeyb.keys[k] = math.ceil(utils.lerp(visuals.alphakeyb.keys[k], 255, 0.9))
            else
                visuals.alphakeyb.keys[k] = math.floor(utils.lerp(visuals.alphakeyb.keys[k], 0, 0.9))
            end
            if visuals.alphakeyb.keys[k] > 0 then
                local weight, height = renderer.measure_text(nil, k)
                local keyc = visuals.keyscode[v[3][3]]
                
                local keyw, keyh = renderer.measure_text(nil, keyc)
                rounded_rect(utils.keypos.x + 2, utils.keypos.y + height*2 + hmod - 1, keyw*1.8 + (keyw < 6 and 6 or 0), keyh*1.2 + 2, 50, 50, 50, 50 * visuals.alphakeyb.keys[k]/255, 5)
                if keyc ~= nil then renderer.text(utils.keypos.x + (string.len(keyc) > 1 and keyw*0.5 or 4) + (keyw < 6 and 2 or 0), utils.keypos.y + height*2 + hmod, 255, 255, 255, 255, nil, 0, keyc) end
                rounded_rect(utils.keypos.x + keyw*2 + (keyw < 6 and 8 or 2), utils.keypos.y + height*2 + hmod - 1, weight*1.1, height*1.2 + 2, 50, 50, 50, 50 * visuals.alphakeyb.keys[k]/255, 5)
                renderer.text(utils.keypos.x + keyw*2 + (keyw < 6 and 10 or 4), utils.keypos.y + height*2 + hmod, 255, 255, 255, 255, nil, 0, k)
                hmod = hmod + height*1.5
            end
        end
    elseif style == "Methamod" then
        local color = {ui.get(tabs["Manipulations"].uistyle[3])}
        local w, h = renderer.measure_text(nil, leng)
        if visuals.keyoldw ~= nil and visuals.keyoldw ~= w then
            w = logs.anim("KEYW", visuals.keyoldw, w, 0.5, visuals.keyoldw > w and math.floor or math.ceil)
        end
        visuals.keyoldw = w
        if w < 0 or visuals.keyoldw < 0 then
            w = 0
            visuals.keyoldw = 0
        end
        if w % 2 == 1 then
            w = w + 1
        end
        renderer.rectangle(utils.keypos.x, utils.keypos.y, 100 + w*0.75, h*1.7, 15, 15, 15, color[4] * visuals.alphakeyb[1]/255)
        renderer.rectangle(utils.keypos.x, utils.keypos.y, 100 + w*0.75, 2, color[1], color[2], color[3], visuals.alphakeyb[1])
        renderer.text(utils.keypos.x + (100 + w*0.75)*0.5, utils.keypos.y + h*0.85, 255, 255, 255, visuals.alphakeyb[1], "c", 0, "keybinds")
        local hmod = 0
        for _, v in ipairs(visuals.bindings) do
            local k = v[1]
            visuals.alphakeyb.keys[k] = visuals.alphakeyb.keys[k] or 0
            if v[2] and v[3][2] > 0 then
                visuals.alphakeyb.keys[k] = math.ceil(utils.lerp(visuals.alphakeyb.keys[k], 255, 0.9))
            else
                visuals.alphakeyb.keys[k] = math.floor(utils.lerp(visuals.alphakeyb.keys[k], 0, 0.9))
            end
            if visuals.alphakeyb.keys[k] > 0 then
                renderer.text(utils.keypos.x + 4, utils.keypos.y + h*2 + hmod - 1, 255, 255, 255, 255, "", 0, k)
                renderer.text(utils.keypos.x + 98 + w*0.75, utils.keypos.y + h*2 + hmod - 1, 255, 255, 255, visuals.alphakeyb.keys[k], "r", 0, "["..visuals.modes[v[3][2]].."]")
                hmod = hmod + h + 2
            end
        end
    elseif style == "Astral" then
        local active_binds = {}
        for _, v in ipairs(visuals.bindings) do
            local k = v[1]
            visuals.alphakeyb.keys[k] = visuals.alphakeyb.keys[k] or 0
            if v[2] and v[3][2] > 0 then
                visuals.alphakeyb.keys[k] = math.ceil(utils.lerp(visuals.alphakeyb.keys[k], 255, 0.9))
                table.insert(active_binds, {k, visuals.modes[v[3][2]], visuals.alphakeyb.keys[k]})
            else
                visuals.alphakeyb.keys[k] = math.floor(utils.lerp(visuals.alphakeyb.keys[k], 0, 0.9))
            end
            if visuals.alphakeyb.keys[k] ~= visuals.alphakeyb.keys[k] then 
                visuals.alphakeyb.keys[k] = 0 
            end
        end
        
        if #active_binds > 0 then
            local title_w, title_h = renderer.measure_text("b", "Binds")
            local max_bind_width = 0
            
            for _, bind in ipairs(active_binds) do
                local bind_text = bind[1] .. " [" .. bind[2] .. "]"
                local w, h = renderer.measure_text("b", bind_text)
                max_bind_width = math.max(max_bind_width, w)
            end
            
            local bg_width = math.max(title_w + 12, max_bind_width + 12)
            local bg_height = title_h + 8 + (#active_binds * 16) + 8
            local radius = 3
            
            rounded_rect(utils.keypos.x, utils.keypos.y, bg_width, bg_height, 54, 61, 74, visuals.alphakeyb[1], radius)
            
            local gradient_height = 2
            local gradient_y = utils.keypos.y + radius
            local gradient_width = bg_width - (radius * 2)
            renderer.gradient(utils.keypos.x + radius, gradient_y, gradient_width, gradient_height, 159, 161, 240, visuals.alphakeyb[1], 187, 145, 236, visuals.alphakeyb[1], true)
           
            renderer.text(utils.keypos.x + bg_width / 2, utils.keypos.y + gradient_height + radius + 6, 164, 168, 175, visuals.alphakeyb[1], "cb", 0, "Binds")
           
            local entry_y = utils.keypos.y + gradient_height + radius + title_h + 10
            for _, bind in ipairs(active_binds) do
                if bind[3] > 0 then
                    renderer.text(utils.keypos.x + 6, entry_y, 164, 168, 175, bind[3], "b", 0, bind[1])
                    renderer.text(utils.keypos.x + bg_width - 6, entry_y, 157, 156, 218, bind[3], "rb", 0, "[" .. bind[2] .. "]")
                    entry_y = entry_y + 16
                end
            end
        end
    end
end
utils.get_speclist = function()
    local speclist = {}
    local all = entity.get_all("CCSPlayer")
    for _, v in pairs(all) do
        local m_iObserverMode = entity.get_prop(v, 'm_iObserverMode')
        local m_hObserverTarget = entity.get_prop(v, 'm_hObserverTarget')
        if m_hObserverTarget ~= nil and m_hObserverTarget <= 64 and not entity.is_alive(v) and (m_iObserverMode == 4 or m_iObserverMode == 5) then
            if speclist[m_hObserverTarget] == nil then speclist[m_hObserverTarget] = {} end
            if v == entity.get_local_player() then
                speclist.obs = m_hObserverTarget
                goto comp
            end
            table.insert(speclist[m_hObserverTarget], {v, entity.get_player_name(v)})
            ::comp::
        end
    end
    return speclist
end
utils.get_avatar = function(ent)
    local steam_id = entity.get_steam64(ent)
    local avatar = images.get_steam_avatar(steam_id)

    if steam_id == nil or avatar == nil then
        return nil
    end

    return renderer.load_rgba(avatar.contents, avatar.width, avatar.height)
end
visuals.alphaspec = {0, 0, 0, specs = {}}
visuals.specoldw = nil
visuals.spectators = function()
    if not ui.get(tabs["Visuals"].spectators[1]) or not entity.get_local_player() then
        if visuals.alphaspec[1] > 0 then
            visuals.alphaspec[1] = math.floor(utils.lerp(visuals.alphaspec[1], 0, 0.35))
            visuals.alphaspec[2] = math.floor(utils.lerp(visuals.alphaspec[2], 0, 0.35))
            visuals.alphaspec[3] = math.floor(utils.lerp(visuals.alphaspec[3], 0, 0.35))
            for k, v in pairs(visuals.alphaspec.specs) do
                visuals.alphaspec.specs[k] = math.floor(utils.lerp(visuals.alphaspec.specs[k], 0, 0.35))
            end
        else
            return
        end
    end
    local lplayer = entity.get_local_player()
    local avatars = ui.get(tabs["Visuals"].spectators[2])
    local players = utils.get_speclist()
    local leng = (function()
        local spec = ""
        local isd = entity.is_alive(lplayer)
        local ps = players[not isd and entity.get_prop(entity.get_local_player(), "m_hObserverTarget") or entity.get_local_player()]
        if ps == nil then return ps end
        for _, v in pairs(ps) do
            spec = utils.max(spec, v[2], renderer.measure_text, "c")
        end
        return string.len(spec) > 0 and spec or nil
    end)()
    if leng == nil and not ui.is_menu_open() then
        visuals.alphaspec[1] = math.floor(utils.lerp(visuals.alphaspec[1], 0, 0.35))
        visuals.alphaspec[2] = math.floor(utils.lerp(visuals.alphaspec[2], 0, 0.35))
        visuals.alphaspec[3] = math.floor(utils.lerp(visuals.alphaspec[3], 0, 0.35))
    else
        visuals.alphaspec[1] = math.ceil(utils.lerp(visuals.alphaspec[1], 255, 0.35))
        visuals.alphaspec[2] = math.ceil(utils.lerp(visuals.alphaspec[2], 120, 0.35))
        visuals.alphaspec[3] = math.ceil(utils.lerp(visuals.alphaspec[3], 60, 0.35))
    end
    local w, h = renderer.measure_text(nil, leng or "spectators")
    if visuals.specoldw ~= nil and visuals.specoldw ~= w then
        w = logs.anim("SPECW", visuals.specoldw, w, 0.5, visuals.specoldw > w and math.floor or math.ceil)
    end
    visuals.specoldw = w
    local style = ui.get(tabs["Manipulations"].uistyle[1])
    if style == "Skeet" then
        if w % 2 == 1 then
            w = w + 1
        end
        local gradient = ui.get(tabs["Manipulations"].uistyle[2])
        renderer.rectangle(utils.specpos.x, utils.specpos.y, 110 + w*0.5, h*2 + (gradient and 4 or 2), g[1], g[2], g[3], visuals.alphaspec[1]) -- w + 18
        renderer.rectangle(utils.specpos.x + 1, utils.specpos.y + 1, 110 + w*0.5 - 2, h*2 + (gradient and 2 or 0), a[1], a[2], a[3], visuals.alphaspec[1])
        renderer.rectangle(utils.specpos.x + 2, utils.specpos.y + 2, 110 + w*0.5 - 4, h*2 - (gradient and 0 or 2), b[1], b[2], b[3], visuals.alphaspec[1])
        renderer.rectangle(utils.specpos.x + 4, utils.specpos.y + 4, 110 + w*0.5 - 8, h*2 - (gradient and 4 or 6), a[1], a[2], a[3], visuals.alphaspec[1])
        renderer.texture(jg, utils.specpos.x + 5, utils.specpos.y + 5, 110 + w*0.5 - 10, h*2 - (gradient and 6 or 8), 255, 255, 255, visuals.alphaspec[1], "r")
        if gradient then
            renderer.gradient(utils.specpos.x + 6, utils.specpos.y + 6, (110 + w*0.5 - 10)*0.5, 1, g1[1], g1[2], g1[3], visuals.alphaspec[1], g2[1], g2[2], g2[3], visuals.alphaspec[1], true)
            renderer.gradient(utils.specpos.x + 6 + (110 + w*0.5 - 10)*0.5, utils.specpos.y + 6, (110 + w*0.5 - 10)*0.5 - (w%10 == 0 and 2 or 1), 1, g2[1], g2[2], g2[3], visuals.alphaspec[1], g3[1], g3[2], g3[3], visuals.alphaspec[1], true)
            renderer.gradient(utils.specpos.x + 6, utils.specpos.y + 7, (110 + w*0.5 - 10)*0.5, 1, g1[1], g1[2], g1[3], visuals.alphaspec[2], g2[1], g2[2], g2[3], visuals.alphaspec[2], true)
            renderer.gradient(utils.specpos.x + 6 + (110 + w*0.5 - 10)*0.5, utils.specpos.y + 7, (110 + w*0.5 - 10)*0.5 - (w%10 == 0 and 2 or 1), 1, g2[1], g2[2], g2[3], visuals.alphaspec[2], g3[1], g3[2], g3[3], visuals.alphaspec[2], true)
            renderer.gradient(utils.specpos.x + 6, utils.specpos.y + 8, (110 + w*0.5 - 10)*0.5, 1, g1[1], g1[2], g1[3], visuals.alphaspec[3], g2[1], g2[2], g2[3], visuals.alphaspec[3], true)
            renderer.gradient(utils.specpos.x + 6 + (110 + w*0.5 - 10)*0.5, utils.specpos.y + 8, (110 + w*0.5 - 10)*0.5 - (w%10 == 0 and 2 or 1), 1, g2[1], g2[2], g2[3], visuals.alphaspec[3], g3[1], g3[2], g3[3], visuals.alphaspec[3], true)
        end
        renderer.text(utils.specpos.x + (110 + w*0.5)*0.5, utils.specpos.y + h + (gradient and 3 or 1), 255, 255, 255, visuals.alphaspec[1], "c", 0, "spectators")
        local hmod = 0
        local isd = entity.is_alive(lplayer)
        if players == nil then return end
        local ps = players[not isd and entity.get_prop(lplayer, "m_hObserverTarget") or lplayer]
        if ps == nil then return end
        for k, v in ipairs(ps) do
            local wh, hw = renderer.measure_text(nil, v[2])
            local validv = true
            if avatars then
                local avatar = utils.get_avatar(v[1])
                if avatar ~= nil then
                    renderer.texture(avatar, utils.specpos.x + 4, utils.specpos.y + h*2 + (gradient and 5 or 3) + hmod, hw, hw, 255, 255, 255, 255, "f")
                else
                    validv = false
                end
            end
            renderer.text(utils.specpos.x + (avatars and validv and hw + 8 or 4), utils.specpos.y + h*2 + (gradient and 5 or 3) + hmod, 255, 255, 255, 255, "", 0, v[2])
            hmod = hmod + h + 1
        end
    elseif style == "晨花" then
        local color = {ui.get(tabs["Manipulations"].uistyle[3])}
        local glow = ui.get(tabs["Manipulations"].uistyle[4])
        local wh, hw = renderer.measure_text(nil, "spectators")
        if glow then utils.shadow(utils.specpos.x, utils.specpos.y, wh*1.5, hw*1.5, 10, 8, {color[1], color[2], color[3], 50 * visuals.alphaspec[1]/255}, {color[1], color[2], color[3], 50 * visuals.alphaspec[1]/255}) end
        rounded_rect(utils.specpos.x, utils.specpos.y, wh*1.5, hw*1.5, color[1], color[2], color[3], color[4] * visuals.alphaspec[1]/255, 5)
        renderer.text(utils.specpos.x + wh*0.3 - 1, utils.specpos.y + hw*0.2, 255, 255, 255, visuals.alphaspec[1], nil, 0, "spectators")
        local hmod = 0
        local isd = entity.is_alive(lplayer)
        if players == nil then return end
        local ps = players[not isd and entity.get_prop(lplayer, "m_hObserverTarget") or lplayer]
        if ps == nil then return end
        for k, v in ipairs(ps) do
            local wh, hw = renderer.measure_text(nil, v[2])
            local validv = true
            if avatars then
                local avatar = utils.get_avatar(v[1])
                if avatar ~= nil then
                    renderer.texture(avatar, utils.specpos.x + 4, utils.specpos.y + h*2.1 + hmod, hw, hw, 255, 255, 255, 255, "f")
                else
                    validv = false
                end
            end
            if string.len(v[2]) > 0 then
                rounded_rect(utils.specpos.x + (avatars and validv and hw + 6 or 4), utils.specpos.y + h*2 + hmod - 1, wh*1.1 + (string.len(v[2]) > 1 and 3 or 6), hw*1.2 + 2, 50, 50, 50, 50, 5)
                renderer.text(utils.specpos.x + (avatars and validv and hw + 8 or 6), utils.specpos.y + h*2 + hmod, 255, 255, 255, 255, "", 0, v[2])
            end
            hmod = hmod + hw*1.2 + 6
        end
    elseif style == "Methamod" then
        local color = {ui.get(tabs["Manipulations"].uistyle[3])}
        renderer.rectangle(utils.specpos.x, utils.specpos.y, 100 + w*0.75, h*1.7, 15, 15, 15, color[4] * visuals.alphaspec[1]/255)
        renderer.rectangle(utils.specpos.x, utils.specpos.y, 100 + w*0.75, 2, color[1], color[2], color[3], visuals.alphaspec[1])
        renderer.text(utils.specpos.x + (100 + w*0.8)*0.5, utils.specpos.y + h*0.85, 255, 255, 255, visuals.alphaspec[1], "c", 0, "spectators")
        local hmod = 0
        local isd = entity.is_alive(lplayer)
        if players == nil then return end
        local ps = players[not isd and entity.get_prop(lplayer, "m_hObserverTarget") or lplayer]
        if ps == nil then return end
        for k, v in ipairs(ps) do
            local wh, hw = renderer.measure_text(nil, v[2])
            local validv = true
            if avatars then
                local avatar = utils.get_avatar(v[1])
                if avatar ~= nil then
                    renderer.texture(avatar, utils.specpos.x + 4, utils.specpos.y + h*2 + hmod, hw, hw, 255, 255, 255, 255, "f")
                else
                    validv = false
                end
            end
            renderer.text(utils.specpos.x + (avatars and validv and hw + 8 or 4), utils.specpos.y + h*2 + hmod, 255, 255, 255, 255, "", 0, v[2])
            hmod = hmod + h + 3
        end
    elseif style == "Astral" then
        local lplayer = entity.get_local_player()
        local isd = entity.is_alive(lplayer)
        if players == nil then return end
        local ps = players[not isd and entity.get_prop(lplayer, "m_hObserverTarget") or lplayer]
        if ps == nil then return end
        
        local title_w, title_h = renderer.measure_text("b", "Spectators")
        local max_spec_width = 0
        
        for _, v in ipairs(ps) do
            local spec_w, spec_h = renderer.measure_text("", v[2])
            max_spec_width = math.max(max_spec_width, spec_w)
        end
        
        local bg_width = math.max(title_w + 12, max_spec_width + 12)
        local bg_height = title_h + 8 + (#ps * 16) + 8
        local radius = 3
        
        rounded_rect(utils.specpos.x, utils.specpos.y, bg_width, bg_height, 54, 61, 74, visuals.alphaspec[1], radius)
        
        local gradient_height = 2
        local gradient_y = utils.specpos.y + radius
        local gradient_width = bg_width - (radius * 2)
        renderer.gradient(utils.specpos.x + radius, gradient_y, gradient_width, gradient_height, 159, 161, 240, visuals.alphaspec[1], 187, 145, 236, visuals.alphaspec[1], true)
       
        renderer.text(utils.specpos.x + bg_width / 2, utils.specpos.y + gradient_height + radius + 6, 164, 168, 175, visuals.alphaspec[1], "cb", 0, "Spectators")
       
        local entry_y = utils.specpos.y + gradient_height + radius + title_h + 10
        for _, v in ipairs(ps) do
            visuals.alphaspec.specs[v[1]] = visuals.alphaspec.specs[v[1]] or 0
            visuals.alphaspec.specs[v[1]] = math.ceil(utils.lerp(visuals.alphaspec.specs[v[1]], 255, 0.35))
            
            if visuals.alphaspec.specs[v[1]] > 0 then
                renderer.text(utils.specpos.x + 6, entry_y, 157, 156, 218, visuals.alphaspec.specs[v[1]], "", 0, v[2])
                entry_y = entry_y + 16
            end
        end
    end
end
utils.in_range_rect = function(curs, coord, size)
    return curs[1] > coord.x and curs[1] < coord.x + size[1] and curs[2] > coord.y and curs[2] < coord.y + size[2] 
end
utils.calcadelta = function(start, dest)
    return {dest[1] - start[1], dest[2] - start[2]}
end
visuals.alphaspencer = {0, 0}
visuals.velwarpos = {x = screen.x*0.5 - 88, y = screen.y*0.25 - 18}
visuals.defindpos = {x = screen.x*0.5 - 88, y = screen.y*0.15 - 18}
visuals.absvelwar = false
visuals.absdefind = false
visuals.draghandler = function()
    if not ui.is_menu_open() then return end
    local lplayer = entity.get_local_player()
    local menu = vector(ui.menu_position())
    local sizemenu = {ui.menu_size()}
    local gradient = ui.get(tabs["Manipulations"].uistyle[2])
    local style = ui.get(tabs["Manipulations"].uistyle[1])
    if lplayer ~= nil then
        if ui.get(tabs["Visuals"].defind[1]) then
            local isinrect = utils.in_range_rect(cursor, visuals.defindpos, {176, 32}) and not utils.in_range_rect(cursor, menu, sizemenu)
            utils.attackhover[5] = {isinrect, tabs["Visuals"].defind[1], visuals.absdefind}
            outlined_rectangle(visuals.defindpos.x, visuals.defindpos.y, 176, 32, 255, 255, 255, 255*visuals.alphaspencer[2], 1)
            renderer.text(visuals.defindpos.x + 88, visuals.defindpos.y + 38, 255, 255, 255, 255*visuals.alphaspencer[2], "c", 0, "Click M2 To Reset Pos")
            if not (abskey or absspec or visuals.absvelwar) and isinrect or visuals.absdefind then
                visuals.alphaspencer[2] = clicked and utils.lerp(visuals.alphaspencer[2], 0, 0.35) or utils.lerp(visuals.alphaspencer[2], 1, 0.35)
                if firstclick or visuals.absdefind then
                    visuals.absdefind = clicked
                    local delta = utils.calcadelta(oldcursor, cursor)
                    local moved = {x = visuals.defindpos.x + delta[1], y = visuals.defindpos.y + delta[2]}
                    visuals.defindpos.x = moved.x < 0 and 0 or moved.x > screen.x - 160 and screen.x - 160 or moved.x
                    visuals.defindpos.y = moved.y < 0 and 0 or moved.y > screen.y - 32 and screen.y - 32 or moved.y
                elseif client.key_state(0x02) then
                    visuals.defindpos = {x = screen.x*0.5 - 88, y = screen.y*0.15 - 18}
                end
            else
                visuals.alphaspencer[2] = clicked and 0 or utils.lerp(visuals.alphaspencer[2], 0, 0.35)
            end
        end
        if ui.get(tabs["Visuals"].velwar[1]) then
            local isinrect = utils.in_range_rect(cursor, visuals.velwarpos, {176, 32}) and not utils.in_range_rect(cursor, menu, sizemenu)
            utils.attackhover[4] = {isinrect, tabs["Visuals"].velwar[1], visuals.absvelwar}
            outlined_rectangle(visuals.velwarpos.x, visuals.velwarpos.y, 176, 32, 255, 255, 255, 255*visuals.alphaspencer[1], 1)
            renderer.text(visuals.velwarpos.x + 88, visuals.velwarpos.y + 38, 255, 255, 255, 255*visuals.alphaspencer[1], "c", 0, "Click M2 To Reset Pos")
            if not (abskey or absspec or visuals.absdefind) and isinrect or visuals.absvelwar then
                visuals.alphaspencer[1] = clicked and utils.lerp(visuals.alphaspencer[1], 0, 0.35) or utils.lerp(visuals.alphaspencer[1], 1, 0.35)
                if firstclick or visuals.absvelwar then
                    visuals.absvelwar = clicked
                    local delta = utils.calcadelta(oldcursor, cursor)
                    local moved = {x = visuals.velwarpos.x + delta[1], y = visuals.velwarpos.y + delta[2]}
                    visuals.velwarpos.x = moved.x < 0 and 0 or moved.x > screen.x - 160 and screen.x - 160 or moved.x
                    visuals.velwarpos.y = moved.y < 0 and 0 or moved.y > screen.y - 32 and screen.y - 32 or moved.y
                elseif client.key_state(0x02) then
                    visuals.velwarpos = {x = screen.x*0.5 - 88, y = screen.y*0.25 - 18}
                end
            else
                visuals.alphaspencer[1] = clicked and 0 or utils.lerp(visuals.alphaspencer[1], 0, 0.35)
            end
        end
    end
    if ui.get(tabs["Visuals"].spectators[1]) then
        local rect = {0, 0}
        if style == "Skeet" then
            local players = utils.get_speclist()
            local leng = (function()
                if players == nil then return players end
                local spec = ""
                local isd = entity.is_alive(lplayer)
                local ps = players[not isd and entity.get_prop(entity.get_local_player(), "m_hObserverTarget") or entity.get_local_player()]
                if ps == nil then return ps end
                for _, v in pairs(ps) do
                    if string.len(v[2]) > string.len(spec) then spec = v[2] end
                end
                return string.len(spec) > 0 and spec or nil
            end)()
            local w, h = renderer.measure_text(nil, leng)
            rect = {110 + w*0.5, h*2 + (gradient and 4 or 2)}
        elseif style == "晨花" then
            local w, h = renderer.measure_text(nil, "spectators")
            rect = {w*1.5, h*1.5}
        elseif style == "Methamod" then
            local players = utils.get_speclist()
            local leng = (function()
                if players == nil then return players end
                local spec = ""
                local isd = entity.is_alive(lplayer)
                local ps = players[not isd and entity.get_prop(entity.get_local_player(), "m_hObserverTarget") or entity.get_local_player()]
                if ps == nil then return ps end
                for _, v in pairs(ps) do
                    if string.len(v[2]) > string.len(spec) then spec = v[2] end
                end
                return string.len(spec) > 0 and spec or nil
            end)()
            local w, h = renderer.measure_text(nil, leng or "spectators")
            rect = {100 + w*0.75, h*1.5}
        elseif style == "Astral" then
            local players = utils.get_speclist()
            if players ~= nil then
                local isd = entity.is_alive(lplayer)
                local ps = players[not isd and entity.get_prop(lplayer, "m_hObserverTarget") or lplayer]
                if ps ~= nil then
                    local title_w, title_h = renderer.measure_text("b", "Spectators")
                    local max_spec_width = 0
                    
                    for _, v in ipairs(ps) do
                        local spec_w, spec_h = renderer.measure_text("", v[2])
                        max_spec_width = math.max(max_spec_width, spec_w)
                    end
                    
                    local bg_width = math.max(title_w + 12, max_spec_width + 12)
                    local bg_height = title_h + 8 + (#ps * 16) + 8
                    rect = {bg_width, bg_height}
                else
                    rect = {80, 30}
                end
            else
                rect = {80, 30}
            end
        end
        local isinrect = utils.in_range_rect(cursor, utils.specpos, rect) and not utils.in_range_rect(cursor, menu, sizemenu)
        utils.attackhover[3] = {isinrect, tabs["Visuals"].spectators[1], absspec}
        if not (abskey or visuals.absdefind or visuals.absvelwar) and (isinrect and firstclick or absspec) then
            absspec = clicked
            local delta = utils.calcadelta(oldcursor, cursor)
            local moved = {x = utils.specpos.x + delta[1], y = utils.specpos.y + delta[2]}
            utils.specpos.x = moved.x < 0 and 0 or moved.x > screen.x - rect[1] and screen.x - rect[1] or moved.x
            utils.specpos.y = moved.y < 0 and 0 or moved.y > screen.y - rect[2] and screen.y - rect[2] or moved.y
        end
    end
    if ui.get(tabs["Visuals"].keybinds[1]) then
        local rect = {0, 0}
        if style == "Skeet" then
            local leng = utils.getlengst()
            local w, h = renderer.measure_text(nil, leng)
            rect = {110 + w*0.8, h*2 + (gradient and 4 or 2)}
        elseif style == "晨花" then
            local w, h = renderer.measure_text(nil, "keybinds")
            rect = {w*1.5, h*1.5}
        elseif style == "Methamod" then
            local leng = utils.getlengst()
            local w, h = renderer.measure_text(nil, leng)
            rect = {100 + w*0.75, h*1.5}
        end
        local isinrect = utils.in_range_rect(cursor, utils.keypos, rect) and not utils.in_range_rect(cursor, menu, sizemenu)
        utils.attackhover[2] = {isinrect, tabs["Visuals"].keybinds[1], abskey}
        if not (absspec or visuals.absdefind or visuals.absvelwar) and (isinrect and firstclick or abskey) then
            abskey = clicked
            local delta = utils.calcadelta(oldcursor, cursor)
            local moved = {x = utils.keypos.x + delta[1], y = utils.keypos.y + delta[2]}
            utils.keypos.x = moved.x < 0 and 0 or moved.x > screen.x - rect[1] and screen.x - rect[1] or moved.x
            utils.keypos.y = moved.y < 0 and 0 or moved.y > screen.y - rect[2] and screen.y - rect[2] or moved.y
        end
    end
end
local function handle_attack(cmd)
    if utils.is_altui and not utils.defaulttab and utils.is_open then
        if utils.attackhover[1] then cmd.in_attack = 0; cmd.in_attack2 = 0 end
    end
    if ui.is_menu_open() then
        for i=2, #utils.attackhover do
            if utils.attackhover[i] and ui.get(utils.attackhover[i][2]) and (utils.attackhover[i][1] or utils.attackhover[i][3]) then cmd.in_attack = 0; cmd.in_attack2 = 0 end
        end
    end
end
local fpstweeks = { ["3d sky"] = { cvar = cvar.r_3dsky, value = 1 }, 
["fog"] = { cvars = { cvar.fog_enable, cvar.fog_enable_water_fog }, value = 1 }, 
["shadows"] = { cvars = { cvar.r_shadows, cvar.cl_csm_static_prop_shadows, cvar.cl_csm_shadows, cvar.cl_csm_world_shadows, cvar.cl_foot_contact_shadows, cvar.cl_csm_viewmodel_shadows, cvar.cl_csm_rope_shadows, cvar.cl_csm_sprite_shadows, cvar.cl_csm_translucent_shadows, cvar.cl_csm_entity_shadows, cvar.cl_csm_world_shadows_in_viewmodelcascade }, value = 1 }, 
["blood"] = { cvar = cvar.violence_hblood, value = 1 }, ["decals"] = { cvars = { cvar.r_drawdecals, cvar.r_drawropes, cvar.r_drawsprites }, value = 1 }, 
["bloom"] = { cvar = cvar.mat_disable_bloom, value = 0 }, 
["other"] = { cvars = { cvar.r_dynamic, cvar.r_eyegloss, cvar.r_eyes, cvar.r_drawtracers_firstperson, cvar.r_dynamiclighting }, value = 1 } }
local function fpsboost(reset)
    if not reset then
        for key, val in pairs(fpstweeks) do
            if utils.multi_parse(tabs["Visuals"].fpsboost[2], key) then
                if val.cvar then
                    if val.cvar:get_int() == val.value then
                        val.cvar:set_int(val.value == 0 and 1 or (val.value == 1 and 0 or val.value))
                    end
                else
                    for _, v in ipairs(val.cvars) do
                        if v:get_int() == val.value then
                            v:set_int(val.value == 0 and 1 or (val.value == 1 and 0 or val.value))
                        end
                    end
                end
            else
                if val.cvar then
                    if val.cvar:get_int() ~= val.value then
                        val.cvar:set_int(val.value)
                    end
                else
                    for _, v in ipairs(val.cvars) do
                        if v:get_int() ~= val.value then
                            v:set_int(val.value)
                        end
                    end
                end
            end
        end
    else
        for key, val in pairs(fpstweeks) do
            if val.cvar then
                if val.cvar:get_int() ~= val.value then
                    val.cvar:set_int(val.value)
                end
            else
                for _, v in ipairs(val.cvars) do
                    if v:get_int() ~= val.value then
                        v:set_int(val.value)
                    end
                end
            end
        end
    end
end
ui.set_callback(tabs["Visuals"].fpsboost[1], function(id)
    if ui.get(id) then
        client.set_event_callback("paint", fpsboost)
    else
        client.unset_event_callback("paint", fpsboost)
        fpsboost(true)
    end
end)
local function trigscp()
    ui.set(skeetgui.visualgui.effects.remove_soverlay, true)
end
local function trigscp1()
    ui.set(skeetgui.visualgui.effects.remove_soverlay, false)
end
local function linear(slot0, slot1, slot2, slot3)
    return slot2 * slot0 / slot3 + slot1
end
local csopealpha = 1
local oldscopelen = nil
local function scopelines()
    local lplayer = entity.get_local_player()
    if lplayer == nil then return end
    trigscp1()
    local animated = ui.get(tabs["Visuals"].scopelines[2])
    local inverted = ui.get(tabs["Visuals"].scopelines[3])
    local is_scoped = entity.is_alive(lplayer) and entity.get_prop(lplayer, "m_bIsScoped") == 1
    local color1 = {ui.get(tabs["Visuals"].scopelines[5])}
    local color2 = {ui.get(tabs["Visuals"].scopelines[7])}
    local gap = ui.get(tabs["Visuals"].scopelines[9])
    local len = ui.get(tabs["Visuals"].scopelines[10])
    local thick = ui.get(tabs["Visuals"].scopelines[11])
    local firstcol = inverted and color2 or color1
    local seccol = inverted and color1 or color2
    oldscopelen = animated and (oldscopelen or len) or 0
    csopealpha = animated and csopealpha or 1
    if animated then
        if is_scoped and entity.is_alive(lplayer) then
            csopealpha = utils.lerp(csopealpha, 1, 0.2)
            oldscopelen = math.floor(utils.lerp(oldscopelen, 0, 0.35, 20))
        else
            csopealpha = utils.lerp(csopealpha, 0, 0.2, 20)
            oldscopelen = math.ceil(utils.lerp(oldscopelen, len, 0.35))
        end
    end
    if animated and csopealpha > 0 or is_scoped then
        if ui.get(tabs["Visuals"].scopelines[7]) ~= "Vertical only" then
            renderer.gradient(screen.x*0.5 - (gap + len), screen.y*0.5 - math.floor(thick*0.5), len + (animated and -oldscopelen or 0), thick, seccol[1], seccol[2], seccol[3], seccol[4] * csopealpha, firstcol[1], firstcol[2], firstcol[3], firstcol[4] * csopealpha, true)
            renderer.gradient(screen.x*0.5 + gap + (animated and oldscopelen or 0), screen.y*0.5 - math.floor(thick*0.5), len + (animated and -oldscopelen or 0), thick, firstcol[1], firstcol[2], firstcol[3], firstcol[4] * csopealpha, seccol[1], seccol[2], seccol[3], seccol[4] * csopealpha, true)
        end
        if ui.get(tabs["Visuals"].scopelines[7]) ~= "Horizontal Only" then
            if ui.get(tabs["Visuals"].scopelines[7]) ~= "T-Shape" then
                renderer.gradient(screen.x*0.5 - math.floor(thick*0.5), screen.y*0.5 - gap - len, thick, len + (animated and -oldscopelen or 0), seccol[1], seccol[2], seccol[3], seccol[4] * csopealpha, firstcol[1], firstcol[2], firstcol[3], firstcol[4] * csopealpha, false)
            end
            renderer.gradient(screen.x*0.5 - math.floor(thick*0.5), screen.y*0.5 + gap + (animated and oldscopelen or 0), thick, len + (animated and -oldscopelen or 0), firstcol[1], firstcol[2], firstcol[3], firstcol[4] * csopealpha, seccol[1], seccol[2], seccol[3], seccol[4] * csopealpha, false)
        end
    end
end
ui.set_callback(tabs["Visuals"].scopelines[1], function(id)
    local nb = ""
    if ui.get(id) then
        nb = "set_event_callback"
    else
        nb = "unset_event_callback"
    end
    client[nb]("paint_ui", trigscp)
    client[nb]("paint", scopelines)
end)
local uimuliplayer = 0
local function indicators_idle()
    if ui.is_menu_open() then
        uimuliplayer = uimuliplayer < 1 and utils.lerp(uimuliplayer, 1, 0.1, 60) or 0
    end
end
local slowalpha = 0
local function velocity_warning()
    local lplayer = entity.get_local_player()
    if lplayer == nil then return end
    local color = {ui.get(tabs["Visuals"].velwar[2])}
    local velmod = entity.get_prop(lplayer, "m_flVelocityModifier")
    local decmod = (1 - velmod) * 10
    local on_ground = bit.band(entity.get_prop(lplayer, "m_fFlags"), bit.lshift(1, 0)) ~= 0 and not misc.isinjump
    if not entity.is_alive(lplayer) then
        velmod = 1
        decmod = 10
    end
    if ui.is_menu_open() then
        velmod = velmod == 1 and uimuliplayer or velmod
        slowalpha = utils.lerp(slowalpha, 1, 0.15)
    else
        if on_ground then
            if decmod <= 1 and decmod > 0 then
                slowalpha = decmod
            elseif velmod < 1 then
                slowalpha = utils.lerp(slowalpha, 1, 0.15)
            else
                slowalpha = utils.lerp(slowalpha, 0, 0.35)
            end
        else
            slowalpha = velmod < 1 and utils.lerp(slowalpha, 0, 0.15) or 0
        end
    end
    if slowalpha > 0 then
        local offset = 150 * velmod
        renderer.rectangle(visuals.velwarpos.x + 12, visuals.velwarpos.y + 17, 152, 5, 0, 0, 0, color[4]*slowalpha)
        renderer.rectangle(visuals.velwarpos.x + 13, visuals.velwarpos.y + 18, offset, 3, color[1], color[2], color[3], color[4]*slowalpha)
        renderer.text(visuals.velwarpos.x + 12 + offset, visuals.velwarpos.y + 19, color[1], color[2], color[3], color[4]*slowalpha, "-c", 0, string.format("%d%%", velmod*100))
        renderer.text(visuals.velwarpos.x + 88, visuals.velwarpos.y + 13, color[1], color[2], color[3], color[4]*slowalpha, "-c", 0, "VELOCITY SLOWDOWN!")
    end
end
local defalpha = 0
local function defensive_indicator()
    local lplayer = entity.get_local_player()
    if lplayer == nil then return end
    if ticks.tickbase_diff == nil then return end
    local color = {ui.get(tabs["Visuals"].defind[2])}
    local base = ticks.tickbase_diff * -1
    if not entity.is_alive(lplayer) then
        base = 0
    end
    if ui.is_menu_open() and base <= 0 then
        base = 15 - (15*uimuliplayer)
        defalpha = utils.lerp(defalpha, 1, 0.35)
    else
        if base > 0 then
            defalpha = utils.lerp(defalpha, 1, 0.35)
        elseif not ui.is_menu_open() then
            defalpha = utils.lerp(defalpha, 0, 0.35)
        end
    end
    if defalpha > 0 then
        if base <= 0 then base = 0 end
        local factor = 1 - (base*(1/15))
        local offset = 150 * factor
        renderer.rectangle(visuals.defindpos.x + 12, visuals.defindpos.y + 17, 152, 5, 0, 0, 0, color[4]*defalpha)
        renderer.rectangle(visuals.defindpos.x + 13, visuals.defindpos.y + 18, offset, 3, color[1], color[2], color[3], color[4]*defalpha)
        renderer.text(visuals.defindpos.x + 13 + offset, visuals.defindpos.y + 19, color[1], color[2], color[3], color[4]*defalpha, "-c", 0, string.format("%d%%", factor*100))
        renderer.text(visuals.defindpos.x + 88, visuals.defindpos.y + 13, color[1], color[2], color[3], color[4]*defalpha, "-c", 0, "DEFENSIVE TRIGGER!")
    end
end
ui.set_callback(tabs["Visuals"].velwar[1], function(id)
    if ui.get(id) then
        client.set_event_callback("paint", velocity_warning)
        if not ui.get(tabs["Visuals"].defind[1]) then client.set_event_callback("paint", indicators_idle) end
    else
        client.unset_event_callback("paint", velocity_warning)
        if not ui.get(tabs["Visuals"].defind[1]) then client.unset_event_callback("paint", indicators_idle); uimuliplayer = 0 end
    end
end)
ui.set_callback(tabs["Visuals"].defind[1], function(id)
    if ui.get(id) then
        client.set_event_callback("paint", defensive_indicator)
        if not ui.get(tabs["Visuals"].velwar[1]) then client.set_event_callback("paint", indicators_idle) end
    else
        client.unset_event_callback("paint", defensive_indicator)
        if not ui.get(tabs["Visuals"].velwar[1]) then client.unset_event_callback("paint", indicators_idle); uimuliplayer = 0 end
    end
end)
local tracers = {}
local function bullet_tracer(e)
    local lplayer = entity.get_local_player()
    if client.userid_to_entindex(e.userid) ~= lplayer then return end
    local impact = vector(e.x, e.y, e.z)
    local lpos = vector(client.eye_position())
    tracers[globals.tickcount()] = {lpos = lpos, impact = impact, time = globals.realtime() + ui.get(tabs["Visuals"].tracer[3])}
end
local function paint_tracer()
    local color = {ui.get(tabs["Visuals"].tracer[2])}
    for i, v in pairs(tracers) do
        if v.time <= globals.realtime() then tracers[i] = nil end
        local xa, ya = renderer.world_to_screen(v.lpos:unpack())
        local xb, yb = renderer.world_to_screen(v.impact:unpack())
        renderer.line(xa, ya, xb, yb, color[1], color[2], color[3], color[4])
    end
end
ui.set_callback(tabs["Visuals"].tracer[1], function(id)
    if ui.get(id) then
        client.set_event_callback("bullet_impact", bullet_tracer)
        client.set_event_callback("paint", paint_tracer)
    else
        client.unset_event_callback("bullet_impact", bullet_tracer)
        client.unset_event_callback("paint", paint_tracer)
    end
end)
utils.weapon_icons = {}
do
    local svg_table = {
        [1]     = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 1.1//EN\" \"http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd\" [\n	<!ENTITY ns_flows \"http://ns.adobe.com/Flows/1.0/\">\n]>\n<svg version=\"1.1\"\n	 xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" xmlns:a=\"http://ns.adobe.com/AdobeSVGViewerExtensions/3.0/\"\n	 x=\"0px\" y=\"0px\" width=\"65px\" height=\"40px\" viewBox=\"0.276 0 65 40\" enable-background=\"new 0.276 0 65 40\" xml:space=\"preserve\">\n<defs>\n</defs>\n<path fill=\"#FFFFFF\" d=\"M61.042,8.221c-0.064-0.532-0.178-1.074-0.156-1.611c0.023-0.569,0.234-0.968-0.439-0.947\n	c-0.207-0.091-0.965-0.178-1.018-0.396c-0.127-0.507-0.268-0.962-0.852-0.803c-0.602,0.165-1.047,0.501-1.57,0.815\n	c-0.426,0.254-0.639,0.239-1.131,0.239c-0.406,0-1.428-0.199-1.783,0c-0.197,0.111-0.162,0.453-0.287,0.525\n	c-0.059,0.036-0.619,0.042-0.668,0c-0.209-0.178,0.137-0.619-0.275-0.622c-0.346-0.003-0.691-0.005-1.035-0.007\n	c-2.875-0.022-5.75-0.043-8.625-0.065c-0.893-0.007-1.785-0.014-2.678-0.021c-0.287-0.002-0.279,0.477-0.445,0.477\n	c-0.361,0-0.654-0.187-0.957-0.191c-2.439-0.042-4.877-0.084-7.316-0.125c-1.15-0.02-2.299-0.04-3.449-0.059\n	c-0.588-0.01-0.729-0.581-1.223-0.579c-2.596,0.015-5.189,0.029-7.785,0.043c-0.777,0.005-1.305,0.385-2.098,0.403\n	c-0.426,0.009-1.154,0.202-1.473-0.117c-0.197-0.196-0.855-1.095-1.121-1.095c-0.32,0-1.52-0.196-1.742,0\n	c-0.254,0.224,0.186,1.204-0.1,1.367c-0.791,0.453-1.691,1.005-2.162,1.828c-0.342,0.6-0.6,0.435-1.311,0.435\n	c-0.186,0-0.449,0.057-0.609-0.05C8.636,7.603,8.36,7.362,8.243,7.394C8.056,7.443,7.499,7.483,7.374,7.623\n	c-0.084,0.094,0,0.633,0,0.765c0,0.439,0.422,0.958,0.619,1.34c0.223,0.427,0.553,0.693,0.67,1.191\n	c0.121,0.506-0.072,1.003-0.186,1.492c-0.209,0.909-0.855,0.898-1.67,1.15c-0.873,0.269-1.945,0.63-2.506,1.401\n	c-0.551,0.756-0.322,0.972,0.477,0.972c0.498,0,1,0.024,1.5,0.038c0.926,0.027,1.898,0.022,2.816,0.153\n	c1.33,0.241,1.992,0.92,2.281,2.231c0.156,0.714,0.012,1.318,0.012,2.018c0,0.339-0.279,0.75-0.408,1.053\n	c-0.279,0.657-0.559,1.313-0.838,1.97c-0.826,1.94-1.506,3.908-2.164,5.912c-0.488,1.488-0.797,3.063-0.74,4.637\n	c0.021,0.597,0.137,1.757,0.939,1.871c0.367,0.053,0.734,0.061,1.104,0.081c2.383,0.126,4.629,0.142,7.012,0.012\n	c1.912-0.105,3.84-0.588,5.748-0.581c-0.201-0.564-0.875-1.679-0.74-2.256c0.178-0.762,0.34-1.512,0.471-2.284\n	c0.273-1.602,0.633-3.193,0.893-4.797c0.234-1.44,0.279-2.63,1.541-3.542c0.68-0.491,1.967,0.309,2.775,0.265\n	c1.055-0.057,2.113-0.079,3.16-0.221c0.547-0.074,1.115-0.108,1.65-0.242c0.639-0.16,0.902-0.022,0.902-0.671\n	c0-1.135,0.088-2.317,0.525-3.377c0.33-0.797,0.816-2,1.547-2.52c0.65-0.461,1.334-1.181,2.186-1.181c1.736,0,3.473,0,5.207,0\n	c5.367,0,10.73,0,16.096,0c0.518,0,0.877,0.079,1.1-0.523c0.365-0.992,0.695-2,0.975-3.019C60.546,10.155,61.142,9.045,61.042,8.221\n	z M31.165,20.209c-0.426,0.904-1.453,0.693-2.316,0.693c-0.697,0-1.795,0.218-2.459-0.017c-0.59-0.207-0.734-0.18-0.939-0.762\n	c-0.113-0.317-0.113-0.526-0.113-0.865c0-0.964,0-1.928,0-2.892c0-1.327,1.307-1.149,2.232-1.149c0.863,0,1.727,0,2.59,0\n	c1.479,0,1.195,1.681,1.195,2.656C31.354,18.657,31.501,19.494,31.165,20.209z\"/>\n<rect id=\"sliceCopy_x5F_32_1_\" x=\"65.053\" fill=\"none\" width=\"56.167\" height=\"40\"/>\n<rect id=\"sliceCopy_x5F_31_1_\" fill=\"none\" width=\"65.054\" height=\"40\"/>\n</svg>",
        [2]     = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 1.1//EN\" \"http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd\" [\n	<!ENTITY ns_flows \"http://ns.adobe.com/Flows/1.0/\">\n]>\n<svg version=\"1.1\"\n	 xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" xmlns:a=\"http://ns.adobe.com/AdobeSVGViewerExtensions/3.0/\"\n	 x=\"0px\" y=\"0px\" width=\"100px\" height=\"40px\" viewBox=\"0.933 0 100 40\" enable-background=\"new 0.933 0 100 40\"\n	 xml:space=\"preserve\">\n<defs>\n</defs>\n<path fill=\"#FFFFFF\" d=\"M46.189,5.703c0.15-0.328,0.387-0.546,0.637-0.796c0.247-0.283,0.619-0.389,1.115-0.318c0.336,0.08,0.688,0.133,1.008,0.265\n	c0.184,0.305,0.537,0.292,0.637,0.69c0.099,0.687,0.272,1.313,0.467,1.98c0.132,0.452-0.198,1.417-0.236,1.916\n	c-0.104,1.374-0.323,2.792-0.284,4.17h-3.185c-0.066,0.155-0.156,0.296-0.265,0.425c-0.538,0.23-1.387,0.128-1.959,0.148\n	c-0.761,0.028-1.526,0.011-2.289,0.011c-1.374,0-2.746-0.106-4.118-0.106c-0.735,0-1.469-0.044-2.193,0.106\n	c-1.238,0.233-1.932,0.951-2.809,1.759c-1.108,1.023-0.775,2.491-0.692,3.813l-0.374,0.372v0.105c-1.45,0.58-3.13,1.218-4.697,1.305\n	c-0.993,0.056-1.805,0.014-2.791-0.121c-1.11-0.152-2.611-0.581-3.711-0.283l-0.9,0.479c-0.496,0.682-0.644,1.317-0.885,2.131\n	c-0.435,1.466-0.87,2.931-1.305,4.395c-0.241,0.81-0.411,1.41-0.411,2.248c0,1.026,0.14,2.053,0.318,3.062\n	c0,0.919-0.194,1.574-0.584,1.964c-1.231,0.737-3.044,0.373-4.431,0.373c-1.58,0-3.238,0.268-4.697-0.373l-0.478-0.584\n	c-0.062-0.555-0.106-1.086-0.106-1.645c-1.027-0.114-1.805-0.152-2.707-0.638c-0.027-0.152-0.08-0.292-0.159-0.423\n	c0.024-0.83-0.178-1.599-0.075-2.423c0.114-0.913,0.386-1.87,0.447-2.777c0.834-1.669,1.569-3.384,2.314-5.095\n	c0.435-0.997,0.833-2.02,1.307-2.999c0.638-1.316,1.287-2.355,0.466-3.795c-0.529-1.055-2.408-1.025-3.45-1.22\n	c-0.531-0.518-0.332-0.989-0.159-1.592c0.301-0.336,0.934-0.467,1.38-0.531c1.08-1.016,1.661-2.02,2.07-3.449\n	C8.273,7.554,8.126,6.838,8.139,6.127C8.21,5.809,8.332,5.614,8.51,5.543c0.764-0.056,1.374,0.139,2.123,0.265\n	c0.741-0.318,1.469-0.689,2.282-0.743V4.004c0.617-0.026,1.246,0.094,1.857,0.159c0.177,0.037,0.266,0.107,0.266,0.213l0.159,0.955\n	c1.595,0,3.201-0.187,4.792-0.158c0.961,0.017,1.923,0.034,2.885,0.051c0.713,0.013,1.659-0.092,2.352,0.107l0.319,0.478h20.645\n	V5.703 M54.576,7.506c-0.062-0.404-0.151-0.812-0.16-1.22c0.105-0.354,0.265-0.549,0.478-0.583c0.755-0.107,1.275,0.078,2.017,0.212\n	c0.795-0.161,1.553-0.749,2.388-0.743V4.163c0.617-0.023,1.246,0.096,1.857,0.159c0.359,0.32,0.379,0.72,0.425,1.168\n	c3.327,0,6.652-0.056,9.978,0l0.371,0.424h20.538V5.862l0.106-0.213c0.236-0.145,0.464-0.324,0.583-0.583\n	c1.13-0.989,2.611,0.047,2.878,1.2c0.157,0.683,0.706,2.297,0.095,2.885c-0.109,1.536-0.256,3.132-0.213,4.67h-3.29l-0.159,0.373\n	c-1.137,0.377-2.709,0.159-3.898,0.159c-1.421,0-2.84-0.047-4.259-0.097c-1.725-0.061-3.158,0.035-4.508,1.234\n	c-0.623,0.554-1.383,1.108-1.469,2.008c-0.031,0.333-0.089,0.672-0.089,1.007c0,0.339,0.349,1.174,0.107,1.367l-0.373,0.424v0.159\n	c-1.65,0.66-3.472,1.186-5.244,1.284c-2.039,0.113-5.019-1.234-6.802,0.042c-0.865,1.059-1.043,2.539-1.42,3.839\n	c-0.393,1.352-0.645,2.893-1.233,4.174c-0.02,1.847,0.974,4.174-0.211,5.838c-1.096,0.549-2.428,0.319-3.628,0.319\n	c-1.551,0-3.102,0-4.652,0l-0.054-0.106c-0.288-0.051-0.569-0.129-0.85-0.212c-0.425-0.247-0.637-0.778-0.637-1.592\n	c0.075-0.224,0.129-0.456,0.158-0.689c-1.015-0.126-1.913-0.153-2.813-0.637v-0.212l-0.106-0.212\n	c0.014-0.686-0.181-1.352-0.151-2.054c0.042-1.033,0.307-2,0.575-2.988h0.055c0.453-1.688,1.415-3.405,2.122-5.001\n	c0.77-1.739,2.012-3.724,2.283-5.613l-0.478-1.433c-0.512-1.028-2.427-1.099-3.45-1.22c-0.472-0.337-0.509-1.239-0.105-1.645\n	c0.275-0.229,0.956-0.521,1.326-0.531C53.956,10.59,54.923,9.364,54.576,7.506 M26.554,14.777c-0.902,0-1.8-0.002-2.701,0.031\n	c-0.994,0.036-1.581,0.145-2.5,0.554c-0.354,0.247-0.583,0.531-0.689,0.849c-0.311,0.62-0.08,1.282,0.053,1.91\n	c0.302,0.301,0.603,0.601,0.902,0.902c0.816,0.196,1.511,0.673,2.387,0.707c0.762,0.029,1.522,0.06,2.283,0.089\n	c2.441-0.388,3.769-0.99,3.98-1.803c0.1-0.75,0.14-1.323-0.266-2.017c-0.247-0.46-0.708-0.866-1.38-1.221h-2.069 M71.08,14.99\n	c-0.649,0-1.616-0.161-2.229,0.107h-0.159c-0.635,0.316-1.419,0.573-1.644,1.327c-0.118,0.667-0.284,1.333,0.052,1.963h0.106\n	l0.796,0.796c0.806,0.297,1.507,0.726,2.396,0.76c0.775,0.029,1.552,0.06,2.327,0.089c2.441-0.319,3.733-0.938,3.875-1.858\n	l0.157-0.743l-0.37-1.274c-0.246-0.46-0.707-0.85-1.379-1.168C73.698,14.99,72.389,14.99,71.08,14.99\"/>\n<rect id=\"sliceCopy_x5F_29_1_\" x=\"100.411\" fill=\"none\" width=\"94.576\" height=\"40\"/>\n<rect id=\"sliceCopy_x5F_28_1_\" fill=\"none\" width=\"100.411\" height=\"40\"/>\n</svg>",
        [3]     = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 1.1//EN\" \"http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd\" [\n	<!ENTITY ns_flows \"http://ns.adobe.com/Flows/1.0/\">\n]>\n<svg version=\"1.1\"\n	 xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" xmlns:a=\"http://ns.adobe.com/AdobeSVGViewerExtensions/3.0/\"\n	 x=\"0px\" y=\"0px\" width=\"53px\" height=\"40px\" viewBox=\"0.736 0 53 40\" enable-background=\"new 0.736 0 53 40\" xml:space=\"preserve\">\n<defs>\n</defs>\n<path fill=\"#FFFFFF\" d=\"M48.592,5.617c-0.147-0.471-0.414-1.474-1.019-1.576c-0.269-0.091-0.546,0-0.812,0c-0.187,0-0.502,1.345-0.861,1.345\n	c-1.086,0-2.173,0-3.258,0c-2.65,0-5.303,0-7.952,0c-0.148,0-0.449,0.064-0.563-0.048c-0.141-0.142-0.255-0.23-0.449-0.23\n	c-0.609,0-1.218,0-1.826,0c-5.491,0-10.98,0-16.471,0c-0.961,0-1.922,0-2.884,0c-0.418,0-0.825,0.086-1.171-0.139\n	c-1.252-0.816-2.454-0.791-3.896-0.916C6.822,4,7.325,4.709,7.007,4.952C6.489,5.346,5.918,5.691,5.602,6.278\n	C5.003,7.387,4.859,8.839,4.58,10.053c-0.209,0.902-0.521,1.729-0.575,2.658c-0.127,2.15,2.342,2.761,3.844,3.474\n	c0.913,0.434,0.695,0.963,0.695,1.831c0,0.443-0.295,0.961-0.44,1.375c-0.205,0.588-0.409,1.175-0.613,1.762\n	c-0.322,0.929-0.584,1.881-0.872,2.821c-0.574,1.872-1.018,3.781-1.414,5.699c-0.237,1.24-0.417,2.5-0.417,3.764\n	c0,0.842,0.369,1.449,0.997,2.077c0.771,0.771,2.134,0.406,3.111,0.361c2.019-0.095,4.037-0.217,6.057-0.286\n	c0.877-0.029,2.564-0.275,2.141-1.539c-0.067-0.199-0.288-0.378-0.438-0.527c-0.114-0.114,0.098-0.509,0.142-0.649\n	c0.141-0.444,0.231-0.899,0.336-1.352c0.213-0.921,0.436-1.844,0.688-2.755c0.139-0.505,0.312-1.008,0.397-1.524\n	c0.07-0.421,0.433-0.794,0.479-1.214c0.117-1.046-0.124-2.82,0.726-3.473c0.653-0.502,1.039-0.57,1.892-0.502\n	c0.603,0.048,1.152,0.046,1.757,0.022c1.952-0.078,3.908,0.368,5.867,0.089c1.052-0.192,2.107-0.729,2.469-1.8\n	c0.197-0.585,0.197-1.238,0.256-1.849c0.04-0.416,0.043-0.869-0.002-1.285c-0.055-0.51-0.32-1.072,0.151-1.347\n	c0.75-0.437,1.729-1.123,2.596-1.275c0.681-0.12,1.488,0,2.176,0c2.619,0,5.236,0,7.855,0c0.763,0,0.872-1.043,1.061-1.691\n	c0.092-0.313,2.236-0.171,2.63,0.023c0.161-0.307,0.142-0.627,0.169-0.963c0.025-0.303,0.37-0.347,0.39-0.64\n	c0.039-0.606,0.085-1.213,0.1-1.82C48.814,8.186,48.843,6.928,48.592,5.617z M29.818,17.649c0,0.542,0,1.084,0,1.627\n	c0,0.963-1.563,0.664-2.198,0.664c-1.446,0-2.893,0-4.339,0c-0.627,0-2.065,0.279-2.639-0.104c-0.395-0.264-0.232-1.251-0.232-1.644\n	c0-0.588,0-1.177,0-1.764c0-1.017,1.256-0.753,1.957-0.753c2.283,0,4.566,0,6.85,0c0.202,0,0.399,0.066,0.505,0.251\n	C29.967,16.351,29.818,17.19,29.818,17.649z\"/>\n<rect id=\"sliceCopy_x5F_28_1_\" x=\"52.804\" fill=\"none\" width=\"100.411\" height=\"40\"/>\n<rect id=\"sliceCopy_x5F_27_1_\" fill=\"none\" width=\"52.805\" height=\"40\"/>\n</svg>",
        [4]     = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 1.1//EN\" \"http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd\" [\n	<!ENTITY ns_flows \"http://ns.adobe.com/Flows/1.0/\">\n]>\n<svg version=\"1.1\"\n	 xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" xmlns:a=\"http://ns.adobe.com/AdobeSVGViewerExtensions/3.0/\"\n	 x=\"0px\" y=\"0px\" width=\"60px\" height=\"40px\" viewBox=\"0.082 0 60 40\" enable-background=\"new 0.082 0 60 40\" xml:space=\"preserve\">\n<defs>\n</defs>\n<path fill=\"#FFFFFF\" d=\"M55.345,9.983c0,1.248,0.063,3.897-1.65,4.051c-1.051,0.094-2.088,0.184-3.143,0.215c-2.047,0.061-4.096,0.18-6.143,0.214\n	c-1.113,0.02-2.221,0.032-3.332,0.111c-0.637,0.046-2.537-0.023-2.674,0.85c-0.156,1.013-0.068,2.066,0.105,3.074\n	c0.076,0.441,0.285,0.908,0.285,1.355c0,0.152-0.674,0.976-0.76,0.984c-2.078,0.231-4.205,0.34-6.295,0.276\n	c-1.01-0.031-2.102,0.059-3.098-0.099c-0.566-0.09-1.131-0.18-1.697-0.268c-0.555-0.088-0.781-0.369-1.357-0.261\n	c-0.865,0.162-1.521,1.495-1.969,2.18c-1.055,1.617-1.732,3.398-2.422,5.202c-0.43,1.056-0.828,2.123-1.211,3.196\n	c-0.404,1.132-1.125,2.513-1.227,3.675C18.696,35.472,18.288,36,17.591,36c-0.326,0-0.648,0-0.973,0c-3.215,0-6.428,0-9.641,0\n	c0.035-0.41,0.137-0.79,0.236-1.188c-1.082,0-2.174-0.051-2.854-1.048c-0.76-1.188-0.133-2.715,0.189-3.946c0,0.032,0,0.063,0,0.097\n	c1.271-1.662,2.359-3.474,3.512-5.219c0.582-0.88,1.223-1.725,1.832-2.585c0.59-0.831,0.92-1.993,1.344-2.921\n	c0.877-1.928,1.02-4.739-1.082-5.893c-0.537-0.294-1.121-0.523-1.646-0.816c-0.52-0.29-0.615-1.042-0.629-1.593\n	c-0.023-1.041,0-2.104,0-3.163c0-0.424,0-0.848,0-1.272c0-0.396-0.34-0.639-0.143-0.987C7.95,5.039,8.909,5.093,9.278,5.05\n	c0.711-0.082,0.832-0.004,1.17-0.583c0.324-0.555,0.477-0.471,1.115-0.449c0.666,0.023,0.76,0.186,0.869,0.851\n	c0.029,0.159,0.547,0.074,0.684,0.074c4.385,0,8.771,0,13.158,0c6.021,0,12.043,0,18.063,0c1.975,0,3.951,0,5.926,0\n	c0.441,0,0.883,0,1.322,0c0.127,0,0.133,0.027,0.193-0.095c0.115-0.229,0.416-0.262,0.643-0.333\n	c0.451-0.143,0.303-0.081,0.641,0.048C53.38,4.682,53.249,4.8,53.64,4.8c0.389,0,0.779,0,1.17,0c0.395,0,0.25,0.74,0.27,1.072\n	C55.169,7.242,55.257,8.613,55.345,9.983 M35.464,14.883c-2.047,0-4.096,0-6.143,0c-0.9,0-1.18,0.381-1.18,1.334\n	c0,0.453-0.301,2.803,0.578,2.803c2.08,0,4.162,0,6.244,0c0.713,0,1.119-0.316,1.119-1.12\n	C36.083,17.427,36.401,14.883,35.464,14.883\"/>\n<rect id=\"sliceCopy_x5F_27_1_\" x=\"59.346\" fill=\"none\" width=\"52.805\" height=\"40\"/>\n<rect id=\"sliceCopy_x5F_26_1_\" fill=\"none\" width=\"59.346\" height=\"40\"/>\n</svg>",
        [7]     = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 1.1//EN\" \"http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd\" [\n	<!ENTITY ns_flows \"http://ns.adobe.com/Flows/1.0/\">\n]>\n<svg version=\"1.1\"\n	 xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" xmlns:a=\"http://ns.adobe.com/AdobeSVGViewerExtensions/3.0/\"\n	 x=\"0px\" y=\"0px\" width=\"111px\" height=\"40px\" viewBox=\"0.492 0 111 40\" enable-background=\"new 0.492 0 111 40\"\n	 xml:space=\"preserve\">\n<defs>\n</defs>\n<path fill=\"#FFFFFF\" d=\"M106.701,10.606l-0.309-0.701l-1.662-0.176V5h-1.797v0.307l-0.131,0.656c-0.117,0.117-0.248,0.396-0.395,0.833l-0.568,1.27\n	l-0.744,1.664l-0.527,0.176h-6.875L92.861,9.38l-1.051-1.095L90.627,6.84h-7.838L82,6.577l-0.877-0.263l-1.051-0.352L61.328,5.788\n	l-1.051,0.088c-0.234,0.058-0.395,0.131-0.482,0.219l-0.264,0.22h-24.35l-0.35-0.352L30.846,9.38l-2.451,0.744l-1.885,0.482\n	l-1.094,0.263l-1.84-0.395L22.35,10.08L16,10.475l-4.293,0.351l-1.926,0.044l-2.234-0.044l-1.926,0.481\n	C5.006,11.481,4.467,11.745,4,12.095l0.875,12.395l10.381-3.416l7.838-2.891l2.979-1.051l2.629-0.964l1.971-0.656l0.875-0.307\n	c0.408-0.088,0.789,0.044,1.139,0.394l0.746,0.525l-0.789,1.052l-1.314,2.408l-1.27,2.409L29.4,23.395\n	c0.146,1.051,0.498,1.752,1.053,2.103c0.584,0.32,1.197,0.467,1.838,0.438l1.752-0.394l0.789-0.352\n	c0.203-0.876,0.584-1.736,1.139-2.583c0.525-0.905,1.094-1.724,1.709-2.453l1.619-1.708l0.832-0.656\n	c0.76,0.612,1.549,0.963,2.365,1.05l2.059-0.132c0.73-0.145,1.43-0.407,2.102-0.787l1.314,0.219l0.352-0.307l0.48-0.043\n	c0.963,2.919,2.176,5.43,3.635,7.532c1.461,2.16,2.875,3.956,4.248,5.387c1.576,1.665,3.242,3.095,4.994,4.292l1.971-3.197\n	l1.443-2.277l0.789-1.007c-2.395-1.693-4.232-3.387-5.518-5.08c-1.256-1.664-2.176-3.183-2.76-4.556\n	c-0.672-1.576-1.008-3.109-1.008-4.598h6l0.615,0.394c0.057,0.117,0.174,0.19,0.35,0.22l0.832,0.132l0.832-0.176l1.139-0.613\n	l1.576-0.832h13.227l0.131-0.744h8.41l0.699,0.525l0.613-0.745h11.781l1.4,0.569l0.746-1.313h0.525l0.48,0.131l0.746-0.263\n	l0.219-0.438L106.701,10.606z M45.912,17.438c-0.264,0.292-0.613,0.438-1.051,0.438h-2.365c-0.467,0-0.875-0.146-1.227-0.438\n	c-0.291-0.292-0.438-0.628-0.438-1.008c0-0.467,0.146-0.861,0.438-1.182c0.352-0.292,0.76-0.424,1.227-0.395l2.365-0.044\n	c0.438,0,0.787,0.146,1.051,0.438c0.262,0.32,0.395,0.715,0.395,1.182L45.912,17.438z\"/>\n<rect id=\"sliceCopy_x5F_47_1_\" x=\"110.92\" fill=\"none\" width=\"105.287\" height=\"40\"/>\n<rect id=\"sliceCopy_x5F_46_1_\" fill=\"none\" width=\"110.92\" height=\"40\"/>\n</svg>",
        [8]     = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 1.1//EN\" \"http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd\" [\n	<!ENTITY ns_flows \"http://ns.adobe.com/Flows/1.0/\">\n]>\n<svg version=\"1.1\"\n	 xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" xmlns:a=\"http://ns.adobe.com/AdobeSVGViewerExtensions/3.0/\"\n	 x=\"0px\" y=\"0px\" width=\"95px\" height=\"40px\" viewBox=\"0.068 0 95 40\" enable-background=\"new 0.068 0 95 40\" xml:space=\"preserve\">\n<defs>\n</defs>\n<path fill=\"#FFFFFF\" d=\"M46.164,17.76l-0.26,0.217c-0.206,0.231-0.305,0.521-0.305,0.869l0.09,0.867l-0.178,0.261l-0.87,0.043l-0.563-0.043\n	l-0.214,0.52h-1.043l-0.306,0.087l-0.261,0.261l-2.128,3.907c-0.288,0.55-0.318,1.027-0.085,1.433\n	c0.171,0.318,0.405,0.521,0.692,0.608h2.953c1.071-0.117,1.894-0.391,2.476-0.825c0.402-0.348,1.824-2.519,4.254-6.512\n	c0.145-0.261-0.044-0.825-0.564-1.693H46.164 M86.93,10.813l0.522,0.044l0.607-0.262h2.126l0.219,0.391l0.172,0.999l-0.172,1\n	l-0.304,0.389h-1.91l-0.394-0.13l-0.39-0.044l-0.521,0.087l-0.259,0.087h-1.216l-0.175-0.13h-1.909l-0.176-0.171H82.24\n	c-0.055,0.201-0.188,0.302-0.389,0.302h-1.78l-0.347-0.13l-0.133-0.086l-12.545,0.303l-0.694,0.738h-0.305l-0.214-0.261h-0.309\n	l-0.175,0.261h-2.604L62.4,16.847c-0.029,0.29-0.218,0.492-0.565,0.608l0.308,0.305l0.691,0.086\n	c0.466,0.087,0.683,0.274,0.652,0.564c-0.177,0.956-0.215,1.664-0.131,2.127l0.044,1.997v2.258c0.058,0.898,0.393,1.853,0.999,2.867\n	c0.115,0.202-0.088,0.404-0.606,0.606l-1.649,0.305l-1.912-0.348l-1.085-0.304c-0.026-1.273,0.044-2.445,0.22-3.517l0.604-2.127\n	c0.231-0.695,0.302-1.202,0.219-1.52l-0.307-1.086l-0.345-0.78c-0.089-0.233,0.13-0.492,0.651-0.782l0.779-0.392l-3.254-0.174\n	l-3.777,0.174c-0.84,0.551-1.939,1.781-3.301,3.691l-2.777,4.167c-0.637,0.927-1.247,1.535-1.823,1.824l-2.476,0.435l-4.3,0.216\n	l-3.037,0.044c-0.288,0-0.479-0.087-0.563-0.26L35.57,26.92c0.058-1.245,0.217-2.142,0.478-2.691l0.824-1.521\n	c0.435-0.782,0.738-1.244,0.912-1.389l0.869-0.782c0.434-0.521,0.651-1.157,0.651-1.91c0-0.84-0.361-1.333-1.086-1.476l-2.432,0.086\n	l-2.65,0.174c-0.867,0.057-1.359,0.203-1.474,0.434c-0.229,0.346-0.636,0.623-1.214,0.825l-0.086,1.563\n	c0.143,1.592,0.589,3.69,1.344,6.295c1.155,4.111,2.212,6.787,3.17,8.032c0.406,0.521,0.36,0.911-0.13,1.171l-3.171,1.13\n	l-3.214,1.128c-0.347,0.087-0.492-0.434-0.436-1.564L26.932,34.3c-0.724-1.91-1.36-3.98-1.91-6.208\n	c-0.524-2.229-0.898-4.371-1.127-6.426l-0.177-2.388l-1.3-0.043l-1.955,1.563c-0.088,0.087-0.233,0-0.436-0.261\n	c-0.203-0.231-0.332-0.333-0.391-0.303c-0.694,0.259-1.736,0.854-3.125,1.779c-1.595,1.129-2.474,1.997-2.649,2.605l-0.304,1.042\n	l0.479,0.521l0.475,0.738c0,0.376-0.114,0.667-0.345,0.868c-0.202,0.203-0.494,0.304-0.87,0.304H8.219\n	c-0.319,0-0.635-0.13-0.956-0.391c-0.376-0.347-0.663-0.811-0.868-1.389l-1.344-5.601c-0.667-3.126-1.014-5.036-1.042-5.731\n	c-0.03-0.723,0.014-1.245,0.13-1.563l0.564-0.826l1.388-1.128c0.696-0.463,1.23-0.693,1.608-0.693l27.307-0.565V9.902L35.7,9.381\n	l1.042-0.695l1.215-0.218l1.648,0.043V6.299h-0.648c0.026,0.317-0.19,0.476-0.648,0.476l-0.524-0.217l-0.086-0.259h-1.521\n	l-0.217,0.216h-0.52c-0.263-0.377-0.393-1.014-0.393-1.911c0-0.869,0.115-1.346,0.347-1.434h0.392l0.261,0.175l1.477-0.044\n	l0.086-0.304c0.088-0.172,0.29-0.259,0.608-0.259c0.376,0,0.564,0.172,0.564,0.52l0.438-0.044V2.476l0.822-0.129l0.909,0.086v0.522\n	l3.432-0.479L48.508,2h1.346l0.608,0.476h0.606v-0.26h0.479V2.39h0.866v4.255l-0.866,0.043v0.173H51.11V6.601h-2.167l0.348,0.521\n	h0.563c0.406,0.059,0.623,0.159,0.65,0.304l0.178,0.825h1.43V8.078h0.649v0.173h1.477V8.078h0.651v0.173h1.477V8.078h0.609v0.173\n	h1.518V8.078h0.609v0.173h1.521V8.078h0.606v0.173H62.4l3.082,1.52v1l0.78,0.433h13.462l0.216-0.13l0.349-0.215h1.605l0.391,0.346\n	h0.782l0.389-0.217l1.695,0.086l0.042-0.173c0.088-0.117,0.203-0.174,0.348-0.174h1.087L86.93,10.813\"/>\n<rect id=\"sliceCopy_x5F_46_1_\" x=\"94.576\" fill=\"none\" width=\"110.92\" height=\"40\"/>\n<rect id=\"sliceCopy_x5F_45_1_\" fill=\"none\" width=\"94.576\" height=\"40\"/>\n</svg>",
        [9]     = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 1.1//EN\" \"http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd\" [\n	<!ENTITY ns_flows \"http://ns.adobe.com/Flows/1.0/\">\n]>\n<svg version=\"1.1\"\n	 xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" xmlns:a=\"http://ns.adobe.com/AdobeSVGViewerExtensions/3.0/\"\n	 x=\"0px\" y=\"0px\" width=\"136px\" height=\"40px\" viewBox=\"0.353 0 136 40\" enable-background=\"new 0.353 0 136 40\"\n	 xml:space=\"preserve\">\n<defs>\n</defs>\n<path fill=\"#FFFFFF\" d=\"M131.697,16.016l-0.18-0.45l-0.227-0.495V14.89H56.996v-1.036l2.162-0.044l1.26,0.226v-0.182l8.781,0.541h0.27l-0.09-5.133\n	l-0.18-0.136l-1.486-0.18l-2.746,0.226l-2.928,0.314l-2.16,0.315H53.35V9.576c0.15,0,0.256-0.06,0.314-0.18l0.135-0.135L53.35,8\n	h-0.045l-3.738,0.226v0.721l0.092,0.226v0.765l-1.262,0.09l-1.938,0.046h-2.16h-1.756l-1.801-0.136l-2.521,0.136l-2.162,0.135\n	l-0.945,0.09h-0.225l-0.09,0.091c-0.09,0.089-0.137,0.254-0.137,0.495v1.216l0.137,1.937v0.135l0.09,0.225l2.205,0.135l2.521-0.226\n	l2.162-0.269l1.125-0.182h1.396v1.126h-3.783c-0.148,0.06-0.238,0.136-0.27,0.225l-0.449,0.091l-1.441,0.271L36.6,15.88h-0.09v0.271\n	l-0.227,1.125l-0.359,1.126H23.766l-1.215-1.216c-0.24-0.24-0.48-0.376-0.721-0.406H11.113l-0.359,0.271l-0.225,0.135l-0.137,0.09\n	l-0.09,0.09h-1.17l-4.008,0.271c-0.6,0.27-0.9,0.524-0.9,0.766v2.972L4,25.382v3.467v1.711l0.09,0.765l0.135,0.136h0.314l1.08-0.225\n	l1.441-0.315l1.396-0.225l0.9-0.136h1.172h1.801l1.531,0.314L14.4,30.56c0.15,0,0.24-0.12,0.271-0.36l0.449-2.881h5.898l0.855,0.63\n	l1.352,1.215l1.26,1.351l1.711,0.586l3.063,0.496L32.412,32l2.115-0.226l0.631-0.9l0.541-1.711l0.314-1.801l0.045-1.395h0.361\n	l0.18-0.091c0.99,0.601,1.875,0.93,2.656,0.991l2.07-0.182l1.352-0.719l0.721-0.586c0.119-0.15,0.449-0.226,0.99-0.226v3.242\n	l10.311-1.08v-3.152c0.061-0.091,0.406-0.211,1.037-0.36l2.16-0.586l2.072-0.586l1.125-0.314l8.736,0.09\n	c-0.57,0.241-1.066,0.36-1.486,0.36c-0.18-0.21-0.645-0.314-1.396-0.314h-0.135c-0.359,0-0.541,0.179-0.541,0.54\n	c-0.24,0.45-0.209,1.02,0.092,1.711l0.584,1.351l0.225,0.226h1.803l0.225-0.676l-0.316-0.314l-0.225-0.136l0.225-0.45H79.42h5.404\n	h2.115h0.406l0.225-0.54V24.03l0.09-0.135l0.09-0.36c0-0.511-0.135-0.871-0.404-1.08l-0.496-0.496v-3.062h-3.512v-0.811h47.818\n	l0.135-0.225c0.361-0.541,0.541-0.961,0.541-1.261L131.697,16.016z M41.191,25.066H38.67c-0.689,0-1.035-0.376-1.035-1.126\n	c0-0.631,0.346-0.945,1.035-0.945h2.521c0.691,0,1.037,0.314,1.037,0.945C42.229,24.69,41.883,25.066,41.191,25.066z\"/>\n<rect id=\"sliceCopy_x5F_52_1_\" x=\"135.832\" fill=\"none\" width=\"125.222\" height=\"40\"/>\n<rect id=\"sliceCopy_x5F_51_1_\" fill=\"none\" width=\"135.832\" height=\"40\"/>\n</svg>",
        [10]    = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 1.1//EN\" \"http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd\" [\n	<!ENTITY ns_flows \"http://ns.adobe.com/Flows/1.0/\">\n]>\n<svg version=\"1.1\"\n	 xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" xmlns:a=\"http://ns.adobe.com/AdobeSVGViewerExtensions/3.0/\"\n	 x=\"0px\" y=\"0px\" width=\"90px\" height=\"40px\" viewBox=\"0.986 0 90 40\" enable-background=\"new 0.986 0 90 40\" xml:space=\"preserve\">\n<defs>\n</defs>\n<path fill=\"#FFFFFF\" d=\"M86.65,14.6l0.258,0.772c0.074,0.566-0.305,1.072-0.258,1.585c-1.242,0.017-2.494,0.167-3.74,0.197\n	c-1.057,0.025-1.992-0.326-3.039-0.326c-1.762,0-3.523,0-5.283,0c-1.238,0-2.23,0.657-3.451,0.729l-0.387-0.3h-0.17\n	c-0.229,1.12-0.488,1.927-1.156,2.872c-1.018,0.339-1.834,0.3-2.91,0.3c-2.129,0-4.26,0-6.391,0c-2.125,0-4.252,0-6.377,0\n	c-1.051,0-2.047-0.1-3.051,0.214c0,1.105,0.186,2.48-0.471,3.428c-0.963,0.613-2.553,0.233-3.639,0.12\n	c-0.963-0.102-1.904-0.233-2.834-0.506l-0.77,0.513c-0.66,0.496-0.514,1.5-0.514,2.229c-0.52,0.212-0.768,0.908-0.986,1.372\n	c0.023,0.244,0.037,0.488,0.086,0.728l0.258,0.343h-0.258c-0.652,0.831-0.898,1.491-0.898,2.571l0.17,0.257\n	c-0.91,0-1.877-0.347-2.775-0.521c-0.406-0.08-0.793-0.257-1.18-0.396c-0.18-0.064-0.373-0.115-0.543-0.196\n	c-0.461-0.216-0.545-0.596-0.9-0.857c0.145-1.954,0.252-4.185,1.121-5.973c0.576-1.179,1.844-1.93,1.963-3.24\n	c0-0.258-0.227-0.515-0.684-0.772c-1.252-0.215-2.193-0.21-3.428,0.258c-1.209,0.435-2.236,1.234-2.939,2.311\n	c-0.6,0.917-0.793,2.403-2.205,2.403c0.016,1.263,0.135,2.517,0.18,3.777c0.055,1.509,0.285,3.076,0.25,4.58\n	c-2.031,1.479-4.344,1.933-6.814,1.928c-0.236-4.398-0.518-8.795-0.6-13.198c-1.578,0.27-3.123,0.545-4.672,0.942\n	c-0.057,0.339-0.07,1.329-0.512,1.329c-0.684,0.162-1.475,0.462-2.143,0.515c-0.174-0.26-0.338-0.465-0.559-0.687l-0.086-0.385\n	c-2.611,1.354-5.375,1.573-8.271,1.714c-0.078-0.099-0.18-0.17-0.299-0.214c-0.74-2.321-1.355-4.659-1.572-7.09\n	c-0.148-1.649-0.492-4.265,0.586-5.683c0.43-0.631,0.951-1.125,1.355-1.769c0.27-0.436,0.584-0.851,0.875-1.274V8.987h8.096v0.214\n	c0.502,0.712,0.973,1.315,1.588,1.929c1.047-0.484,1.799-1.07,2.699-1.8c4.197-0.034,8.361,0.639,12.557,0.171\n	c0.207-0.593,0.406-1.188,0.557-1.8c0.119-0.489,0.43-1.218,0.428-1.714c0.988-0.93,3.234-1.02,4.555-0.979\n	c1.781,0.056,3.563,0.114,5.342,0.171c4.707,0.15,9.41,0.301,14.115,0.451c2.225,0.071,4.449,0.119,6.672,0.177\n	c2.209,0.058,4.436,0.18,6.641,0.18c0.229-0.056,0.443,0.1,0.643,0.471c1.027,1.134,0.895,3.184,0.814,4.628\n	c-0.057,1.019-0.311,1.997-0.428,3c0.768-0.033,1.527,0.177,2.27,0.342c0.059,0.104,0.09,0.223,0.086,0.342c1.127,0,2.254,0,3.381,0\n	c0.988,0,2.164,0.184,3.133-0.086c2.037-0.569,4.105-0.52,6.213-0.429l0.303,0.172V14.6 M65.951,8.645H38.398\n	c-0.943,0-1.414,0.5-1.414,1.5v1.371c0,0.971,0.473,1.457,1.414,1.457c8.449,0,16.902,0,25.352,0c0.801,0,2.656,0.293,3.23-0.429\n	c0.707-0.565,0.648-2.888,0-3.471C66.752,8.788,66.41,8.645,65.951,8.645\"/>\n<rect id=\"sliceCopy_x5F_45_1_\" x=\"90.918\" fill=\"none\" width=\"94.576\" height=\"40\"/>\n<rect id=\"sliceCopy_x5F_44_1_\" fill=\"none\" width=\"90.918\" height=\"40\"/>\n</svg>",
        [11]    = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 1.1//EN\" \"http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd\" [\n	<!ENTITY ns_flows \"http://ns.adobe.com/Flows/1.0/\">\n]>\n<svg version=\"1.1\"\n	 xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" xmlns:a=\"http://ns.adobe.com/AdobeSVGViewerExtensions/3.0/\"\n	 x=\"0px\" y=\"0px\" width=\"114px\" height=\"40px\" viewBox=\"0.383 0 114 40\" enable-background=\"new 0.383 0 114 40\"\n	 xml:space=\"preserve\">\n<defs>\n</defs>\n<path fill=\"#FFFFFF\" d=\"M109.303,18.864c-1.885,0.245-3.764,0.179-5.65,0.008c-0.254-0.023-0.436-0.182-0.695-0.182c-0.521,0-1.039,0-1.561,0\n	c-1.27,0-2.537,0-3.807,0c-0.41,0-0.383,0.017-0.723,0.216c-0.373,0.219-0.748,0.425-1.188,0.206\n	c-1.104-0.551-1.303,0.506-1.686,1.228c-0.219,0.412-0.797-0.372-0.797,0.366c0,0.562,0.219,1.117-0.389,1.31\n	c-0.775,0.246-1.631-0.172-2.418-0.172c-0.639,0-1.277,0-1.916,0c-0.326,0-1.236-0.197-1.236,0.198c0,0.433,0.025,0.308-0.346,0.362\n	c-0.236,0.035-0.531-0.032-0.77-0.047c-0.207-0.014-0.469,0.015-0.666-0.059c-0.324-0.121-0.248-0.171-0.377-0.454\n	c0.34-0.283-0.787-0.172-0.996-0.172c-1.109,0-2.217,0-3.326,0c-2.67,0-5.338,0-8.006,0c-1.461,0-2.848,0.125-4.303,0.251\n	c-0.414,0.035-0.828,0.074-1.244,0.114c-0.467,0.048-1.289,0.332-1.707,0.248c-0.238-0.048-0.428-0.25-0.611-0.396\n	c-0.09-0.073-0.018-0.39-0.082-0.39c-0.402,0-0.803,0-1.205,0c-1.49,0-2.979,0-4.469,0c0.156,1.975,0.318,3.948,0.496,5.919\n	c0.057,0.641,0.807,5.033,0.215,5.181c-1.924,0.482-3.852,0.851-5.818,1.125c-0.521,0.073-2.01,0.644-2.135-0.114\n	c-0.154-0.937-0.217-1.902-0.32-2.844c-0.154-1.449-0.262-2.901-0.379-4.354c-0.057-0.723-0.115-1.446-0.174-2.168\n	c-0.002-0.042-0.707-0.076-0.754,0.004c-0.18,0.306-0.311,0.844-0.758,0.703c0.113-0.245,0.23-0.489,0.346-0.735\n	c-0.256,0-0.512,0-0.766,0c-0.229,0-0.104,0.103-0.162,0.278c-0.197,0.565-0.396,1.131-0.592,1.697\n	c-0.156,0.45-0.529,1.303-1.047,1.404c-0.598,0.118-1.197,0.234-1.797,0.352c-0.355,0.069-0.613,0.034-0.98-0.012\n	c-0.383-0.048-1.145,0.01-1.469-0.201c-0.391-0.251-0.762-0.455-1.184-0.652c-0.113-0.054-0.402-0.298-0.51-0.276\n	c-0.197,0.041-0.355,0.495-0.426,0.635c-0.836,1.669-1.529,3.395-2.428,5.033c-0.193,0.353-0.436,0.649-0.807,0.788\n	c-0.447,0.167-1.539-0.638-1.859-0.869c-0.854-0.616-1.707-1.233-2.563-1.849c-0.121-0.087-0.254-0.162-0.379-0.241\n	c0.551-0.685,0.859-1.654,1.291-2.427c0.598-1.066,1.619-1.721,2.279-2.731c0.568-0.875,0.463-2.745-0.896-2.745\n	c-1.17,0-2.338,0-3.508,0c-0.969,0-1.934,0-2.9,0c-0.764,0-1.584,0.378-2.297,0.622c-1.639,0.56-3.277,1.136-4.895,1.757\n	c-3.723,1.429-7.469,2.788-11.227,4.127c-1.652,0.589-3.396,1-5.176,0.964C4.129,29.845,4,28.991,4,27.762\n	c0-0.603,0.211-1.1,0.305-1.688c0.064-0.409-0.078-0.921,0.057-1.297c0.332-0.934,0.219-1.852,0.182-2.832\n	c-0.016-0.365-0.035-0.714-0.082-1.076c-0.035-0.279-0.068-0.557-0.104-0.837c-0.016-0.113-0.164-0.161-0.227-0.361\n	C3.988,19.214,4,18.803,4,18.328c0-0.543,0.605-0.543,1.023-0.648c0.924-0.232,1.91-0.198,2.857-0.198\n	c0.438,0,0.875-0.021,1.311-0.039c0.344-0.015,0.434-0.999,0.686-1.258c0.584-0.601,2.129-0.414,2.895-0.43\n	c1.836-0.038,3.672-0.077,5.506-0.114c1.002-0.02,2.004-0.042,3.006-0.06c0.502-0.008,1.004-0.018,1.508-0.024\n	c0.166-0.003,1.145-0.144,1.264,0.013c0.514,0.667,0.762,1.764,1.801,1.419c0.84-0.279,1.646-0.702,2.398-1.167\n	c0.914-0.564,2.01-1.449,3.119-1.449c0.906-0.037,1.814,0.002,2.723-0.039c0.484-0.022,0.906,0.086,1.219-0.287\n	c0.389-0.469,0.531-0.67,1.086-0.987c0.76-0.434,1.494-0.036,2.299,0.165c0.359,0.09,1.301,0.933,0.617,1.149\n	c0.477,0.087,0.389-0.119,0.389-0.511c0-0.287-0.342-0.432-0.492-0.694c-0.279-0.491-0.617-1.15-0.588-1.731\n	c-0.967,0.148-1.934,0.297-2.898,0.451c-0.797,0.125-1.609,0.022-2.416,0.022c-1.027,0-2.055-0.001-3.082-0.021\n	c-0.895-0.017-1.822-0.135-2.691-0.011c-1.002,0.144-2.025-0.019-3.031-0.088c-0.256-0.019-0.348-1.993-0.375-2.348\n	c-0.039-0.509-0.035-0.953,0.01-1.462c0.035-0.419,0.27-0.762,0.334-1.145c0.105-0.631,1.943-0.32,2.443-0.32\n	c1.824,0,3.668,0.118,5.492,0.18c1.881,0.065,3.859-0.056,5.727,0.169c0.857,0.103,1.811,0.395,2.672,0.34\n	c1.025-0.067,2.047-0.114,3.072-0.154C44.748,7.018,45.615,7,46.482,6.991c0.461-0.006,0.902,0.014,1.357-0.058\n	c0.123-0.018,0.449-0.006,0.543-0.072c0.344-0.247,0.266-0.544,0.775-0.691c0.775-0.366,1.57-0.043,2.361,0.078\n	c0.176,0.027,0.268,0.294,0.404,0.398c0.146,0.185,0.621,0.306,0.863,0.346c0.826,0.133,1.762,0.155,2.602,0.113\n	c2.016-0.102,4.008-0.314,6.016-0.494c0.939-0.083,1.883-0.074,2.824-0.091c0.746-0.013,2.271-0.081,2.746,0.594\n	c0.482,0.683,0.418,2.113,0.191,2.865c-0.156,0.516-0.531,0.982-0.811,1.439c-0.207,0.341-2.541,0.15-2.865,0.15\n	c-1.02,0-2.072-0.005-3.08-0.133c-1.088-0.135-2.23-0.423-3.313-0.22c-0.439,0.083-1.205-0.199-1.59,0.006\n	c-0.16,0.086-0.332,0.542-0.424,0.694c-0.195,0.319-0.186,0.183-0.455,0.331c-0.992,0.542-2.326,0.987-2.705,2.127\n	c7.971,0,15.943,0,23.918,0c1.15,0,2.297-0.295,3.445-0.347c0.361-0.016,0.738,0,1.096-0.067c0.516-0.097,0.559-0.221,0.967-0.493\n	c0.32-0.214,0.715-0.128,1.094-0.128c0.537,0,0.678-0.089,0.996,0.345c0.467,0.64,0.439,0.604,1.195,0.604c1.008,0,2.016,0,3.021,0\n	c1.662,0,3.322,0,4.98,0c-0.127-0.457-0.643-1.774-0.238-2.181c0.303-0.301,0.656-0.737,1.078-0.86\n	c0.234-0.069,0.973,0.069,1.053,0.295c0.301,0.86,0.451,1.688,0.609,2.587c0.064,0.353,0.047,0.703,0.047,1.061\n	c0,0.309-0.057,0.262,0.172,0.405c0.244,0.151,0.24,0.487,0.043,0.679c0.221,0.002,0.479-0.172,0.6-0.172c0.193,0,0.387,0,0.582,0\n	c0.24,0,0.24,0.093,0.416,0.129c0.344,0.071,0.695,0.042,1.047,0.042c1.795,0,3.59,0,5.385,0c1.77,0,3.535,0,5.305,0\n	c0.313,0,0.709-0.109,0.914,0.173c0.15,0.208,0.104,0.847,0.133,1.102C109.84,18.02,109.9,18.726,109.303,18.864 M41.992,24.304\n	c-0.826,0.814,1.682,1.338,2.16,1.338c1.012,0,2.285,0.259,2.668-0.932c0.158-0.494,0.646-1.276-0.17-1.127\n	c-0.576,0.104-0.932,0.291-1.543,0.291C44.043,23.873,43.021,24.03,41.992,24.304\"/>\n<rect id=\"sliceCopy_x5F_50_1_\" x=\"113.817\" fill=\"none\" width=\"113.213\" height=\"40\"/>\n<rect id=\"sliceCopy_x5F_49_1_\" fill=\"none\" width=\"113.816\" height=\"40\"/>\n</svg>",
        [13]    = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 1.1//EN\" \"http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd\" [\n	<!ENTITY ns_flows \"http://ns.adobe.com/Flows/1.0/\">\n]>\n<svg version=\"1.1\"\n	 xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" xmlns:a=\"http://ns.adobe.com/AdobeSVGViewerExtensions/3.0/\"\n	 x=\"0px\" y=\"0px\" width=\"121px\" height=\"40px\" viewBox=\"0.292 0 121 40\" enable-background=\"new 0.292 0 121 40\"\n	 xml:space=\"preserve\">\n<defs>\n</defs>\n<path fill=\"#FFFFFF\" d=\"M115.749,9.167c0.857,0,0.471,2.731,0.471,3.313c0,0.337-0.201,0.214-0.52,0.214c-0.721,0-1.439,0-2.16,0\n	c-1.896,0-3.793-0.028-5.689,0.027c-2.211,0.063-4.418,0.117-6.629,0.137c-0.912,0.009-1.824,0.014-2.738,0.026\n	c-0.633,0.009-1.268,0.018-1.902,0.026c-0.297,0.004-0.596,0.009-0.896,0.014c-0.453,0.007-0.225,0.121-0.389,0.557\n	c-0.289,0.757-1.619,1.708-2.455,1.34c-0.594-0.263-1.092-0.833-1.566-1.261c-0.158-0.142-0.928-0.271-1.152-0.35\n	c-0.533-0.186-1.012-0.295-1.57-0.356c-2.105-0.234-4.252-0.021-6.363,0.06c-0.557,0.021-0.438,0.319-0.574,0.82\n	c-0.061,0.22-0.213,0.307-0.451,0.331c-0.451,0.045-0.404,0.06-0.445,0.51c-0.045,0.488-0.088,0.977-0.137,1.464\n	c-0.008,0.073-1.02,0.047-1.113,0.049c-2.322,0.025-4.645,0.051-6.967,0.077c-2.127,0.022-4.365-0.08-6.471,0.221\n	c-0.529,0.075-1.061,0.103-1.588,0.185c-0.373,0.058-1.342,0.398-1.686,0.31c-0.656-0.168-0.564-2.532-0.564-3.15\n	c-1.418,0.322-2.855,0.543-4.283,0.828c-0.338,0.067-0.693,0.076-1.035,0.108c-0.025,0.002-0.166,0.794-0.209,0.925\n	c-0.221,0.662,0.055,1.778,0.145,2.458c0.135,1.016,0.338,2.021,0.586,3.017c0.691,2.638,1.543,5.188,2.539,7.721\n	c0.508,1.296,0.955,2.754,1.693,3.939c-2.098,0.727-4.223,1.887-6.17,2.922c-0.232,0.122-0.631,0.455-0.932,0.322\n	c-0.256-0.331-0.465-0.696-0.654-1.067c-0.414-0.81-0.771-1.671-1.047-2.536c-0.326-1.023-0.65-2.045-0.977-3.067\n	c-1.115-3.5-1.943-7.08-2.869-10.633c-0.424,0.195-0.883,0.361-1.283,0.602c-0.234,0.14-0.4,0.346-0.633,0.469\n	c-0.553,0.293-1.492,0.332-2.115,0.38c-1.143,0.087-2.107-0.201-3.129-0.698c-0.305-0.148-0.543-0.458-0.82-0.235\n	c-0.221,0.177-0.523,0.279-0.775,0.405c-0.359,0.18-0.521,0.97-0.666,1.335c-0.229,0.569-0.441,1.145-0.629,1.729\n	c-0.262,0.814-0.521,1.676-0.586,2.533c-0.084,1.115-0.227,2.238-0.227,3.355c0,0.394-0.004,0.829-0.49,0.704\n	c-0.705-0.182-1.381-0.523-2.037-0.836c-1.029-0.49-2.025-1.042-3.045-1.551c-0.43-0.214,0.008-0.744,0.16-1.093\n	c0.871-1.985,1.662-3.99,2.361-6.044c0.246-0.728,0.875-1.838,0.273-2.524c-0.318-0.362-0.654-0.693-0.949-1.073\n	c-0.15-0.192-1.109-0.189-1.367-0.185c-2.004,0.036-4.008,0.074-6.012,0.191c-2.258,0.131-4.514,0.232-6.773,0.313\n	c-3.426,0.123-6.404,2.42-8.979,4.478C9.907,22,8.495,23.127,7.271,24.354c-0.289,0.29-0.539,0.834-0.904,1.017\n	c-0.838,0.419-1.053-0.529-1.205-1.167c-0.217-0.902-0.148-1.886-0.227-2.813c-0.086-1.021-0.174-2.044-0.264-3.064\n	c-0.094-1.042-0.189-2.069-0.338-3.104c-0.203-1.427-1.084-4.081,1.24-4.081c1.418,0,2.838,0,4.256,0c5.543,0,11.086,0,16.627,0\n	c0.607,0,1.217,0,1.824,0c0.215,0,0.459,0.044,0.666,0c0.6,0,0.607-1.056,1.258-1.211c1.049-0.251,2.076-0.308,3.105-0.679\n	c0.578-0.207,0.883-0.372,1.355-0.762c0.574-0.472,0.629-0.925,0.723-1.628c0.158-1.187-0.057-2.533,1.553-2.492\n	c0.518,0.014,0.777,0.437,1.162,0.805c0.504,0.48,0.74,0.329,1.443,0.245c0.633-0.076,0.729-0.02,1.055,0.499\n	c0.271,0.436,0.313,0.98,0.424,1.479c0.029,0.131,2.723-0.137,3.049-0.156c0.906-0.056,1.842,0.244,2.74,0.327\n	c0.662,0.062,1.355,0,2.018,0c2.836,0,5.67,0,8.504,0c0.49,0,0.98,0,1.469,0c-0.068-0.398-0.107-0.804-0.279-1.175\n	c0.557,0,1.115,0,1.674,0c0.834,0,0.055,0.417,0.582,0.682c0.229,0.112,0.67,0.022,0.914,0.022c2.035,0,4.07,0,6.105,0\n	c5.836,0,11.672,0,17.508,0c1.51,0,3.021,0,4.531,0c-0.049-0.242-0.045-0.479-0.045-0.726c0-0.287-0.27-0.733-0.131-0.99\n	c0.133-0.247,0.457-1.181,0.73-1.207c0.604-0.058,1.203-0.115,1.807-0.172c0.459-0.045,0.271,0.448,0.271,0.827\n	c0,0.687,0,1.374,0,2.061c0,0.175,0,0.35,0,0.524c0,0.061-0.383,0.128-0.377,0.295c0.012,0.204,1.123,0.831,1.309,0.969\n	c0.777,0.576,1.789,0.681,2.725,0.728c4.078,0.204,8.133,0.103,12.215,0.027c1.215-0.022,2.447,0.039,3.645-0.15\n	C112.755,9.162,115.222,8.426,115.749,9.167 M42.96,15.515c-1.186,0-1.322,1.667-0.752,2.397c0.461,0.462,0.996,0.377,1.588,0.377\n	c0.529,0,3.209,0.357,3.453-0.412c0.326-1.023,0.465-2.362-1.047-2.362C45.122,15.515,44.04,15.515,42.96,15.515 M6.565,15.421\n	c0.275,1.894,0.426,3.796,0.705,5.689c3.07-2.703,6.371-5.087,9.686-7.477c-3.543,0-7.084,0-10.625,0\n	C6.409,14.229,6.487,14.825,6.565,15.421\"/>\n<rect id=\"sliceCopy_x5F_44_1_\" x=\"120.306\" fill=\"none\" width=\"90.918\" height=\"40\"/>\n<rect id=\"sliceCopy_x5F_43_1_\" fill=\"none\" width=\"120.306\" height=\"40\"/>\n</svg>",
        [14]    = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 1.1//EN\" \"http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd\" [\n	<!ENTITY ns_flows \"http://ns.adobe.com/Flows/1.0/\">\n]>\n<svg version=\"1.1\"\n	 xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" xmlns:a=\"http://ns.adobe.com/AdobeSVGViewerExtensions/3.0/\"\n	 x=\"0px\" y=\"0px\" width=\"107px\" height=\"40px\" viewBox=\"0.611 0 107 40\" enable-background=\"new 0.611 0 107 40\"\n	 xml:space=\"preserve\">\n<defs>\n</defs>\n<path fill=\"#FFFFFF\" d=\"M60.227,6.817c0.49,0,1.104-0.11,1.461,0.277c0.119,0.128,0.258,0.132,0.416,0.132c0.213,0,0.119,0.124,0.24,0.148\n	c0.234,0.047,0.445-0.006,0.678,0.014c0.484,0.04,0.914,0.29,1.332,0.529c0.432,0.246,0.848,0.178,1.299,0.312\n	c0.248,0.072,1.029,0.321,1.189,0.482c0.234,0.237,0.361,1.071,0.4,1.401c0.057,0.487,0.025,0.948-0.104,1.424\n	c-0.143,0.463-0.59,1.788-1.227,1.821c1.648,0,3.295,0,4.943,0c1.131,0,2.266,0,3.396,0c0.328,0,1.252-0.173,1.545,0\n	c0.271,0.161,0.146,0.559,0.553,0.636c0.447,0.084,0.898,0.157,1.342,0.255c0.756,0.167,1.496,0.382,2.256,0.526\n	c0.381,0.073,0.76,0.143,1.145,0.198c0.729,0.104,0.762-0.313,0.854-0.96c0.107-0.75,0.721-1.292,0.77-2.075\n	c0.025-0.401,0.074-0.792,0.129-1.192c0.029-0.227,0.904-0.103,1.127-0.103c0.162,0,0.076,2.091,0.076,2.335c0,0.483,0,0.967,0,1.45\n	c0,0.127-0.088,0.594-0.037,0.674c0.135,0.213,0.926,0.163,1.107,0.179c0.313,0.026,0.611,0.043,0.924,0.039\n	c3.451-0.042,6.9-0.073,10.352-0.106c1.486-0.015,3.021,0.093,4.49-0.098c0.375-0.048,0.764-0.014,1.141-0.014\n	c0.502,0,0.434,0.585,0.512,0.985c0.082,0.436,0.291,0.764-0.051,1.066c-0.23,0.205-0.756,0.228-1.061,0.216\n	c-3.145-0.128-6.256-0.223-9.404-0.223c-2.174,0-4.35,0-6.523,0c-0.439,0-0.865-0.034-1.291,0.073\n	c-0.293,0.072-0.273,0.56,0.076,0.56c0.359,0,1.117-0.155,1.439,0c0.869,0.418,0.594,1.56,0.594,2.318\n	c0,0.152-0.768,0.065-0.93-0.015c-0.406-0.204-0.613-0.186-1.072-0.186c-1.75,0-3.537,0.168-5.293,0.225\n	c-1.121,0.037-2.232,0.184-3.35,0.224c-0.16,0.006-0.881-0.068-0.967,0.058c-0.242,0.355-0.48,0.85-0.885,1.044\n	c-0.617,0.297-1.176-0.006-1.623-0.441c-0.377-0.37-0.648-0.42-1.117-0.628c0.066,0.552,0.125,1.079,0.111,1.634\n	c-0.016,0.654,0.029,1.314-0.818,1.153c-0.227-0.044-0.432-0.219-0.666-0.226c-0.357-0.011-0.717-0.019-1.074-0.03\n	c-0.602-0.016-1.205-0.004-1.807-0.004c-2.41,0-4.818,0.036-7.229,0.036c0.58,2.124,0.557,4.076,0.557,6.248\n	c0,0.323,0.166,4.877-0.32,4.808c-1.672-0.237-3.467-0.055-5.152-0.055c-0.967,0-1.934,0-2.902,0c-0.596,0-1.32,0.066-1.324-0.716\n	c-0.023-3.722-0.047-7.443-0.07-11.164c-0.002-0.255,0.109-1.172-0.088-1.293c-0.367-0.227-0.873,0.112-0.842,0.514\n	c0.023,0.287,0.281,0.869-0.07,1.019c-0.305,0.13-0.076,0.651-0.055,0.979c0.021,0.314,0.016,0.96-0.139,1.222\n	c-0.307,0.52-1.467,0.967-2.029,0.967c-1.201,0-2.271-0.05-3.359-0.595c-0.313,0.934-0.689,1.834-1.039,2.755\n	c-0.189,0.501-0.398,1-0.568,1.507c-0.064,0.195-0.273,0.552-0.25,0.754c0.029,0.287,0.328,0.442,0.26,0.781\n	c-0.098,0.481-0.615,1.106-1.105,1.131c-0.738,0.037-1.541-0.309-2.244-0.516c-0.447-0.132-0.879-0.341-1.313-0.511\n	c-0.449-0.174-1.086-0.592-1.582-0.513c0.887-1.25,1.633-2.691,2.408-4.014c0.254-0.433,0.508-0.866,0.76-1.299\n	c0.133-0.229,0.449-0.636,0.436-0.888c-0.027-0.548-0.014-1.128-0.592-1.417c-0.178-0.122-0.648-0.432-0.871-0.449\n	c-3.254-0.229-6.49-0.518-9.752-0.518c-1.605,0-3.213-0.065-4.813,0.093c-1.025,0.102-2.051,0.204-3.078,0.306\n	c-1.137,0.112-2.871,0.412-2.801,1.837c0.021,0.455,0.137,0.907,0.35,1.31c0.154,0.289,0.611,0.673,0.537,1.036\n	c-0.041,0.199-0.316,0.213-0.482,0.222c-0.658,0.029-1.318,0.06-1.977,0.09c-2.324,0.106-4.65,0.212-6.973,0.318\n	c-0.959,0.044-1.914,0.087-2.871,0.131c-0.418,0.018-1.035,0.151-1.438-0.036c-0.857-0.401-0.801-1.524-0.801-2.33\n	c0-0.933,0-1.866,0-2.799c0-2.188,0-4.376,0-6.565c0-0.736-0.066-0.738,0.568-1.176c0.205-0.141,0.916,0.016,1.158,0.025\n	c0.297,0.011,0.605-0.001,0.898,0.04c1.961,0.272,3.922,0.544,5.883,0.815c0.672,0.092,1.502,0.086,2.063,0.508\n	c0.736,0.555,1.186,1.444,2.143,1.681c0.428,0.105,0.936,0.009,1.369-0.005c3.299-0.11,6.523-1.059,9.535-2.359\n	c1.26-0.544,2.514-1.046,3.877-1.286c1.277-0.225,2.582-0.255,3.869-0.439c0.852-0.122,1.676-0.179,2.533-0.22\n	c0.049-0.002,0.633-1.865,0.914-2.112c0.734-0.643,1.84-0.322,2.684-0.138c0.785,0.173,1.521,0.378,2.283,0.641\n	c0.549,0.189,0.408,1.605,0.619,1.605c0.934,0,1.869,0,2.803,0c0.969,0,1.936,0,2.904,0c0.313,0,0.096-0.483,0.17-0.483\n	c0.426,0,0.852,0,1.275,0c0.527,0,1.055,0,1.582,0c0.043,0,0.26-0.03,0.291,0c0.131,0.12-0.164,0.477,0.098,0.487\n	c0.799,0.031,1.596,0.016,2.395,0.043c1.564,0.05,3.086,0.012,4.654-0.111c0.801-0.063,1.602-0.111,2.4-0.2\n	c0.855-0.095,1.775,0.017,2.406-0.613c0.139-0.139,0.77-1.024,0.586-1.146c-0.385-0.255-0.748-0.503-1.176-0.682\n	c-0.893-0.373-1.824-0.492-2.762-0.687c-0.42-0.087-0.844-0.158-1.254-0.287c-0.256-0.08-0.359-0.111-0.547-0.298\n	c-0.234-0.235-0.219-0.222-0.574-0.222c-0.369,0-1.068,0.179-1.395,0c-0.314-0.386-0.51-0.885-0.361-1.374\n	C58.008,6.933,58.521,6.352,58.48,6C59.148,6.073,59.744,6.375,60.227,6.817 M48.037,22.538c-0.506,0.007-1.01,0.014-1.518,0.021\n	c-0.67,0.01-1.482-0.183-1.285,0.841c0.186,0.972,1.258,0.847,1.996,0.847C48.271,24.245,48.246,23.245,48.037,22.538\"/>\n<rect id=\"sliceCopy_x5F_57_1_\" fill=\"none\" width=\"106.674\" height=\"40\"/>\n</svg>",
        [16]    = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 1.1//EN\" \"http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd\" [\n	<!ENTITY ns_flows \"http://ns.adobe.com/Flows/1.0/\">\n]>\n<svg version=\"1.1\"\n	 xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" xmlns:a=\"http://ns.adobe.com/AdobeSVGViewerExtensions/3.0/\"\n	 x=\"0px\" y=\"0px\" width=\"106px\" height=\"40px\" viewBox=\"0.931 0 106 40\" enable-background=\"new 0.931 0 106 40\"\n	 xml:space=\"preserve\">\n<defs>\n</defs>\n<path fill=\"#FFFFFF\" d=\"M53.07,21.232c0-1.862-2.195-1.415-3.436-1.415c-0.672,0,0.037,2.086,0.113,2.441c-0.354,0.234-0.986-0.743-1.123-0.929\n	c-0.346-0.412-0.348-1.005-0.391-1.512c-0.93,0.618-1.42,1.331-0.826,2.447c0.494,0.929,1.34,0.824,2.229,0.824\n	c0.732,0,1.516,0.081,2.246-0.017C52.906,22.933,52.906,22.042,53.07,21.232 M90.232,8.877c0.016,0.174,0.092,1.221,0.363,1.221\n	c0.666,0,1.33,0,1.996,0c0.371,0,0.223-0.853,0.238-1.16c0.031-0.573,0.059-1.147,0.088-1.721c-0.426,0-1.502-0.213-1.855,0\n	C90.732,7.416,90.404,8.504,90.232,8.877 M95.652,13.907c-0.074-0.038-0.33-0.293-0.371-0.293c-0.305,0-0.609,0-0.914,0\n	c-0.713,0-0.744,0.228-1.182,0.802c-0.367,0.48-0.975-0.322-1.197-0.411c-0.418-0.17-1.254,0-1.701,0\n	c-0.152,0-1.324-0.067-1.324,0.058c0,0.941-0.184,1.223-1.057,1.584c-0.359,0.147-0.816,0.067-1.199,0.067\n	c-5.574,0-11.148,0-16.723,0c-1.539,0-3.078,0-4.615,0c-0.967,0-1.447,0.143-1.898-0.879c-0.15,0.247-0.303,0.494-0.453,0.741\n	c-0.055,0.09-0.426,0.232-0.426,0.146c0,0.445,0,0.89,0,1.335c0,1.356,0,2.713,0,4.07c0,0.362,0.518,0.562,0.254,0.827\n	c-0.521,0.52-0.418,1.035-0.367,1.732c0.08,1.062,0.043,2.209,0.211,3.257c0.328,2.061,1.148,4.17,1.758,6.154\n	c0.068,0.217,0.42,0.119,0.098,0.488c-0.027,0.033-0.156,0.051-0.195,0.062c-0.494,0.158-0.99,0.314-1.484,0.47\n	c-1.451,0.459-2.9,0.919-4.354,1.377c-0.426,0.136-1.775,0.861-2.121,0.288c-0.115-0.192-0.139-1.016-0.195-1.253\n	c-0.168-0.678-0.354-1.344-0.541-2.016c-0.643-2.331-1.1-4.759-1.168-7.181c0-0.265,0.199-1.125,0.051-1.32\n	c-0.074-0.097-0.469-0.143-0.59-0.181c-0.109-0.035-0.047-0.437-0.047-0.552c-0.262,0.26-0.463,0.635-0.842,0.635\n	c-0.637,0-1.268,0-1.902,0c-0.748,0-1.492,0-2.24,0c-0.32,0-0.916-0.12-1.219,0c-0.523,0.208-0.555,0.866-1.035,0.063\n	c-0.402-0.672-1.09,0.396-1.283,0.693c-0.375,0.587-0.691,0.73-0.391,1.454c0.115,0.273,0.334,0.468,0.041,0.615\n	c-0.373,0.185-0.924,0.326-1.184,0.655c-0.639,0.813-1.061,1.94-1.502,2.878c-0.307,0.647-0.537,0.816-0.205,1.438\n	c0.408,0.759,0.23,0.895-0.471,0.918c-1.16,0.039-7.844,0.565-6.377-1.964c1.744-3.008,3.488-6.018,5.234-9.026\n	c0.242-0.417,0.484-0.834,0.725-1.25c0.404-0.695,0.18-2.125-0.541-2.567c-0.639-0.39-1.574,0.313-2.105-0.414\n	c-0.402-0.547-0.264-2.337-0.135-2.917c-0.266,0.021-0.471-0.087-0.715-0.181c-0.127-0.051-0.213-0.308-0.189-0.308\n	c-0.408,0-0.814,0-1.225,0c-1.516,0-3.031,0-4.547,0c-0.5,0-1,0-1.5,0c-0.42,0-0.34,0.677-0.58,1.021\n	c-0.693,0.999-1.902,1.44-2.494,2.525c-0.236,0.437-0.346,1.044-0.873,1.044c-0.898,0-0.861-0.011-1.303,0.763\n	c-0.301,0.528-0.248,0.605-0.832,0.605c-0.721,0-1.443,0-2.164,0c-0.523,0,0.002-0.732-0.326-0.732c-0.33,0-1.369-0.186-1.623,0.005\n	c-0.99,0.747-1.98,1.492-2.973,2.24c-0.387,0.291-0.773,0.583-1.162,0.875c-0.648,0.489-0.912,0.237-0.984-0.482\n	c-2.023,1.302-4.047,2.605-6.07,3.908c-0.615,0.396-1.652,0.76-1.838,1.501c-0.285,1.137-1.695,0.994-2.426,0.336\n	c-0.66-0.59-0.604-1.174-0.604-1.987c0-1.213,0-2.427,0-3.641c0-2.955,0-5.91,0-8.866c0-0.618-0.145-1.511,0.107-2.104\n	c0.406-0.945,1.396-0.964,2.266-0.964c2.186,0,4.375,0,6.563,0c5.473,0,10.943,0,16.416,0c0.463,0,0.932-0.144,1.084,0.451\n	c0.104,0.427,0.158,0.33,0.584,0.33c0.656,0,1.314,0,1.973,0c1.383,0,2.77,0,4.154,0c0.578,0,0.145-0.193,0.449-0.311\n	c0.6-0.23,1.033-0.226,1.684-0.226c0.35,0-0.037-0.912,0.189-1.138c0.336-0.336,1.033-0.385,1.5-0.425c0.512-0.044,1.047,0,1.561,0\n	c0.277,0,1.252,0.165,1.424-0.081c0.256-0.364,0.883-0.953,0.971-1.384c0.131-0.651-0.957-0.842-1.176-1.415\n	c-0.432-1.131,0.768-2.193,1.859-1.748c0.861,0.354,0.877,1.13,0.877,1.907c0,0.682,0,1.363,0,2.046\n	c0,0.235-0.043,0.235,0.207,0.235c0.5,0,0.381-0.088,0.381-0.578c0-0.411,1.094-0.203,1.449-0.203c0.234,0,0.357-0.086,0.357,0.16\n	c0,0.071-0.004,0.865-0.004,0.865c2.172,0,4.336,0,6.5,0c2.395,0,4.789,0,7.186,0c0.461,0,0.66,0.344,0.891,0.687\n	c0.182,0.275,0.49-0.09,0.662-0.247c0.236-0.086,0.666,0,0.916,0c0.203,0,0.531,0.101,0.576-0.122\n	c0.047-0.238,0.176-0.367,0.434-0.367c0.18,0,0.357,0,0.535,0c4.154,0,8.307,0,12.463,0c2.148,0,4.297,0,6.447,0\n	c0.945,0,2.424-0.335,3.047,0.537c0.643-0.885,1.291-1.755,1.967-2.615c0.201-0.257,0.502-0.808,0.848-0.876\n	c0.588-0.118,1.107-0.219,1.703-0.219c0.518,0,0.609-0.135,0.609,0.359c0,0.665,0,1.328,0,1.992c0,1.276,0,2.553,0,3.83\n	c0,0.158,1.059,0.069,1.236,0.069c0.375,0,0.486-0.439,0.891-0.439c1.303,0,2.605,0,3.908,0c1.154,0,2.904-0.352,2.904,1.347\n	c0,1.39-0.838,1.438-1.953,1.438C99.008,13.907,97.33,13.907,95.652,13.907\"/>\n<rect id=\"sliceCopy_x5F_43_1_\" x=\"106.639\" fill=\"none\" width=\"120.306\" height=\"40\"/>\n<rect id=\"sliceCopy_x5F_42_1_\" fill=\"none\" width=\"106.639\" height=\"40\"/>\n</svg>",
        [17]    = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 1.1//EN\" \"http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd\" [\n	<!ENTITY ns_flows \"http://ns.adobe.com/Flows/1.0/\">\n]>\n<svg version=\"1.1\"\n	 xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" xmlns:a=\"http://ns.adobe.com/AdobeSVGViewerExtensions/3.0/\"\n	 x=\"0px\" y=\"0px\" width=\"53px\" height=\"40px\" viewBox=\"0.618 0 53 40\" enable-background=\"new 0.618 0 53 40\" xml:space=\"preserve\">\n<defs>\n</defs>\n<path fill=\"#FFFFFF\" d=\"M49.094,9.701c0,0.879,0.135,1.34-0.459,1.984c-0.35,0.379-1.695,0.123-2.195,0.123c-0.834,0-0.65,0.497-0.65,1.203\n	c0,0.555,0.314,1.433-0.346,1.433c-1.813,0-3.625,0-5.439,0c-0.715,0-0.389,0.39-0.324,0.981c0.045,0.408-0.5,0.384-0.418,0.772\n	c0.072,0.34,0.141,0.681,0.201,1.023c-0.885,0-1.768-0.017-2.652-0.047c-0.201-0.007-1.086,1.877-1.309,2.137\n	c-0.469,0.542-0.834,1.023-1.572,1.212c-0.473,0.12-1.002,0.066-1.484,0.076c-1.406,0.027-2.539-0.041-3.762-0.839\n	c0,2.376,0,4.754,0,7.131c0,0.434,0,0.867,0,1.302c0,0.469-0.564,0.107-0.766,0.381c-0.09,0.123,0,0.653,0,0.797\n	c0,0.691,0,1.382,0,2.073c0,1.363,0,2.728,0,4.091c0,0.124,0.08,0.465-0.074,0.465c-0.537,0-1.074,0-1.609,0\n	c-1.283,0-2.564,0-3.848,0c-0.162,0-0.074-2.17-0.074-2.4c0-1.416,0-2.829,0-4.244c0-0.9-0.373-0.781-1.223-0.781\n	c-0.67,0-1.342,0-2.012,0c-0.516,0-0.66-0.476-0.957-0.879c-0.105-0.142,0.145-0.777,0.18-0.938c0.17-0.753,0.34-1.506,0.51-2.26\n	c0.438-1.94,0.855-3.889,1.324-5.821c0.146-0.606,0.266-0.785-0.023-1.316c-0.346-0.639-0.658-1.399-1.18-1.921\n	c-0.627-0.627-2.438-0.265-3.219-0.206c-0.41,0.03-0.635,0.312-0.924,0.601c-0.439,0.44-0.785-0.345-1.004-0.481\n	c-0.213-0.134-0.938,0-1.18,0c-0.785,0-1.57,0-2.355,0c-0.072,0-1.016-0.016-1.016,0.013c0,0.587,0,1.173,0,1.76\n	c0,0.573,0,1.146,0,1.721c0,0.076-0.986,0.339-1.197,0.339c-0.574,0-0.934-0.06-1.477-0.216c-0.471-0.136-1.041-0.003-1.494-0.167\n	c-0.367-0.133-0.734-0.581-0.91-0.91c-0.416-0.775,0.125-1.568,0.195-2.335c0.188-2.062,0.17-4.167,0.279-6.24\n	c0.063-1.155,0.123-2.31,0.186-3.465C4.855,5.124,5.992,4.697,5.977,4c4.141,0.244,8.277,0.562,12.381,1.165\n	c0.395,0.059,0.803,0.129,1.201,0.129c0,0,0.244,0.273,0.264,0.335c0.109,0.341-0.014,0.488-0.264,0.648\n	c-0.846,0.545-1.922,0.405-2.896,0.405c-0.955,0-1.902-0.089-2.855-0.16c-0.713-0.053-1.428-0.106-2.143-0.159\n	c-0.139-0.011-0.896,0.031-0.967-0.111c-0.008-0.017-0.018-0.033-0.025-0.048c-0.105,0.641,0.402,0.442,0.898,0.48\n	c0.545,0.043,1.09,0.08,1.631,0.145c1.074,0.128,2.119,0.141,3.201,0.141c1.875,0,3.75,0,5.625,0c2.18,0,4.357,0,6.535,0\n	c1.309,0,2.615,0,3.924,0c0.215,0,0.18-0.684,0.215-0.898c0.098-0.578-0.07-0.796,0.521-0.865c0.832-0.097,1.848-0.186,2.656,0.036\n	c0.359,0.098,0.549,0.536,0.699,0.86c0.211,0.45,0.168,0.436,0.637,0.436c1.24,0,2.48,0,3.721,0c0.178,0,0.357,0,0.535,0\n	c0.258,0,0.049-0.049,0.15-0.239C41.77,6.02,41.623,5.627,41.9,5.517c0.553-0.221,2.486-1.297,3.068-0.812\n	c0.861,0.719,0.678,1.348,0.678,2.432c0,0.535-0.299,2.036,0.623,2.036c0.602,0,1.205,0,1.807,0\n	C48.732,9.174,48.734,9.134,49.094,9.701 M29.404,18.804c1.184,0.417,2.367,0.287,3.621,0.287c1.021,0,2.223-0.265,1.936-1.629\n	c-0.313-1.489-2.244-1.054-3.389-1.054c-0.563,0-1.402-0.135-1.928,0.127C28.912,16.9,28.719,18.286,29.404,18.804 M7.223,6.778\n	c-0.463,0-0.67-0.069-0.67,0.481c0,0.395,0.006,0.786,0.02,1.18c0.031,0.807,0.104,1.606,0.172,2.411\n	c0.318-1.326,0.648-2.627,1.055-3.929C7.605,6.875,7.414,6.827,7.223,6.778\"/>\n<rect id=\"sliceCopy_x5F_38_1_\" x=\"53.106\" fill=\"none\" width=\"106.002\" height=\"40\"/>\n<rect id=\"sliceCopy_x5F_37_1_\" fill=\"none\" width=\"53.106\" height=\"40\"/>\n</svg>",
        [19]    = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 1.1//EN\" \"http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd\" [\n	<!ENTITY ns_flows \"http://ns.adobe.com/Flows/1.0/\">\n]>\n<svg version=\"1.1\"\n	 xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" xmlns:a=\"http://ns.adobe.com/AdobeSVGViewerExtensions/3.0/\"\n	 x=\"0px\" y=\"0px\" width=\"82px\" height=\"40px\" viewBox=\"0.866 0 82 40\" enable-background=\"new 0.866 0 82 40\" xml:space=\"preserve\">\n<defs>\n</defs>\n<path fill=\"#FFFFFF\" d=\"M53.8,23.734c-0.438,0.659-0.258,1.709-0.24,2.46c0.002,0.06-0.016,0.598,0.037,0.598c0.381,0,0.762,0,1.145,0\n	c0.082,0,0.633-0.046,0.633,0.038c0,0.187-0.104,0.832,0.082,0.884c0.975,0.28,1.463,1.165,2.625,0.72\n	c1.367-0.522,1.93-1.767,1.219-3.074c-0.455-0.833-1.355-1.137-1.902-1.898c-0.355-0.498-0.434-0.672-1.131-0.57\n	C55.407,23.02,54.421,23.026,53.8,23.734 M43.317,25.128c0-0.72-0.283-2.204-1.158-2.204c-1.131,0-2.262,0-3.395,0\n	c-0.555,0-1.109,0-1.664,0c-0.188,0-0.535-0.071-0.711,0c-0.33,0.131-0.711,0.674-0.965,0.916c-0.309,0.293-0.725,0.586-0.969,0.943\n	c-0.285,0.412-0.082,1.101-0.047,1.56c0,0.99,0.299,1.815,1.111,2.404c1.275,0.923,2.176,0.38,3.469-0.101\n	C40.382,28.128,43.317,26.892,43.317,25.128 M64.821,13.927c0.303-0.454-0.605-0.54-0.811-0.54c-0.654,0-1.305,0-1.959,0\n	c-1.375,0-2.754,0-4.129,0c-2.045,0-4.107-0.2-6.148-0.316c0,0.158-0.033,1.35,0.029,1.35c0.342,0,0.684,0,1.025,0\n	c1.555,0,3.111,0,4.666,0c1.713,0,3.424,0,5.137,0c0.545,0,1.092,0,1.637,0C64.745,14.422,64.599,14.373,64.821,13.927\n	 M66.396,13.206c-0.537,0-0.721-0.147-0.721,0.428c0,0.266-0.094,0.415,0.182,0.45c0.256,0.032,0.652,0.225,0.521,0.561\n	c-0.135,0.353-0.441,0.669-0.412,1.019c0.049,0.601,0.098,1.203,0.146,1.804c0.02,0.246,0.553,0.244,0.553,0.053\n	c0-0.546,0-1.092,0-1.638C66.665,15.349,66.979,13.565,66.396,13.206 M78.091,17.93c0.695,0.585,1.059,3.123-0.105,3.396\n	c-0.693,0.164-1.555,0.023-2.256,0.023c-1.107,0-2.215,0-3.322,0c-0.27,0-0.541,0-0.811,0c-0.111,0-0.16-0.269-0.252-0.271\n	c-0.113-0.002-0.373,0.245-0.449,0.315c0.391,0.449,0.873,0.908,1.045,1.495c0.131,0.443-0.057,1.046-0.113,1.486\n	c-0.123,0.988-0.234,1.968-0.316,2.959c-0.037,0.433,0.018,1.023-0.121,1.438c-0.16,0.476-0.535,0.451-0.975,0.451\n	c-0.914,0-2.436,0.438-2.654-0.709c-0.182-0.958-0.119-1.906-0.348-2.861c-0.137-0.581-2.313-0.329-2.744-0.301\n	c-0.322,0.021-0.775,0.856-0.799,1.098c-0.059,0.629-0.117,1.258-0.174,1.887c-0.166,1.789-1,3.62-2.43,4.752\n	c-1.322,1.048-3.074,1.568-4.74,1.666c-0.682,0.04-1.361,0.081-2.043,0.12c-0.355,0.021-0.809,0.13-1.156,0.029\n	c-0.521-0.152-1.014-0.08-0.967-0.687c0.029-0.398,0.201-0.83,0.293-1.217c0.158-0.655,0.318-1.31,0.475-1.965\n	c0.078-0.325,0.285-0.748,0.158-1.07c-0.344-0.865-2.014-0.559-2.836-0.586c-0.604-0.021-0.738,0.061-1.076,0.567\n	c-0.24,0.358-0.766,0.679-1.107,0.942c-2.471,1.897-5.5,3.983-8.701,4.092c-1.91,0.064-3.938-0.012-5.84-0.191\n	c-0.621-0.058-1.244-0.117-1.867-0.175c-0.596-0.057-0.385-0.464-0.402-1.03c-0.012-0.409,0.07-0.459-0.281-0.591\n	c-0.52-0.194-1.037-0.389-1.557-0.581c-1.268-0.474-2.533-0.948-3.801-1.421c-0.195-0.073-0.451-0.228-0.662-0.238\n	c-0.139-0.005-1.367-0.158-1.426-0.054c-0.283,0.495-0.701,1.181-1.34,1.181c-0.768,0-1.533,0-2.301,0c-4.895,0-9.787,0-14.682,0\n	c-1.689,0-1.227-3.19-1.227-4.275c0-1.95,0.018-3.898-0.016-5.848c-0.039-2.168-0.078-4.334-0.162-6.502\n	c-0.037-0.893,0.348-0.92,0.975-0.92c0.797,0,1.594,0,2.391,0c5.424,0,10.848,0,16.271,0c1.195,0,2.529,0.17,3.713-0.042\n	c1.516-0.271,2.908-0.363,4.441-0.363c4.695,0,9.391,0,14.088,0c0.266,0,0.037-1.702,0.168-2.009c0.418-0.99,0.82-1.98,1.201-2.984\n	c0.215-0.566,0.367-0.948,0.982-1.203c0.602-0.251,0.424-1.083,0.584-1.686c0.199-0.738,1.281-1.597,1.744-0.576\n	c0.205,0.435,0.178,0.976,0.178,1.439c0,0.2,0.053,0.483,0,0.675c-0.023,0.09-0.225,0.178-0.225,0.394\n	c0,0.177-0.113,0.957,0.082,0.957c0.789,0,1.58,0,2.367,0c2.768,0,5.531,0,8.299,0c0.672,0,1.344,0,2.016,0\n	c0.299,0,0.867-0.497,1.121-0.646c0.533-0.31,0.961-0.291,0.961-0.974c0-0.543-0.172-0.135-0.27-0.36c-0.074-0.172,0-0.542,0-0.729\n	c0-0.406,0.262-0.896,0.756-0.938c0.314-0.028,1.131-0.295,1.186,0.201c0.059,0.528,0.037,1.059,0.037,1.59\n	c0,0.507,0.035,0.863,0.168,1.354c0.16,0.607,0.281,0.726,0.852,0.726c0.455,0,0.619-0.077,0.912,0.24\n	c0.459,0.496,0.918,0.991,1.377,1.486c0.648,0.697,1.551,1.362,1.551,2.387c0,1.266,0,2.532,0,3.798\n	c0,0.182-0.125,0.861,0.104,0.861c0.645,0,1.287,0,1.932,0C75.339,17.93,76.716,17.93,78.091,17.93\"/>\n<rect id=\"sliceCopy_x5F_41_1_\" x=\"82.738\" fill=\"none\" width=\"136.197\" height=\"40\"/>\n<rect id=\"sliceCopy_x5F_40_1_\" fill=\"none\" width=\"82.738\" height=\"40\"/>\n</svg>",
        [24]    = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 1.1//EN\" \"http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd\" [\n	<!ENTITY ns_flows \"http://ns.adobe.com/Flows/1.0/\">\n]>\n<svg version=\"1.1\"\n	 xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" xmlns:a=\"http://ns.adobe.com/AdobeSVGViewerExtensions/3.0/\"\n	 x=\"0px\" y=\"0px\" width=\"97px\" height=\"40px\" viewBox=\"0.51 0 97 40\" enable-background=\"new 0.51 0 97 40\" xml:space=\"preserve\">\n<defs>\n</defs>\n<path fill=\"#FFFFFF\" d=\"M87.245,6.455c0.617,0.926,1.002,2.6,1.002,3.704c0,0.369,0,0.737,0,1.106c0,0.174,0.326,0.687,0.393,0.879\n	c0.039,0.119,1.439,0.019,1.672,0.022c0.465,0.009,1.813-0.238,1.971,0.288c0.197,0.655,0.637,1.474,0.115,2.049\n	c-0.434,0.475-1.232,0.479-1.854,0.552c-0.74,0.088-1.129,0.345-1.885,0.155c-0.115,0.61-0.158,0.749-0.613,1.169\n	c-0.408,0.377-0.574,0.065-0.574,0.76c0,0.369-0.063,0.897-0.363,1.034c-0.268,0.121-1.104,0.062-1.395-0.006\n	c-0.293-0.068-1.135-0.43-1.391-0.284c-0.406,0.231-0.734,0.382-1.189,0.56c-0.943,0.368-0.523,1.76-0.494,2.513\n	c0.076,2.004,0,4.027,0,6.034c0,0.945-0.123,1.873-0.268,2.802c-0.063,0.402-0.209,0.761-0.326,1.151\n	c-0.156,0.522-0.139,0.695-0.68,0.754c-1.039,0.115-2.629,0.173-2.816-1.208c-0.125-0.927-0.279-1.505-0.215-2.432\n	c0.143-2.113,0.285-4.228,0.422-6.342c0.02-0.283,0.469-2.361,0.289-2.438c-0.795-0.337-1.166-1.349-2.107-1.513\n	c-0.361-0.063-0.75,0.023-1.096,0c-0.463-0.032-0.834-0.016-1.297,0.077c-0.887,0.178-1.945,0.015-2.852,0.015\n	c0.045-0.393,0.105-0.79,0.092-1.186c-0.676,0.4-1.303,0.758-2.029,1.049c-0.68,0.272-1.488,0.137-2.213,0.137\n	c0.201,0.88,0.41,1.763,0.545,2.656c0.037,0.257,0.371,1.335,0.23,1.54c-0.01,0.014-0.557,0.2-0.6,0.223\n	c-0.287,0.158-0.107,0.404-0.041,0.708c0.443,2.043,0.928,4.073,1.348,6.122c0.398,1.935,0.881,3.855,1.326,5.779\n	c0.129,0.55-0.254,0.452-0.719,0.519c-0.418,0.06-0.85,0.12-1.277,0.182c-0.887,0.126-1.787,0.146-2.682,0.286\n	c-0.252,0.039-0.955,0.292-1.033-0.03c-0.086-0.367-0.164-0.734-0.248-1.1c-0.279-1.208-0.557-2.416-0.836-3.625\n	c-0.412-1.786-0.865-3.56-1.262-5.35c-0.104-0.476-0.201-0.958-0.314-1.432c-0.131-0.541-0.055-1.049-0.643-1.049\n	c-0.971,0-2.014-0.06-2.943,0.227c-0.838,0.259-1.031,1.63-1.781,1.786c-1.021,0.212-2.006,0.285-3.051,0.356\n	c-1.279,0.087-2.729,0.087-3.945-0.363c-0.324-0.12-0.672-0.21-0.971-0.38c-0.428-0.242-0.818-0.715-1.131-0.257\n	c-0.189,0.278-0.879,1.117-0.701,1.502c0.096,0.209,0.271,0.87,0.48,0.869c-0.143,0.143-0.32,0.417-0.5,0.502\n	c-0.102,0.047-0.334-0.13-0.434,0.038c-0.285,0.476-0.578,0.945-0.873,1.414c-0.471,0.749-0.998,1.726-1.158,2.605\n	c-0.082,0.454,0.18,1.082-0.09,1.46c-0.328,0.285-1.084,0.167-1.436,0.005c-0.871-0.399-1.684-0.887-2.512-1.369\n	c-0.295-0.172-2.563-1.28-2.424-1.79c0.238-0.876,0.789-1.683,1.213-2.487c1.01-1.918,2.107-3.782,3.195-5.658\n	c0.393-0.677-0.275-2.297-0.85-2.728c-0.811-0.612-2.219-1.055-3.217-1.236c-1.824-0.333-3.869-0.667-5.715-0.403\n	c-1.191,0.17-2.352,0.732-3.48,1.131c-2.529,0.895-5.059,1.79-7.586,2.685c-4.275,1.514-8.553,3.028-12.826,4.542\n	c-0.867,0.304-4.174,0.66-4.174-0.725c0-1.951,0.188-4.039-0.059-5.975c-0.258-1.995-0.205-4.016-0.365-6.023\n	c-0.115-1.439,1.342-1.311,2.406-1.336c1.039-0.025,2.08-0.045,3.121-0.065c4.154-0.081,8.316-0.002,12.471-0.002\n	c2.035,0,4.07,0,6.104,0c0.682,0,1.547-0.395,2.207-0.566c0.98-0.253,1.775-0.522,2.598-1.109c0.838-0.599,1.672-0.793,2.662-1.047\n	c0.395-0.102,0.801-0.152,1.193-0.265c0.426-0.122,0.887-0.793,1.205-1.1c0.578-0.555,1.15-1.644,1.971-1.753\n	c0.471-0.063,0.898-0.151,1.367-0.089c0.303,0.04,0.607,0.081,0.912,0.122c0.178,0.023,0.352-0.091,0.512-0.078\n	c0.209,0.017,0.412,0.16,0.592,0.25c0.178,0.089,0.492,0.024,0.686,0.024c0.48,0,0.73,0.186,0.73,0.723c0,0.572,0,1.145,0,1.717\n	c0,0.114,0.182-0.057,0.182-0.225c0-0.133-0.092-0.808,0-0.894c0.18-0.167,1.289,0,1.537,0c0.256,0,0.514,0,0.768,0\n	c0.209,0-0.039-0.485,0.066-0.593c0.105-0.106,1.277,0.005,1.277,0.061c0,0.212-0.115,0.532,0.135,0.532\n	c0.131,0,0.73,0.07,0.73-0.061c0.002-0.196-0.111-0.531,0.125-0.531c0.313,0,0.625,0,0.939,0c0.234,0,0.121,0.335,0.121,0.532\n	c0,0.131,0.639,0.061,0.777,0.061c0.152,0-0.039-0.509,0.045-0.593c0.072-0.073,0.596,0,0.699,0c0.109,0,0.531-0.068,0.531,0.061\n	c0,0.37-0.123,0.532,0.26,0.532c0.109,0,0.672,0.076,0.744,0c0.07-0.074-0.086-0.593,0.033-0.593c0.299,0,0.596,0,0.896,0\n	c0.381,0,0.256,0.166,0.256,0.532c0,0.046,1.004,0.275,1.004-0.147c0-0.314-0.084-0.385,0.223-0.385c0.326,0,0.652,0,0.979,0\n	c0.105,0-0.035,0.524,0.029,0.593c0.07,0.076,0.633,0,0.742,0c0.336,0,0.26-0.041,0.26-0.384c0.002-0.334,0.227-0.209,0.533-0.209\n	c0.104,0,0.627-0.073,0.701,0c0.08,0.081-0.104,0.593,0.043,0.593c0.129,0,0.643,0.082,0.732,0c0.141-0.131-0.188-0.593,0.1-0.593\n	c0.354,0,1.268-0.202,1.268,0.209c0,0.408-0.043,0.384,0.363,0.384c0.471,0,0.365-0.07,0.365-0.532c0-0.058,1.127-0.165,1.232-0.061\n	c0.066,0.069-0.08,0.593,0.027,0.593c0.34,0,0.678,0,1.014,0c0.447,0,0.234,0.733,0.234,1.108c0,0.069,0.299,0.032,0.359,0.032\n	c0.867,0,1.736,0,2.604,0c2.869,0,5.736,0,8.607,0c1.488,0,2.979,0,4.467,0c0.188,0,0.52,0.067,0.699,0\n	c0.52-0.192,1.105-0.967,1.5-1.381c0.139-0.144,0.586-0.467,0.602-0.673c0.023-0.311,0.018-0.65,0.088-0.956\n	c0.148-0.639,0.506-1.231,1.221-1.231c0.273,0,0.58-0.146,0.844-0.218c0.125-0.035,0.625,0.429,0.719,0.538\n	C86.86,5.048,87.106,5.813,87.245,6.455 M64.032,7.959c-4.465,0-8.932,0-13.396,0c-1.654,0-3.313,0-4.971,0\n	c0.039,0-0.125,0.501,0.049,0.501c0.219,0,0.436,0,0.654,0c0.955,0,1.912,0,2.867,0c3.271,0,6.545,0,9.816,0c1.252,0,2.5,0,3.752,0\n	c0.334,0,0.666,0,1.002,0C64.155,8.461,64.032,8.332,64.032,7.959 M48.892,22.278c0,1.434,3.088,1.003,3.896,1.003\n	c0.551,0,1.105,0,1.658,0c0.703,0,0.973-0.427,1.223-0.965c0.385-0.822-0.619-1.276-1.213-1.361c-0.531-0.076-1.133,0-1.668,0\n	C51.61,20.956,48.892,20.453,48.892,22.278 M25.224,16.943c0.375-0.809,0.287-1.733-0.84-1.733c-0.703,0-1.557-0.141-2.244,0.03\n	c-0.59,0.148-1.004,1.021-0.604,1.536c0.307,0.394,0.68,0.486,1.143,0.486C23.386,17.262,24.671,17.5,25.224,16.943 M8.763,14.207\n	c-0.365-0.03-0.73-0.062-1.096-0.091c0.055,1.964,0.24,3.918,0.32,5.883c0.012,0.325-0.119,1.125,0.156,1.324\n	c0.607,0.438,1.334,0.495,2.047,0.621c0.885,0.155,1.932-0.33,2.768-0.623c0.934-0.326,1.846-0.701,2.736-1.14\n	c0.984-0.486,1.727-0.833,1.492-2.037c-0.092-0.474-0.18-0.911-0.336-1.364c-0.244-0.708-0.154-0.951-0.889-1.056\n	c-0.955-0.137-1.869-0.41-2.803-0.659C11.7,14.677,10.261,14.394,8.763,14.207\"/>\n<rect id=\"sliceCopy_x5F_40_1_\" x=\"96.644\" fill=\"none\" width=\"82.738\" height=\"40\"/>\n<rect id=\"sliceCopy_x5F_39_1_\" fill=\"none\" width=\"96.643\" height=\"40\"/>\n</svg>",
        [25]    = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 1.1//EN\" \"http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd\" [\n	<!ENTITY ns_flows \"http://ns.adobe.com/Flows/1.0/\">\n]>\n<svg version=\"1.1\"\n	 xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" xmlns:a=\"http://ns.adobe.com/AdobeSVGViewerExtensions/3.0/\"\n	 x=\"0px\" y=\"0px\" width=\"108px\" height=\"40px\" viewBox=\"0.438 0 108 40\" enable-background=\"new 0.438 0 108 40\"\n	 xml:space=\"preserve\">\n<defs>\n</defs>\n<path fill=\"#FFFFFF\" d=\"M102.268,14.504c0.492-0.026,0.979-0.086,1.449-0.219c0.715-0.2,0.596-0.063,0.621-0.643h-0.002v-1.153\n	c0-0.376-0.041-0.611-0.428-0.729c-0.506-0.154-0.73-0.242-1.082-0.65c-0.617-0.72-1.426-1.234-2.246-1.699\n	c-0.303-0.172-0.664-0.375-1.025-0.375c-0.451,0.002-0.457,0.476-0.533,0.811c-0.125,0.542-0.313,1.073-0.691,1.493\n	c-0.291,0.324-0.637,0.296-1.047,0.262c-2.781-0.232-5.66-0.031-8.451-0.031c-2.904,0-5.805,0-8.707,0c-4.68,0-9.359,0-14.039,0\n	c-2.332,0-4.664,0-6.996,0c-2.176,0-4.396-0.126-6.568,0.026c-0.84,0.058-0.85-0.318-0.959-1.01\n	c-0.127-0.801-1.367-0.007-1.836-0.324c-0.182-0.123,0.182-0.695-0.119-0.728c-0.18-0.019-0.697-0.06-0.674,0.208\n	c0.039,0.424,0.088,0.522-0.371,0.522c-0.494,0-0.99,0-1.486,0c-2.285,0-4.572,0-6.857,0c-1.176,0-2.352,0-3.525,0\n	c-0.295,0-0.385-0.045-0.385,0.293c0,0.268,0.051,0.534,0.051,0.801c-0.541-0.269-0.209-0.701-0.529-1.156\n	c-0.287-0.409-0.957-0.306-1.385-0.292c-0.59,0.017-1.271,0.036-1.789-0.292c-0.145-0.091-0.172-0.476-0.252-0.471\n	c-0.174,0.014-0.262-0.13-0.443-0.14c-0.469-0.024-0.883-0.026-1.162,0.376c-0.232,0.335-0.744,1.413-1.139,1.479\n	c-0.102,0.016,0.016,1.029-0.559,0.788c-0.301-0.126-0.693-0.653-0.639-0.997c-2.301,0.196-4.6,0.422-6.9,0.635\n	c-2.279,0.209-4.561,0.419-6.84,0.629c-1.172,0.108-2.342,0.216-3.514,0.323c-0.424,0.038-0.738,0.042-1.061,0.338\n	c-0.307,0.284-0.59,0.401-1.004,0.478c-1.078,0.202-2.189,0.299-3.277,0.458C5.412,13.583,3.988,13.48,4,14.106\n	c0.037,2.264,0.072,4.526,0.109,6.791c0.02,1.212,0.037,2.425,0.059,3.637c0.008,0.508-0.24,2.451,0.246,2.641\n	c0.848,0.334,1.621-0.224,2.404-0.557c0.773-0.326,1.924-0.666,2.508-1.308c0.326-0.359,0.482-0.94,0.672-1.376\n	c0.209-0.484,0.426-0.966,0.703-1.415c0.453-0.73,0.934-1.157,1.781-1.345c2.182-0.485,4.332-1.077,6.533-1.493\n	c-0.129,0.208-0.117,0.47-0.141,0.705c0.543,0,1.084,0.038,1.623,0.111c0.322,0.044,1.244,0.049,1.414,0.365\n	c0.406,0.756,0.092,1.535-0.252,2.228c-0.549,1.105-1.164,2.175-1.764,3.253c-0.385,0.694-1.264,1.667-1.236,2.495\n	c0.025,0.782,1.043,1.039,1.646,1.208c0.84,0.236,1.666,0.391,2.521,0.561c1.053,0.208,2.131,0.574,3.213,0.285\n	c0.975-0.262-0.104-0.974-0.305-1.415c-0.441-0.961,0.027-1.692,0.457-2.538c0.488-0.957,0.955-1.926,1.398-2.907\n	c0.273-0.61,0.525-1.906,1.268-2.113c0.801-0.224,1.764-0.183,2.588-0.229c0.561-0.032,1.127-0.019,1.688-0.059\n	c0.443-0.032,0.861-0.226,1.309-0.226c0.721,0,1.299-0.686,1.713-1.192c0.508-0.62,0.846-1.187,1.688-1.346\n	c0.75-0.142,1.57-0.082,2.322,0.019c0.615,0.083,1.219,0.229,1.818,0.385c0.383,0.1,0.889,0.403,1.283,0.355\n	c0.758-0.091,1.275-0.821,2.061-0.938c1.074-0.159,2.252-0.021,3.32,0.107c0.912,0.109,1.916-0.172,2.787,0.142\n	c0.967,0.348,2.205,0.235,3.221,0.223c1.102-0.014,2.203-0.011,3.305-0.014c2.336-0.007,4.67-0.023,7.004-0.057\n	c2.309-0.034,4.613,0.008,6.92,0.02c1.172,0.007,2.318-0.131,3.479-0.263c0.496-0.055,1.029-0.062,1.506-0.222\n	c0.465-0.156,0.846-0.286,1.344-0.286c4.639,0,9.275,0,13.914,0c2.336,0,4.672,0,7.008,0c1.215,0,2.432,0,3.646,0\n	c0.668,0,1.111-0.743,1.215-1.324c0.127-0.705-0.178-1.663-0.891-1.941c-0.547-0.215-1.664,0.384-1.941-0.299\n	C100.996,14.364,102.045,14.516,102.268,14.504z M34.068,20.138c-0.488,0.698-1.904,0.399-2.607,0.361\n	c-0.523-0.029-1.115,0.083-1.521-0.335c-0.285-0.292-0.373-0.738-0.287-1.13c0.281-1.27,2.008-0.936,2.947-0.883\n	c0.467,0.026,1.123-0.09,1.461,0.327C34.467,18.979,34.256,19.603,34.068,20.138z M98.859,15.117c-4.107,0-8.096-0.093-12.203-0.02\n	c-2.043,0.038-4.088,0.044-6.133,0.028c-0.836-0.006-1.676-0.053-2.51-0.028c-0.516,0.016-1.023-0.088-0.506-0.684\n	c0.23-0.264,0.859-0.128,1.172-0.128c0.451,0,0.902,0,1.354,0c1.025,0,2.053,0,3.078,0c2.053,0,4.105,0,6.158,0\n	c2.014,0,4.029,0,6.041,0c0.521,0,1.041,0,1.563,0c0.121,0,0.461-0.073,0.539,0.057c0.027,0.073,0.068,0.135,0.121,0.191\n	c0.234,0.106,0.625-0.016,0.883,0.008c0.24,0.023,0.289,0.159,0.455,0.323L98.859,15.117z M32.977,9.632\n	c0.066,0.018,0.123,0.041,0.176,0.07C33.008,9.746,33.018,9.655,32.977,9.632z M30.402,9.702c-0.035,0-0.07,0-0.105,0\n	C30.369,9.646,30.379,9.696,30.402,9.702z\"/>\n<rect id=\"sliceCopy_x5F_56_1_\" x=\"108.339\" fill=\"none\" width=\"94.488\" height=\"40\"/>\n<rect id=\"sliceCopy_x5F_55_1_\" fill=\"none\" width=\"108.338\" height=\"40\"/>\n</svg>",
        [26]    = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 1.1//EN\" \"http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd\" [\n	<!ENTITY ns_flows \"http://ns.adobe.com/Flows/1.0/\">\n]>\n<svg version=\"1.1\"\n	 xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" xmlns:a=\"http://ns.adobe.com/AdobeSVGViewerExtensions/3.0/\"\n	 x=\"0px\" y=\"0px\" width=\"106px\" height=\"40px\" viewBox=\"0.512 0 106 40\" enable-background=\"new 0.512 0 106 40\"\n	 xml:space=\"preserve\">\n<defs>\n</defs>\n<path fill=\"#FFFFFF\" d=\"M101.77,12.422C101.854,12.512,101.953,12.62,101.77,12.422c-0.129-0.138-0.07-0.075-0.002,0\n	c-0.434-0.467-1.918-0.183-2.484-0.183c-0.701,0-1.402,0-2.104,0c-0.615,0-1.135,0.15-1.078-0.593\n	c0.078-0.992,0.137-2.072-0.08-3.009c-0.115-0.505,0.074-1.107,0.139-1.606c0.074-0.582-0.098-1.041-0.295-1.574\n	c-0.314-0.84-2.314-0.28-2.945-0.196c-0.543,0.102-0.168,1.793-0.217,2.171c-0.188,1.423-1.453,1.112-2.549,1.112\n	c-1.512,0-3.023,0-4.533,0c-3.029,0-6.061,0-9.09,0c-0.387,0-1.492,0.206-1.742-0.15c-0.189-0.265-0.395-0.49-0.607-0.735\n	c-0.254-0.29-1.082-0.037-1.418-0.022c-0.412,0.018-0.947,0.129-1.279-0.196c-0.506-0.496-0.17-1.673-1.137-0.972\n	c-0.346,0.252-0.654,0.489-1.066,0.623c-0.17,0.056-0.342,0.12-0.5,0.205c-0.17,0.09-0.15,0.286-0.313,0.345\n	c-0.654,0.244-1.762-0.071-2.072-0.695c-0.146-0.295-0.705-0.605-0.945-0.848c-0.316-0.318-0.795-0.406-1.23-0.38\n	c-0.631,0.037-0.807,0.826-1.311,1.23c-0.232,0.185-0.586,0.357-0.736,0.617c-0.094,0.159-0.619,0.11-0.807,0.309\n	c-0.168,0.172-0.379,0.671-0.664,0.671c-0.666,0-1.33,0-1.996,0c-1.299,0-2.602,0-3.898,0c-2.637,0-5.273,0-7.91,0\n	c-1.209,0-2.65-0.217-3.834,0.025c-0.984,0.201-1.723,1.362-2.41,2.014c-0.527,0.499-1.035,1.313-1.799,1.353\n	c-0.971,0.048-1.51,0.988-2.311,1.437c-0.391,0.22-0.814,0.176-1.246,0.234c-0.627,0.085-1.227,0.179-1.863,0.184\n	c-1.4,0.012-2.799,0.051-4.199,0.036c-1.775-0.018-3.551-0.044-5.324-0.084c-0.682-0.015-1.369-0.024-2.051,0.048\n	c-0.322,0.034-0.998,0.402-1.188,0.271c0.484-0.228,0.197-0.709-0.246-0.51c-0.404,0.184-0.691,0.544-1.111,0.714\n	c-1.086,0.441-2.615,0.184-3.758,0.167c-2.867-0.044-5.734-0.051-8.604-0.051c-1.008,0-2.236-0.481-2.758,0.729\n	c-0.236,0.544-0.164,1.229-0.148,1.805c0.01,0.367-0.178,1.443,0.123,1.722c0.33,0.303,0.436,0.341,0.453,0.848\n	c0.02,0.506-0.006,1.016-0.006,1.523c0,0.638,0,1.276,0,1.914c0,0.253,0.17,1.388-0.086,1.518c-0.707,0.359-0.326,2.604-0.326,3.372\n	c0,0.893,0.016,2.236,1.252,1.628c0.582-0.286,5.666-1.776,6.006-1.89c0.363-0.12,22.014-7.005,24.047-7.556\n	c1.578-0.427,3.566-0.407,4.99,0.524c1.305,0.854,0.705,2.652,0.248,3.856c-0.525,1.38-0.791,2.838-1.6,4.078\n	c-0.939,1.436-1.635,3.414-0.502,4.923C39.756,34.849,41.711,35,43.418,35c0.615,0,1.41,0.031,1.801-0.539\n	c0.311-0.452,0.363-1.718-0.326-1.924c0.5-0.543,0.561-1.456,0.768-2.137c0.264-0.862,0.664-1.68,0.904-2.544\n	c0.264-0.944,0.621-1.826,0.928-2.754c0.158-0.475,0.326-1.171,0.771-1.468c0.494-0.333,0.787,0.496,1.057,0.75\n	c0.477,0.453,1.873,0.187,2.473,0.193c0.947,0.009,1.906-0.029,2.85,0.072c0.787,0.086,1.73,0.243,2.422-0.252\n	c0.365-0.262,0.785-0.561,1.273-0.486c0.34,0.052-0.061,0.88,0.01,1.148c0.137,0.536,1.24,0.741,1.572,0.313\n	c0.225-0.29,0.184-0.615,0.344-0.911c0.203-0.381,0.082-0.762,0.275-1.126c0.281-0.532-0.229-1.635,0.254-2.039\n	c0.352-0.294,0.928,1.094,0.971,1.313c0.082,0.395-0.227,2.424,0.689,1.901c-0.004,0.564,1.074,0.445,1.402,0.374\n	c0.295-0.065,0.369-0.197,0.363-0.502c-0.012-0.638,0.133-0.512,0.779-0.512c2.535,0,5.072,0,7.609,0c5.176,0,10.352,0,15.525,0\n	c1.025,0,2.064,0.05,3.09-0.01c0.711-0.042,1.449-0.148,2.158-0.042c0.76,0.117,0.309,0.98,1.201,0.969\n	c0.754-0.012,1.607,0.218,2.34-0.024c0.658-0.217,0.508-1.167,0.469-1.704c-0.072-1.005-0.047-2.012-0.047-3.02\n	c0-0.392,0.27-0.942,0.102-1.319c-0.092-0.208-0.234-0.687-0.469-0.732c-0.027-0.51,0.443-1.429-0.363-1.551\n	c0.951-0.248,2.016-0.092,2.988-0.092c0.387,0,1.852,0.253,2.135-0.091c0.373-0.454,0.168-1.289,0.168-1.825\n	C101.906,13.872,102.195,12.882,101.77,12.422z M31.307,18.557c-1.768,0.501-22.436,7.108-24.18,7.868\n	c0.078-0.2,0.318-0.158,0.41-0.365c0.068-0.153-0.182-0.258-0.09-0.457c-0.756,0.051-0.662-1.169-0.631-1.633\n	c0.064-1.019,0.135-2.004,0.125-3.032c-0.004-0.386-0.383-2.77,0.383-2.77c1.686,0,3.373,0,5.059,0c6.504,0,13.006,0,19.51,0\n	c-0.227,0.085-0.348,0.32-0.584,0.388C31.365,18.541,31.41,18.528,31.307,18.557z M57.254,23.322\n	c-0.477,1.005-2.689,0.591-3.479,0.555c-0.824-0.039-1.656-0.009-2.48-0.009c-0.613,0-1.512,0.296-1.703-0.44\n	c-0.109-0.421-0.211-1.076-0.051-1.479c0.197-0.493-0.002-1.315,0.389-1.67c0.484-0.438,0.637-0.173,0.744,0.308\n	c0.145,0.652,0.332,1.315,0.801,1.812c0.359,0.379,0.881,0.714,1.391,0.843c0.439,0.11,1.1-0.348,0.563-0.733\n	c-0.537-0.386-2.021-2.388-0.686-2.466c0.775-0.046,1.564-0.004,2.338-0.004c0.334,0,1.955-0.222,2.148,0.055\n	c0.195,0.281,0.023,1.184,0.023,1.518C57.254,22.075,57.455,22.895,57.254,23.322z\"/>\n<rect id=\"sliceCopy_x5F_39_1_\" x=\"106.002\" fill=\"none\" width=\"96.643\" height=\"40\"/>\n<rect id=\"sliceCopy_x5F_38_1_\" fill=\"none\" width=\"106.002\" height=\"40\"/>\n</svg>",
        [27]    = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 1.1//EN\" \"http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd\" [\n	<!ENTITY ns_flows \"http://ns.adobe.com/Flows/1.0/\">\n]>\n<svg version=\"1.1\"\n	 xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" xmlns:a=\"http://ns.adobe.com/AdobeSVGViewerExtensions/3.0/\"\n	 x=\"0px\" y=\"0px\" width=\"79px\" height=\"40px\" viewBox=\"0.179 0 79 40\" enable-background=\"new 0.179 0 79 40\" xml:space=\"preserve\">\n<defs>\n</defs>\n<path fill=\"#FFFFFF\" d=\"M16.496,23.018c0-0.12,1.014-1.983,1.082-2.145c0.25-0.584,0.646-1.114,0.982-1.677c-0.309-0.308-1.252-0.33-1.68-0.368\n	c-0.594-0.054-1.141-0.193-1.758-0.287c-1.076-0.165-2.322-0.357-3.357-0.737c-0.855-0.315-1.957-0.406-2.762-0.942\n	c-0.408-0.272-0.896-0.453-1.291-0.655c-0.469-0.241-0.855-0.652-1.287-0.94C6.1,15.047,5.682,14.455,5.219,14.57\n	c0.057-0.348-0.553-0.652-0.736-0.9c-0.186-0.25-0.396-0.568-0.449-0.9c-0.043-0.265-0.045-0.676,0-0.942\n	c0.049-0.311,0.059-0.665,0.121-0.981c0.08-0.387,0.387-0.593,0.574-0.9c0.195-0.32,0.115-0.682,0.266-0.982\n	c0.129-0.258,0.078-0.683,0.143-0.941c0.084-0.326,0.26-0.873,0.697-0.86V7.122c3.945,0,7.891,0,11.836,0\n	c1.395,0,2.801,0.053,4.193-0.001C22.229,7.106,22.688,7,23,7c0.166,0,0.301,0.123,0.424,0.123c0.271,0,0.547,0,0.818,0\n	c9.039,0,18.078,0,27.115,0c2.584,0,5.168,0,7.75,0c0.598,0,1.197,0,1.795,0c0.119,0,0.242,0,0.363,0\n	c0.172,0,0.33,0.087,0.408,0.246c0.117,0.231,0.256,0.163,0.514,0.163c0,0.563-0.039,1.099,0,1.637h-0.164V9.25\n	c0.117-0.015,0.238,0.014,0.328,0.083c0.178-0.154,0.602-0.126,0.816-0.042V9.25c0.457,0.045,0.328,0.702,0.328,1.023\n	c1.834,0,3.668,0,5.502,0c1.213,0,2.426,0,3.637,0c0.318,0,1.32-0.183,1.584,0.082c0.34,0.343,0.328,0.478,0.328,0.983\n	c0,0.336,0.031,0.69,0,1.023c-0.031,0.279-0.057,0.778-0.469,0.778c-1.066,0-2.133,0-3.197,0c-0.607,0-1.213,0-1.818,0\n	c0,0.149,0,0.301,0,0.45H69.02c-0.18,0.539-1.908,0.287-2.385,0.287c-0.766,0-1.533,0-2.303,0c-0.303,0-0.549-0.003-0.795,0.164\n	c0.307,0.377-0.33,0.469-0.613,0.45v0.123H61.49c0,0.272,0,0.546,0,0.818l-0.369,0.041c-0.184,0.457-0.393,0.877-0.652,1.31\n	c-0.252,0.42-0.82,0.736-1.002,1.105c-0.34,0.684-2.078,0.492-2.682,0.492c-0.67,0-1.504-0.215-1.924-0.737\n	c-1.713,0.015-3.469,0.122-5.146,0.122c-0.221,0-0.467,0.21-0.645,0.328c-0.105,0.071-0.148,0.091-0.205,0.205\n	c-0.047,0.093-0.324,0.098-0.428,0.204c-0.299,0.3-0.635,0.597-0.861,0.983c-0.406,0.692-0.549,1.514-1.434,1.74\n	c-0.65,0.165-2.453,0.019-2.453-0.962c0-0.293-0.15-0.584-0.164-0.9c-0.018-0.321-0.008-0.609-0.084-0.9\n	c-1.258,0.008-2.516,0.016-3.773,0.025c-0.693,0.003-1.387,0.009-2.082,0.013c-0.273,0.002-0.553,0.115-0.814,0.085\n	c0.006,0.358-0.348,0.409-0.471,0.655c-0.152,0.308-0.381,0.526-0.633,0.778c-0.232,0.232-0.438,0.517-0.697,0.776\n	c-0.143,0.146-0.338,0.184-0.43,0.368c0.01-0.016-0.318,0.272-0.346,0.288c-0.904,0.452-2.414,0.205-3.479,0.205\n	c-0.813,0-1.627,0-2.439,0c-0.252,0-0.762-0.042-0.549-0.41h-0.164c-0.047,0.233-0.246,0.432-0.246,0.655\n	c0,0.169-0.168,0.5-0.246,0.696c-0.092,0.234-4.371,8.874-4.439,9.003c-0.238,0.458-0.158,0.603-0.365,0.638\n	c-0.248,0.041,0.025,0.341-0.166,0.528c-0.223,0.218-0.613,0.146-0.93,0.147c-1.883,0.01-3.768,0.02-5.65,0.03\n	c-0.711,0.002-2.037,0.241-2.607-0.238c-0.193-0.162-0.572-0.479-0.572-0.736c0-0.371,1.439-3.585,1.701-4.122L16.496,23.018z\n	 M34.318,17.885v-0.041l-3.807,0.041c0,0.342-0.059,0.767,0.121,1.064c0.363,0.605,0.732,0.615,1.467,0.615\n	c0.469,0,1.334,0.048,1.584-0.451c0.115-0.234,0.471-0.982,0.715-1.023C34.387,18.02,34.357,17.947,34.318,17.885 M29.201,18.581\n	v-0.083c-0.068,0.094-0.146,0.203-0.203,0.287h-0.043c-0.014,0.044-0.025,0.08-0.041,0.124h-0.039\n	c-0.016,0.044-0.027,0.079-0.043,0.123c-0.16,0.113-0.258,0.327-0.287,0.532h0.941C29.5,19.241,29.146,19.002,29.201,18.581\"/>\n<rect id=\"sliceCopy_x5F_37_1_\" x=\"78.561\" fill=\"none\" width=\"53.106\" height=\"40\"/>\n<rect id=\"sliceCopy_x5F_36_1_\" fill=\"none\" width=\"78.561\" height=\"40\"/>\n</svg>",
        [28]    = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 1.1//EN\" \"http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd\" [\n	<!ENTITY ns_flows \"http://ns.adobe.com/Flows/1.0/\">\n]>\n<svg version=\"1.1\"\n	 xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" xmlns:a=\"http://ns.adobe.com/AdobeSVGViewerExtensions/3.0/\"\n	 x=\"0px\" y=\"0px\" width=\"95px\" height=\"40px\" viewBox=\"0.099 0 95 40\" enable-background=\"new 0.099 0 95 40\" xml:space=\"preserve\">\n<defs>\n</defs>\n<path fill=\"#FFFFFF\" d=\"M89.14,10.486c0.611,0.12,2.045,2.156,0.947,2.193c0.295,0.923-3.137,0.646-4.053,0.65\n	c-3.748,0.019-7.498,0.036-11.244,0.055c-3.01,0.015-6.016,0.028-9.023,0.043c-0.168,0.001-0.205,1.095-0.205,1.295\n	c0,0.562,0.537,0.452,0.699,0.847c0.174,0.431,0,1.423,0,1.994c0,0.632,0.313,2.117-0.699,1.745c0,0.823,0.137,1.803-0.049,2.594\n	c0.863,0.126,0.447,4.008,0.447,4.933c0,1.662,0,3.324,0,4.985c0,0.397,0.043,2.393-0.023,2.393c-0.965,0-0.629,1.503-0.623,2.293\n	c0,0.092,0.535,0.448-0.066,0.448c-0.285,0-1.379,0.203-1.379-0.249c0-0.154,0.299-0.135,0.299-0.448c0-0.217,0-0.432,0-0.646\n	c0-0.387-0.051-0.894-0.051-1.197c0-0.202-0.748-0.516-0.748-1.047c0-3.374,0-6.747,0-10.118c0-0.349-0.059-0.789,0.051-1.096\n	c0.102-0.284,0.35-0.427,0.35-0.947c0-0.534,0.275-2.248-0.498-1.846c-0.166-0.281-0.174-2.006,0-2.143\n	c-0.201-0.104-0.498-0.239-0.498-0.499c0-0.16-0.35-0.684-0.35-0.399c0,0.355-0.111,0.327-0.301,0.548\n	c-0.127,0.15-0.447-0.005-0.447,0.249c0,0.112-0.047,0.285-0.148,0.35c-0.539,0.34-1.268,0.153-1.945,0.2\n	c-0.689,0.045-1.158,0.249-1.496-0.35c-0.064-0.115,0-0.461,0-0.598c0-0.082-0.854-0.05-0.963-0.05c-1.988,0-3.973,0-5.959,0\n	c-0.303,0-4.045-0.055-4.045,0.05c0,0.17-0.051,0.437,0,0.598c0.104,0.325,0.264,0.131,0.4,0.449\n	c0.203,0.47,0.016,0.913,0.447,1.396c0.188,0.209,0.447,0.026,0.447,0.398c0,0.215,0,0.432,0,0.648c0,0.847,0,1.696,0,2.542\n	c0,1.711,0,3.423,0,5.134c0,0.831,0,1.662,0,2.492c0,0.477-0.1,0.974-0.1,1.395c0,0.85-1.025,0.548-1.678,0.548\n	c-2.088,0-4.176,0-6.268,0c-0.578,0-1.643,0.185-2.074-0.25c-0.199-0.2-0.498,0.087-0.498-0.349c0-0.216,0-0.432,0-0.648\n	c0-0.415,0-0.831,0-1.246c0-3.372,0.154-6.854-0.1-10.168c-0.078-1.034,0.287-1.216,0.697-1.944\n	c-0.971,0.026-2.24-0.323-1.943,0.997c0.113,0.502,0.693,0.75,0.15,1.246c-0.232,0.211-0.686,0.208-0.998,0.25\n	c-0.725,0.093-0.479-0.048-0.748,0.349c-0.238,0.355-0.314,0.731-0.447,1.146c-0.135,0.417-0.285,0.839-0.398,1.246\n	c-0.09,0.316-0.117,1.063-0.35,1.297c-0.254,0.255,0.078,0.921-0.199,1.196c-0.154,0.152,0.051,0.498-0.273,0.498\n	c-0.17,0-0.52,0.183-0.723,0.2c-1.139,0.099-3.762,0.198-3.789-1.347c-0.014-0.808,0.576-1.701,0.799-2.391\n	c0.215-0.679,0.646-1.72,0.646-2.393c0-0.571,0.268-0.711-0.1-1.246c-0.334-0.489-0.787-0.669-1.295-0.922\n	c-0.461-0.229-0.811-0.553-1.047-1.072c-0.086-0.189-0.08-0.409-0.199-0.548c-0.207-0.244-0.129-0.092-0.523-0.225\n	c-0.236-0.079-0.375-0.222-0.375-0.473c0-0.108-1.756-0.05-1.93-0.05c-0.879,0-3.357,0.449-4.002-0.2\n	c-0.525-0.529,0.129-1.046-0.779-1.046c-0.719,0-1.508,0.102-2.211-0.075c-0.182-0.045-0.365,0.224-0.6,0.224\n	c-0.406,0-0.113,0.154-0.398,0.399c-2.25,1.934-4.768,3.874-7.227,5.434c-0.119,0.075-0.32,0.035-0.449,0.149\n	c-0.102,0.091-0.174,0.524-0.35,0.699c-0.123,0.124-0.613,0.433-0.797,0.523c-0.615,0.306-1.322,0.125-1.846-0.273\n	c-0.531-0.406-0.945-1.785-0.945-2.392c0-0.678-0.281-1.905-0.574-2.493c-0.338-0.682-0.262-1.739-0.373-2.492\n	c-0.133-0.894-0.377-3.481,1.146-3.042c0.262-0.29,1.434-0.149,1.896-0.149c2.078,0,4.156,0,6.236,0c2.674,0,5.113-0.25,7.82-0.25\n	c0.707,0,1.416,0,2.125,0c-0.082,0,0.279-0.519,0.266-0.498c0.188-0.282,0.059-0.278,0.398-0.499c0.26-0.167,0.711-0.064,0.896-0.2\n	c0.35-0.251-0.09-0.797-0.1-1.096c-0.018-0.654,0.273-0.575,0.699-0.849c0.307-0.196,0.617-0.797,0.99-0.797\n	c0.43,0,0.77-0.018,0.979,0.4c0.131,0.263,0.678,0.169,0.973,0.349c0.211,0.129,0.162,0.341,0.547,0.449\n	c0.668,0.185,1.648,0,2.359,0c0.449,0,0.957-0.263,1.08,0.398c0.539-0.219,0.623,0.961,0.648,1.347\n	c1.238-0.003,2.938,0.209,3.988-0.2c0.338-0.131,1.156-1.085,1.396-0.349c0.35-0.278,0.912-0.4,1.246-0.15\n	c0.301-0.521,2.234-0.345,2.791-0.249c0.166,0.029,0.285,0.289,0.348,0.299c0.197,0.031,0.443-0.051,0.648-0.05\n	c0.418,0.001,0.877-0.05,1.309-0.05c0.65,0,1.301,0,1.951,0c0.24,0,0.439,0.244,0.629,0.25c0.213,0.005,0.688-0.56,0.748,0.099\n	c0.4-0.085,0.652,0.045,1.084,0.035c0.438-0.011,0.875-0.022,1.314-0.034c0.078-0.002,0.139-0.217,0.244-0.25\n	c0.404-0.124,0.787-0.146,1.145-0.324c0.322-0.159,0.697-0.311,1.049-0.398c0.211-0.054,1.199-0.398,0.525-0.63\n	c-0.768-0.267-1.533-0.531-2.301-0.797c-0.41-0.142-1.66-0.315-1.791-0.841c-0.107-0.431-1.305-0.182-1.619-0.499\n	c-0.348-0.35-0.957-0.46-1.146-0.947C46.409,3.86,46.677,3.6,46.97,3.233c0.553-0.69,0.904,0.374,1.195,0.374\n	c0.26,0,0.576,0.153,0.799,0.25c0.441-0.743,3.939,0.7,4.594,0.876c0.594,0.16,1.826,0.408,2.109,0.969\n	c0.025,0.05,0.434-0.192,0.623,0c0.115,0.115,0.051,0.483,0.051,0.647c0,0.432,0,0.865,0,1.296c0,0.433,0,0.864,0,1.296\n	c0,0.715-0.762,0.697-1.363,0.697c-0.641,0-0.859,0.052-1.354,0.249c-0.238,0.096-0.189,0.449,0.082,0.449c1.934,0,3.869,0,5.803,0\n	c0.318,0,1.154,0.125,1.367-0.049c0.178-0.146-0.111-0.495,0.275-0.623c0.564-0.19,0.385-0.538,0.422-1.072\n	c0.021-0.266-0.109-0.172,0.102-0.548c0.029-0.052,0.41-0.434,0.498-0.499c0.305-0.221,1.297-0.557,1.695-0.349\n	c0.225,0.118,0.299,0.125,0.299,0.499c0,0.494,0.152,0.221,0.348,0.548c0.242,0.406,0.25,0.662,0.25,1.196\n	c0,1.585,2.24,1.046,3.426,1.046C75.173,10.486,82.155,10.486,89.14,10.486 M15.415,13.327c0.107-0.044,0.182-0.119,0.299-0.149\n	c-2.773,0-5.549,0-8.324,0c0.078,0.451,0.104,1.205,0.299,1.595c0.197,0.394,0.547,0.302,0.697,0.738\n	c0.232,0.685,0.465,1.37,0.699,2.053c0.885-0.645,1.578-0.852,2.242-1.395c0.441-0.358,1.063-0.644,1.496-0.947\n	C13.71,14.602,14.569,13.978,15.415,13.327\"/>\n<rect id=\"sliceCopy_x5F_57_1_\" x=\"94.487\" fill=\"none\" width=\"106.674\" height=\"40\"/>\n<rect id=\"sliceCopy_x5F_56_1_\" fill=\"none\" width=\"94.488\" height=\"40\"/>\n</svg>",
        [29]    = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 1.1//EN\" \"http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd\" [\n	<!ENTITY ns_flows \"http://ns.adobe.com/Flows/1.0/\">\n]>\n<svg version=\"1.1\"\n	 xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" xmlns:a=\"http://ns.adobe.com/AdobeSVGViewerExtensions/3.0/\"\n	 x=\"0px\" y=\"0px\" width=\"103px\" height=\"40px\" viewBox=\"0.707 0 103 40\" enable-background=\"new 0.707 0 103 40\"\n	 xml:space=\"preserve\">\n<defs>\n</defs>\n<path fill=\"#FFFFFF\" d=\"M99.27,14.756c0-1.109,0-2.708,0-3.66c-10.268-0.007-21.047-0.038-31.318-0.044c-5.971-0.003-11.938-0.009-17.908-0.012\n	c-1.703-0.001-3.408-0.002-5.113-0.003c-0.492,0-1.629-0.226-1.93-0.112c-0.395-1.529-5.18-0.701-6.264-0.701\n	c-3.242,0-6.867-0.436-10.057,0.037c-1.035,0.467-2.201,0.701-3.064,1.145c-0.754,0.389-1.588,0.71-2.326,1.071\n	c-0.738,0.361-1.414,0.801-2.104,1.144c-0.594,0.296-1.215,1.017-1.939,1.163c-0.58,0.118-1.229,0.765-1.754,1.053\n	c-0.756,0.415-1.73,0.726-2.584,1.034c-1.051,0.379-2.262,0.814-3.436,0.959c-1.441,0.18-2.221-0.393-3.285-0.921\n	c-0.322-0.161-0.178-0.37-0.66-0.37c-0.197,0-1.48-0.087-1.48,0.074c0,0.332-0.012,0.666,0,0.997\n	c0.035,1.262,0.074,2.524,0.074,3.84c0,1.77-0.52,4.049,0.59,5.315c0.885,1.014,2.09,2.494,3.285,2.955\n	c1.658,0.639,1.99,0.131,2.4-0.96c0.209-0.551,0.707-1.315,1.072-1.846c1.686-2.455,4.154-4.688,6.867-5.945\n	c0,0.111,0.004,0.222,0,0.333c0.035-0.013,0.072-0.025,0.109-0.037c2.016-0.775,2.471,0.929,3.322,2.178\n	c0.502,0.731,0.979,1.319,1.699,1.699c2.334,1.225,5.334,0.611,7.533-0.923c1.539-1.074,3.309-1.975,5.242-2.512\n	c0.744-0.206,1.564-0.401,2.398-0.461c0.299-0.021,1.205-0.879,1.775-1.163c0.518-0.258,1.189-0.148,1.762-0.148\n	c1.518,0,3.033,0,4.549,0c0.938,0,2.145-0.207,3.066,0c0.102,0.023-0.145,0.402,0.172,0.41c0.559,0.012,1.115,0.022,1.676,0.034\n	c-0.053-0.254-0.051-0.443,0.199-0.443c0.85,0,0.305-0.278,0.574-0.369c0.09-0.029,2.77-0.44,2.77-0.111\n	c0,1.404,3.613,0.813,4.387,0.812c2.619,0,5.74-0.484,8.316,0c0.494,0.093,0.998,0.475,1.531,0.628c0.258,0.074,0,0.404,0.232,0.409\n	c0.582,0.011,1.162,0.022,1.744,0.034c0.131-0.697,6.092-0.268,6.914-0.268c4.262-0.006,8.525-0.014,12.787-0.02\n	c1.631-0.003,3.844,0.328,4.963-0.449c0.287-0.2,0.5-0.789,0.813-1.071c0.684-0.617,1.266-0.468,2.398-0.442\n	c0-0.789,0-1.575,0-2.363c0-0.376,0-0.99,0-1.366c-1.119-0.05-1.939-0.014-2.391-0.014c-0.445,0-0.234-0.137-0.008-0.615\n	C97.633,14.729,98.404,14.756,99.27,14.756z M30.113,23.368c-0.547,0.712-1.691,1.172-2.436,1.403\n	c-1.072,0.332-2.473,0.114-3.396-0.479c-0.895-0.571-1.406-2.039-0.223-2.843c0,0.998-0.23,2.658,0.889,2.658\n	c-0.195,0,0.664-2.645,0.811-2.99c0.607-0.166,1.406-0.075,2.07-0.075c1.121,0,2.059-0.143,2.471,0.924\n	C30.496,22.479,30.422,22.966,30.113,23.368z\"/>\n<rect id=\"sliceCopy_x5F_55_1_\" x=\"103.27\" fill=\"none\" width=\"108.338\" height=\"40\"/>\n<rect id=\"sliceCopy_x5F_54_1_\" fill=\"none\" width=\"103.27\" height=\"40\"/>\n</svg>",
        [30]    = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 1.1//EN\" \"http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd\" [\n	<!ENTITY ns_flows \"http://ns.adobe.com/Flows/1.0/\">\n]>\n<svg version=\"1.1\"\n	 xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" xmlns:a=\"http://ns.adobe.com/AdobeSVGViewerExtensions/3.0/\"\n	 x=\"0px\" y=\"0px\" width=\"63px\" height=\"40px\" viewBox=\"0.945 0 63 40\" enable-background=\"new 0.945 0 63 40\" xml:space=\"preserve\">\n<defs>\n</defs>\n<path fill=\"#FFFFFF\" d=\"M29.965,4.83c0.885-0.461,1.518-1.202,2.396-0.611c0.273,0.184,0.648,0.38,0.891,0.611c0.252,0.238,0.234,0.259,0.234,0.656\n	c0,0.06-0.018,0.752,0.021,0.752c4.695,0,9.391,0,14.086,0c1.967,0,3.936,0,5.902,0c0.256,0,0.068-0.004,0.18-0.141\n	c0.047-0.056-0.031-0.215,0-0.281c0.059-0.118,0.094-0.068,0.188-0.188c0.09-0.117,0.518-0.657,0.684-0.657\n	c0.469,0,0.998-0.097,1.336,0.141c0.068,0.049,0.328,0.353,0.328,0.423c0,0.105,0.283,0.16,0.283,0.375\n	c0,0.091-0.039,0.262,0.047,0.305c0.014,0.007,0.328,0.271,0.328,0.234c0,0.4,0.387,0.232,0.518,0.446\n	c0.098,0.161-0.137,0.73,0.049,0.822c0.078,0.041,0.186,0.416,0.186,0.54c0,0.079-0.023,0.207,0,0.282\n	c-0.061-0.185,0.449,0.234,0.26,0.234c0.451,0,1.041-0.109,1.479,0c-0.08-0.02,0.281,0.27,0.281,0.188c0,0.104-0.02,0.226,0,0.33\n	c0.063,0.365,0,0.802,0,1.174c0,0.188,0,0.375,0,0.563c0,0.416-0.254,0.278-0.646,0.268c-0.348-0.009-1.117-0.159-1.373,0.014\n	c-0.049,0.032-0.141,0.579-0.141,0.656c0,0.139-0.238,0.563-0.33,0.587c-0.125,0.032-0.143,0.353-0.258,0.47\n	c-0.068,0.07-0.305,0.38-0.305,0.376c0,0.447-0.494,0.223-0.75,0.211c-1.969-0.095-3.957-0.027-5.926-0.041\n	c-2.447-0.017-4.893-0.033-7.338-0.05c-0.191-0.001-0.268,0.045-0.418,0.045c-0.555-0.001-0.639-0.106-0.639,0.422\n	c0,0.392,0,0.782,0,1.174s0,0.782,0,1.174c0,0.47-1.705,0.328-2.137,0.328c-0.656,0-0.959,1.067-1.408,1.526\n	c-0.236,0.241-0.682,0.558-0.682,0.963c0,0.494,0,0.988,0,1.482c0,0.32,0,0.64,0,0.959c0,0.141,0,0.282,0,0.423\n	c0,0.084,0.447,0,0.539,0.188c0.199,0.401,0.092,1.139,0.023,1.502c-0.098,0.515-0.102,0.709-0.563,0.939\n	c-0.336,0.168-0.496,0.381-0.564,0.798c-0.123,0.736,0,1.6,0,2.348c0,2.442,0,4.883,0,7.326c0,0.162,0.096,0.742,0,0.844\n	c-0.086,0.091-0.766,0-0.885,0c-1.422,0-2.84,0-4.262,0c-0.588,0-1.176,0-1.764,0c-0.422,0-0.51,0.085-0.65-0.188\n	c-0.178-0.351,0-1.357,0-1.784c0-2.989,0-5.977,0-8.967c-0.275,0.204-0.277,0.656-0.723,0.656c-0.215,0-1.67-0.039-1.67-0.329\n	c0-0.411-0.094-1.175-0.094-1.737c0-0.097,0.004-0.987-0.01-0.987c-0.768,0-1.535,0-2.303,0c-0.986,0-1.973,0-2.961,0\n	c-0.473,0.001-0.268,0.625-0.268,1.034c-1.059-0.016-2.119-0.031-3.178-0.047c-0.238-0.004-0.455,1.21-0.555,1.243\n	c-0.068,0.022-0.305,0.423-0.305,0.54c0,0.307-0.148,0.38-0.281,0.657c-0.186,0.384-0.322,0.802-0.471,1.174\n	c-0.1,0.251-0.068,0.375-0.186,0.611c-0.098,0.194-0.254,0.493-0.33,0.656c-0.182,0.389-0.26,0.712-0.375,1.127\n	c-0.033,0.12-0.236,0.375-0.283,0.516c-0.074,0.232-0.168,0.5-0.234,0.752c-0.121,0.461-0.041,0.284,0.141,0.609\n	c0.068,0.118,0.236,0.531,0.236,0.657c0,0.49,0.088,1.288-0.377,1.502c-0.291,0.135-0.92-0.137-1.063-0.141\n	c-0.43-0.017-0.971-0.08-1.326-0.098c-1.066-0.055-2.074-0.142-3.137-0.168c-0.869-0.019-1.633-0.202-2.615-0.202\n	c-0.299,0-0.566-0.127-0.855-0.151c-0.365-0.028-1.146,0.118-1.146-0.341c0,0.011-0.602-0.209-0.703-0.399\n	c-0.119-0.219-0.094-0.437-0.094-0.705c0-0.919,0.236-1.536,0.422-2.394c0.08-0.372,0.258-0.729,0.375-1.127\n	c0.033-0.109,0.07-0.209,0.096-0.281c0.055-0.161,0.123-0.151,0.188-0.282c0.084-0.174-0.008-0.464,0.141-0.611\n	c0.574-0.571,1.012-1.564,1.361-2.348c0.385-0.864,1.059-1.597,1.408-2.3c0.105-0.213,0.262-0.364,0.377-0.517\n	c0.059-0.083,0.375-0.546,0.375-0.61c0-0.463,0.609-0.737,0.609-1.244c0-0.03,0.191-0.57,0.236-0.681\n	c0.117-0.307,0.354-0.371,0.281-0.751c-0.033-0.169-0.27-0.503-0.377-0.657c-0.125-0.181-0.25-0.484-0.445-0.681\n	c-0.256-0.253-0.305-0.437-0.305-0.845c0-0.422-0.893-0.211-1.242-0.211c-0.441,0-0.881-0.059-1.176-0.118\n	c-0.303-0.06-0.439-0.441-0.68-0.563c-0.117-0.058-0.379-0.401-0.471-0.493c-0.121-0.122-0.375-0.386-0.375-0.61\n	c0-0.271-0.094-0.932-0.094-1.362c0-0.782,0-1.565,0-2.348c0-0.501,0.094-1.092,0.094-1.455c0-0.251-0.043-0.517,0.168-0.587\n	C5.168,8.307,5.188,8.22,5.316,8.117C5.389,8.06,5.521,8.032,5.598,7.976c0.021-0.017,0.045-0.188,0.094-0.235\n	c0.025-0.023,0.383-0.238,0.438-0.259c0.18-0.071,0.189-0.171,0.314-0.257C6.719,7.034,7.07,6.819,7.381,6.66\n	c0.348-0.177,1.332-0.609,1.223-1.079c0.113,0.044,0.262,0,0.375,0.047C8.906,5.067,9.248,4.83,9.754,4.854\n	c0.262,0.013,0.867-0.02,0.867,0.281c0,0.113,0.088,0.66,0.141,0.728c0.162,0.203,0.848,0.096,1.168,0.097\n	c1.104,0.003,2.205,0.006,3.307,0.008c4.875,0.012,9.748,0.023,14.623,0.036c0.02,0,0.039,0,0.061,0\n	C29.92,5.657,29.844,5.092,29.965,4.83 M27.242,18.54c-0.188-0.375-0.229-1.035-0.656-1.22c-0.316-0.137-0.971-0.047-1.316-0.047\n	c-0.625,0-1.25,0-1.877,0c0.1,0.592,0.721,1.187,1.127,1.548c0.164,0.146,0.809,0.385,0.846,0.61\n	c0.072,0.438-0.479,0.715-0.869,0.587c-0.773-0.256-1.184-0.41-1.76-1.01c-0.139-0.143-0.658-0.496-0.658-0.657\n	c0-0.129-0.318-0.731-0.398-0.893c-0.035-0.067-0.01-0.117-0.023-0.188c-0.676,0.124-0.529,1.042-0.893,1.409\n	c-0.145,0.145-0.375,0.751-0.375,0.915c0,0.283-0.375,0.625-0.375,0.893c0,0.157,6.176,0.154,6.902,0.164\n	c-0.049-0.261,0.02-0.351,0.188-0.517c0.043-0.042,0.33-0.56,0.33-0.516c0-0.245,0.057-0.294,0-0.517\n	C27.377,18.892,27.234,18.743,27.242,18.54\"/>\n<rect id=\"sliceCopy_x5F_31_1_\" x=\"63.669\" fill=\"none\" width=\"65.054\" height=\"40\"/>\n<rect id=\"sliceCopy_x5F_30_1_\" fill=\"none\" width=\"63.669\" height=\"40\"/>\n</svg>",
        [31]    = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 1.1//EN\" \"http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd\" [\n	<!ENTITY ns_flows \"http://ns.adobe.com/Flows/1.0/\">\n]>\n<svg version=\"1.1\"\n	 xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" xmlns:a=\"http://ns.adobe.com/AdobeSVGViewerExtensions/3.0/\"\n	 x=\"0px\" y=\"0px\" width=\"53px\" height=\"40px\" viewBox=\"0.058 0 53 40\" enable-background=\"new 0.058 0 53 40\" xml:space=\"preserve\">\n<defs>\n</defs>\n<path fill=\"#FFFFFF\" d=\"M23.898,15.073h-3.27c-0.43,0-0.645,0.215-0.645,0.645v1.843c0,0.46,0.215,0.69,0.645,0.69c1.09,0,2.424,0.211,3.316-0.553\n	C24.322,17.351,25.113,15.073,23.898,15.073 M48.03,7.89l0.324,0.138c-0.164,2.292-0.609,4.586-0.922,6.861\n	c-0.271,1.161-2.057,1.371-3.016,1.636c-0.76,0.208-1.773,0.653-2.572,0.668c-0.666,0.012-5.881-0.247-5.881,0.46\n	c0,0.589,0.346,2.973-0.643,2.903c-1.518-0.271-3.095-0.141-4.634-0.141c-1.547,0-3.016-0.062-4.531,0.23\n	c-0.254-0.186-0.396-0.472-0.369-0.783c-0.461,0.736-0.92,1.105-1.381,1.105h-4.561c-0.873,0-1.07,1.418-1.387,2.077\n	c-0.707,1.474-1.063,3.009-1.445,4.591c-0.668,2.753-0.988,5.048-0.621,7.886c0,0.821-1.033,0.312-1.527,0.38\n	c-0.422,0.058-0.791,0.149-1.207,0.063c-1.195-0.25-2.393-0.501-3.588-0.751c-0.945-0.198-1.881-0.476-2.816-0.714\n	c-1.094-0.279-2.764-0.429-3.111-1.742c-0.459-1.458,0.307-3.41,0.654-4.86c0.35-1.449,0.693-2.901,1.051-4.35\n	c0.637-2.582,1.498-5.112,2.072-7.691c0.094-1.422-1.553-1.975-2.229-2.945c-0.543-0.777-0.26-2.394-0.26-3.271\n	c0-1.045-0.191-2.389,0.15-3.398C5.889,5.33,6.969,4.643,7.689,4.066c0.609,0.089,2.219,0.011,2.625,0.553\n	c0.723,0.289,1.596,0.428,2.395,0.507c1.746,0.174,3.457,0.118,5.203,0.369l0.23,0.552c1.785-0.453,3.654-0.276,5.506-0.276\n	c1.738,0,3.445-0.145,5.133,0.276c-0.063-0.123-0.078-0.276-0.047-0.46c0.031-0.215,0.291-0.369,0.781-0.461l0.785,0.139\n	c0.229-0.229,0.627-1.176,0.828-1.244c1.221-0.076,1.754,0.055,2.901,0.461c0.406,0.144,1,0.458,1.428,0.461\n	c0.426,0.002,0.828-0.262,1.289-0.23c1.107,0.072,2.271,0.465,3.359,0.688c0.611,0.125,1.088,0.389,1.615,0.739\n	c0.438,0.136,1.107,0.066,1.566,0.093c0.168,0.11,0.26,0.265,0.275,0.46c1.051,0.287,1.914,0.546,2.855,1.06\n	C47.091,7.553,47.362,7.655,48.03,7.89\"/>\n<rect id=\"sliceCopy_x5F_34_1_\" x=\"52.354\" fill=\"none\" width=\"83.251\" height=\"40\"/>\n<rect id=\"sliceCopy_x5F_33_1_\" fill=\"none\" width=\"52.354\" height=\"40\"/>\n</svg>",
        [32]    = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 1.1//EN\" \"http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd\" [\n	<!ENTITY ns_flows \"http://ns.adobe.com/Flows/1.0/\">\n]>\n<svg version=\"1.1\"\n	 xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" xmlns:a=\"http://ns.adobe.com/AdobeSVGViewerExtensions/3.0/\"\n	 x=\"0px\" y=\"0px\" width=\"50px\" height=\"40px\" viewBox=\"0.104 0 50 40\" enable-background=\"new 0.104 0 50 40\" xml:space=\"preserve\">\n<defs>\n</defs>\n<path fill=\"#FFFFFF\" d=\"M45.953,6.063c0.016-0.2,0.158-0.843-0.018-1c-0.262-0.234-0.563,0.109-0.469-0.422c0.162-0.781-1.193-0.643-1.623-0.612\n	c-1.141,0.083-2.285,0.043-3.43,0.039c-3.064-0.012-6.131-0.023-9.197-0.036c0,0.324,0.164,1.146-0.027,1.427\n	c-0.143,0.209-0.961,0.072-1.156,0.072c-1.229,0-2.457,0-3.688,0c-0.498,0-1.051,0.238-1.041-0.371\n	c0.002-0.196,0.072-0.58-0.229-0.573c-0.15,0.004-0.604,0.148-0.58-0.145c0.039-0.52-0.215-0.365-0.701-0.366\n	C18.689,4.061,13.584,4.047,8.48,4.032c0,0.281,0,0.563,0,0.844C8.043,4.859,7.605,4.844,7.168,4.829\n	c0,0.665-0.705,0.998-0.984,1.594c-0.236,0.501-0.641,1.074-0.939,1.6C4.992,8.466,4.836,9.134,4.885,9.64\n	c0.051,0.549-0.02,0.54-0.416,0.807c-0.244,0.165-0.164,1.037-0.227,1.334c-0.076,0.364-0.102,0.865-0.041,1.231\n	c0.055,0.329,0.201,0.207,0.42,0.333c0.107,0.062,0.074,0.206,0.184,0.277c0.361,0.232,0.906,0.27,1.297,0.46\n	c0.926,0.453,1.893,1.212,2.52,2.043c0.328,0.432-0.031,0.683,0.004,1.173c0.029,0.368-0.332,0.676-0.332,0.937\n	c0,0.291-0.387,1.043-0.529,1.292c-0.096,0.176-0.459,0.709-0.447,0.865c0.01,0.169-0.391,1.01-0.5,1.166\n	c-0.217,0.306-0.363,0.817-0.492,1.175c-0.242,0.67-0.611,1.379-0.984,2.062c-0.148,0.27-0.24,0.723-0.35,1.026\n	c-0.137,0.385-0.148,0.786-0.283,1.174c-0.293,0.845-0.443,1.887-0.477,2.774c-0.01,0.244-0.217,0.275-0.221,0.522\n	c-0.004,0.224,0.018,0.452,0.018,0.674C4.027,31.557,4,32.151,4,32.743c0,1.296,2.09,0.281,2.781,0.661\n	c0.264,0.145-0.055,0.626,0.434,0.788c0.342,0.113,0.734,0.099,1.057,0.272c0.623,0.337,1.686,0.557,2.398,0.624\n	c1.34,0.123,2.707,0.257,4.018,0.587C15.201,35.803,15.473,36,16.014,36c0.525,0,1.041-0.094,1.561-0.094\n	c0.324,0,0.938,0.286,0.938-0.27c0-0.201-0.861-0.411-1.004-0.582c-0.537-0.646-0.799-2.336-0.449-3.098\n	c0.197-0.43,0.273-1.12,0.365-1.593c0.088-0.458,0.359-0.827,0.461-1.273c0.18-0.788,0.51-1.419,0.744-2.209\n	c0.197-0.665,0.529-1.3,0.633-1.99c0.08-0.537,0.354-1.216,0.322-1.746c-0.025-0.437,0.146-1.09,0.23-1.526\n	c0.068-0.351,0.221-0.428,0.564-0.432c2.957-0.026,5.916,0,8.871,0c1.266,0,2.529-0.019,3.793,0.037\n	c0.135,0.005,0.797,0.074,0.797-0.177c0-0.419,0.285-0.999-0.139-1.237c-0.227-0.127-0.047-1.873-0.047-2.165\n	c0-0.459-0.055-0.917-0.059-1.377c-0.01-0.85,0.273-1.136,0.857-1.692c0.313-0.299,1.496-0.091,1.934-0.091c0.734,0,1.471,0,2.205,0\n	c1.441,0,2.885,0,4.326,0c0.461,0,2.92,0.335,3.004-0.256c0.189-1.305,0.014-2.761,0.014-4.081\n	C45.936,8.797,45.844,7.41,45.953,6.063z M11.762,35.064c0.135-0.009,0.268,0.063,0.328,0.094\n	C11.975,35.133,11.867,35.118,11.762,35.064z M32.818,19.558c-0.066,0.439-0.432,0.248-0.805,0.225c0,0.728-0.125,0.61-0.854,0.61\n	c-0.941,0-1.883,0-2.824,0c-1.672,0-3.357-0.068-5.025,0.047c-0.82,0.057-0.574-0.582-0.617-1.176\n	c-0.041-0.575-0.428-1.044-0.469-1.63c-0.041-0.582,0.459-1.025,0.459-1.579c0-0.498,0.645-0.76,0.846-1.148\n	c0.205-0.221,0.918-0.57,1.213-0.469c0.547,0.188,0.188,1.837,0.146,2.25c-0.08,0.791,0.535,1.082,0.924,1.655\n	c0.402,0.587,0.854,0.821,1.479,1.14c0.457,0.233,1.064,0.192,1.564,0.165c0.314-0.017,0.455-0.67,0.23-0.792\n	c-0.086-0.046-0.637,0.076-0.637-0.059c0-0.017-0.447-0.202-0.475-0.216c-0.504-0.245-0.992-0.568-1.342-1.013\n	c-0.504-0.639-0.338-1.551-0.338-2.31c0-0.299,0.209-0.761,0.512-0.822c1.102-0.227,2.328,0.067,3.451,0.017\n	c0.723-0.032,1.342-0.013,1.844,0.541c0.188,0.206,0.762,0.412,0.76,0.604c-0.008,0.913-0.01,1.827,0.006,2.74\n	C32.875,18.744,32.879,19.155,32.818,19.558z\"/>\n<rect id=\"sliceCopy_x5F_26_1_\" x=\"50.022\" fill=\"none\" width=\"59.346\" height=\"40\"/>\n<rect id=\"sliceCopy_x5F_25_1_\" fill=\"none\" width=\"50.022\" height=\"40\"/>\n</svg>",
        [33]    = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 1.1//EN\" \"http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd\" [\n	<!ENTITY ns_flows \"http://ns.adobe.com/Flows/1.0/\">\n]>\n<svg version=\"1.1\"\n	 xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" xmlns:a=\"http://ns.adobe.com/AdobeSVGViewerExtensions/3.0/\"\n	 x=\"0px\" y=\"0px\" width=\"60px\" height=\"40px\" viewBox=\"0.452 0 60 40\" enable-background=\"new 0.452 0 60 40\" xml:space=\"preserve\">\n<defs>\n</defs>\n<path fill=\"#FFFFFF\" d=\"M56.153,9.869c0-0.543-0.922-0.353-1.25-0.353c-0.711,0-3.484,0.394-3.936-0.186c-0.164-0.048-0.305-0.173-0.463-0.231\n	c0.164-0.419-0.186-0.813-0.186-1.25c0-0.327,0.18-0.748-0.416-0.741c0.223-0.618-0.23-1.426-0.693-1.667\n	c-0.715-0.371-1.59,0.044-2.178-0.417c-0.566-0.446-0.688-0.982-1.482-1.019c-0.613-0.028-1.373,0.046-2.021,0.046\n	c-7.535,0-15.068,0-22.604,0c-2.551,0-5.104,0-7.654,0c-0.975,0-1.512,0.461-1.893,1.296c-0.262-0.189-0.311,0.065-0.555,0.046\n	c-0.32-0.024-0.354-0.038-0.65-0.185c-0.641-0.32-0.916-0.095-1.25,0.324C8.896,5.57,8.706,5.878,8.692,5.905\n	c-0.07,0.128-0.221,0.257-0.301,0.416C8.241,6.62,8.2,6.997,8.46,7.294c-0.688,0-1.375,0-2.061,0c-0.479,0-0.35-0.24-0.717-0.278\n	C5.392,6.987,4.575,7.24,4.409,7.572C4.2,7.989,4.058,8.053,4.015,8.452c-0.033,0.3,0,0.623,0,0.926c0,3.086,0,6.174,0,9.26\n	c0,1.228-0.248,2.084,1.367,2.084c1.297,0,1.721-0.625,2.199-1.667c0.252-0.549,0.467-1.139,0.695-1.667\n	c0.178-0.414,0.693-1.317,0.693-1.713c0-0.427,0.236-1.955,0.557-2.176c-0.023,0.305,0.287,0.928,0.508,1.041\n	c0.359,0.184,0.939,0.069,1.32,0.069c0.957,0,1.912,0,2.869,0c0.414,0,1.598-0.19,2.016,0c0.189,0.086,0.23,0.425,0.416,0.509\n	c0.25,0.113,0.65-0.099,0.957-0.108c0.836-0.025,1.674-0.05,2.512-0.075c0.285-0.009,0.539,0.147,0.791,0.021\n	c0.191-0.097,0.148-0.523,0.371-0.301c0.127,0.127,0.021,0.474,0.139,0.533c0.34,0.169-0.232,1.877-0.232,2.153\n	c0,0.648-0.551,1.4-0.602,2.083c-0.057,0.779-0.092,1.514-0.092,2.315c0,0.769,0.092,1.605,0.092,2.315\n	c0,0.332-0.008,1.038,0.371,1.134c0.633,0.162,0.648,0.146,0.648,0.811c0,1.671,0.268,3.06,0.508,4.63\n	c0.055,0.348,0.232,0.823,0.232,1.157c0,0.438,0.277,0.716,0.277,1.112c0,0.65,0.316,1.764,0.604,2.315\n	c0.344,0.665,0.811,0.556,1.59,0.556c0.439,0,0.938,0.231,1.479,0.231c0.572,0,0.979-0.058,1.492-0.162\n	c0.432-0.087,2.432,0.213,2.082-0.486c-0.166-0.332,0.076-0.819-0.092-1.157c-0.068-0.135-0.201-0.076-0.279-0.231\n	c-0.047-0.098-0.016-0.185-0.068-0.278c-0.094-0.163-0.162-0.325-0.256-0.51c-0.158-0.313-0.268-0.729-0.346-1.111\n	c-0.164-0.777-0.248-1.495-0.371-2.269c-0.197-1.247-0.807-3.198-0.463-4.445c0.402-1.462-0.186-2.989-0.186-4.584\n	c0-0.801,0.092-1.532,0.092-2.315c0-0.35-0.145-1.064,0.348-1.064c1.186,0,2.434-0.085,3.637-0.139\n	c1.357-0.061,2.871,0.103,2.871-1.575c0-0.493,0.787-0.741,0.787-1.065c0-0.379,0.217-0.767,0-1.157\n	c0.176-0.051,0.371-0.046,0.576-0.046c1.873,0,3.746,0,5.619,0c0.838,0,1.166-0.198,1.166,0.648c0,0.771,0,1.544,0,2.315\n	c0,1.564-0.023,3.106-0.139,4.63c-0.127,1.678-0.389,3.856,1.598,4.515c0.705,0.234,2.762,1.234,3.08,0.301\n	c0.207-0.611,0-1.665,0-2.315c0-3.087,0-6.174,0-9.261c0-0.539,0.32-0.686,0.693-0.926c0.533-0.344,1.002-1.126,1.459-0.185\n	c0.096,0.196,0.707,0.887,0.904,1.019c0.492,0.331,0.742-0.145,0.738-0.648c0-0.095-0.146-0.585-0.137-0.602\n	c0.111-0.235,0.828-0.369,0.902-0.369c0.848,0,1.697,0,2.545,0c0.463,0,1.318,0.216,1.6-0.278\n	C56.423,11.777,56.153,10.425,56.153,9.869z M4.616,11.555c0-0.479,0-0.958,0-1.437c-0.012-0.183,0-0.373,0-0.555\n	C4.759,10.079,4.757,11.039,4.616,11.555z M28.649,15.212c-0.078-0.227-0.127-0.445-0.047-0.695c0.09,0.227,0.182,0.41,0.324,0.602\n	c0.139,0.171,0.268,0.442,0.51,0.556C28.696,15.675,28.825,15.729,28.649,15.212z M33.466,14.517\n	c-0.127,0.242-0.186,0.577-0.324,0.788c-0.271,0.413-0.787,0.37-1.318,0.37c-0.59,0-0.459-0.248-0.766-0.556\n	c-0.184-0.182-1-1.372-0.975-1.528c0.07-0.422,1.885-0.184,2.324-0.184c0.412,0,1.533-0.278,1.336,0.369\n	C33.833,14.125,33.601,14.256,33.466,14.517z\"/>\n<rect id=\"sliceCopy_x5F_36_1_\" x=\"60.273\" fill=\"none\" width=\"78.561\" height=\"40\"/>\n<rect id=\"sliceCopy_x5F_35_1_\" fill=\"none\" width=\"60.272\" height=\"40\"/>\n</svg>",
        [34]    = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 1.1//EN\" \"http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd\" [\n	<!ENTITY ns_flows \"http://ns.adobe.com/Flows/1.0/\">\n]>\n<svg version=\"1.1\"\n	 xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" xmlns:a=\"http://ns.adobe.com/AdobeSVGViewerExtensions/3.0/\"\n	 x=\"0px\" y=\"0px\" width=\"83px\" height=\"40px\" viewBox=\"0.703 0 83 40\" enable-background=\"new 0.703 0 83 40\" xml:space=\"preserve\">\n<defs>\n</defs>\n<path fill=\"#FFFFFF\" d=\"M36.703,5.446c0.086-0.147,0.182-0.209,0.129-0.432c1.227-0.171,1.477,1.296,2.58,1.296c2.352,0,4.701,0,7.051,0\n	c7.238,0,14.479,0,21.717,0c0.572,0,3.002-0.409,3.363,0.302c0.455,0.893,0.588,2.007,1.025,2.962\n	c0.447,0.983,2.074,0.364,2.906,0.364c1.01,0,2.238,0.128,3.219,0.216c0.561,0.05,0.561,0.16,0.555,0.733\n	c-0.008,0.813-0.072,2.492-0.025,3.304c0.031,0.54,0.182,0.705-0.734,0.671c-1.242-0.046-2.484,0-3.727,0\n	c0.559,1.262,1.119,2.524,1.678,3.786c0.068,0.157,0.043,0.447,0.051,0.621c0.031,0.87,0.129,0.947-0.746,0.969\n	c-0.828,0.021-0.908,0.158-1.289-0.536c-0.432-0.784-0.861-1.567-1.293-2.352c-0.176-0.321-2.072-0.277-2.072,0.32\n	c0,0.854-0.086,1.775-0.086,2.657c0,0.893,0.26,1.745,0.26,2.657c0,0.809,0.482,1.781,0.734,2.549\n	c0.26,0.792,0.504,1.647,0.691,2.462c0.252,1.093,1.383,4.505,0.086,5.227c-0.676,0.377-1.695,0.483-2.461,0.562\n	c-0.516,0.053-1.09,0.056-1.557,0.13c-0.326,0.051-1.166,0.329-1.447,0.216c-0.771-0.311-0.797-0.452-1.059-1.125\n	c-0.182-0.465-0.426-0.89-0.584-1.359c-0.057-0.175-0.064-0.398-0.064-0.584c0-0.341-0.199-0.37-0.301-0.648\n	c-0.131-0.354-0.18-0.949-0.217-1.296c-0.092-0.857-0.174-1.668-0.174-2.548c0-0.35-0.172-0.827-0.172-1.253\n	c0-0.446-0.057-0.816-0.086-1.253c-0.063-0.922-0.131-1.766-0.131-2.678c0-1.006-0.279-2.171-1.383-2.376\n	c-1.459-0.272-1.875,1.499-2.98,2.052c-0.5,0.25-0.813,0.686-1.297,0.927c-0.686,0.345-1.217,0.693-2.02,0.788\n	c-1.742,0.203-3.34,0.404-4.633-0.831c-1.658,3.098-1.77,6.559-1.77,10.195c0,0.454,0,0.907,0,1.361c0,0.202-0.037,0.54-0.305,0.54\n	c-0.203,0-0.016,0.498-0.086,0.648c-0.248,0.531-2.492,0.216-3.16,0.216c-1.449,0-2.898,0-4.346,0c-0.033,0,0.008-0.463-0.012-0.518\n	c-0.025-0.079,0.051-0.283,0-0.346c-0.096-0.122-0.666-0.05-0.863-0.043c-0.744,0.026-1.291,0.184-1.512-0.604\n	c-0.223-0.795-0.129-1.807-0.129-2.657c0-1.714-0.006-3.499,0.475-5.076c0.066-0.218,0.287-0.431,0.367-0.669\n	c0.066-0.198,0.074-0.429,0.152-0.627c0.174-0.449,0.518-0.854,0.691-1.296c0.332-0.845,0.814-1.706,0.863-2.636\n	c0.029-0.543-0.061-0.846-0.303-1.296c-0.148-0.277-0.561-1.21-0.873-1.208c-2.664,0.016-5.328,0.028-7.992,0.051\n	c-1.168,0.011-3.055-0.313-4.051,0.186c-0.502,0.252-1.123-0.41-1.123-0.842c0-0.835,0-1.671,0-2.505c0-0.194,0-0.389,0-0.583\n	c0-0.45-0.779-0.022-1.08-0.324c-0.086-0.085-0.277,0.019-0.389-0.151c-0.006-0.007-0.17-0.296-0.131-0.28\n	c-0.148-0.061-0.455,0-0.611,0c-3.203,0-6.406,0-9.609,0c-3.098,0-6.197,0-9.295,0c-0.82,0-0.441,0.938-0.443,1.469\n	c-0.006,1.124-0.252,2.355-0.355,3.486c-0.15,1.643-0.303,3.288-0.453,4.93c-0.031,0.342-0.221,0.717-0.324,1.065\n	C5.305,25.232,4.807,25.026,4,25.102c0-2.806,0-5.612,0-8.417c0-1.618,0-3.233,0-4.851c0-0.308,0-0.615,0-0.923\n	c0-0.264,0.525,0.06,0.561,0.065c1.598,0.244,3.541,0.216,5.293,0.216c3.748,0,7.498,0,11.246,0c2.186,0,4.377,0.043,6.563-0.001\n	c0.699-0.014,1.398-0.028,2.098-0.042c0.342-0.007,0.289-0.064,0.289-0.389c0-0.447,0-0.894,0-1.339c0-0.677-0.273-2.066,0-2.679\n	c0.49-1.09,6.264-0.058,6.264-0.475C36.313,5.749,36.48,5.825,36.703,5.446 M55.063,20.653c-0.678-0.679-1.123-1.545-1.209-2.505\n	c-0.279,0.218-1.385,1.297-1.102,1.576c0.744,0.741,1.689,1.227,2.744,1.318C55.35,20.912,55.207,20.782,55.063,20.653\n	 M59.814,18.579c-0.842-0.863-2.102-1.609-3.361-1.399c-0.941,0.157-1.203,0.022-1.219,1.052c0,0.766,0.191,1.521,0.584,2.179\n	c0.248,0.414,0.314,0.669,0.826,0.582c0.48-0.084,0.945-0.253,1.365-0.502C58.813,20.017,59.27,19.307,59.814,18.579 M40.936,32.878\n	C40.859,32.66,40.963,32.957,40.936,32.878\"/>\n<rect id=\"sliceCopy_x5F_35_1_\" x=\"83.251\" fill=\"none\" width=\"60.272\" height=\"40\"/>\n<rect id=\"sliceCopy_x5F_34_1_\" fill=\"none\" width=\"83.251\" height=\"40\"/>\n</svg>",
        [35]    = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 1.1//EN\" \"http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd\" [\n	<!ENTITY ns_flows \"http://ns.adobe.com/Flows/1.0/\">\n]>\n<svg version=\"1.1\"\n	 xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" xmlns:a=\"http://ns.adobe.com/AdobeSVGViewerExtensions/3.0/\"\n	 x=\"0px\" y=\"0px\" width=\"113px\" height=\"40px\" viewBox=\"0.299 0 113 40\" enable-background=\"new 0.299 0 113 40\"\n	 xml:space=\"preserve\">\n<defs>\n</defs>\n<path fill=\"#FFFFFF\" d=\"M108.467,11.969c-0.254-0.553,0.512-1.195-0.391-1.396c-0.547-0.122-1.109-0.024-1.66-0.036\n	c-0.35-0.008-0.223-0.584-0.361-0.803c-0.328-0.529-1.225-0.31-1.73-0.276c-0.723,0.047-0.982,0.245-0.982,1.002\n	c-0.516-0.036-1.025-0.129-1.541-0.15c-0.023,0.092,0,0.167,0.074,0.225c-8.863,0-17.725-0.004-26.59,0\n	c-2.156,0.001-4.314,0.006-6.471-0.001c-1.078-0.002-2.156-0.009-3.234-0.02c-0.588-0.006-1.176-0.014-1.764-0.022\n	c-0.373-0.006-0.771,0.099-1.139,0.053c-0.26-0.034-0.387-0.291-0.666-0.33c-0.24-0.034-0.816,0.138-1.006-0.021\n	c-0.574-0.485-1.508-0.23-2.256-0.186c-1.037,0.063-2.078,0.052-3.115,0.032c-0.568-0.01-1.133-0.023-1.701-0.029\n	c-0.041-0.001-0.635,0.069-0.527-0.041c-0.018,0-0.623-0.086-0.375,0.037c-1.211-0.195-2.445-0.195-3.668-0.158\n	c-0.377,0.011-3.369,0.156-3.316-0.064c0.098-0.412-0.488-0.273-0.682-0.303c-0.324-0.051-0.064-0.503-0.582-0.465\n	c-0.383,0.028-1.637-0.206-1.445,0.426c-0.125-0.013-0.25-0.024-0.375-0.037c0,0.753-0.918,1.106-1.48,1.4\n	c-0.824,0.43-1.66,0.813-2.531,1.075c-0.438,0.132-0.848,0.44-1.277,0.616c-0.484,0.198-0.973,0.391-1.455,0.596\n	c-1.072,0.454-2.18,0.833-3.24,1.305c-0.482,0.212-0.969,0.275-1.469,0.417c-0.471,0.131-0.893,0.357-1.389,0.396\n	c-0.313,0.024-0.986-0.044-1.127-0.385c-0.162-0.391-1.221-0.051-1.582-0.014c-2.307,0.236-4.654,0.392-6.971,0.465\n	c-1.045,0.032-2.053,0.279-3.096,0.342c-1.172,0.072-2.332,0.182-3.508,0.204c-0.945,0.018-1.898,0.112-2.846,0.074\n	c-0.279-0.011-0.602-0.031-0.861,0.092c-0.107,0.05-0.193,0.134-0.219,0.255c-0.297,0.094-0.613,0.102-0.92,0.089\n	c-0.484-0.02-0.971-0.1-1.457-0.067c-0.395,0.027-0.652-0.173-1.02-0.173c-1.102,0-1.891,0.12-2.416,1.186\n	c-0.232,0.472,0.006,0.898,0.07,1.376c0.064,0.496,0.049,1,0.111,1.499c0.148,1.192,0.156,2.387,0.23,3.584\n	c0.072,1.137,0.172,2.272,0.285,3.406c0.092,0.908-0.006,2.235,0.441,3.056c0.457,0.836,1.648,0.867,2.469,0.741\n	c0.268-0.04,0.924-0.094,1.018-0.409c0.131-0.444,0.92-0.512,1.311-0.641c1.002-0.333,1.848-0.795,2.775-1.285\n	c0.461-0.242,0.949-0.398,1.432-0.586c0.545-0.212,1.02-0.557,1.568-0.755c0.799-0.286,1.566-0.703,2.287-1.153\n	c0.305-0.19,0.592-0.411,0.92-0.559c0.428-0.194,0.676,0.082,1.064-0.008c0.404-0.092,0.822-0.375,1.199-0.541\n	c0.539-0.234,1.078-0.468,1.615-0.703c1.143-0.497,2.279-1.058,3.445-1.499c0.848-0.32,1.568,0.56,1.902,1.262\n	c0.139,0.29,0.043,0.561,0.449,0.634c0.588,0.107,1.162-0.33,1.654-0.585c0.418-0.217,0.854-0.203,1.291-0.349\n	c0.441-0.147,0.867-0.349,1.254-0.609c0.676-0.456,0.281-1.536,0.543-2.234c0.113-0.309,0.432-0.508,0.543-0.819\n	c0.096-0.266,0.154-0.384,0.396-0.578c0.641-0.505,1.318-0.773,2.113-0.955c0.82-0.187,1.75-0.314,2.592-0.356\n	c1.082-0.053,1.221,0.905,1.77,1.651c1.02,1.38,3.566,1.423,4.965,0.588c0.748-0.448,1.338-1.111,2.076-1.57\n	c0.311-0.191,0.533-0.55,0.848-0.702c0.072-0.036,0.779-0.417,0.715-0.434c0.738,0.188,1.605,0.141,2.369,0.14\n	c1.273-0.001,2.545-0.089,3.818-0.1c1.145-0.011,2.289-0.022,3.434-0.033c0.375-0.003,0.811-0.122,1.105,0.187\n	c0.416,0.435,0.809,0.894,1.33,1.209c0.764,0.462,1.656,0.545,2.527,0.59c1.234,0.066,2.457,0.049,3.682-0.098\n	c4.814-0.58,9.551-1.453,14.42-1.354c2.775,0.056,5.578,0.114,8.35-0.106c0.615-0.049,1.225-0.143,1.832-0.265\n	c0.623-0.126,1.387-0.158,1.965-0.434c0.537-0.662,1.617-0.003,1.58-1.122c-0.016-0.448,0.096-1.186-0.137-1.577\n	c-0.223-0.373,0.051-0.788,0.434-0.902c0.365-0.11,0.76-0.059,1.137-0.069c0.703-0.02,1.402-0.124,2.107-0.122\n	c2.926,0.011,5.854,0.022,8.781,0.033c-0.029-0.116-0.066-0.229-0.113-0.338c0.178,0,0.514,0.05,0.516-0.22\n	c0.004-0.467,0.025-0.875-0.174-1.309C108.434,11.898,108.449,11.932,108.467,11.969C108.203,11.401,108.467,11.969,108.467,11.969z\n	 M5.088,17.262L5.088,17.262 M42.172,18.163c-0.17-0.593,1.631-0.336,2.078-0.36c0.24-0.013,0.752-0.064,0.871,0.223\n	c0.107,0.259,0.117,0.839,0.014,1.095c-0.244,0.592-1.91,0.594-2.416,0.411C42.324,19.39,41.859,18.328,42.172,18.163\n	C42.057,17.766,42.172,18.163,42.172,18.163z\"/>\n<rect id=\"sliceCopy_x5F_54_1_\" x=\"112.592\" fill=\"none\" width=\"103.27\" height=\"40\"/>\n<rect id=\"sliceCopy_x5F_53_1_\" fill=\"none\" width=\"112.593\" height=\"40\"/>\n</svg>",
        [36]    = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 1.1//EN\" \"http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd\" [\n	<!ENTITY ns_flows \"http://ns.adobe.com/Flows/1.0/\">\n]>\n<svg version=\"1.1\"\n	 xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" xmlns:a=\"http://ns.adobe.com/AdobeSVGViewerExtensions/3.0/\"\n	 x=\"0px\" y=\"0px\" width=\"50px\" height=\"40px\" viewBox=\"0.566 0 50 40\" enable-background=\"new 0.566 0 50 40\" xml:space=\"preserve\">\n<defs>\n</defs>\n<path fill=\"#FFFFFF\" d=\"M46.436,8.843c-0.043-0.794-0.086-1.587-0.131-2.381c-0.029-0.54,0.066-1.193-0.457-1.521\n	c-0.615-0.342-1.129-0.253-1.838-0.25c-1.301,0.005-2.602,0.01-3.902,0.014c-2.701,0.01-5.402,0.02-8.104,0.03\n	c-0.203,0.001-0.406,0.001-0.608,0.002c-0.02,0,0.014,0.46-0.014,0.46c-0.129,0-0.258,0-0.386,0c-1.371,0-2.74,0-4.109,0\n	c-0.5,0-0.999,0-1.498,0c-0.24,0,0.078-0.46-0.139-0.46c-0.762,0-1.524,0-2.286,0c-3.116,0-6.233,0-9.351,0\n	c-0.778,0-1.556,0-2.333,0c-0.102,0-0.137-0.495-0.221-0.562c-0.123-0.099-0.613-0.061-0.766-0.077\n	c-0.166-0.016-0.612-0.146-0.767-0.077c-0.213,0.097-0.255,0.55-0.46,0.665c-0.479,0.269-1.21-0.124-1.712,0.127\n	c-0.5,0.25-0.987,0.906-1.302,1.354C5.498,6.957,4.588,8.147,4.435,9.12c-0.182,1.155-0.402,3.243,0.547,4.096\n	c0.854,0.769,2.12,0.867,3.068,1.467c1.068,0.673,1.262,1.242,0.983,2.445c-0.16,0.685-0.389,1.33-0.65,1.979\n	c-0.542,1.346-1.113,2.659-1.709,3.981c-0.743,1.648-1.292,3.315-1.8,5.041c-0.441,1.497-0.979,3.061-0.856,4.646\n	c0.062,0.807,0.8,0.721,1.454,0.852c1.389,0.276,2.777,0.556,4.166,0.832c2.536,0.508,5.071,1.015,7.605,1.522\n	c0.473,0.094,2.6-0.147,1.449-0.867c-0.281-0.176-1.184-0.527-1.205-0.867c-0.042-0.65-0.085-1.299-0.127-1.95\n	c-0.059-0.902-0.209-1.717,0.061-2.581c0.525-1.688,1.155-3.345,1.767-5c0.151-0.413,1.155-3.689,1.403-3.683\n	c0.402,0.012,0.806,0.024,1.209,0.036c1.541,0.045,3.081,0.091,4.622,0.136c2.031,0.059,4.083-0.154,6.086-0.487\n	c0.434-0.073,1.516-0.053,1.414-0.687c-0.08-0.502-0.168-1.003-0.225-1.509c-0.086-0.786-0.211-1.582-0.203-2.376\n	c0.008-1.026,0.576-1.373,1.504-1.585c0.76-0.175,1.701-0.04,2.475-0.051c1.627-0.024,3.256-0.048,4.885-0.072\n	c1.027-0.015,2.057-0.031,3.086-0.046c1.01-0.014,0.969-1.587,0.979-2.25C46.436,11.045,46.496,9.939,46.436,8.843z M32.582,18.252\n	c-0.031,0.516,0.094,1.227-0.477,1.504c-0.39,0.191-1.087,0.086-1.509,0.058c-1.131-0.077-2.219-0.12-3.347,0.008\n	c-1.347,0.153-4.798,0.486-4.798-1.492c0-0.892-0.104-1.819,0.51-2.559c0.66-0.711,1.421-0.664,2.298-0.616\n	c0.146,0.007,0.228,1.491,0.253,1.71c0.08,0.681,1.198,1.454,1.75,1.777c0.549,0.319,1.051,0.699,1.728,0.472\n	c0.709-0.239-0.407-0.511-0.527-0.55c-0.348-0.111-0.625-0.292-0.837-0.58c-0.42-0.565-1.074-1.205-1.166-1.934\n	c-0.122-0.97,0.112-0.893,0.864-0.885c1.254,0.015,2.506,0.028,3.76,0.042c0.121-0.328,0.992,0.432,1.123,0.615\n	C32.629,16.542,32.635,17.445,32.582,18.252z\"/>\n<rect id=\"sliceCopy_x5F_25_1_\" x=\"50.462\" fill=\"none\" width=\"50.022\" height=\"40\"/>\n<rect id=\"sliceCopy_x5F_24_1_\" fill=\"none\" width=\"50.463\" height=\"40\"/>\n</svg>",
        [38]    = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 1.1//EN\" \"http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd\" [\n	<!ENTITY ns_flows \"http://ns.adobe.com/Flows/1.0/\">\n]>\n<svg version=\"1.1\"\n	 xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" xmlns:a=\"http://ns.adobe.com/AdobeSVGViewerExtensions/3.0/\"\n	 x=\"0px\" y=\"0px\" width=\"113px\" height=\"40px\" viewBox=\"0.565 0 113 40\" enable-background=\"new 0.565 0 113 40\"\n	 xml:space=\"preserve\">\n<defs>\n</defs>\n<path fill=\"#FFFFFF\" d=\"M67.317,20.894c-0.037-0.009-0.064-0.017-0.084-0.022C67.263,20.878,67.286,20.885,67.317,20.894z M67.931,20.871\n	c-0.027,0.007-0.051,0.015-0.084,0.022C67.886,20.885,67.911,20.877,67.931,20.871z M109.155,19.066\n	c-0.352,0.696-2.316,0.325-3.229,0.325c-1,0-6.762-0.398-6.795,0.365c-0.434-0.27-0.572-0.287-1.137-0.244\n	c-0.514,0.04-0.512,0.223-1.135,0.284c0.266-1.15-3.184-0.568-3.912-0.568c-1.879,0-4.188,0.335-5.988-0.081\n	c-0.355,0.846-5.551,0.27-6.557,0.267c-2.807-0.008-5.611-0.015-8.418-0.022c-0.074,0.612,0.166,1.317-0.203,1.582\n	c-0.01-0.036,0.004-0.063,0.041-0.082c-0.252,0.071-0.893,0.188-0.893-0.102c0-0.709-0.977,0.148-0.771,0.143\n	c-0.445,0.011-0.371-0.208-0.893-0.324c0.332,0.074-0.672,0-0.563,0c-0.535,0-0.371,0.155-0.773,0.263\n	c0.238-0.087-0.936-0.087-0.697,0c-0.4-0.109-0.236-0.263-0.771-0.263c0.113,0-0.861,0.078-0.523,0\n	c-0.064,0.015-0.9,0.274-0.488,0.365c-0.547-0.12-0.178-0.365-0.816-0.365c-0.033,0-0.521,0.625-0.521,0.143\n	c0-0.307-0.582-0.004-0.865,0.107c0.029-0.065-1.146-0.053-0.676,0.035c-0.559-0.104-0.396-0.18-1.014-0.285\n	c0.025,0.005-1.301,0.288-1.301,0.143c0-0.039-2.84-0.021-2.84,0c0-0.498-1.947,0.7-1.947,0c0-0.271-0.721,0.174-0.975,0.263\n	c-0.662,0.234-1.254,0.269-1.502,0.894c-0.102,0.253-0.057,1.14,0,1.462c0.045,0.254,0.359,0.624,0.365,0.729\n	c0.029,0.572,0.018,0.975-0.486,0.975c-0.303,0-0.162,0.813-0.162,1.096c0,0.906,0,1.813,0,2.72c0,1.59-0.277,3.685,0.08,5.112\n	c-2.381,0-4.76,0-7.141,0c-0.439,0-0.486-1.551-0.486-2.07c0-0.815,0.256-5.518-0.305-5.518c-0.379,0-0.574,0.322-0.809,0.325\n	c-1.543,0.013-3.086,0.023-4.631,0.036c-0.652,0.005-1.154,0.373-1.318,0.977c-0.037,0.14-0.008,0.461-0.041,0.528\n	c-0.023,0.05,0.178,0.446,0.082,0.608c-0.084,0.144-0.609,0.045-0.771,0.203c-0.25,0.246-0.357,0.591-0.527,0.892\n	c-0.291,0.523-0.732,1.218-0.973,1.786c1.074,1.871-2.852,0.546-3.611,0.324c-0.963-0.28-1.592-0.173-1.338-1.136\n	c0.1-0.381,0.477-0.651,0.689-0.975c1.068-1.62,1.861-2.974,2.881-4.504c0.516-0.774,1.299-1.503,0.648-2.435\n	c-0.736-1.056-2.58-0.667-3.795-0.68c-1.098-0.012-1.834-0.471-3.014-0.451c-1.398,0.021-2.42-0.093-3.416,0.563\n	c-0.324,0.214-0.604,0.554-0.893,0.852c-0.781,0.807-0.896,0.948-1.176,2.028c-0.395,1.516-2.227,0.854-3.852,0.854\n	c-1.461,0-2.924,0-4.385,0c-1.113,0-3.482,0.407-4.506,0c-0.203-0.081-0.309-0.486-0.527-0.65c-0.277-0.204,0.35-0.323-0.363-0.323\n	c-0.545,0-1.699-0.189-1.951,0.162c-0.197,0.273,0,1.432,0,1.784c0,1.307-0.238,1.063-1.543,1.015\n	c0.092,0.529-0.104,0.896-0.729,0.731c0.027,0.026,0.053,0.054,0.08,0.081c-1.656,0.548-0.648-2.093-0.648-2.678\n	c0-1.421,0-2.841,0-4.261c0-1.238-0.064-2.46-0.123-3.612c-0.02-0.417-0.121-1.001-0.121-1.278c0-0.345-0.422-0.831,0.029-0.831\n	c0.463,0,1.83-0.151,1.393,0.405c0.973,0.115,1.391-0.186,1.662,0.568c0.146,0.403,0,1.128,0,1.563c0,0.473,0,0.946,0,1.419\n	c0,0.003,2.557,0.573,2.557-0.263c0-1.594,3.76,0.5,3.977-0.975c0.117-0.796-0.188-0.649-0.928-0.649\n	c-1.17,0-2.287,0.335-2.604-0.608c-0.287-0.863-0.234-4.003,0.285-4.382c0.342-0.25,1.041-0.163,1.537-0.163c1.73,0,3.459,0,5.189,0\n	c2.037,0,4.264-0.164,6.236-0.07c1.129,0.054,3.521-0.488,3.148,0.923c-0.123,0.459-0.734,0.992-1.016,1.339\n	c-0.484,0.597-1.035,1.464-1.664,1.988c-0.332,0.279-0.848,0.759-1.258,0.893c-1.045,0.344-4.592-0.728-4.748,0.569\n	c-0.148,1.222,3.82,0.608,4.881,0.608c0.391,0,0.756-0.553,0.963-0.771c0.732-0.773,2.371-3.651,3.477-3.651\n	c0.98,0,2.336,0.229,2.934-0.325c0.191-0.177,0.047-0.693,0.244-0.853c0.281-0.226,0.965-0.08,1.295-0.08\n	c0.74,0,1.127-0.488,0.234-0.488c-0.096,0-1.18,0.12-1.285,0c-0.301-0.345-0.006-0.771,0.342-0.771c0.822,0,1.795-0.171,2.457-0.202\n	c0.398-0.019,0.711,0.02,1.016,0.122c0.348,0.117-0.123,0.405,0.725,0.405c0.523,0,1.592-0.155,1.953,0.081\n	c0.152,0.1-0.037,0.706,0.082,0.771c0.766,0.418,2.77,0.04,3.711,0.04c0,0,0.227-2.518,0.063-2.759\n	c-0.555-0.826-1.162,0.246-1.82,0.243c-2.299-0.015-4.973,0.292-7.168-0.021c-0.428-0.06-0.225-1.861-0.225-2.332\n	c0-0.198-0.125-1.082,0-1.217c0.268-0.288,2.867,0.053,3.213,0.056c1.813,0.011,3.613,0.077,5.188,0.309\n	c0.311,0.046,0.811,0.575,0.811-0.243c0-0.734,2.023-0.365,2.635-0.365c0.799,0-0.215,0.771,0.705,0.771\n	c0.506,0,1.205,0.132,1.693,0c0.26-0.069-0.217-0.691,0.648-0.487c-0.172-0.44-0.148-0.883,0.324-0.851\n	C46.907,6.105,47.196,6,47.921,6c1.254,0,0.678,0.151,0.975,1.015c0.314,0.919,1.357,1.499,2.477,0.975\n	c0.195-0.094-0.35-0.487,0.275-0.487c0.705,0,1.408,0,2.113,0c0.928,0,0.035,0.689,1.211,0.689c1.207,0,1.982-0.174,3.055-0.447\n	c1.322-0.337,2.668-0.622,4.018-0.892c1.227-0.246,1.674-0.165,3.232-0.176c1.385-0.008,2.768-0.019,4.152-0.027\n	c0.805-0.006,0.51,0.107,0.648,0.73c0.199,0.888,0,2.05,0,2.963c0,0.472,0,0.946,0,1.42c0,0.863-0.504,0.567-1.299,0.567\n	c-2.088,0-4.455,0.311-6.492-0.122c-0.682-0.144-1.467-0.487-2.148-0.648c-0.758-0.179-1.561-0.43-2.232-0.568\n	c-0.82-0.172-1.633-0.122-2.475-0.122c-1.258,0-0.973-0.181-1.178,0.69c-0.184,0.78-0.297,2.232,0.51,2.232c3.084,0,6.17,0,9.254,0\n	c1.904,0,3.809,0,5.713,0c0.852,0,0.348-0.132,0.551-0.73c0.127-0.378-0.1-0.599,0.162-0.854c0.332-0.323,1.957-0.081,2.51-0.081\n	c0.49,0,0.871,0.135,1.223,0.447c-0.078-1.018,1.133-0.33,1.381,0c0.533,0.703-0.141,1.218,1.271,1.218c1.906,0,3.77,0,5.686,0\n	c1.242,0,2.486,0,3.732,0c0.424,0,1.295,0.5,0.387,0.689c0.455,0.444,0.287,0.986,0.287,1.847c0,1.374-0.02,1.277,1.469,1.277\n	c2.689,0,5.379,0,8.07,0c0.68,0,0.121-0.406,0.727-0.406c0.154,0,0.988,0.91,1.055,0c0.1,0.099,0.395,0.198,0.527,0.366\n	c0.025-0.121,0.002-0.281,0-0.406c1.238,0.646,3.615,0.406,5.461,0.406c0.463,0,0.818,0,1.742,0c0.709,0,3.016-0.354,3.186,0.284\n	C109.155,18.142,109.284,18.811,109.155,19.066z M9.819,21.947c0-0.793,0.027-0.73-0.855-0.73c-0.566,0-1.41-0.125-1.701,0.163\n	c0,0.748-0.125,1.616,0,2.353c0.129,0.761-0.254,0.853,0.732,0.853c0.74,0,1.432,0.075,1.824-0.244\n	C9.71,23.648,9.819,22.729,9.819,21.947z M44.716,24.746c0.008-1.67-1.387-1.992-2.719-1.014c-0.859,0.63-0.803,1.414-0.527,2.354\n	c-1.658,0.136-0.199-3.137-1.582-2.719c-0.314,0.737-0.502,2.344,0.445,2.8c0.756,0.364,3.41,0.377,4.018-0.121\n	C44.743,25.725,44.714,25.354,44.716,24.746z M51.372,10.869c-0.531-0.528-2.666,0.39-2.68,0.568\n	c-0.541-0.012-1.082-0.026-1.623-0.041c-0.063-0.349-2.51-1.034-3.002-0.527c-0.234,0.24-0.041,1.283-0.082,1.705\n	c2.461,0.01,4.924,0.026,7.387,0.04C51.372,12.335,51.548,11.046,51.372,10.869z M74.175,13.548c-0.613,0-1.43-0.197-1.662,0.244\n	c0.555,0,1.107,0,1.662,0C74.175,13.71,74.175,13.629,74.175,13.548z M63.247,20.858c-0.045,0.017-0.084,0.029-0.109,0.035\n	C63.21,20.879,63.241,20.868,63.247,20.858z\"/>\n<rect id=\"sliceCopy_x5F_51_1_\" x=\"113.213\" fill=\"none\" width=\"135.832\" height=\"40\"/>\n<rect id=\"sliceCopy_x5F_50_1_\" fill=\"none\" width=\"113.213\" height=\"40\"/>\n</svg>",
        [39]    = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 1.1//EN\" \"http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd\" [\n	<!ENTITY ns_flows \"http://ns.adobe.com/Flows/1.0/\">\n]>\n<svg version=\"1.1\"\n	 xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" xmlns:a=\"http://ns.adobe.com/AdobeSVGViewerExtensions/3.0/\"\n	 x=\"0px\" y=\"0px\" width=\"105px\" height=\"40px\" viewBox=\"0.572 0 105 40\" enable-background=\"new 0.572 0 105 40\"\n	 xml:space=\"preserve\">\n<defs>\n</defs>\n<path fill=\"#FFFFFF\" d=\"M32.818,4.705c0.49-0.443,0.162-0.798,0.393-1.326c0.115-0.262,0.879-0.505,1.102-0.306c0.436,0.388-0.383,1.851,0.332,1.96\n	c0.34,0.052,0.961,0.224,0.912-0.235c-0.027-0.265,0.59-0.088,0.689,0.074c0.217,0.345,0.455,0.306,0.426-0.132\n	c-0.035-0.532,0.225-0.46,0.717-0.438c0.168,0.008,0.949-0.102,0.977,0.023c0.029,0.125-0.09,0.708,0.059,0.756\n	c0.508,0.167,1.307,0.016,1.842,0.016c0.822,0,1.646,0,2.469,0c0.096,0,0.658,0.08,0.697-0.062c0.035-0.122-0.119-0.324-0.014-0.429\n	c0.188-0.188,0.82-0.042,1.051-0.021c0.523,0.048,1.055,0.021,1.576,0.021c0.785,0,0.639,0.02,0.711-0.625\n	c0.016-0.129,0.643-0.148,0.678,0.078c0.049,0.324-0.104,0.786,0.385,0.651c0.305-0.083,0.145,0.933,0.086,1.089\n	c-0.197,0.533-0.557,1.094-0.816,1.606c-0.15,0.298-1.309,2.499-0.801,2.472c0.178-0.01,1.363-0.097,1.365,0.049\n	c0.004,0.665,0.908,0.372,1.467,0.372c1.238,0,2.521,0.097,3.754-0.019c0.396-0.036,0.807-0.1,1.205-0.054\n	c0.572,0.064-0.084,0.515,0.662,0.515c3.105,0,6.213,0,9.318,0c5.125,0,10.248,0,15.373,0c1.064,0,2.131-0.098,3.193-0.003\n	c0.164,0.014,0.844,0.344,0.844,0.171c0-0.332,0.344-0.089,0.344-0.315c0-0.675,0-1.35,0-2.025c0-0.334-0.217-2.933,0.039-3.051\n	C84,5.45,85.018,5.406,85.037,5.656c0.035,0.48,0.338,0.072,0.445,0.365c0.084,0.23-0.014,0.537-0.018,0.775\n	c-0.004,0.322,0.154,0.172,0.311,0.368c0.221,0.277,0.186,0.769,0.182,1.099c-0.008,0.549-0.209,1.354-0.027,1.879\n	c0.104,0.302,0.498,0.081,0.721,0.195c0.236,0.124,0.158,0.625,0.162,0.833c0.018,0.975,2.082-0.174,2.307,0.532\n	c0.02,0.063,0.135,0.709,0.002,0.709c-0.301,0-0.598,0-0.898,0c-0.023,0-0.111,0.348-0.141,0.393c0.164,0,0.9-0.108,0.988,0.08\n	c0.117,0.257,0.004,0.578-0.27,0.631c-0.248,0.047-1.998-0.117-2.004,0.05c-0.004,0.087,8.428,0.072,9.238,0.072\n	c0.209,0,0.229-0.127,0.25-0.289c0.018-0.122,0.629-0.054,0.711-0.054c0.414,0,0.826,0.002,1.24-0.002\n	c0.766-0.01,1.533-0.023,2.299-0.007c0.193,0.003,0.453-0.025,0.637,0.045c0.117,0.046,0.016,1.641,0.016,1.833\n	c0,0.12,0.199,1.069,0.033,1.097c-0.566,0.095-1.146,0.028-1.717,0.028c-1.463,0-2.945-0.066-4.404,0.036\n	c-0.721,0.051-0.266-0.478-0.631-0.478c-0.906,0-1.811,0-2.717,0c-1.553,0-3.105,0-4.658,0c-0.227,0-0.553-0.055-0.787-0.018\n	c-0.201,0.033-0.109,0.309-0.162,0.437c-0.164,0.404-0.432,0.202-0.615,0.464c-0.26,0.372,0.303,2.34-0.162,2.361\n	c-0.348,0.017-0.691-0.061-1.035-0.086c-0.59-0.045-0.52-0.297-0.52-0.809c0-0.454,0.162-0.902,0.135-1.364\n	c-0.014-0.219-0.113-0.186-0.287-0.162c-0.24,0.034-0.146-0.159-0.26-0.299c-0.529-0.662-0.367,1.66-0.619,1.64\n	c-0.424-0.034-0.639,0.086-0.734,0.534c-0.131,0.581,0.168,0.718-0.525,0.924c-0.365,0.108-0.063,0.302-0.67,0.302\n	c-0.666,0-1.346-0.051-2.016-0.052c-3.197-0.008-6.393-0.016-9.59-0.023c-1.51-0.004-3.02-0.008-4.529-0.012\n	c-0.754-0.001-1.504-0.002-2.256-0.005c-0.48-0.001-2.068-0.205-2.275,0.129c-0.129,0.207-0.666,0.088-0.814-0.038\n	c-0.08-0.064-0.076-0.392-0.205-0.392c-0.357-0.002-0.719-0.004-1.078-0.007c-1.438-0.01-2.863-0.071-4.299-0.116\n	c-1.23-0.038-2.24,0.152-3.281,0.818c-0.48,0.308-0.674,0.595-0.637,1.18c0.012,0.158-0.051,0.583,0.025,0.727\n	c0.113,0.217,0.191-0.011,0.328,0.043c0.275,0.109,0.008,0.667-0.264,0.667c-0.465-0.003-0.463,0.145-0.455,0.614\n	c0.021,1.098,0.146,2.224,0.254,3.317c0.041,0.406,0.242,0.618,0.363,0.978c0.135,0.398,0.166,0.823,0.291,1.224\n	c0.346,1.125,0.783,2.214,1.148,3.317c0.166,0.5,0.303,1.073,0.59,1.522c0.209,0.332,0.447,0.579,0.248,1.02\n	c-0.16,0.354-1.023,0.452-1.352,0.568c-0.758,0.269-1.521,0.513-2.283,0.767C47.58,36.413,46.332,37,45.07,37\n	c-0.723,0-0.766-2.128-1.006-2.625c-0.486-1.001-0.744-2.358-0.977-3.458C42.9,30.02,42.533,29.22,42.367,28.3\n	c-0.207-1.161-0.381-2.392-0.668-3.527c-0.221-0.868,0.004-0.969-0.869-1.016c-1.563-0.085-3.135-0.045-4.699-0.025\n	c-0.463,0.005-0.928,0.018-1.391,0.018c-0.504,0-0.744-0.125-0.988,0.317c-0.174,0.313-0.594,0.934-0.594,1.278\n	c0,0.285-0.412,0.792-0.533,1.071c-0.205,0.465-0.58,0.914-0.857,1.337c-0.652,0.996-0.855,1.867-1.029,3.007\n	c-0.125,0.814-2.238-0.365-2.666-0.552c-1.178-0.515-2.475-0.928-3.605-1.528c-1.711-0.907,2.068-4.806,2.746-5.494\n	c0.639-0.65,1.299-1.645,0.99-2.61c-0.299-0.938-1.889-1.245-2.748-1.245c-0.037-0.01-0.074-0.02-0.111-0.03\n	c-0.025-0.247-0.236-0.125-0.236-0.363c0-0.466,0-0.933,0-1.399c0-0.486-0.111-0.514-0.543-0.348\n	c-0.508,0.196-0.348,0.517-0.334,1.037c0.027,0.979,0.326,1.527-0.775,1.573c-0.598,0.024-1.199-0.01-1.795-0.032\n	c-0.262-0.01-0.568-0.054-0.824,0.014c-0.1,0.026-0.145,0.9-0.145,1.047c0,0.332-1.701,0.266-1.996,0.266\n	c-0.141,0-0.197,0.443-0.213,0.541c-0.064,0.401-0.057,0.479-0.49,0.54c-0.277,0.04-0.563,0.054-0.842,0.055\n	c-0.494,0-0.385-0.163-0.385-0.593c-0.553,0.504-1.283,0.693-1.826,1.215c-0.479,0.461-1.02,0.673-1.42,1.234\n	c-0.201,0.278-0.988,0.303-1.299,0.18c-0.379-0.147-0.168-1.516-0.168-1.795c-0.777-0.006-1.686,1.171-2.148,1.669\n	c-0.896,0.957-1.939,1.926-2.42,3.17c-0.176,0.451-0.082,0.736-0.635,0.76c-0.42,0.019-0.98,0.121-1.373-0.079\n	c-0.303-0.153-0.129-0.747-0.205-1.01c-0.111-0.39-0.248-0.72-0.279-1.146c-0.133-1.823-0.471-3.679-0.674-5.506\n	c-0.127-1.151-0.209-2.306-0.291-3.463c-0.094-1.285,0.074-2.553,0.156-3.832c0.014-0.223-0.133-0.933,0.121-1.044\n	c0.406-0.18,0.938,0.01,1.357,0.024c0.357,0.012,0.199,0.48,0.223,0.698c0.049,0.437,1.018,0.237,1.305,0.237\n	c1.625,0,3.252,0,4.877,0c3.236,0,6.477,0,9.715,0c1.338,0,2.893,0.224,4.203-0.057c1.023-0.218,1.527-1.44,2.416-1.882\n	c0.318-0.159,0.365-0.204,0.443-0.54c0.076-0.316,0.57-0.249,0.811-0.242c1.172,0.034,2.334,0.069,3.508,0.069\n	c1.029,0,2.061,0.033,3.088,0.022c0.592-0.007,0.445-0.086,0.396-0.611c-0.018-0.189,0.063-0.398,0.016-0.583\n	c-0.031-0.122-0.305-0.25-0.363-0.097c-0.15,0.377,0.221,0.484-0.389,0.484c-0.236,0-0.533-0.108-0.453-0.445\n	c0.037-0.162-1.188-0.095-1.346-0.095c-0.854,0-0.213,0.298-0.717,0.511c-0.93,0.395-0.699-0.824-0.678-1.363\n	C32.762,6.993,32.539,5.817,32.818,4.705 M40.277,20.361c-0.525-0.533-1.898-0.099-2.555-0.099c-1.301,0-0.797,1.615-0.775,2.507\n	c0.016,0.52,1.084,0.291,1.416,0.291c0.352,0,0.703,0,1.057,0c0.695,0,0.104-0.04,0.367-0.294c0.379-0.366,1.293-0.642,1.342-1.244\n	C41.17,21.033,40.668,20.571,40.277,20.361 M35.027,20.999c-0.414-0.658-0.447,0.586-0.447,0.77\n	c-0.004,0.906,0.623,1.292,1.477,1.292c0-0.244-0.418-0.59-0.504-0.872C35.426,21.767,35.148,21.414,35.027,20.999\"/>\n<rect id=\"sliceCopy_x5F_48_1_\" x=\"105.287\" fill=\"none\" width=\"99.902\" height=\"40\"/>\n<rect id=\"sliceCopy_x5F_47_1_\" fill=\"none\" width=\"105.287\" height=\"40\"/>\n</svg>",
        [40]    = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 1.1//EN\" \"http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd\" [\n	<!ENTITY ns_flows \"http://ns.adobe.com/Flows/1.0/\">\n]>\n<svg version=\"1.1\"\n	 xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" xmlns:a=\"http://ns.adobe.com/AdobeSVGViewerExtensions/3.0/\"\n	 x=\"0px\" y=\"0px\" width=\"125px\" height=\"40px\" viewBox=\"0.521 0 125 40\" enable-background=\"new 0.521 0 125 40\"\n	 xml:space=\"preserve\">\n<defs>\n</defs>\n<path fill=\"#FFFFFF\" d=\"M121.221,13.454c0.01-0.37-0.152-0.347-0.811-0.347c-1.818,0-5.217,0-7.037,0c-6.291,0-12.582,0-18.873,0\n	c-6.982,0-13.961,0-20.943,0c-0.775,0-1.551,0-2.326,0c-0.529,0-0.453,0.003-0.453-0.55c0-1.012,0-2.024,0-3.035\n	c0-0.491,0-0.982,0-1.474c0-0.507,0.469-0.802-0.352-1.055c-0.959-0.295-2.402,0.006-3.387,0c-0.65-0.006-2.354-0.33-2.857,0.175\n	C63.813,7.54,63.135,7.8,62.643,8.048c-0.715,0.36-1.596,0.616-2.357,0.616c-2.922,0-5.846,0-8.77,0\n	c0.191-0.785,0.045-1.548,0.045-2.265c0-0.302,0.213-0.848,0.088-1.077c-0.303-0.559-2.525-0.22-3.035-0.22\n	c-0.701,0.046-0.527,1.417-0.527,1.956c0,0.396,0,0.792,0,1.188c0,0.218,0.088,0.417-0.158,0.417c-0.645,0-1.285,0-1.926,0\n	c-1.715,0-3.432,0-5.146,0c-0.41,0-0.244-0.561-0.244-0.923c0-0.296,0.115-0.938-0.045-1.187c-0.369-0.571-2.283-0.22-2.918-0.22\n	c-0.871,0-0.09,1.704-0.336,2.154c-0.318,0.586-2.572-0.007-3.254,0.22c-0.461,0.154-0.813,0.414-0.836,0.968\n	c-0.027,0.656-0.178,2.056,0.045,2.683c0.283,0.799,1.754,0.383,2.549,0.439c1.076,0.075,2.395,0.088,3.564,0.088\n	c0.713,0,1.428,0,2.145,0c0.105,0,0.066,0.202,0.01,0.265c-0.092,0.096-0.613,0.059-0.723,0.064\n	c-0.975,0.041-1.869,0.051-2.754,0.419c-0.588,0.245-1.371,0.886-2.021,1.319c-0.73,0.485-1.621,0.902-2.465,1.275\n	c-0.795,0.351-1.582,0.683-2.373,0.967c-0.67,0.24-1.379,0.396-2.17,0.396c-0.537,0-2.809,0.415-3.107,0\n	c-0.162-0.226,0.234-0.501,0.309-0.703c0.059-0.165,0.043-0.471,0.043-0.704c0-0.408,0.176-1.08,0.131-1.408\n	c-0.096-0.719-0.611-0.879-1.252-0.879c-1.564,0-3.129,0-4.695,0c-1.93,0-3.859,0-5.791,0c-0.682,0-1.965-0.226-2.553,0.044\n	c-0.527,0.241-0.504,0.835-0.572,1.319c-0.031,0.219-0.188,0.547-0.066,0.792c0.135,0.265,0.428,0.393,0.506,0.66\n	c-0.721-0.03-1.6-0.221-2.287-0.176c-0.182,0.012-0.352,0.176-0.547,0.176c-0.322,0-0.646,0-0.969,0c-1.008,0-2.018,0-3.027,0\n	c-0.225,0-0.82-0.026-0.996,0.176c-0.283,0.327-0.09,1.413-0.09,1.847c0,0.593,0,1.188,0,1.781c0,2.053,0,4.105,0,6.156\n	c0,1.027,0,2.053,0,3.079c0,0.942,0.355,1.158,1.275,1.121c1.334-0.055,2.668-0.06,4.002-0.087\n	c-0.227,0.968,3.959,1.164,3.959-0.027c0-0.517-0.303-0.695-0.352-1.206c-0.027-0.288,0-0.59,0-0.879\n	c0-0.631,0.033-0.625,0.703-0.615c0.367,0.006,0.439,0.088,0.807-0.066c3.143-1.319,6.283-2.639,9.426-3.958\n	c0.393-0.166,0.785-0.33,1.178-0.496c0.344-0.144,0.311-0.399,0.756-0.548c0.279-0.093,1.789-0.09,1.883,0.099\n	c0.271,0.543,1.166-0.46,1.166-0.795c0-0.42,0.158-0.917,0.484-1.228c0.246-0.235,0.361-0.263,0.764-0.263\n	c0.373,0,0.285-0.035,0.865,0.088c0.508,0.106,1.131,0.043,1.674,0.043c0.219,0,0.639,1.275,0.568,1.627\n	c-0.072,0.352-0.529,0.625-0.529,1.011c0,0.121-0.418,0.866-0.57,0.945c-0.268,0.136-0.564,0.833-0.703,1.077\n	c-0.178,0.308-0.541,0.62-0.66,0.924c-0.154,0.393-0.131,0.941-0.131,1.385c0,0.538-0.656,1.109-0.406,1.685\n	c0.445,1.037,2.363,1.33,3.328,1.715c0.49,0.194,1.496-0.182,1.992-0.258c0.283-0.042,1.09-0.33,1.154-0.546\n	c0.184-0.641-0.111-1.586-0.184-2.239c-0.082-0.734,0.021-0.952,0.344-1.642c0.24-0.518,0.424-0.907,0.631-1.375\n	c0.146-0.331,0.525-0.728,0.527-1.099c0.137,0.05,0.289,0.087,0.436,0.087c5.582,0,11.258-0.044,16.768-0.044\n	c0.221,0,0.824-1.212,0.959-1.407c0.352-0.505,0.801-1.023,1.078-1.584c0.26-0.524,0.787-1.096,1.166-1.54\n	c0.357-0.42,0.543-0.835,1.059-0.833c6.443,0.01,12.885,0.019,19.324,0.03c2.582,0.004,5.164,0.008,7.746,0.012\n	c0.49,0,0.338,0.414,0.369,0.837c0.029,0.416,0.211,1.25,0.836,1.055c0,0.868-0.176,1.998,0.043,2.814\n	c-0.951,0-0.967,0.212-0.969,1.011c-0.002,0.946,0.178,1.1,1.189,1.1c-0.059,0.233-0.045,0.463-0.045,0.704\n	c0,0.139-0.721,0.132-0.924,0.285c-0.34,0.256-0.221,0.848-0.221,1.254c0,0.635-0.141,0.916,0.529,1.013\n	c0.855,0.121,1.918-0.071,2.814-0.09c-0.357,0.505,0.996,2.593,1.143,3.211c-0.738,0.021-0.871,2.128-0.594,2.682\n	c0.225,0.447,1.787,0.176,2.186,0.176c0.447,0,0.574,0.007,0.826-0.309c0.205-0.255,0.664-1.112,0.264-1.319\n	c0.307-0.569-0.146-0.846-0.439-1.23c-0.258-0.341-0.42-0.833-0.615-1.275c-0.26-0.591-0.686-2.438-1.363-2.552\n	c0.059-0.191,0.131-0.755,0.131-0.989c0-0.222-0.098-0.389-0.219-0.571c-0.225-0.337-0.176-0.701-0.176-1.188\n	c0-0.533,0-1.069,0-1.604c0-0.303,0.146-0.921,0.064-1.166c-0.074-0.229,0.199-0.82,0.199-1.188c0-1.029,0.131-1.923,0.131-3.015\n	c0-0.87-0.111-1.796-0.043-2.636c5.604,0.018,11.207,0.036,16.811,0.052c3.227,0.011,6.455,0.021,9.684,0.03\n	c0.574,0.003,1.152,0.01,1.729,0.006c1.129-0.007,1.33,0.142,1.33-0.271C121.221,15.218,121.211,13.899,121.221,13.454z\n	 M18.049,23.572c-0.061,0.325-1.047,0.792-1.318,0.792c-0.316,0-0.42,0.277-0.703,0.351c-0.131,0.033-1.121,0.015-1.275-0.175\n	c-0.139-0.172-0.002-1.125,0.088-1.275c0.338-0.33,1.813-0.088,2.316-0.088C17.623,23.176,18.164,22.967,18.049,23.572z\n	 M38.279,21.726c-0.043-0.453,0.377-0.686,0.658-0.925c0,0.575-0.176,1.258,0.398,1.584C38.861,22.565,38.328,22.229,38.279,21.726z\n	 M40.963,22.385c0.025-0.35-0.309-0.332-0.309-0.64c0-0.225,0-0.452,0-0.679c-0.189-0.772,2.123-0.432,2.639-0.44\n	C43.035,21.789,42.074,22.302,40.963,22.385z\"/>\n<rect id=\"sliceCopy_x5F_53_1_\" x=\"125.222\" fill=\"none\" width=\"112.593\" height=\"40\"/>\n<rect id=\"sliceCopy_x5F_52_1_\" fill=\"none\" width=\"125.222\" height=\"40\"/>\n</svg>",
        [42]    = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 1.1//EN\" \"http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd\" [\n	<!ENTITY ns_flows \"http://ns.adobe.com/Flows/1.0/\">\n]>\n<svg version=\"1.1\"\n	 xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" xmlns:a=\"http://ns.adobe.com/AdobeSVGViewerExtensions/3.0/\"\n	 x=\"0px\" y=\"0px\" width=\"88px\" height=\"40px\" viewBox=\"0.771 0 88 40\" enable-background=\"new 0.771 0 88 40\" xml:space=\"preserve\">\n<defs>\n</defs>\n<path fill=\"#FFFFFF\" d=\"M79.674,17.957c-1.666-0.476-3.418-0.873-5.145-1.038c-2.676-0.256-5.332-0.59-8.021-0.59c-3.211,0-6.424,0-9.637,0\n	c-0.186,0.782-0.553,0.829-0.709,0c-0.023,0-0.045,0-0.066,0c-0.117,0.833-0.561,0.792-0.711,0c-0.389-0.27-0.6,0.679-1.066,0.679\n	c-0.461,0-0.689-0.952-1.066-0.679c-0.121,0.833-0.563,0.792-0.713,0c-0.021,0-0.043,0-0.064,0c-0.025,0.182-0.08,0.679-0.355,0.679\n	c-0.232,0-0.322-0.533-0.357-0.679c-0.389-0.263-0.619,0.802-1.184,0.666c-0.301-0.072-0.834-1.16-0.986-0.458\n	c-0.178,0.814-0.553,0.307-0.676-0.208c-0.221,0.18-0.389,1.096-0.646,0.377c-0.07-0.198-0.115-0.564-0.451-0.377\n	c-0.113,0.263-0.291,0.591-0.594,0.666c-0.354,0.085-0.625-0.205-0.775-0.485c-0.084-0.153-0.334-0.324-0.455-0.094\n	c-0.049,0.094-0.215,0.564-0.311,0.593c-0.254,0-0.324-0.515-0.355-0.679c-0.021,0-0.043,0-0.064,0\n	c-0.053,0.357-0.373,1.056-0.615,0.377c-0.158-0.445-0.09-0.377-0.551-0.377c-0.686,0-1.373,0-2.061,0\n	c-0.502,0-0.803,0.488-1.328,0.341c-0.285-0.08-0.545-0.156-0.814-0.276c-0.293-0.131-0.293-0.097-0.275-0.406\n	c0.033-0.533-0.002-1.094,0.172-1.602c0.225-0.659,0.451-1.318,0.676-1.977c0.08-0.23,0.066-1.163-0.145-1.208\n	c-0.563-0.123-1.125-0.246-1.688-0.369c-0.332,1.654-0.832,3.468-2.396,4.351c-0.854,0.481-1.865,0.841-2.854,0.808\n	c-3.459-0.119-6.92-0.239-10.381-0.358c-2.635-0.091-5.316,0.196-7.949,0.308c-1.492,0.064-2.994,0.282-4.48,0.423\n	c-0.629,0.06-1.02-0.482-1.596-0.695c-0.816-0.302-2.094-0.319-2.818,0.235c-0.56,0.428-1.089,0.945-1.327,1.62\n	c-0.117,0.336-0.189,0.688-0.236,1.04c-0.035,0.25-0.008,0.737-0.143,0.871c-0.574,0-0.594,1.331-0.115,1.478\n	c-0.064-0.02,0.18,0.022,0.176,0.015c0.012,0.234,0.029,0.468,0.053,0.701c0.045,0.424,0.109,0.846,0.203,1.262\n	c0.316,1.405,0.982,2.65,2.536,2.854c1.205,0.158,2.207-1.046,3.029-1.778c0.498-0.401,1.018-0.178,1.557-0.042\n	c0.861,0.215,1.779,0.256,2.662,0.313c3.48,0.222,6.984,0.222,10.471,0.208c1.1-0.005,2.203-0.008,3.301-0.077\n	c0.773-0.048,1.504-0.28,2.273-0.354c0.846-0.082,1.697-0.068,2.543-0.013c0.465,0.031,0.93,0.076,1.393,0.13\n	c0.402,0.048,0.736,0.315,1.035,0.58c1.145,1.011,1.219,2.72,0.342,3.945c0.6,0.169,1.199,0.339,1.797,0.508\n	c0.283,0.081,0.324-0.478,0.404-0.709c0.457-1.321,0.916-2.643,1.373-3.964c0.045-0.127,0.082-0.218,0.082-0.351\n	c0-0.419,0.051-0.342,0.467-0.388c0.426-0.047,0.816-0.455,1.252-0.363c0.297,0.063,0.463,0.221,0.766,0.221\n	c0.719,0,1.439,0,2.158,0c0.477,0,0.252-0.086,0.475-0.509c0.283-0.542,0.543,0.294,0.574,0.509c0.021,0,0.043,0,0.064,0\n	c0.117-0.815,0.596-0.815,0.711,0c0.275,0.199,0.383-0.2,0.465-0.333c0.158-0.259,0.443-0.395,0.744-0.333\n	c0.322,0.066,0.486,0.375,0.57,0.665c0.309,0.196,0.371-0.209,0.439-0.377c0.301-0.744,0.541,0.137,0.66,0.377\n	c0.025-0.183,0.08-0.679,0.355-0.679c0.256,0,0.348,0.51,0.389,0.679c0.314,0.213,0.596-0.679,1.035-0.679\n	c0.326,0,0.559,0.208,0.682,0.499c0.113,0.271,0.355,0.271,0.422-0.028c0.174-0.791,0.594-0.349,0.676,0.208\n	c0.021,0,0.043,0,0.064,0c0.117-0.815,0.594-0.815,0.711,0c0.33,0.241,0.625-0.679,1.066-0.679c0.316,0,0.535,0.234,0.666,0.499\n	c0.133,0.263,0.371,0.277,0.439-0.028c0.172-0.791,0.594-0.349,0.674,0.208c0.021,0,0.043,0,0.064,0\n	c0.051-0.349,0.398-1.073,0.629-0.377c0.07,0.208-0.021,0.377,0.199,0.377c0.357,0,0.715,0,1.072,0c1.453,0,2.906,0,4.359,0\n	c2.76,0,5.506,0.047,8.258-0.142c1.59-0.108,3.225-0.113,4.801-0.346c2.922-0.433,6.234-1.128,8.524-3.134\n	C82.792,18.943,81.182,18.389,79.674,17.957z\"/>\n<rect id=\"sliceCopy_x5F_14_1_\" x=\"88.001\" fill=\"none\" width=\"88\" height=\"40\"/>\n<rect id=\"sliceCopy_x5F_13_1_\" fill=\"none\" width=\"88.001\" height=\"40\"/>\n</svg>",
        [43]    = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 1.1//EN\" \"http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd\" [\n	<!ENTITY ns_flows \"http://ns.adobe.com/Flows/1.0/\">\n]>\n<svg version=\"1.1\"\n	 xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" xmlns:a=\"http://ns.adobe.com/AdobeSVGViewerExtensions/3.0/\"\n	 x=\"0px\" y=\"0px\" width=\"19px\" height=\"40px\" viewBox=\"0.981 0 19 40\" enable-background=\"new 0.981 0 19 40\" xml:space=\"preserve\">\n<defs>\n</defs>\n<path fill=\"#FFFFFF\" d=\"M6.558,9.661V7.897C5.853,7.809,5.5,7.471,5.5,6.882C5.5,6.5,5.632,6.25,5.896,6.133L6.778,6h4.851l4.102,6.57V26.46\n	l-2.074,1.015l-0.66-0.132c-0.147-0.265-0.089-0.515,0.175-0.75c0.235-0.207,0.589-0.441,1.06-0.707l0.616-0.309V13.188\n	l-1.763-1.014v2.073l-1.06,0.97v2.073h-0.441v2.116h0.441v2.205h-0.441v2.117h0.441v2.205h-0.441v2.116h0.441v2.029l1.06,1.808v1.5\n	c0,0.411-0.206,0.616-0.618,0.616h-7.85C4.204,34,4,33.795,4,33.384v-1.5l1.014-1.808v-2.029h0.485v-2.116H5.014v-2.205h0.485V21.61\n	H5.014v-2.205h0.485V17.29H5.014v-2.073L4,14.247v-2.822c0-0.411,0.204-0.618,0.616-0.618h0.618L6.558,9.661L6.558,9.661z\"/>\n<rect id=\"sliceCopy_x5F_8_1_\" x=\"19.73\" fill=\"none\" width=\"35.337\" height=\"40\"/>\n<rect id=\"sliceCopy_x5F_7_1_\" fill=\"none\" width=\"19.73\" height=\"40\"/>\n</svg>",
        [44]    = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 1.1//EN\" \"http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd\" [\n	<!ENTITY ns_flows \"http://ns.adobe.com/Flows/1.0/\">\n]>\n<svg version=\"1.1\"\n	 xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" xmlns:a=\"http://ns.adobe.com/AdobeSVGViewerExtensions/3.0/\"\n	 x=\"0px\" y=\"0px\" width=\"29px\" height=\"40px\" viewBox=\"0.745 0 29 40\" enable-background=\"new 0.745 0 29 40\" xml:space=\"preserve\">\n<defs>\n</defs>\n<path fill=\"#FFFFFF\" d=\"M20.402,11.622c0.158,0.928,0.826,1.643,1.236,2.436c0.526,1.017,0.949,2.126,1.405,3.18c0.36,0.835,0.72,1.661,1.203,2.426\n	c0.466,0.735,0.625,1.479,0.575,2.338c-0.138,2.415,0.123,4.84,0.123,7.255c0,1.127,0.104,2.311-0.015,3.433\n	c-0.037,0.35-0.188,0.619-0.54,0.702c-0.219,0.05-0.705,0.093-0.778-0.206c-0.095-0.388,0.408-0.438,0.488-0.743\n	c0.106-0.405,0-0.838,0-1.248c0-1.313,0.006-2.625-0.003-3.936c-0.019-2.28-0.13-4.489-0.723-6.684\n	c-0.089-0.333-0.251-0.85-0.501-1.094c-0.21-0.205-0.155-0.589-0.376-0.787c-0.641-0.574-0.93-1.369-1.408-2.124\n	c-0.219-0.346-0.465-0.623-0.726-0.934c-0.177-0.209-0.17-0.565-0.403-0.704c-0.425-0.253-1.172-0.132-1.662-0.154\n	c-0.42-0.02-1.266-0.158-1.619,0.149c-0.184,0.159-0.057,0.886-0.057,1.116c0,0.365-0.182,1.116,0.241,1.292\n	c0.318,0.134,0.687,0.115,1.022,0.141c0.554,0.043,1.094,0.183,1.631,0.316c0.992,0.247,1.592,0.619,2.315,1.339\n	c0.804,0.799,0.946,1.832,1.302,2.861c0.427,1.234,0.631,2.308,0.479,3.622c-0.221,1.903-1.132,3.89-2.333,5.371\n	c-1.501,1.851-4.071,2.264-6.244,2.754c-1.084,0.244-2.244,0.398-3.332,0.08c-0.938-0.276-1.881-0.575-2.813-0.878\n	c-0.624-0.204-1.023-0.659-1.575-1.002c-0.33-0.206-0.549-0.501-0.826-0.767c-0.343-0.326-0.667-0.487-0.919-0.917\n	c-1.101-1.877-1.639-3.926-1.565-6.112c0.057-1.682,0.483-3.414,1.521-4.74c0.526-0.677,0.946-1.117,1.739-1.421\n	c0.858-0.329,1.719-0.521,2.573-0.815c0.509-0.174,1.514,0.244,1.641-0.439c0.068-0.37,0.191-1.888-0.313-1.888\n	c-0.423-0.002-0.209-4.994-0.209-5.509C10.433,9.358,9.81,9.426,9.315,9.209C9.109,9.12,8.973,8.953,9.018,8.72\n	c0.029-0.158,0.119-0.305,0.212-0.434C9.362,8.1,9.345,8.075,9.43,7.884c0.166-0.364,0.487-0.46,0.854-0.47\n	c0.459-0.011,0.612-0.333,1.064-0.333c1.323,0,2.648,0,3.971,0c0.166,0,1.525,0.071,1.549-0.036\n	c0.055-0.264-0.032-0.553-0.014-0.822c0.02-0.291,0.577-0.218,0.758-0.205c0.408,0.029,0.582,0.302,0.582,0.741\n	c0,0.16-0.223,0.29-0.059,0.441c0.133,0.123,0.291,0.214,0.417,0.346c0.279,0.289,0.296,0.853,0.523,1.209\n	C19.622,9.604,19.693,10.889,20.402,11.622L20.402,11.622z\"/>\n<rect id=\"sliceCopy_x5F_6_1_\" x=\"28.987\" fill=\"none\" width=\"20.777\" height=\"40\"/>\n<rect id=\"sliceCopy_x5F_5_1_\" fill=\"none\" width=\"28.987\" height=\"40\"/>\n</svg>",
        [45]    = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 1.1//EN\" \"http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd\" [\n	<!ENTITY ns_flows \"http://ns.adobe.com/Flows/1.0/\">\n]>\n<svg version=\"1.1\"\n	 xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" xmlns:a=\"http://ns.adobe.com/AdobeSVGViewerExtensions/3.0/\"\n	 x=\"0px\" y=\"0px\" width=\"21px\" height=\"40px\" viewBox=\"0.758 0 21 40\" enable-background=\"new 0.758 0 21 40\" xml:space=\"preserve\">\n<defs>\n</defs>\n<path fill=\"#FFFFFF\" d=\"M16.764,21.076c0-1.426,0-2.853,0-4.279c0-0.718,0.062-1.563-0.082-2.198c-0.105-0.464-0.323-0.632-0.494-0.987\n	c-0.117-0.24-0.124-0.413-0.124-0.727c0-0.121-0.252-0.357-0.288-0.425c-0.131-0.239-0.179-0.673-0.35-0.844\n	c-0.381-0.381-0.234-1.188-0.617-1.563c-0.186-0.181-0.104-0.72-0.287-0.905c-0.181-0.18-0.317-0.567-0.393-0.761\n	c-0.205-0.544-0.432-1.076-0.615-1.604c0.028-0.288-0.201-0.114-0.289-0.288c-0.051-0.098,0.075-0.378,0-0.454\n	C13.178,5.995,12.863,6.027,12.813,6c-0.299,0.113-0.608,0.684-0.781,1.029c0.067-0.454-1.954-0.247-2.229-0.247\n	c-0.658,0-1.318,0-1.978,0c-0.239,0-0.624-0.076-0.854,0C6.499,6.938,6.14,8.509,6.315,8.509c0.084,0,1.028-0.014,1.028,0.06\n	c0,0.513,0,1.025,0,1.538c0,0.395-0.248,0.622-0.248,1.05c0,0.25-0.822,0.264-1.072,0.308c-0.509,0.089-2.468,0.003-1.931,1.077\n	c0.022,1.171,0,2.347,0,3.52c0,4.896,0,9.793,0,14.689c0,0.579,0,1.156,0,1.735c0,0.408,1.219,0.796,1.55,0.927\n	c2.151,0.841,4.179,0.654,6.369,0.198c0.726-0.151,1.613-0.405,2.2-0.85c0.179-0.135,0.248-0.028,0.248-0.241\n	c0-0.555,0-1.109,0-1.664c0-2.31,0-4.619,0-6.93c0-3.78,0-7.562,0-11.343c0.268,0.193,0.422,0.549,0.616,0.782\n	c0.2,0.235,0.323,0.557,0.496,0.823c0.093,0.143,0.436,0.503,0.492,0.658c0.212,0.566,0,1.633,0,2.245c0,2.866,0,5.733,0,8.599\n	c0,1.424,0,2.851,0,4.275c0,0.211-0.248,0.272-0.248,0.637c0,0.338-0.044,0.329,0.29,0.329c0.223,0,0.226-0.011,0.328-0.082\n	c0.39-0.269,0.33-0.692,0.33-1.255C16.764,26.753,16.764,23.916,16.764,21.076z M14.047,27.064c0,0.288,0,0.576,0,0.864\n	c0,0.66-0.011,0.577-0.652,0.658c-0.91,0.115-1.819,0.229-2.729,0.344c-0.408,0.05-0.879,0.189-1.291,0.137\n	c-1.533-0.192-3.066-0.385-4.602-0.575c-0.329-0.041-0.229-0.218-0.229-0.522c0-0.343,0-0.686,0-1.028\n	c1.614,0.165,3.231,0.329,4.847,0.493c0.702,0.071,1.553-0.163,2.249-0.238c0.805-0.084,1.604-0.169,2.406-0.255\n	C14.047,26.981,14.047,27.023,14.047,27.064z M14.047,15.141c0,0.288,0,0.576,0,0.864c0,0.66-0.011,0.577-0.652,0.658\n	c-0.91,0.115-1.819,0.229-2.729,0.344c-0.408,0.05-0.879,0.189-1.291,0.137c-1.533-0.192-3.066-0.385-4.602-0.575\n	c-0.329-0.041-0.229-0.218-0.229-0.522c0-0.343,0-0.686,0-1.028c1.614,0.165,3.231,0.329,4.847,0.493\n	c0.702,0.071,1.553-0.163,2.249-0.238c0.805-0.084,1.604-0.169,2.406-0.255C14.047,15.058,14.047,15.1,14.047,15.141z\"/>\n<rect id=\"sliceCopy_x5F_7_1_\" x=\"20.777\" fill=\"none\" width=\"19.73\" height=\"40\"/>\n<rect id=\"sliceCopy_x5F_6_1_\" fill=\"none\" width=\"20.777\" height=\"40\"/>\n</svg>",
        [46]    = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 1.1//EN\" \"http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd\" [\n	<!ENTITY ns_flows \"http://ns.adobe.com/Flows/1.0/\">\n]>\n<svg version=\"1.1\"\n	 xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" xmlns:a=\"http://ns.adobe.com/AdobeSVGViewerExtensions/3.0/\"\n	 x=\"0px\" y=\"0px\" width=\"29px\" height=\"40px\" viewBox=\"0.137 0 29 40\" enable-background=\"new 0.137 0 29 40\" xml:space=\"preserve\">\n<defs>\n</defs>\n<path fill=\"#FFFFFF\" d=\"M23.592,12.281c-0.081,0.191-0.014,0.423,0.205,0.696c0.19,0.273,0.137,0.64-0.164,1.104l-1.311,1.555\n	c-0.307,0.353-0.747,0.574-1.302,0.678l0.374-0.611l0.188-0.039L23,13.726l-0.271-0.709l-0.984-0.939\n	c-0.386-0.265-0.733-0.453-1.062-0.572l-0.859-0.075l-1.342,1.833l-0.364,0.553h0.151L17.36,14.92l-0.521-1.042\n	c-0.217-0.737-0.259-1.336-0.122-1.801l0.491-0.899c0.189-0.381,0.189-0.9,0-1.555l0.451,0.165c0.354,0.19,0.613,0.491,0.775,0.9\n	l0.125,1.104l0.04,0.45l0.613-1.35c0.026-0.272-0.15-0.696-0.532-1.27l-0.899-1.145c-0.164-0.245-0.231-0.818-0.204-1.719\n	C17.604,5.833,17.74,5.246,17.987,5c0.054,0.573,0.299,1.077,0.734,1.514c0.22,0.219,0.806,0.464,1.761,0.737\n	c0.382,0.109,0.613,0.34,0.694,0.695l0.327,0.859l0.451,0.613c0.191,0.247,0.341,0.314,0.45,0.205c0.11-0.108,0-0.422-0.325-0.94\n	c-0.357-0.544-0.303-1.146,0.161-1.8c0.055,0.273,0.382,0.682,0.982,1.228c0.599,0.573,0.968,1.133,1.104,1.678l0.039,0.818\n	l-0.326,0.982L23.592,12.281z M21.382,15.351l1.229-1.677l-0.205-0.532l-0.859-0.777c-0.356-0.245-0.682-0.423-0.982-0.532\n	l-0.572-0.04l-1.227,1.676h0.04v0.246l-3.232,3.929l-0.735,0.49l-1.227,0.573c-1.229,0.573-2.046,1.159-2.455,1.759L4.034,30.488\n	c-0.108,0.272,0.042,0.735,0.452,1.391c0.462,0.71,1.078,1.337,1.84,1.882c0.766,0.545,1.506,0.911,2.374,1.145\n	c0.867,0.233,1.473-0.04,1.473-0.04l7.118-9.984c0.408-0.599,0.696-1.568,0.857-2.904c0.138-1.362,0.261-2.113,0.369-2.249\n	l2.659-4.337L21.382,15.351z\"/>\n<rect id=\"sliceCopy_x5F_11_1_\" x=\"28.367\" fill=\"none\" width=\"88\" height=\"40\"/>\n<rect id=\"sliceCopy_x5F_10_1_\" fill=\"none\" width=\"28.367\" height=\"40\"/>\n</svg>",
        [47]    = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 1.1//EN\" \"http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd\" [\n	<!ENTITY ns_flows \"http://ns.adobe.com/Flows/1.0/\">\n]>\n<svg version=\"1.1\"\n	 xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" xmlns:a=\"http://ns.adobe.com/AdobeSVGViewerExtensions/3.0/\"\n	 x=\"0px\" y=\"0px\" width=\"36px\" height=\"40px\" viewBox=\"0.25 0 36 40\" enable-background=\"new 0.25 0 36 40\" xml:space=\"preserve\">\n<defs>\n</defs>\n<path fill=\"#FFFFFF\" d=\"M8.704,19.472l1.801,1.009l-0.747,1.275l-1.76-1.01v2.022H6.551v-2.068l-1.847,1.056L4,20.481l1.802-1.009L4,18.417\n	l0.747-1.274l1.804,1.055v-2.11h1.447v2.066l1.76-1.011l0.703,1.274L8.704,19.472z M11.76,7.964l2.151-1.25l-0.86-1.486L10.979,6.44\n	V4.016H9.219v2.502l-2.188-1.29L6.172,6.714l2.189,1.25L6.172,9.216l0.859,1.486l2.188-1.251v2.501h1.761V9.528l2.071,1.174\n	l0.86-1.486L11.76,7.964z M29.534,9.626l1.757-1.055l-0.702-1.274l-1.757,1.011V6.243h-1.451v2.109l-1.802-1.055l-0.748,1.274\n	l1.76,1.055l-1.76,1.011l0.704,1.274l1.846-1.055v2.065h1.451v-2.021l1.757,1.011l0.748-1.274L29.534,9.626z M16.146,11.645\n	l-1.323,1.146h-0.618c-0.412,0-0.616,0.207-0.616,0.617v2.822l1.014,0.97v2.073h0.485v2.116h-0.485v2.204h0.485v2.117h-0.485v2.204\n	h0.485v2.116h-0.485v2.028l-1.014,1.809v1.499c0,0.411,0.204,0.616,0.616,0.616h7.85c0.412,0,0.618-0.205,0.618-0.616v-1.499\n	l-1.06-1.809v-2.028h-0.441v-2.116h0.441v-2.204h-0.441v-2.117h0.441V21.39h-0.441v-2.116h0.441v-2.073l1.06-0.97v-2.072\n	l1.763,1.014v12.389l-0.616,0.31c-0.471,0.266-0.824,0.5-1.06,0.707c-0.264,0.234-0.322,0.484-0.175,0.749l0.66,0.133l2.074-1.015\n	V14.554l-4.102-6.57h-4.851l-0.883,0.134c-0.264,0.116-0.396,0.366-0.396,0.749c0,0.589,0.353,0.927,1.058,1.015V11.645\"/>\n<rect id=\"sliceCopy_x5F_9_1_\" x=\"35.337\" fill=\"none\" width=\"20.776\" height=\"40\"/>\n<rect id=\"sliceCopy_x5F_8_1_\" fill=\"none\" width=\"35.337\" height=\"40\"/>\n</svg>",
        [48]    = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 1.1//EN\" \"http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd\" [\n	<!ENTITY ns_flows \"http://ns.adobe.com/Flows/1.0/\">\n]>\n<svg version=\"1.1\"\n	 xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" xmlns:a=\"http://ns.adobe.com/AdobeSVGViewerExtensions/3.0/\"\n	 x=\"0px\" y=\"0px\" width=\"20px\" height=\"40px\" viewBox=\"0.914 0 20 40\" enable-background=\"new 0.914 0 20 40\" xml:space=\"preserve\">\n<defs>\n</defs>\n<path fill=\"#FFFFFF\" d=\"M13.512,6.782c0.186,0.529,0.41,1.06,0.617,1.605c0.073,0.193,0.21,0.581,0.391,0.761c0.186,0.185,0.102,0.724,0.29,0.905\n	c0.381,0.375,0.235,1.183,0.616,1.563c0.171,0.17,0.219,0.605,0.348,0.844c0.038,0.068,0.29,0.304,0.29,0.425\n	c0,0.313,0.005,0.486,0.122,0.726c0.173,0.356,0.389,0.523,0.494,0.988c0.144,0.635,0.084,1.48,0.084,2.198c0,1.427,0,2.853,0,4.279\n	c0,2.839,0,5.678,0,8.518c0,0.563,0.059,0.987-0.33,1.255c-0.104,0.071-0.105,0.082-0.328,0.082c-0.334,0-0.29,0.009-0.29-0.33\n	c0-0.365,0.248-0.426,0.248-0.636c0-1.425,0-2.851,0-4.275c0-2.866,0-5.733,0-8.599c0-0.611,0.212-1.678,0-2.245\n	c-0.059-0.155-0.401-0.516-0.494-0.658c-0.171-0.266-0.294-0.587-0.494-0.823c-0.196-0.232-0.348-0.588-0.618-0.781\n	c0,3.782,0,7.563,0,11.344c0,2.31,0,4.619,0,6.93c0,0.554,0,1.108,0,1.663c0,0.214-0.067,0.107-0.246,0.242\n	c-0.588,0.444-1.477,0.698-2.2,0.849c-2.19,0.457-4.218,0.645-6.371-0.197c-0.329-0.13-1.548-0.519-1.548-0.928\n	c0-0.578,0-1.155,0-1.734c0-4.896,0-9.793,0-14.69c0-1.172,0.022-2.349,0-3.52c-0.537-1.074,1.422-0.988,1.931-1.077\n	c0.25-0.044,1.072-0.058,1.072-0.308c0-0.429,0.246-0.656,0.246-1.051c0-0.513,0-1.025,0-1.538c0-0.075-0.942-0.06-1.026-0.06\n	c-0.175,0,0.183-1.571,0.656-1.728c0.229-0.075,0.612,0,0.854,0c0.658,0,1.317,0,1.978,0c0.273,0,2.297-0.207,2.229,0.247\n	C12.205,6.684,12.514,6.114,12.814,6c0.047,0.027,0.364-0.005,0.41,0.041c0.076,0.076-0.05,0.356,0,0.454\n	C13.313,6.669,13.542,6.495,13.512,6.782 M8.124,15.092c-1.668,1.459-2.443,3.85-2.383,6.018c0.057,2.044,0.773,4.496,3.207,4.637\n	c-1.777-1.101-1.617-3.839-0.043-5.019c-0.322,0.908,0.155,1.776,0.777,2.425c0.312,0.326,1.866,1.955,1.155,2.428\n	c1.1,0.425,2.086-1.626,2.223-2.385c0.198-1.295-0.136-2.542-0.866-3.605c-1.201-1.746-3.429-4.28-1.727-6.391\n	C9.687,13.831,8.905,14.461,8.124,15.092 M14.047,27.064c0-0.041,0-0.083,0-0.123c-0.802,0.085-1.604,0.17-2.406,0.255\n	c-0.697,0.074-1.547,0.309-2.249,0.236c-1.615-0.164-3.232-0.328-4.847-0.492c0,0.342,0,0.684,0,1.028\n	c0,0.304-0.101,0.48,0.229,0.522c1.532,0.19,3.067,0.382,4.601,0.575c0.412,0.051,0.883-0.086,1.289-0.136\n	c0.909-0.115,1.819-0.23,2.729-0.344c0.644-0.081,0.654,0.002,0.654-0.659C14.047,27.64,14.047,27.353,14.047,27.064\"/>\n<rect id=\"sliceCopy_x5F_10_1_\" x=\"20.777\" fill=\"none\" width=\"28.367\" height=\"40\"/>\n<rect id=\"sliceCopy_x5F_9_1_\" fill=\"none\" width=\"20.776\" height=\"40\"/>\n</svg>",
        [49]    = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 1.1//EN\" \"http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd\" [\n	<!ENTITY ns_flows \"http://ns.adobe.com/Flows/1.0/\">\n]>\n<svg version=\"1.1\"\n	 xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" xmlns:a=\"http://ns.adobe.com/AdobeSVGViewerExtensions/3.0/\"\n	 x=\"0px\" y=\"0px\" width=\"40px\" height=\"40px\" viewBox=\"0 0 40 40\" enable-background=\"new 0 0 40 40\" xml:space=\"preserve\">\n<defs>\n</defs>\n<path fill=\"#FFFFFF\" d=\"M33.236,12.732c0-0.401-0.201-0.602-0.6-0.602H20.668c-0.146,0-0.273,0.056-0.383,0.164l-0.219,0.438v7.649l0.219,0.437\n	l0.383,0.11h11.969c0.398,0,0.6-0.182,0.6-0.547V12.732 M35.477,10.547c0.291,0.363,0.438,0.8,0.438,1.311v16.339\n	c0,0.474-0.146,0.875-0.438,1.204c-0.328,0.398-0.766,0.6-1.311,0.6H5.805c-0.475,0-0.893-0.201-1.258-0.602\n	C4.184,29.07,4,28.67,4,28.195V11.857c0-0.509,0.184-0.947,0.547-1.311C4.912,10.183,5.33,10,5.805,10h28.361\n	C34.711,10,35.148,10.183,35.477,10.547 M27.334,16.667l-0.436-0.273l0.162-0.273l0.492,0.273v-0.492h0.383l-0.055,0.492\n	l0.492-0.273l0.164,0.273l-0.547,0.273l0.547,0.272l-0.164,0.328l-0.492-0.273l0.055,0.547h-0.383v-0.547l-0.492,0.273l-0.162-0.328\n	L27.334,16.667 M26.133,16.394l-0.492,0.273l0.492,0.272l-0.164,0.328l-0.547-0.273l0.109,0.547h-0.438v-0.547l-0.438,0.273\n	l-0.219-0.328l0.492-0.272l-0.492-0.273l0.219-0.273l0.438,0.273v-0.492h0.438l-0.109,0.492l0.547-0.273L26.133,16.394\n	 M26.188,26.065l-0.109-0.329l-0.383-0.218h-1.529c-0.146,0-0.256,0.071-0.33,0.218c-0.109,0.071-0.162,0.183-0.162,0.329v1.529\n	l0.162,0.384l0.33,0.109h1.529l0.383-0.109l0.109-0.384V26.065 M27.553,25.519l-0.328,0.219c-0.109,0.072-0.162,0.183-0.162,0.329\n	v1.528l0.162,0.384l0.33,0.109h1.582l0.33-0.109l0.109-0.384v-1.529l-0.111-0.328l-0.328-0.219H27.553 M26.188,22.459l-0.109-0.382\n	l-0.385-0.11h-1.529l-0.328,0.11l-0.162,0.382v1.53l0.162,0.326l0.33,0.221h1.529l0.383-0.221l0.109-0.326V22.459 M29.465,22.077\n	l-0.328-0.11h-1.584l-0.328,0.11c-0.109,0.145-0.164,0.272-0.164,0.382v1.53l0.164,0.326l0.328,0.221h1.584l0.33-0.221l0.109-0.326\n	v-1.53L29.465,22.077 M32.854,25.737l-0.383-0.219h-1.475l-0.383,0.219c-0.111,0.072-0.162,0.183-0.162,0.329v1.528l0.162,0.384\n	l0.383,0.109h1.477l0.381-0.109l0.164-0.384v-1.529L32.854,25.737 M32.854,22.077l-0.383-0.11h-1.475l-0.385,0.11l-0.162,0.382v1.53\n	l0.162,0.326l0.385,0.221h1.475l0.383-0.221l0.164-0.326v-1.53L32.854,22.077 M23.727,16.394l-0.49,0.273l0.49,0.272l-0.107,0.328\n	l-0.602-0.273l0.109,0.547h-0.383v-0.547l-0.492,0.273l-0.164-0.328l0.438-0.272l-0.438-0.273l0.164-0.273l0.492,0.273v-0.492h0.383\n	l-0.109,0.492l0.602-0.273L23.727,16.394 M14.328,22.841l0.438-0.764l0.328-0.82h0.109l-0.055,0.82l-0.055,0.764v1.804h-1.748\n	L14.328,22.841 M22.252,25.519h-1.475c-0.109,0-0.238,0.071-0.383,0.218l-0.219,0.329v1.529l0.219,0.384l0.383,0.109h1.475\n	l0.383-0.109l0.164-0.384v-1.529l-0.164-0.328L22.252,25.519 M22.252,21.967h-1.475l-0.383,0.11l-0.219,0.382v1.53l0.219,0.326\n	c0.145,0.147,0.273,0.221,0.383,0.221h1.475l0.383-0.221l0.164-0.326v-1.53l-0.164-0.382L22.252,21.967 M11.541,24.809v1.257h3.553\n	v1.912h1.803v-1.912h1.039v-1.421h-1.039v-4.81h-2.295L11.541,24.809 M9.629,23.17l0.602,0.053l0.438,0.111l0.328-1.366\n	l-0.656-0.164L9.574,21.75c-1.166,0-2.059,0.309-2.678,0.929c-0.547,0.583-0.818,1.33-0.818,2.24c0,0.982,0.271,1.767,0.818,2.349\n	c0.547,0.547,1.33,0.82,2.35,0.82l0.984-0.109l0.711-0.164l-0.164-1.475l-0.547,0.218H9.629c-0.438,0-0.82-0.146-1.146-0.436\n	c-0.365-0.257-0.547-0.675-0.547-1.258c0-0.437,0.164-0.819,0.492-1.148C8.682,23.351,9.082,23.17,9.629,23.17\"/>\n<rect id=\"sliceCopy_x5F_2_1_\" x=\"39.914\" fill=\"none\" width=\"29.462\" height=\"40\"/>\n<rect id=\"sliceCopy_x5F_1_1_\" fill=\"none\" width=\"39.914\" height=\"40\"/>\n</svg>",
        [59]    = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 1.1//EN\" \"http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd\" [\n	<!ENTITY ns_flows \"http://ns.adobe.com/Flows/1.0/\">\n]>\n<svg version=\"1.1\"\n	 xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" xmlns:a=\"http://ns.adobe.com/AdobeSVGViewerExtensions/3.0/\"\n	 x=\"0px\" y=\"0px\" width=\"88px\" height=\"40px\" viewBox=\"0.77 0 88 40\" enable-background=\"new 0.77 0 88 40\" xml:space=\"preserve\">\n<defs>\n</defs>\n<path fill=\"#FFFFFF\" d=\"M81.523,17.321c0.83-0.059,1.65-0.207,2.477-0.31c-1.496,1.853-2.959,3.775-4.885,5.212\n	c-1.383,1.032-3.055,1.711-4.693,2.218c-1.012,0.313-2.045,0.607-3.104,0.696c-2.861,0.241-5.773,0.68-8.646,0.68\n	c-3.883,0-7.768,0-11.65,0c-0.732,0-1.461,0-2.191,0c-0.168,0-0.828,0.087-0.98-0.034c-0.123-0.101-0.271-0.788-0.344-0.964\n	c-0.285-0.683-0.67-1.262-1.326-1.648c-1.615-0.956-3.736-0.243-4.92,1.059c-0.563,0.619-1.559,2.116-1.021,2.991\n	c0.201,0.327,0.693,0.345,1.014,0.52c0.256,0.139,0.373,0.508,0.275,0.788c-0.139,0.403-0.604,0.458-0.969,0.419\n	c-1.482-0.191-2.406-1.377-2.406-2.807c0-0.807,0.066-1.643-0.029-2.444c-0.1-0.846-0.881-0.528-1.5-0.438\n	c-1.002,0.146-2.006,0.293-3.008,0.439c-1.176,0.172-2.385,0.188-3.57,0.267c-2.967,0.197-5.889,0.482-8.857,0.338\n	c-3.246-0.157-6.498-0.26-9.734-0.566c-0.955-0.09-1.912-0.181-2.867-0.271c-1.076-0.103-1.572,0.72-2.07,1.517\n	c-0.277,0.442-0.719,0.957-1.24,0.45c-0.326-0.316-0.32-0.86-0.357-1.282c-0.072-0.842-0.086-1.688-0.094-2.529\n	c-0.17-0.426-0.605-0.644-0.74-1.118c-0.217-0.77-0.01-1.694,0.596-2.239c0.281-0.254,0.164-0.924,0.182-1.308\n	c0.018-0.416,0.041-0.832,0.08-1.247c0.037-0.389,0.043-0.849,0.332-1.146c0.578-0.594,1.047,0.154,1.334,0.598\n	c0.527,0.817,1.059,1.47,2.109,1.37c1-0.095,2-0.189,3-0.284c3.223-0.304,6.463-0.41,9.697-0.579\n	c2.971-0.154,5.916,0.162,8.887,0.358c1.16,0.077,2.332,0.106,3.484,0.275c1.021,0.149,2.043,0.298,3.063,0.448\n	c0.279,0.04,0.557,0.081,0.834,0.121c0.414,0.061,0.436-0.521,0.465-0.758c0.098-0.777,0.004-1.619,0.004-2.402\n	c0-1.396,1.297-2.85,2.797-2.649c0.75,0.1,0.738,0.908,0.191,1.257c-0.391,0.248-0.877,0.162-1.004,0.723\n	c-0.158,0.701,0.137,1.686,0.561,2.25c0.1,0.125,0.316,0.234,0.379,0.379c0.072,0.166,0,0.519,0,0.7c0,0.38,0.791,0.194,1.107,0.194\n	c0.996,0,1.992,0,2.988,0c1.746,0,3.492,0,5.236,0c2.977,0,5.986,0.34,8.949,0.588c3.016,0.253,6.037,0.347,9.059,0.48\n	c1.711,0.075,3.42,0.151,5.131,0.227c1.16,0.052,2.359-0.137,3.516-0.219C78.548,17.534,80.037,17.426,81.523,17.321z\"/>\n<rect id=\"sliceCopy_x5F_12_1_\" x=\"88\" fill=\"none\" width=\"88\" height=\"40\"/>\n<rect id=\"sliceCopy_x5F_11_1_\" fill=\"none\" width=\"88\" height=\"40\"/>\n</svg>",
        [60]    = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 1.1//EN\" \"http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd\" [\n	<!ENTITY ns_flows \"http://ns.adobe.com/Flows/1.0/\">\n]>\n<svg version=\"1.1\"\n	 xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" xmlns:a=\"http://ns.adobe.com/AdobeSVGViewerExtensions/3.0/\"\n	 x=\"0px\" y=\"0px\" width=\"137px\" height=\"40px\" viewBox=\"0.128 0 137 40\" enable-background=\"new 0.128 0 137 40\"\n	 xml:space=\"preserve\">\n<defs>\n</defs>\n<path fill=\"#FFFFFF\" d=\"M132.043,15.743l-23.484-0.052l-0.053-0.923l0.461-0.051l0.051-0.359l-7.537-0.103v-0.205l-3.129,0.052l-0.615,0.204\n	l-5.434-0.051l1.078,0.205v0.923l-0.258,0.308l-1.18-0.051v0.41h-0.871v-1.539h0.203v-0.205l-3.332-0.102l-0.104,0.307l-0.102,0.77\n	l-0.102,0.154l-0.256,0.103l-0.258-0.154l-0.205-0.103l0.053-0.718l-0.104-0.308h-0.668l-0.051,1.128l-0.205,0.205l-0.203,0.154\n	h-0.359l-0.309,0.667L66.15,16.563l-0.359-0.205l-0.461-0.103l-0.975,0.358l-0.102-1.282l-0.924,0.052l0.051,0.82l-0.051,0.103\n	l-0.152,0.257l-0.309,0.103l-0.154,0.051l-0.154-0.051c-0.137,0-0.238,0.067-0.307,0.205l-0.205,0.308l-0.104,0.205v4.358\n	l0.309,0.104l0.051,0.36l-0.666,0.257v1.588c0.066,1.232,0.221,2.377,0.461,3.437l1.127,3.999l0.668,2.104l0.205,0.257L56.355,36\n	H56.15v-0.207l-0.82-2.718l-1.18-4.563l-0.41-3.078l-0.102-1.332l-0.564,0.103l-0.719-0.103h-4.818l-1.59,0.153h-0.258\n	c-0.238,0-0.428,0.051-0.563,0.153l-0.309,0.308l-1.127,2.153l0.563,0.667l-0.152,0.103c-0.205,0.068-0.445,0.172-0.719,0.309\n	l-0.359,0.307l-0.102,0.153l-2.205,4.309l-0.053,0.41l0.258,0.409l0.205,0.154l-0.205,0.462l-7.23-1.691l6.512-11.281l0.154-0.463\n	l0.102-0.923l-0.357-0.922l-0.564-0.615l-0.615-0.308l-1.641-0.052v0.205l-0.463,0.051l-0.051-2.82l-1.281-0.051l-0.053-0.462\n	h-5.178l-1.23,0.924l-4.873,0.103v0.461l-4.256,0.052l0.051,2.666h-2.973v1.077h-1.436v-1.025l-4.82,3.025v-2.461l-6.104,2.769\n	l-0.051,1.025l-0.051,0.154l-0.256,0.204l-0.205-0.204L4,23.435l0.104-13.64h5.436L9.744,10l0.154,0.718l13.998,0.153l0.154,0.103\n	l0.102,0.257l11.334,0.052l-0.053-0.462h1.334v-0.359l0.461-0.051l0.053,0.359l1.332-0.052v-0.615h1.334l0.102,0.103l3.436-5.486\n	l0.154-0.206l0.41-0.307L44.563,4h0.307l17.076,1.846l0.514,0.104l0.871,0.513l0.514,0.871l0.203,0.462l-0.102,3.333l0.359-0.052\n	l0.051-1.486l1.076,0.205V9.436l0.359-0.051V9.282l0.104-0.154l0.256-0.103l18.973,0.308l0.205,0.41v0.513l0.514,0.052l0.102,0.052\n	l0.154,0.204l0.102,1.231h0.666l0.053-2l3.129-4.41l0.307-0.256c0.205-0.172,0.41-0.239,0.615-0.206\n	c0.514,0.069,0.889,0.257,1.129,0.564l0.152,0.358L92.199,6l0.051,5.795h5.436l0.719,0.256l3.076-0.052v-0.204h7.539V10.41h22.973\n	l0.205,0.205v4.872L132.043,15.743 M91.123,8.77l-0.256-0.258l-0.205-0.666l-0.051-0.513L89.43,7.23l-1.846,2.872l0.258,0.205h3.486\n	L91.584,10V8.77H91.123 M87.893,11.795h3.281l0.154-0.513h-3.436V11.795 M62.201,6.77l-0.152-0.103H47.689h-0.357l-0.564,0.256\n	l-0.463,0.462L46.1,7.641l-0.82,2l0.309,0.308l16.357-0.102l0.205-0.052l0.41-0.205c0.41-0.274,0.617-0.719,0.617-1.334\n	c0-0.513-0.189-0.923-0.566-1.229L62.201,6.77 M8.924,16.307l-0.205-0.051H4.924l-0.205,0.051l-0.154,0.308l0.205,0.257l0.154,0.102\n	H8.77l0.154-0.152l0.154-0.257L8.924,16.307 M4.564,10.256v0.564h4.871l-0.051-0.359L9.23,10.256l-0.205-0.051L4.564,10.256\n	 M51.689,20.051l-0.41-0.154h-1.947l-0.463,0.462c-0.273,0.443-0.428,0.854-0.461,1.23c-0.033,0.375,0.084,0.751,0.359,1.129\n	l0.461,0.409l-0.205,0.152l-0.666-0.513c-0.445-0.409-0.686-0.853-0.719-1.332c-0.033-0.308,0.035-0.666,0.205-1.076l0.205-0.462\n	l-0.871,0.308c-0.615,0.41-0.891,1.01-0.82,1.795c0.035,0.445,0.256,0.855,0.666,1.231l0.615,0.461h4.615v-0.615l0.41-0.615\n	c0.172-0.479,0.137-1.01-0.102-1.591L51.689,20.051\"/>\n<rect id=\"sliceCopy_x5F_42_1_\" x=\"136.197\" fill=\"none\" width=\"106.639\" height=\"40\"/>\n<rect id=\"sliceCopy_x5F_41_1_\" fill=\"none\" width=\"136.197\" height=\"40\"/>\n</svg>",
        [61]    = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 1.1//EN\" \"http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd\" [\n	<!ENTITY ns_flows \"http://ns.adobe.com/Flows/1.0/\">\n]>\n<svg version=\"1.1\"\n	 xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" xmlns:a=\"http://ns.adobe.com/AdobeSVGViewerExtensions/3.0/\"\n	 x=\"0px\" y=\"0px\" width=\"95px\" height=\"40px\" viewBox=\"0.521 0 95 40\" enable-background=\"new 0.521 0 95 40\" xml:space=\"preserve\">\n<defs>\n</defs>\n<path fill=\"#FFFFFF\" d=\"M90.463,5.74l-0.337-1.179l-0.281-0.337H72.61l-0.394,0.169l-0.394-0.057H58.407l-0.505-0.225l-0.395,0.225H51.67v1.628\n	h-1.685v0.786h-1.123V5.853L48.47,5.348l-0.394,0.056v-1.01L47.74,4h-2.808v1.517H33.144v0.168h-6.849V5.46H14.056l-0.338-0.281\n	l-3.592-0.056L9.227,4.617v0.955L8.049,7.817l-0.729,3.649L5.635,10.4l-0.281,1.46l-0.618-0.057c-0.411,0-0.655,0.188-0.729,0.562\n	c-0.038,0.3,0.075,0.542,0.336,0.729l0.393,0.112l2.078,0.225L6.7,14.273l-0.055,1.292l0.448,0.449l1.46,0.505\n	c0.749,0.262,1.234,0.506,1.46,0.729c0.3,0.263,0.394,0.618,0.281,1.067l-0.394,1.01l-0.786,1.629\n	c-0.825,1.796-1.497,3.723-2.021,5.782c-0.485,2.021-0.842,4.154-1.066,6.4l-0.112,2.75L17.985,36l-0.618-0.897l0.113-1.348\n	l2.862-12.126l0.393,0.111l1.011-0.111l0.843-0.169l0.842,0.112l1.461,0.447l0.842,0.338l5.838-0.224l0.898-0.169l0.562-0.617\n	l2.246-5.502c0.111-0.263,0.261-0.468,0.448-0.617l0.225-0.112h12.744l0.111-1.909l0.281-0.225v-0.954l-0.281-0.225V9.839h1.18\n	v0.843h1.908v1.01h5.672l0.504,0.169l0.337-0.226h13.417l0.338-0.111l0.224,0.168h17.46l0.225-0.505l0.337-1.179l0.169-2.19\n	L90.463,5.74z M33.817,16.521l-0.842,2.358l-1.123,2.526l-2.47,0.168l-2.75-0.113l-1.236-0.112l-1.628-0.056l-1.46-0.619\n	l-0.953-1.123c-0.227-0.487-0.264-1.01-0.113-1.571c0.111-0.524,0.373-1.011,0.785-1.46c0.301-0.3,0.786-0.562,1.46-0.786\n	l0.897-0.225l-0.616,0.729c-0.488,0.637-0.769,1.329-0.842,2.078c-0.038,0.448,0.092,1.01,0.394,1.684l0.448,0.955l0.394-0.281\n	l-0.225-0.562l-0.114-1.122c0.037-0.525,0.188-0.992,0.449-1.404l0.674-0.898l1.349-1.403l6.399-0.056l0.393,0.058l0.619,0.338\n	l0.111,0.561V16.521z\"/>\n<rect id=\"sliceCopy_x5F_30_1_\" x=\"94.576\" fill=\"none\" width=\"63.669\" height=\"40\"/>\n<rect id=\"sliceCopy_x5F_29_1_\" fill=\"none\" width=\"94.576\" height=\"40\"/>\n</svg>",
        [63]    = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 1.1//EN\" \"http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd\" [\n	<!ENTITY ns_flows \"http://ns.adobe.com/Flows/1.0/\">\n]>\n<svg version=\"1.1\"\n	 xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" xmlns:a=\"http://ns.adobe.com/AdobeSVGViewerExtensions/3.0/\"\n	 x=\"0px\" y=\"0px\" width=\"56px\" height=\"40px\" viewBox=\"0.224 0 56 40\" enable-background=\"new 0.224 0 56 40\" xml:space=\"preserve\">\n<defs>\n</defs>\n<path fill=\"#FFFFFF\" d=\"M23.356,4.978c1.391,0.152,2.791,0.081,4.188,0.081c0.695-0.1,1.398-0.084,2.1-0.081c4.27,0.045,8.543,0.046,12.814,0.015\n	c0.086-0.236,0.084-0.555,0.291-0.718c0.486,0.004,0.965,0.063,1.447,0.101c0.195,0.322,0.367,0.673,0.684,0.897\n	c0.236,0.152,0.227,0.486,0.408,0.669c2.205,0.002,4.408,0.023,6.611,0.083c0.363,0.788,0.348,1.763,0,2.554\n	c-2.244,0.004-4.48,0.023-6.721-0.013c-0.188,0.865,0.01,1.763-0.205,2.625c-0.102,0.319-0.473,0.391-0.766,0.397\n	c-2.045,0.092-4.096-0.016-6.141,0.086c0.697-0.063,1.158,0.51,1.748,0.766c0.158,0.074,0.369,0.258,0.23,0.443\n	c-0.289,0.286-0.682,0.438-1.053,0.581c-0.561,0.034-1.121,0.034-1.684,0.06c1.785,5.599,3.525,11.216,5.254,16.833\n	c0.336,1.121,0.738,2.217,1.006,3.357c-0.148,0.13-0.301,0.256-0.455,0.384c-0.02,0.304-0.014,0.615-0.09,0.911\n	c-0.244,0.248-0.637,0.26-0.963,0.311c-0.287,0.043-0.381,0.469-0.697,0.439c-0.408-0.029-0.756,0.242-1.16,0.229\n	c-0.832-0.002-1.668,0.035-2.5-0.002c-0.293-0.304-0.395-0.772-0.547-1.163c-1.537-4.949-3.133-9.879-4.691-14.82\n	c-0.699-2.361-1.445-4.707-2.158-7.064c-0.377,0.31-0.631,0.745-0.773,1.206c-0.135,0.473,0.08,0.949,0.07,1.426\n	c0,0.774,0.018,1.547,0.004,2.321c-0.582,0.453-1.281,0.708-1.965,0.967c-1.135,0.424-2.338,0.622-3.541,0.72\n	c-0.994,0.083-1.973-0.156-2.9-0.49c-0.805-0.231-1.699-0.559-2.51-0.162c-0.787,0.294-1.248,1.066-1.465,1.844\n	c-0.41,1.484-0.967,2.924-1.4,4.404c-0.35,1.123-0.809,2.22-0.98,3.395c-0.148,0.767-0.092,1.553-0.023,2.326\n	c0.398,0.229,0.953,0.341,1.098,0.836c-0.301,0.423-0.73,0.729-1.156,1.022c-0.121,0.089-0.256,0.125-0.41,0.112\n	c-2.432,0.013-4.867,0.048-7.299,0.061c-0.285,0.024-0.514-0.165-0.752-0.287c0.02-0.336,0.023-0.671,0.014-1.005\n	c-0.857-0.104-1.963-0.331-2.271-1.26c-0.137-1.304,0.039-2.63,0.404-3.888c0.508-1.68,1.037-3.354,1.625-5.009\n	c0.244-0.713,0.58-1.387,0.912-2.062c0.545-1.094,1.359-2.033,1.84-3.159c0.301-1.049,0.082-2.383-0.912-2.996\n	c-0.949-0.607-2.104-0.233-3.146-0.309c-0.412-0.214-0.213-0.778-0.238-1.151c0.996-0.324,2.227-0.25,2.979-1.092\n	c0.346-0.299,0.287-0.771,0.338-1.181C7.915,8.958,7.679,8.373,7.261,7.99C6.958,7.713,6.583,7.403,6.622,6.947\n	C6.56,6.554,6.806,6.246,7.05,5.974C7.255,5.88,7.454,5.76,7.677,5.71c0.344-0.053,0.654,0.129,0.971,0.235\n	c0.258-0.368,0.578-0.689,0.885-1.019c0.609-0.036,1.219,0.013,1.826-0.018c0.162-0.279,0.244-0.597,0.348-0.902\n	c0.314-0.012,0.629-0.004,0.943,0.007c0.143,0.296,0.264,0.6,0.383,0.905C16.474,4.91,19.915,4.899,23.356,4.978z M7.79,6.364\n	c-0.082,0.029-0.25,0.089-0.334,0.12C7.382,6.6,7.308,6.716,7.233,6.833c0.119,0.279,0.35,0.483,0.66,0.512\n	c0.115-0.169,0.377-0.286,0.332-0.525C8.296,6.548,7.956,6.48,7.79,6.364z M26.696,12.881c-0.863-0.078-1.592,0.523-2.432,0.571\n	c-0.002,0.135-0.004,0.269-0.008,0.404c-0.244,0.422-0.645,0.761-0.758,1.249c-0.166,0.798,0.023,1.709,0.643,2.269\n	c0.307,0.277,0.748,0.498,0.768,0.968c-0.85,0.015-1.402-0.724-1.859-1.334c-0.547-0.812-0.074-1.789-0.127-2.673\n	c0.029-0.2-0.172-0.313-0.264-0.462c0-0.098,0.006-0.295,0.008-0.393c-0.666-0.026-1.234,0.384-1.699,0.817\n	c-0.531,0.518-0.939,1.24-0.871,2.004c0.07,1.087,0.949,1.979,1.961,2.284c1.66,0.378,3.461,0.238,4.986-0.546\n	c0.846-0.397,1.496-1.194,1.684-2.11c0.068-0.685,0.059-1.446-0.355-2.03C28.003,13.323,27.353,13,26.696,12.881z\"/>\n<rect id=\"sliceCopy_x5F_33_1_\" x=\"56.166\" fill=\"none\" width=\"52.354\" height=\"40\"/>\n<rect id=\"sliceCopy_x5F_32_1_\" fill=\"none\" width=\"56.167\" height=\"40\"/>\n</svg>",
        [64]    = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 1.1//EN\" \"http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd\" [\n	<!ENTITY ns_flows \"http://ns.adobe.com/Flows/1.0/\">\n]>\n<svg version=\"1.1\"\n	 xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" xmlns:a=\"http://ns.adobe.com/AdobeSVGViewerExtensions/3.0/\"\n	 x=\"0px\" y=\"0px\" width=\"73px\" height=\"40px\" viewBox=\"0.77 0 73 40\" enable-background=\"new 0.77 0 73 40\" xml:space=\"preserve\">\n<defs>\n</defs>\n<path fill=\"#FFFFFF\" d=\"M67.963,5.501c0,1.125,1.094,1.697,1.189,2.859c0.041,0.508-0.045,0.981,0.025,1.49c0.1,0.688-0.117,1.155-0.34,1.818\n	c-0.113,0.344,0.082,1.061,0.045,1.466c-0.021,0.208-0.143,1.268-0.451,1.268c-0.514,0-1.023,0-1.535,0c-6.262,0-12.52,0-18.779,0\n	c-2.416,0-4.832,0-7.25,0c-0.832,0-0.725-0.034-1.104,0.82c-0.383,0.856-0.645,1.706-0.744,2.64\n	c-0.043,0.402,0.035,1.521-0.189,1.857c-0.41,0.618-2.184,0.163-2.994,0.422c-0.682,0.218-3.314,0.631-3.314,1.38\n	c0,1.442,0.021,3.16-1.184,4.155c-0.994,0.82-2.537,0.919-3.764,0.919c-1.018,0-2.311,0.199-3.172-0.507\n	c-0.945-0.775-1.633-1.451-2.035-2.658c-0.055-0.165-0.404-1.703-0.742-1.151c-0.15,0.245,0.217,1.47,0.268,1.743\n	c0.131,0.724-0.195,0.669-0.74,0.443c-0.453-0.189-1.047-0.396-1.531-0.292c-0.619,0.132-1.203,0.262-1.834,0.305\n	c-0.457,0.03-0.105,1.008-0.158,1.39c-0.088,0.61-0.176,1.222-0.264,1.833c-0.061,0.422-0.65,0.978-0.9,1.344\n	c-0.451,0.66-0.627,0.797-0.52,1.572c0.092,0.665,0.123,1.272,0.123,1.945c0,0.666-0.373,0.646-0.848,1.083\n	c-0.586,0.543-0.66,0.721-0.879,1.475c-0.098,1.091-2.1,0.874-2.979,0.84c-1.289-0.049-2.57-0.111-3.857-0.201\n	c-1.121-0.078-2.223,0.146-2.932-0.855c-0.855-1.212-0.547-2.532-0.381-3.908c0.408-3.355,1.795-6.53,3.404-9.458\n	c0.518-0.939,1.049-1.873,1.545-2.825c0.576-1.105,1.404-2.266,1.799-3.447c0.18-0.542,0.148-1.096,0.391-1.625\n	c0.193-0.426,0.445-0.292,0.795-0.478c0.283-0.151,0.459-0.586,0.742-0.77c0.543-0.352,1.395-0.378,2.012-0.498\n	c0.717-0.139,0.717-0.285,1.232-0.771c0.434-0.409,0.713-0.786,1.291-0.918c0.316-0.073,0.633-0.146,0.949-0.219\n	c0.262-0.06,0.658,0.105,0.895-0.007c1.135-0.54,0.027-1.776-0.809-1.833c-0.539-0.036-1.338,0.563-1.727-0.001\n	c0.561-0.248,1.117-0.524,1.73-0.421c0.689,0.115,1.279,0.314,1.982,0.314c0.594,0,0.32-0.013,0.656-0.379\n	c0.205-0.221,0.424-0.433,0.654-0.626c0.646-0.539,1.201-0.399,2.045-0.399c-0.332-0.197-1.287-0.536-1.457-0.863\n	c-0.08-0.151-0.055-1.625,0.053-1.726c0.105-0.099,0.76,0,0.912,0c0.33,0,0.027,0.323,0.244,0.323c0.43,0,0.41-0.044,0.41,0.384\n	c0,0.329,0.199,0.208,0.506,0.208c0.477,0,1.494-0.206,1.922,0c0.145,0.069,0.291,0.485,0.449,0.485c0.295,0,0.59,0,0.885,0\n	c0.971,0,1.955,0.108,2.895,0.108c2.93,0,5.861,0,8.791,0c0.551,0,0.725,0.216,1.203,0.216c0.896,0,1.791,0,2.686,0\n	c5.338,0,10.676,0,16.014,0c1.518,0,3.035,0,4.555,0c0.648,0,1.418-0.447,2.02-0.655C66.25,4.983,66.617,4.8,67.023,4.8\n	c0.348,0,0.434-0.092,0.512,0.247C67.604,5.341,67.578,5.614,67.963,5.501 M46.654,7.065c0.23-0.784-1.373-0.431-1.838-0.431\n	c-0.623,0-1.244,0-1.865,0c-0.148,0-0.936-0.109-1.045,0c-0.592,0.6,1.709,0.431,1.838,0.431\n	C44.715,7.065,45.684,7.065,46.654,7.065 M56.58,7.012c0.23-0.702-1.727-0.377-2.139-0.377c-0.922,0-1.846,0-2.77,0\n	c-0.039,0.71,1.645,0.379,2.088,0.379C54.699,7.012,55.641,7.012,56.58,7.012 M61.436,7.065c0.924,0,1.846,0,2.77,0\n	c0.543,0,1.086,0,1.629,0c0.109,0,0.859,0.066,0.512-0.323c-0.072-0.081-0.703,0-0.809,0c-0.652,0-1.307,0-1.961,0\n	C63.186,6.742,61.262,6.45,61.436,7.065 M29.066,20.769c-0.441,0.284-0.764,0.488-1.268,0.621c-0.672,0.177-0.963,0.022-1.117,0.748\n	c-0.189,0.878,0.111,1.413,0.523,2.144c0.094,0.167,0.438,0.408,0.268,0.549c-0.33,0.275-0.346,0.111-0.666-0.16\n	c-0.885-0.75-1.174-1.676-1.445-2.756c-0.021-0.092-1.188-0.406-1.311-0.38c-0.594,0.132-1.15,0.281-1.727,0.473\n	c0.234,0.626,0.467,1.25,0.73,1.863c0.395,0.922,0.676,1.139,1.504,1.731c1.148,0.819,3.412,0.771,4.766,0.449\n	c1.09-0.259,1.732-0.712,2.289-1.673c0.32-0.554,0.244-1.424,0.301-2.057c0.092-1.012,0.076-0.956-0.861-1.301\n	C30.516,20.823,29.367,20.022,29.066,20.769\"/>\n<rect id=\"sliceCopy_x5F_24_1_\" x=\"73.203\" fill=\"none\" width=\"50.463\" height=\"40\"/>\n<rect id=\"sliceCopy_x5F_23_1_\" fill=\"none\" width=\"73.203\" height=\"40\"/>\n</svg>",
        [500]   = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 1.1//EN\" \"http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd\" [\n	<!ENTITY ns_flows \"http://ns.adobe.com/Flows/1.0/\">\n]>\n<svg version=\"1.1\"\n	 xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" xmlns:a=\"http://ns.adobe.com/AdobeSVGViewerExtensions/3.0/\"\n	 x=\"0px\" y=\"0px\" width=\"93px\" height=\"40px\" viewBox=\"0.769 0 93 40\" enable-background=\"new 0.769 0 93 40\" xml:space=\"preserve\">\n<defs>\n</defs>\n<path fill=\"#FFFFFF\" d=\"M89,19.84c-5.682-0.877-11.365-1.754-17.046-2.631c-0.346-0.054-0.704-0.028-1.053-0.028\n	c-1.146-0.005-2.292-0.009-3.438-0.014c-3.738-0.016-7.479-0.031-11.218-0.046c-3.681-0.015-7.361-0.03-11.041-0.044\n	c-1.07-0.005-2.141-0.009-3.213-0.014c-0.213-0.001-0.426-0.001-0.639-0.002c-0.321-0.001-0.609,0.402-0.996,0.402\n	c-0.844,0-1.688,0-2.531,0c-0.62,0-0.684,0.138-0.684-0.463c0-1.774,0-3.548,0-5.323c0-0.23,0-0.458,0-0.688\n	c0-0.171-0.516-0.073-0.648-0.073c-0.096,0-0.648-0.062-0.648,0.044c0,0.226,0,0.452,0,0.678c0,1.808,0,3.615,0,5.423\n	c0,0.348,0.176,0.804-0.221,0.804c-0.887,0-1.772,0-2.658,0c-0.33,0-0.66,0-0.99,0c-0.25,0-0.292,0.361-0.604,0.418\n	c-0.288,0.051-0.537-0.081-0.701-0.311c-0.076-0.105-0.063-0.107-0.18-0.107c-0.419,0-0.839,0-1.258,0c-0.42,0-0.84,0-1.26,0\n	c-0.372,0-0.503,0.419-0.901,0.371c-0.232-0.029-0.442-0.371-0.615-0.371c-0.393,0-0.786,0-1.18,0c-0.436,0-0.871,0-1.307,0\n	c-0.096,0-0.192,0-0.288,0c-0.016,0-0.134,0.15-0.121,0.136c-0.116,0.138-0.323,0.234-0.504,0.234\n	c-0.412,0.045-0.503-0.37-0.88-0.374c-0.466-0.005-0.932-0.011-1.396-0.016c-0.333-0.004-0.667-0.008-1-0.013\n	c-0.077-0.001-0.127,0.123-0.159,0.176c-0.055,0.09-0.382,0.196-0.487,0.194c-0.149-0.002-0.354-0.124-0.496-0.174\n	c-0.077-0.026-0.148-0.196-0.221-0.196c-0.34,0-0.68,0-1.019,0c-0.455,0-0.91,0-1.365,0c-0.362,0-0.349,0.051-0.662,0.198\n	c-0.295,0.138-0.553,0.305-0.837,0.021c-0.258-0.258-0.617-0.148-0.973-0.141c-0.765,0.017-1.283-0.198-2.01-0.462\n	c-0.375-0.137-0.978-0.022-1.369-0.023c-1.676-0.009-3.351-0.016-5.026-0.024c-0.513-0.003-0.956,0.498-1.063,0.957\n	c-0.156,0.665-0.064,1.445-0.083,2.123c-0.018,0.622-0.01,1.245-0.01,1.867c0,0.339,0,0.678,0,1.015\n	c0,0.265,0.292,0.657,0.405,0.896c0.048,0.104,0.294,0.646,0.369,0.646c0.168,0,0.336,0,0.504,0c0.851,0,1.702,0,2.554,0\n	c0.951,0,1.902,0,2.853,0c0.407,0,0.874,0.08,1.257-0.077c0.319-0.131,0.676-0.346,1.016-0.417c0.346-0.071,0.778,0,1.131,0\n	c0.343,0,0.437-0.063,0.738-0.154c0.226-0.07,0.427-0.087,0.602,0.123c0.121,0.079,0.074,0.154,0.221,0.154c0.847,0,1.692,0,2.539,0\n	c0.411,0,0.297-0.068,0.627-0.288c0.482-0.322,0.621,0.288,1.002,0.288c0.842,0,1.685,0,2.526,0c0.35,0,0.451-0.446,0.898-0.318\n	c0.106,0.03,0.312,0.318,0.377,0.318c0.124,0,0.248,0,0.371,0c0.813,0,1.626,0,2.438,0c0.064,0,0.224-0.223,0.285-0.257\n	c0.282-0.162,0.67-0.082,0.894,0.142c0.199,0.198,0.516,0.115,0.787,0.115c0.474,0,0.946,0,1.419,0c0.155,0,0.708,0.092,0.813-0.04\n	c0.29-0.364,0.697-0.314,1.079-0.144c0.277,0.121,0.275,0.154,0.616,0.154c0.921,0,1.843,0,2.764,0c0.257,0,0.514,0,0.771,0\n	c0.043,0,0.019,0.414,0.019,0.462c0,0.933,0,1.865,0,2.798c0,0.362,0,0.724,0,1.085c0,0.307-0.005,0.256,0.32,0.256\n	c0.09,0,0.915,0.023,0.915-0.021c0.003-0.298,0.005-0.596,0.008-0.894c0.007-0.886,0.015-1.772,0.021-2.657\n	c0.002-0.24-0.034-0.228,0.182-0.228c0.268-0.001,0.535-0.001,0.803-0.003c1.079-0.001,2.158-0.003,3.237-0.005\n	c3.564-0.006,7.13-0.011,10.694-0.019c6.643-0.011,13.283-0.022,19.924-0.034c1.755-0.002,3.519-0.142,5.263-0.343\n	c2.595-0.3,5.132-0.848,7.493-1.999C86.378,22.103,87.671,21.058,89,19.84 M76.491,19.532c0.356,0.204,0.541,0.52,0.452,0.925\n	c-0.025,0.116-0.085,0.742-0.31,0.742c-0.632,0-1.264,0-1.897,0c-0.289,0-0.563-0.61-0.563-0.833\n	c-0.02-0.197,0.238-0.861,0.505-0.866c0.356-0.007,0.716-0.013,1.076-0.019C75.974,19.478,76.304,19.398,76.491,19.532\"/>\n<rect id=\"sliceCopy_x5F_18_1_\" x=\"92.999\" fill=\"none\" width=\"93\" height=\"40\"/>\n<rect id=\"sliceCopy_x5F_17_1_\" fill=\"none\" width=\"93\" height=\"40\"/>\n</svg>",
        [505]   = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 1.1//EN\" \"http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd\" [\n	<!ENTITY ns_flows \"http://ns.adobe.com/Flows/1.0/\">\n]>\n<svg version=\"1.1\"\n	 xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" xmlns:a=\"http://ns.adobe.com/AdobeSVGViewerExtensions/3.0/\"\n	 x=\"0px\" y=\"0px\" width=\"88px\" height=\"40px\" viewBox=\"0.77 0 88 40\" enable-background=\"new 0.77 0 88 40\" xml:space=\"preserve\">\n<defs>\n</defs>\n<path fill=\"#FFFFFF\" d=\"M79.889,13.682c-2.439,0.664-4.924,1.355-7.436,1.676c-1.604,0.205-3.207,0.41-4.813,0.614\n	c-2.414,0.309-4.881,0.404-7.314,0.508c-5.094,0.217-10.201-0.132-15.18-1.259c-0.203-0.046-0.66-0.257-0.838-0.217\n	c-0.152,0.035-0.359,0.266-0.486,0.36c-0.127,0.093-0.301,0.034-0.453,0.022c0.016,0.085-0.018,0.179,0,0.264\n	c-0.117-0.039-0.234-0.078-0.352-0.117c0,0.117,0,0.234,0,0.352c-0.107-0.049-0.215-0.098-0.324-0.146\n	c-0.002,0.088-0.055,0.176-0.059,0.264c-0.324-0.108-0.33-0.169-0.471,0.146c-0.063-0.042-0.239-0.21-0.287-0.144\n	c-0.154,0.216-0.158,0.155-0.389,0.026c-0.013,0.081-0.076,0.154-0.088,0.235c-0.188-0.127-0.361,0.073-0.412,0.037\n	c-0.275-0.191-0.247-0.203-0.469,0.05c-0.078-0.078-0.156-0.156-0.235-0.234c-0.3,0.374-0.313,0.251-0.728,0.026\n	c-0.57-0.309-1.209-0.451-1.852-0.504c-0.58-0.048-1.17-0.024-1.753-0.022c-1.602,0.008-3.203,0.015-4.806,0.022\n	c-2.246,0.01-4.503,0.002-6.746,0.14c-1.594,0.097-3.188,0.195-4.781,0.292c-1.25,0.076-2.506,0.373-3.741,0.569\n	c-1.171,0.186-2.333,0.608-3.452,0.987c-1.543,0.524-3.029,1.034-4.334,2.036c-1.242,0.954-2.328,2.092-3.205,3.392\n	c-0.393,0.584-0.834,1.046-0.885,1.756c-0.045,0.637,0.92,0.946,1.334,1.153c0.23,0.116,0.225,0.584,0.277,0.82\n	c0.059,0.263,0.43,0.33,0.664,0.422c0.462,0.18,1.135,0.35,1.615,0.184c0.389-0.134,0.775-0.267,1.163-0.401\n	c0.492-0.169,0.829-0.514,1.243-0.831c1.248-0.958,2.518-1.868,4.072-2.238c0.803-0.19,1.683-0.264,2.506-0.279\n	c1.771-0.033,3.544,0.28,5.233,0.798c0.526,0.162,0.968,0.425,1.515,0.347c0.264-0.037,0.631-0.422,0.849-0.574\n	c0.913-0.636,2.13-1.015,3.239-1.033c0.711-0.011,1.415,0.133,2.083,0.369c0.413,0.144,0.896,0.545,1.321,0.515\n	c0.318-0.023,0.504-0.266,0.773-0.434c0.58-0.362,1.239-0.597,1.916-0.691c1.133-0.16,1.952,0.127,2.752,0.884\n	c0.406,0.385,0.692,0.688,0.99,1.158c0.346,0.542,0.444,0.841,1.119,0.919c0.538,0.063,0.727-0.021,1.084-0.377\n	c0.423-0.423,0.845-0.845,1.267-1.267c0.083,0.33,0.165,0.661,0.249,0.992c0.067,0.27,0.186,0.184,0.462,0.184\n	c0.81,0,1.62,0,2.431,0c0.246,0,0.525-0.371,0.748-0.482c0.396-0.199,0.766,0.016,1.16,0.139c0.242,0.075,0.428,0.316,0.658,0.173\n	c0.471-0.296,0.799-0.441,1.328-0.271c0.098,0.031,0.725,0.32,0.752,0.299c0.227-0.182,0.58-0.451,0.879-0.475\n	c0.191-0.016,0.656,0.092,0.822,0.193c0.07,0.043,0.313,0.248,0.379,0.198c0.205-0.154,0.4-0.311,0.637-0.414\n	c0.369-0.161,0.705-0.031,1.08,0.047c0.113,0.024,0.234,0.211,0.344,0.21c0.123-0.002,0.434-0.298,0.555-0.362\n	c0.498-0.264,0.783-0.195,1.305-0.094c0.127,0.024,0.229,0.103,0.342,0.167c0.16,0.094,0.283-0.099,0.42-0.206\n	c0.494-0.388,1.08-0.643,1.633-0.191c0.367,0.301,0.498,0.212,0.975,0.136c0.678-0.109,1.355-0.21,2.033-0.314\n	c2.795-0.43,5.625-1.018,8.289-1.986c2.977-1.082,5.939-2.522,8.543-4.333c1.752-1.219,3.424-2.55,5.1-3.869\n	c0.621-0.488,1.24-0.976,1.859-1.463C82.631,12.918,81.26,13.3,79.889,13.682 M33.88,18.735c0-0.088-0.033-0.617,0.028-0.617\n	c0.25,0,0.501,0,0.752,0c0.563,0,1.125,0,1.688,0c-0.023,0.235-0.01,0.361,0.059,0.588C35.564,18.716,34.722,18.726,33.88,18.735\"/>\n<rect id=\"sliceCopy_x5F_23_1_\" x=\"88\" fill=\"none\" width=\"73.203\" height=\"40\"/>\n<rect id=\"sliceCopy_x5F_22_1_\" fill=\"none\" width=\"88\" height=\"40\"/>\n</svg>",
        [506]   = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 1.1//EN\" \"http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd\" [\n	<!ENTITY ns_flows \"http://ns.adobe.com/Flows/1.0/\">\n]>\n<svg version=\"1.1\"\n	 xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" xmlns:a=\"http://ns.adobe.com/AdobeSVGViewerExtensions/3.0/\"\n	 x=\"0px\" y=\"0px\" width=\"84px\" height=\"40px\" viewBox=\"0.769 0 84 40\" enable-background=\"new 0.769 0 84 40\" xml:space=\"preserve\">\n<defs>\n</defs>\n<path fill=\"#FFFFFF\" d=\"M78.014,17.543c-3.205-1.368-6.578-2.345-9.939-3.251c-0.588-0.158-1.015-0.275-1.5,0.163\n	c-0.313,0.279,0.337,0.461,0.496,0.516c0.294,0.102,0.597,0.189,0.881,0.319c0.643,0.296,1.276,0.533,1.82,0.984\n	c0.288,0.237,0.464,0.314,0.531,0.673c0.065,0.372,0.097,1.068-0.436,1.146c-0.377,0.055-0.752,0.11-1.128,0.166\n	c-0.208,0.03-0.542-0.135-0.749-0.204c-0.666-0.224-1.333-0.448-1.999-0.672c-2.114-0.71-4.229-1.432-6.388-2.001\n	c-1.448-0.382-2.934-0.622-4.401-0.914c-0.594-0.117-1.192-0.211-1.789-0.316c-0.225-0.04-0.494,0.339-0.702,0.294\n	c-0.395-0.085-0.29-0.567-0.746-0.392c-0.438,0.168-0.481,0.261-0.849-0.015c-0.389-0.292-0.479-0.157-0.94,0.02\n	c-0.267,0.103-0.478-0.261-0.67-0.442c-0.141-0.133-0.517,0.408-0.771,0.169c-0.382-0.357-0.351-0.338-0.825-0.111\n	c-0.293,0.14-0.577-0.174-0.84-0.333c-0.154-0.094-0.456,0.369-0.657,0.25c-0.416-0.247-0.492-0.408-0.908-0.17\n	c-0.413,0.236-0.42,0.091-0.787-0.22c-0.24-0.204-0.577,0.112-0.836,0.242c-0.112,0.056-0.512-0.537-0.607-0.458\n	c-0.36,0.298-0.391,0.469-0.792,0.225c-0.417-0.255-0.401-0.235-0.841-0.005c-0.445,0.232-0.36-0.188-0.756-0.355\n	c-0.098-0.041-0.3,0-0.402,0c-0.376,0-0.751,0-1.127,0c-2.545,0-5.054,0.024-7.594,0.167c-3.048,0.173-6.156,0.18-9.187,0.551\n	c-3.136,0.384-6.266,0.875-9.344,1.585c-0.657,0.151-1.306,0.297-1.971,0.41c-0.279,0.047-0.698,0.034-0.935,0.201\n	c-0.449,0.317-0.479,0.29-1.003,0.125c0.188,0.782-1.118,0.447-1.488,0.557c-0.582,0.174-1.017,1.312-1.264,1.758\n	c-0.725,1.307-1.437,2.627-2.081,3.975c-0.294,0.616-0.459,1.185-0.488,1.867c-0.042,0.948,0.391,1.801,1.257,2.19\n	c0.533,0.239,0.961,0.403,1.567,0.244c0.33-0.086,0.654-0.218,0.979-0.326c1.213-0.406,2.396-1.061,3.565-1.587\n	c0.597-0.269,1.055-0.451,1.691-0.567c0.578-0.106,1.154-0.222,1.734-0.305c1.212-0.173,2.419-0.368,3.637-0.475\n	c2.923-0.256,5.837-0.508,8.765-0.677c0.528-0.031,1.058-0.042,1.585-0.048c0.261-0.003,0.8-0.097,1.031,0.065\n	c0.695,0.486,1.181,1.059,2.098,0.83c0.289-0.072,0.609-0.391,0.856-0.555c0.558-0.371,1.05-0.805,1.672-1.075\n	c1.072-0.465,2.07-0.532,3.196-0.394c0.388,0.046,0.775,0.093,1.162,0.141c0.602,0.073,1.26,0.501,1.772,0.802\n	c1.065,0.626,1.605,1.659,1.845,2.85c0.071,0.356,0.143,0.713,0.214,1.069c0.01,0.048,0.324,0.101,0.372,0.114\n	c0.223,0.063,0.209-0.002,0.354-0.189c0.135-0.176,0.525-0.258,0.683-0.055c0.301,0.387,0.368,0.472,0.368,0.956\n	c0,0.193,1.121,0.089,1.305,0.089c0.956,0,1.913,0,2.867,0c0.927,0,1.851,0.006,2.776-0.021c3.039-0.087,6.126-0.018,9.155-0.29\n	c4.409-0.396,8.899-1.431,12.867-3.445c2.53-1.283,4.563-3.103,6.623-5C79.338,18.104,78.676,17.824,78.014,17.543 M6.646,23.41\n	c0.367,0.521,0.544,0.862,0.287,1.474c-0.129,0.306-0.843,0.85-1.215,0.713c-0.633-0.233-0.896-0.47-1.052-1.136\n	C4.409,23.366,5.906,22.854,6.646,23.41\"/>\n<rect id=\"sliceCopy_x5F_21_1_\" x=\"84\" fill=\"none\" width=\"88\" height=\"40\"/>\n<rect id=\"sliceCopy_x5F_20_1_\" fill=\"none\" width=\"84\" height=\"40\"/>\n</svg>",
        [507]   = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 1.1//EN\" \"http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd\" [\n	<!ENTITY ns_flows \"http://ns.adobe.com/Flows/1.0/\">\n]>\n<svg version=\"1.1\"\n	 xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" xmlns:a=\"http://ns.adobe.com/AdobeSVGViewerExtensions/3.0/\"\n	 x=\"0px\" y=\"0px\" width=\"83px\" height=\"40px\" viewBox=\"0.769 0 83 40\" enable-background=\"new 0.769 0 83 40\" xml:space=\"preserve\">\n<defs>\n</defs>\n<path fill=\"#FFFFFF\" d=\"M72.746,17.599c-2.281-2.65-5.035-4.742-8.083-6.41c-2.328-1.275-4.773-2.445-7.396-2.961\n	c-1.687-0.332-3.375-0.771-5.091-0.904c-1.203-0.093-2.407-0.187-3.611-0.279c-0.365-0.028-0.732-0.057-1.099-0.084\n	c-0.06-0.005-0.278-0.634-0.393-0.779c-0.4-0.509-1.96,0.013-2.576,0.093c-0.283,0.036-0.696,0.582-0.906,0.768\n	c-0.578,0.515-1.319,0.854-2.038,1.133c-1.966,0.765-4.344,0.954-6.443,0.77c-0.354-0.032-0.795-0.129-1.149-0.093\n	c-0.177,0.018-0.379,0.172-0.554,0.159c-0.199-0.016-0.484-0.226-0.662-0.309c-0.361-0.168-0.463-0.261-0.832-0.172\n	c-0.592,0.142-1.185,0.285-1.777,0.428c-3.575,0.86-6.974,2.02-10.221,3.767c-0.763,0.41-1.518,0.835-2.275,1.255\n	c-0.13,0.072-0.116,0.104-0.162,0.262c-0.039,0.14-0.248,0.186-0.372,0.248c-0.293,0.147-0.611,0.279-0.794,0.554\n	c-0.176,0.263-0.316,0.462-0.635,0.537c-0.603,0.142-0.979,0.059-1.1,0.782c-0.086,0.513-0.19,0.292-0.522,0.287\n	c-0.397-0.006-1.061,0.078-0.989,0.633c-0.134,0.351-0.14,0.569-0.506,0.661c-0.246,0.062-0.496-0.265-0.771-0.265\n	c-0.298,0-0.498,0.218-0.599,0.475c-0.17,0.437-0.093,0.775-0.597,0.826c-0.313,0.031-0.995-0.336-0.912,0.322\n	c0.111,0.881-1.259,0.505-1.559,0.933c-0.298,0.425-0.438,0.896-0.58,1.385c-0.126,0.434,0.029,0.473,0.338,0.809\n	c-0.292,0.152-0.782,0.268-0.878,0.599c-0.12,0.422-0.24,0.844-0.361,1.266c-0.265,0.919-0.534,1.838-0.788,2.759\n	c-0.23,0.841-0.638,1.667-1.098,2.403c-0.186,0.298-0.724,0.863-0.754,1.206c-0.061,0.705,1.965,0.803,2.431,0.909\n	c0.3,0.067,0.49,0.289,0.752,0.446c0.436,0.262,0.873,0.523,1.31,0.785c1.56,0.936,3.383,1.544,5.188,1.082\n	c2.735-0.7,4.913-3.199,5.161-6.024c0.031-0.362,0.039-0.713,0.039-1.077c0.33,0.259,0.502-0.434,0.609-0.619\n	c0.354-0.613,0.697-1.223,1.204-1.73c1.146-1.146,2.712-1.003,4.197-0.879c0.417,0.034,0.466-0.313,0.689-0.639\n	c0.462-0.679,0.948-1.318,1.596-1.838c1.503-1.208,3.476-1.575,5.3-1.002c0.646,0.203,0.64,0.322,0.946-0.29\n	c0.429-0.858,1.19-1.648,1.979-2.187c1.566-1.069,3.699-1.063,5.231,0.07c0.823,0.609,1.53,1.469,1.998,2.377\n	c0.193,0.377,0.444,1.625,0.944,1.711c0.38,0.066,2.059-0.619,2.296-0.911c0.351-0.425-0.201-0.615,0.37-0.844\n	c0.331-0.131,0.652-0.242,0.991-0.346c1.432-0.434,2.851-0.838,4.327-1.106c2.614-0.474,5.276-0.598,7.917-0.361\n	c3.425,0.305,6.998,1.538,10.043,3.096c3.707,1.896,7.233,4.853,9.479,8.388c-0.236-2.076-1.183-4.143-2.131-5.981\n	C75.743,21.503,74.333,19.473,72.746,17.599 M11.362,22.941c0.811-0.022,1.612-0.114,2.395,0.159\n	c1.455,0.506,2.713,2.02,3.093,3.492c0.408,1.577,0.042,3.309-1.062,4.502c-0.86,0.929-1.741,1.289-2.942,1.398\n	c-1.111,0.101-1.828,0.042-2.843-0.574c-1.111-0.678-1.639-1.491-2.055-2.669c-0.411-1.165-0.238-2.368,0.129-3.537\n	C8.452,24.521,10.085,23.039,11.362,22.941\"/>\n<rect id=\"sliceCopy_x5F_20_1_\" x=\"83\" fill=\"none\" width=\"84\" height=\"40\"/>\n<rect id=\"sliceCopy_x5F_19_1_\" fill=\"none\" width=\"83.001\" height=\"40\"/>\n</svg>",
        [508]   = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 1.1//EN\" \"http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd\" [\n	<!ENTITY ns_flows \"http://ns.adobe.com/Flows/1.0/\">\n]>\n<svg version=\"1.1\"\n	 xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" xmlns:a=\"http://ns.adobe.com/AdobeSVGViewerExtensions/3.0/\"\n	 x=\"0px\" y=\"0px\" width=\"93px\" height=\"40px\" viewBox=\"0.77 0 93 40\" enable-background=\"new 0.77 0 93 40\" xml:space=\"preserve\">\n<defs>\n</defs>\n<path fill=\"#FFFFFF\" d=\"M86.75,22.427c0.75-0.46,1.5-0.92,2.25-1.379c-2.124-0.492-4.242-1.06-6.39-1.444c-3.32-0.595-6.639-1.189-9.958-1.785\n	c-1.713-0.307-3.426-0.614-5.138-0.921c-1-0.179-1.914-0.158-2.942-0.142c0.322,0.328,0.433,1.081-0.209,1.081\n	c-0.371-0.014-0.479-0.493-0.618-0.765c-0.157-0.302-0.388-0.2-0.724-0.206c-0.403-0.007-0.806-0.013-1.21-0.02\n	c0.397,0.262,0.685,1.142-0.052,1.161c-0.435,0.011-0.565-0.448-0.74-0.762c-0.241-0.431-0.205-0.457-0.686-0.474\n	c-0.406-0.015-0.814-0.03-1.222-0.045c0.241,0.311,0.7,1.019,0.122,1.234c-0.447,0.167-0.785-0.118-0.937-0.481\n	c-0.147-0.36-0.139-0.729-0.545-0.714c-0.447,0.017-0.895,0.034-1.342,0.051c0.315,0.301,0.58,1.286-0.161,1.207\n	c-0.47-0.049-0.585-0.486-0.76-0.847c-0.228-0.467-0.257-0.39-0.778-0.39c-0.425,0-0.848,0-1.271,0\n	c0.293,0.369,0.671,1.208-0.151,1.249c-0.473,0.023-0.587-0.515-0.75-0.849c-0.207-0.425-0.207-0.37-0.681-0.37\n	c-0.434,0-0.866,0-1.3,0c0.251,0.373,0.568,1.382-0.271,1.229c-0.383-0.059-0.499-0.554-0.659-0.858\n	c-0.221-0.418-0.289-0.352-0.77-0.398c-0.423-0.042-0.848-0.083-1.271-0.124c0.171,0.218,0.347,0.522,0.389,0.795\n	c0.075,0.48-0.408,0.638-0.765,0.435c-0.397-0.227-0.555-0.822-0.759-1.218c-0.066-0.129-1.249-0.064-1.402-0.07\n	c-0.505-0.021-1.009-0.042-1.515-0.063c0.229,0.264,0.516,0.645,0.504,1.005c-0.009,0.229-0.678,0.708-0.81,0.423\n	c-0.161-0.349-0.323-0.698-0.484-1.046c-0.135-0.291-0.403-0.478-0.635-0.697c-0.067-0.064-0.347-0.016-0.433-0.016\n	c-0.416,0-0.832,0-1.248,0c-0.902,0-1.804,0-2.706,0c-0.479,0-0.489,0.087-0.494-0.378c-0.009-0.748-0.018-1.497-0.026-2.245\n	c-0.02-1.634-0.039-3.269-0.058-4.902c-0.006-0.512-1.412-0.568-1.412-0.104c0,1.02,0,2.041,0,3.061c0,1.316,0,2.631,0,3.947\n	c0,0.315,0,0.63,0,0.945c0,0.118-0.266-0.004-0.271,0.086c-0.02,0.273-0.039,0.547-0.059,0.821\n	c-0.087-0.226-0.061-0.393-0.304-0.386c-0.369,0.011-0.736,0.021-1.105,0.033c-0.852,0.025-1.704,0.051-2.556,0.076\n	c-0.287,0.009-0.253,0.114-0.373,0.395c-0.032,0.076-0.323,0.009-0.402,0.004c-0.119-0.009-0.095-0.329-0.182-0.393\n	c-0.11-0.082-0.548-0.021-0.681-0.026c-0.49-0.019-0.981-0.037-1.473-0.056c-0.315-0.013-0.631-0.024-0.947-0.036\n	c-0.09-0.004-0.102,0.088-0.145,0.163c-0.13,0.226-0.113,0.253-0.37,0.27c-0.242,0.017-0.222,0.023-0.331-0.195\n	c-0.038-0.075-0.057-0.21-0.151-0.209c-0.335,0.003-0.669,0.006-1.003,0.009c-0.764,0.007-1.527,0.013-2.29,0.02\n	c-0.064,0-0.141,0.224-0.167,0.273c-0.109,0.206-0.111,0.176-0.348,0.152c-0.224-0.022-0.177-0.425-0.461-0.425\n	c-0.847,0-1.693,0-2.541,0c-0.323,0-0.331-0.018-0.545,0.236c-0.372,0.439-0.39-0.1-0.671-0.236\n	c-0.144-0.069-0.522,0.02-0.677,0.025c-0.497,0.019-0.992,0.037-1.488,0.055c-0.34,0.012-0.68,0.024-1.019,0.037\n	c-0.249,0.01-0.234,0.414-0.489,0.429c-0.37,0.022-0.425-0.052-0.738-0.184c-0.251-0.105-0.542-0.298-0.818-0.305\n	c-0.824-0.017-1.647-0.034-2.472-0.051c-1.176-0.025-2.437-0.197-3.601-0.057c-0.689,0.083-1.324,0.141-2.021,0.141\n	c-0.158,0-0.636-0.077-0.705,0.132c-0.102,0.301-0.077,0.589-0.077,0.908c0,1.293-0.347,2.541-0.232,3.848\n	c0.06,0.681,0.235,1.277,0.249,1.967c0.005,0.259-0.063,0.607,0.098,0.83c0.217,0.304,0.625,0.133,0.979,0.101\n	c0.161-0.014,0.323-0.028,0.485-0.042c0.033-0.003,0.205,0.214,0.253,0.239c0.226,0.115,0.622,0.091,0.877,0.102\n	c0.606,0.024,1.206,0.048,1.813,0.031c1.481-0.042,2.956-0.096,4.435-0.182c0.27-0.017,0.459-0.142,0.701-0.264\n	c0.342-0.17,0.439-0.287,0.843-0.287c0.188,0,0.193,0.444,0.419,0.452c0.37,0.014,0.74,0.027,1.11,0.04\n	c0.459,0.017,0.917,0.033,1.375,0.049c0.159,0.006,0.618,0.109,0.761,0.028c0.158-0.088,0.27-0.767,0.581-0.318\n	c0.224,0.324,0.226,0.287,0.606,0.28c0.851-0.017,1.702-0.032,2.553-0.048c0.33-0.006,0.173-0.269,0.431-0.395\n	c0.409-0.199,0.313,0.451,0.533,0.451c0.633,0,1.265,0,1.897,0c0.431,0,1.335,0.212,1.546-0.21c0.074-0.149,0.437-0.397,0.57-0.151\n	c0.133,0.247,0.117,0.364,0.383,0.354c0.761-0.028,1.521-0.057,2.282-0.084c0.24-0.01,0.48-0.018,0.721-0.027\n	c0.217-0.007,0.032-0.464,0.337-0.44c0.16,0.013,0.235-0.027,0.292,0.121c0.019,0.047,0.075,0.287,0.129,0.289\n	c0.212,0.004,0.422,0.009,0.633,0.014c0.811,0.019,1.621,0.037,2.433,0.055c0.276,0.006,0.553,0.011,0.83,0.019\n	c0.191,0.004,0.207-0.196,0.288-0.357c0.01,0.133-0.013,0.794,0.103,0.819c0.279,0.062,0.228,0.069,0.23,0.339\n	c0.009,0.794,0.016,1.59,0.024,2.385c0.008,0.883,0.018,1.767,0.027,2.65c0.001,0.195,0.004,0.393,0.005,0.589\n	c0.002,0.092,0.619,0.238,0.69,0.238c0.063,0,0.69-0.129,0.69-0.243c0.001-0.186,0.002-0.37,0.003-0.555\n	c0.005-0.878,0.01-1.757,0.014-2.635c0.004-0.785,0.009-1.571,0.013-2.355c0-0.052-0.034-0.243,0.03-0.243\n	c0.231-0.001,0.463-0.002,0.694-0.004c1.631-0.008,3.264-0.016,4.895-0.026c0.511-0.003,1.021,0.186,1.44,0.456\n	c0.248,0.159,0.164,0.204,0.448,0.202c2.325-0.011,4.65-0.023,6.976-0.035c7.025-0.035,14.053-0.071,21.078-0.104\n	c0.827-0.004,1.648,0.006,2.473-0.053C79.374,25.844,83.249,24.503,86.75,22.427 M70.573,19.667c0.691,0,1.381,0,2.071,0\n	c0.323,0,0.536,0.26,0.628,0.56c0.182,0.594-0.06,1.095-0.551,1.421c-0.179,0.117-0.616,0.029-0.821,0.029c-0.387,0-0.774,0-1.161,0\n	c-0.296,0-0.689-0.349-0.793-0.599C69.693,20.467,70.131,20,70.573,19.667\"/>\n<rect id=\"sliceCopy_x5F_19_1_\" x=\"93.001\" fill=\"none\" width=\"83.001\" height=\"40\"/>\n<rect id=\"sliceCopy_x5F_18_1_\" fill=\"none\" width=\"93\" height=\"40\"/>\n</svg>",
        [509]   = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 1.1//EN\" \"http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd\" [\n	<!ENTITY ns_flows \"http://ns.adobe.com/Flows/1.0/\">\n]>\n<svg version=\"1.1\"\n	 xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" xmlns:a=\"http://ns.adobe.com/AdobeSVGViewerExtensions/3.0/\"\n	 x=\"0px\" y=\"0px\" width=\"88px\" height=\"40px\" viewBox=\"0.769 0 88 40\" enable-background=\"new 0.769 0 88 40\" xml:space=\"preserve\">\n<defs>\n</defs>\n<path fill=\"#FFFFFF\" d=\"M75.351,14.06c0.65,0.375,0.224,1.386-0.5,1.024c-0.275-0.138-0.425-0.41-0.566-0.669c-0.198-0.362-0.276-0.49-0.682-0.592\n	c0.181,0.202,0.372,0.484,0.326,0.771c-0.07,0.433-0.588,0.6-0.917,0.326c-0.222-0.157-0.455-0.435-0.577-0.678\n	c-0.217-0.436-0.248-0.553-0.728-0.655c0.228,0.312,0.327,0.935-0.029,1.185c-0.227,0.125-0.715,0.048-0.917-0.089\n	c-0.237-0.16-0.361-0.479-0.499-0.714c-0.195-0.334-0.23-0.494-0.628-0.529c0.206,0.319,0.445,0.806,0.06,1.096\n	c-0.281,0.19-0.626,0.003-0.872-0.145c-0.257-0.153-0.382-0.501-0.504-0.762c-0.176-0.375-0.219-0.426-0.639-0.456\n	c0.185,0.141,0.395,0.605,0.282,0.83c-0.091,0.18-0.081,0.262-0.276,0.275c-0.236,0.015-0.472,0.031-0.707,0.046\n	c-0.315,0.02-0.488-0.46-0.601-0.678c-0.177-0.338-0.268-0.553-0.652-0.592c0.084,0.167,0.335,0.687,0.188,0.851\n	c-0.204,0.228-0.479,0.451-0.791,0.235c-0.305-0.212-0.379-0.427-0.581-0.73c-0.243-0.365-0.3-0.578-0.74-0.652\n	c0.139,0.237,0.207,0.716,0.127,0.978c-0.12,0.394-0.763,0.343-1.031,0.178c-0.266-0.163-0.361-0.417-0.513-0.687\n	c-0.077-0.138-0.16-0.275-0.23-0.417c-0.115-0.231-0.137-0.201-0.397-0.201c0.096,0.21,0.122,0.563-0.01,0.752\n	c-0.184,0.266-0.561,0.504-0.861,0.202c-0.293-0.292-0.408-0.728-0.624-1.073c-0.186-0.296-0.652-0.185-0.945-0.136\n	c-0.528,0.088-1.087,0.507-1.573,0.75c-1.035,0.518-2.029,0.896-3.195,1.04c-2.778,0.341-5.755,0.023-8.492-0.498\n	c-0.989-0.188-1.979-0.376-2.969-0.564c-0.361-0.069-0.723-0.137-1.083-0.206c-0.133-0.025-0.386-0.021-0.497-0.105\n	c-0.291-0.218-0.58-0.466-0.916-0.614c-0.22-0.097-0.542,0.007-0.785,0.007c-0.475,0-0.902-0.359-1.352-0.472\n	c-0.519-0.128-0.948,0.185-1.377,0.43c-0.177,0.101-0.426-0.043-0.63,0.131c-0.167,0.144-0.347,0.256-0.546,0.349\n	c-0.168,0.079-0.523,0.319-0.609,0.105c-0.081-0.205-0.281,0.252-0.4,0.258c0.013-0.075-0.036-0.161-0.029-0.237\n	c-0.169-0.03-0.235,0.018-0.252,0.163c-0.013,0.116-0.162,0.239-0.208,0.08c-0.028-0.102-0.251-0.274-0.251-0.107\n	c0,0.139,0.009,0.39-0.236,0.309c-0.18-0.06,0.099-0.26-0.213-0.215c-0.147,0.021,0.033,0.293-0.091,0.309\n	c-0.322,0.04-0.086-0.151-0.23-0.183c-0.351-0.077-0.116,0.207-0.236,0.267c-0.261,0.13-0.504-0.377-0.504,0.082\n	c0,0.069-0.29,0.109-0.304,0.013c-0.023-0.167-0.259-0.217-0.259-0.07c0,0.167-0.1,0.239-0.296,0.183\n	c-0.196-0.055,0.086-0.244-0.26-0.157c-0.135,0.034,0.06,0.178-0.185,0.202c-0.239,0.024-0.143-0.178-0.369-0.141\n	c-0.122,0.021-0.001,0.179-0.149,0.192c-0.188,0.016-0.375,0.031-0.563,0.047c-0.306,0.025-0.613,0.032-0.919,0.047\n	c-0.656,0.032-1.298,0.042-1.954,0.032c-1.316-0.02-2.61-0.175-3.914-0.349c-3.037-0.405-6.049,0.425-8.828,1.597\n	c-1.652,0.696-3.226,1.467-4.962,1.921c-0.55,0.144-1.137,0.245-1.703,0.297c-0.744,0.068-1.154,0.192-1.581,0.833\n	c-0.346,0.519-0.655,1.044-1.071,1.509c-0.441,0.494-0.892,0.952-1.189,1.547c-0.322,0.645-0.009,1.094,0.405,1.616\n	c0.316,0.397,0.657,0.78,0.927,1.212c0.848,1.357,1.696,2.714,2.544,4.071c0.334,0.534,0.901,0.245,1.379,0.059\n	c0.533-0.207,0.898-0.988,1.237-1.435c0.533-0.7,1.079-1.453,1.872-1.875c0.581-0.263,1.2-0.3,1.795-0.479\n	c0.34-0.102,0.717-0.17,1.032-0.333c0.379-0.197,0.691-0.527,1.011-0.805c0.363-0.316,0.776-0.559,1.243-0.673\n	c0.291-0.07,0.678-0.248,0.979-0.223c0.726,0.058,1.377,0.096,2.07,0.313c0.26,0.081,0.556,0.263,0.816,0.306\n	c0.399,0.064,0.649-0.17,0.955-0.378c0.575-0.392,1.146-0.925,1.799-1.178c1.277-0.494,3.122,0.346,3.787,1.495\n	c0.342,0.59,0.682,1.163,1.064,1.727c0.62,0.914,1.08-0.472,1.248-0.897c0.454-1.149,1.086-2.177,2.347-2.565\n	c1.254-0.386,2.302,0.1,3.321,0.757c0.469,0.302,0.843,0.913,1.206,1.336c0.135,0.157,0.171-0.133,0.189,0.21\n	c0.007,0.131,0.018,0.262,0.018,0.393c0,0.32,0.054,0.626-0.093,0.913c-0.31,0.601-0.607,1.147-1.06,1.659\n	c-0.263,0.299-0.713,0.693-0.713,1.121c0.067,0.284,0.401,0.33,0.63,0.346c0.631,0.047,1.317,0.159,1.946,0.068\n	c0.615-0.088,0.914-0.252,1.056-0.86c0.327-1.403,0.646-2.805,0.942-4.215c0.145-0.686,1.368-0.43,1.855-0.427\n	c1.615,0.009,3.231,0.018,4.847,0.026c3.274,0.017,6.55,0.035,9.825,0.052c0.222,0.001,0.445-0.011,0.665,0.019\n	c0.582,0.077,1.143,0.256,1.603,0.636c0.291,0.214,0.555,0.47,0.747,0.776c0.074,0.118,0.135,0.489,0.23,0.557\n	c0.143,0.101,0.706,0.003,0.889,0c0.322-0.006,0.644-0.025,0.965-0.038c0.515-0.02,1.031-0.026,1.545-0.071\n	c1.647-0.149,3.292-0.296,4.938-0.445c2.246-0.202,4.508-0.801,6.657-1.461c0.713-0.22,1.426-0.439,2.139-0.659\n	c0.364-0.112,0.803-0.15,1.072-0.43c1.074-1.122,2.149-2.244,3.224-3.366c0.904-0.943,1.809-1.887,2.712-2.831\n	C81.117,14.79,78.233,14.425,75.351,14.06L75.351,14.06z M38.178,27.241c-0.795,0.693-1.822-0.559-0.955-1.128\n	c0.385-0.252,0.943-0.087,1.111,0.343C38.446,26.747,38.288,26.973,38.178,27.241C38.02,27.378,38.178,27.241,38.178,27.241z\"/>\n<rect id=\"sliceCopy_x5F_22_1_\" x=\"87.999\" fill=\"none\" width=\"88\" height=\"40\"/>\n<rect id=\"sliceCopy_x5F_21_1_\" fill=\"none\" width=\"88\" height=\"40\"/>\n</svg>",
        [512]   = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 1.1//EN\" \"http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd\" [\n	<!ENTITY ns_flows \"http://ns.adobe.com/Flows/1.0/\">\n]>\n<svg version=\"1.1\"\n	 xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" xmlns:a=\"http://ns.adobe.com/AdobeSVGViewerExtensions/3.0/\"\n	 x=\"0px\" y=\"0px\" width=\"88px\" height=\"40px\" viewBox=\"0.769 0 88 40\" enable-background=\"new 0.769 0 88 40\" xml:space=\"preserve\">\n<defs>\n</defs>\n<path fill=\"#FFFFFF\" d=\"M80.262,15.992c1.247-0.126,2.493-0.253,3.738-0.379c-0.065,0.26-0.317,0.445-0.493,0.629\n	c-0.285,0.297-0.569,0.595-0.854,0.893c-0.708,0.741-1.518,1.509-2.417,2.019c-1.701,0.967-3.377,2.025-5.253,2.626\n	c-2.75,0.881-5.685,1.103-8.541,1.364c-1.182,0.108-2.38,0.089-3.566,0.121c-0.574,0.015-1.153-0.023-1.729-0.04\n	c-0.548-0.017-1.135,0.028-1.676-0.062c-1.508-0.247-3.014-0.493-4.521-0.74c-1.211-0.198-2.41-0.547-3.606-0.827\n	c-1.241-0.289-2.674-0.117-3.949-0.134c-0.198-0.003-0.397-0.005-0.598-0.008c-0.051,0-0.206-0.283-0.237-0.328\n	c-0.125-0.173-0.479,0.18-0.648,0.242c-0.701,0.259-1.402,0.518-2.104,0.777c-0.771,0.284-1.747,0.824-2.583,0.771\n	c-0.366-0.024-0.621-1.002-0.733-1.29c-0.699-1.799-1.615-4.556-4.006-4.348c-0.939,0.082-1.809,0.159-2.358,1.049\n	c-0.171,0.277-0.371,0.551-0.518,0.842c-0.183,0.367-0.215,0.564-0.66,0.59c-0.637,0.037-1.362-0.192-1.979-0.304\n	c-0.532-0.095-1.042-0.175-1.579-0.223c-1.254-0.112-2.673-0.374-3.934-0.167c-0.637,0.104-1.271,0.201-1.901,0.34\n	c-0.565,0.124-1.288,0.388-1.868,0.344c-0.581-0.044-1.226-0.385-1.78-0.569c-0.766-0.255-1.859,0.628-2.296,1.192\n	c-0.464,0.602-0.597,1.37-0.971,2.018c-0.146,0.254-0.239,0.611-0.536,0.679c-0.391,0.088-0.824,0.244-1.139-0.094\n	c-0.557-0.599-1.068-1.376-1.926-1.472c-1.132-0.125-1.966,0.558-2.729,1.318c-1.136,1.132-2.124,2.396-3.175,3.603\n	c-0.427,0.491-0.829,1.087-1.322,1.51c-0.292,0.251-0.585,0.502-0.877,0.752c-0.271,0.233-0.439,0.408-0.652-0.02\n	c-0.396-0.795-0.267-1.731-0.251-2.585c0.028-1.478,0.573-3.022,1.19-4.346c1.441-3.097,4.168-5.237,7.049-6.943\n	c2.252-1.333,4.88-1.98,7.435-2.442c1.156-0.209,2.31-0.466,3.478-0.591c1.698-0.181,3.396-0.363,5.095-0.544\n	c0.366-0.039,0.882-0.194,1.249-0.125c0.205,0.038,0.489,0.195,0.673,0.201c0.376,0.012,0.751,0.024,1.127,0.036\n	c1.365,0.044,2.729,0.102,4.094,0.162c0.159,0.007,0.224-0.171,0.364-0.171c0.281,0,0.563,0,0.845,0c0.367,0,0.739-0.02,1.105,0.008\n	c1.068,0.083,2.136,0.165,3.204,0.247c1.497,0.116,2.993,0.23,4.49,0.346c0.476,0.037,0.953,0.073,1.429,0.11\n	c0.082,0.006,0.164,0.013,0.247,0.019c0.379,0.029,0.457,0.457,0.605,0.679c0.033,0.05,0.059-0.202,0.056-0.216\n	c-0.023-0.125-0.047-0.25-0.07-0.375c0.874,0.008,1.746,0.016,2.619,0.024c0.412,0.003,0.564-0.127,0.564,0.306\n	c0,0.239-0.006,0.196-0.241,0.196c-0.23,0-0.462,0-0.693,0c0.173,0.369,0.357,0.834,0.789,0.963\n	c0.191,0.049,0.473-0.011,0.669-0.016c0.875-0.021,1.749-0.041,2.624-0.062c1.225-0.029,2.448-0.136,3.67-0.212\n	c0.459-0.028,1.025-0.276,1.467-0.134c0.775,0.25,1.552,0.5,2.327,0.75c1.84,0.594,3.796,1.196,5.725,1.374\n	c2.528,0.233,5.057,0.466,7.585,0.699C76.636,16.194,78.419,16.074,80.262,15.992L80.262,15.992z\"/>\n<rect id=\"sliceCopy_x5F_17_1_\" x=\"88\" fill=\"none\" width=\"93\" height=\"40\"/>\n<rect id=\"sliceCopy_x5F_16_1_\" fill=\"none\" width=\"88\" height=\"40\"/>\n</svg>",
        [515]   = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 1.1//EN\" \"http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd\" [\n	<!ENTITY ns_flows \"http://ns.adobe.com/Flows/1.0/\">\n]>\n<svg version=\"1.1\"\n	 xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" xmlns:a=\"http://ns.adobe.com/AdobeSVGViewerExtensions/3.0/\"\n	 x=\"0px\" y=\"0px\" width=\"88px\" height=\"40px\" viewBox=\"0.77 0 88 40\" enable-background=\"new 0.77 0 88 40\" xml:space=\"preserve\">\n<defs>\n</defs>\n<path fill=\"#FFFFFF\" d=\"M81.719,16.672c-2.687,0.233-5.324,0.597-7.978-0.112c-1.418-0.379-2.739-1.008-3.988-1.769\n	c-0.284-0.174-0.567-0.348-0.852-0.521c-0.28-0.169-0.324-0.133-0.644-0.069c-1.189,0.24-2.353,0.525-3.563,0.604\n	c-1.765,0.115-3.53,0.23-5.295,0.345c-1.07,0.07-2.102-0.092-3.17-0.206c-1.321-0.141-2.658-0.227-3.964-0.471\n	c-0.65-0.122-1.31-0.221-1.953-0.369c-0.313-0.072-0.624-0.267-0.846-0.013c-0.38,0.435-0.724,0.72-1.298,0.843\n	c-0.399,0.085-0.806,0.201-1.215,0.223c-0.551,0.029-0.657-0.198-0.946-0.584c-0.434-0.575-1.26-1.158-2.035-0.923\n	c-1.293,0.392-2.531,0.977-3.908,0.896c-1.048-0.062-2.021-0.016-3.053-0.32c-0.938-0.277-1.703-0.752-2.689-0.86\n	c-1.288-0.139-2.527-0.267-3.82-0.267c-5.349,0-10.757,0.391-15.877,2.023c-1.929,0.615-3.891,1.188-5.739,2.017\n	c-0.679,0.304-1.313,0.704-1.958,1.073c-0.768,0.438-1.632,0.874-2.198,1.566c-0.209,0.255-0.42,0.506-0.636,0.755\n	c-0.287,0.332,0.16,0.667,0.373,0.923c0.388,0.465,0.81,0.912,1.253,1.324c0.452,0.421,0.83,0.907,1.437,0.487\n	c0.543-0.375,1.075-0.732,1.645-1.062c1.289-0.745,2.607-1.318,3.974-1.916c1.783-0.78,3.63-1.561,5.54-1.964\n	c1.413-0.299,2.843-0.704,4.272-0.903c1.484-0.207,2.968-0.414,4.451-0.62c2.427-0.338,4.933-0.33,7.374-0.216\n	c1.318,0.062,2.635,0.147,3.953,0.23c0.56,0.035,1.127,0.126,1.688,0.126c0.086,0,0.11,0.603,0.15,0.709\n	c0.129,0.338,0.238,0.59,0.449,0.881c-1.228-0.112-2.227-0.977-3.418-1.1c-1.468-0.151-2.932-0.283-4.403-0.398\n	c-2.473-0.194-5.024-0.1-7.486,0.188c-3.924,0.459-7.89,1.155-11.532,2.752c-1.91,0.838-3.916,1.634-5.664,2.777\n	c-0.606,0.396-1.261,0.73-1.734,1.282c-0.226,0.263,0.947,1.511,1.147,1.74c0.571,0.651,1.106,1.24,2.021,1.11\n	c0.148-0.021,0.241-0.482,0.344-0.592c0.27-0.292,0.531-0.472,0.866-0.691c1.518-0.993,3.337-1.583,5.018-2.249\n	c2.513-0.996,5.138-1.656,7.749-2.342c1.178-0.309,2.509-0.266,3.718-0.37c1.104-0.095,2.207-0.216,3.313-0.266\n	c1.688-0.077,3.374-0.153,5.062-0.23c1.228-0.055,2.497,0.252,3.713,0.41c1.125,0.145,2.256,0.255,3.384,0.382\n	c0.28,0.031,0.565,0.033,0.848,0.049c0.24,0.013,0.635-0.077,0.838,0.012c0.211,0.091,0.355,0.481,0.451,0.66\n	c0.24,0.44,0.411,0.86,0.363,1.359c-0.071,0.695-0.194,1.201-0.434,1.858c-0.058,0.159-0.432,0.417-0.229,0.595\n	c0.178,0.157,0.743-0.293,0.84-0.39c0.846-0.834,1.139-2.225,0.661-3.302c0.735,0.584,1.764-0.144,2.351-0.579\n	c0.171-0.126,0.234-0.316,0.332-0.504c0.061-0.114,0.062-0.442,0.131-0.495c0.24-0.185,0.472-0.399,0.789-0.435\n	c0.34-0.038,0.628,0.214,0.509,0.542c0.194-0.187,0.447-0.3,0.712-0.3c0.245,0,0.432,0.003,0.656,0.133\n	c0.152,0.088,0.252,0.351,0.402,0.407c0.178,0.066,1.872-0.083,1.9-0.179c0.062-0.2,0.024-0.372,0.237-0.346\n	c0.266,0.032,0.53,0.063,0.794,0.095c0.899,0.108,1.797,0.216,2.697,0.324c2.685,0.323,5.367,0.651,8.051,0.981\n	c1.209,0.149,2.42,0.332,3.632,0.447c1.238,0.118,2.53,0.371,3.775,0.314c1.356-0.062,2.705,0.024,3.983-0.457\n	c1.822-0.686,3.534-1.358,4.845-2.876c0.729-0.843,1.438-1.682,2.115-2.566C83.239,16.412,82.479,16.542,81.719,16.672\n	L81.719,16.672z M7.515,20.904c-0.778,0.778-1.727-0.719-0.759-1.118c0.383-0.158,0.874,0.079,0.955,0.495\n	C7.753,20.497,7.599,20.712,7.515,20.904C7.374,21.044,7.515,20.904,7.515,20.904z M10.307,19.914\n	c-0.716,0.716-1.741-0.561-0.844-1.107c0.383-0.234,0.91-0.002,1.029,0.424C10.559,19.464,10.394,19.702,10.307,19.914\n	C10.166,20.054,10.307,19.914,10.307,19.914z M30.418,15.081c-0.724,0.724-1.76-0.537-0.91-1.113\n	c0.369-0.25,0.898-0.084,1.067,0.325C30.693,14.58,30.526,14.817,30.418,15.081C30.277,15.221,30.418,15.081,30.418,15.081z\n	 M33.21,15.261c-0.711,0.71-1.757-0.508-0.91-1.082c0.354-0.241,0.894-0.095,1.067,0.302C33.489,14.759,33.315,15.004,33.21,15.261\n	C33.069,15.401,33.21,15.261,33.21,15.261z M12.827,23.275c-0.705,0.706-1.767-0.502-0.909-1.083\n	c0.342-0.232,0.815-0.107,1.026,0.239C13.13,22.736,12.946,22.987,12.827,23.275C12.688,23.416,12.827,23.275,12.827,23.275z\n	 M15.079,22.315c-0.644,0.644-1.74-0.363-1.021-0.99C14.699,20.682,15.801,21.682,15.079,22.315\n	C14.938,22.455,15.238,22.175,15.079,22.315z M35.701,19.073c-0.729,0.729-1.747-0.608-0.841-1.061\n	C35.506,17.69,36.287,18.488,35.701,19.073C35.562,19.213,35.841,18.933,35.701,19.073z M38.192,19.344\n	c-0.193,0.084-0.408,0.238-0.624,0.196c-0.425-0.08-0.702-0.542-0.524-0.947C37.486,17.585,38.994,18.655,38.192,19.344\n	C38.192,19.344,38.332,19.223,38.192,19.344z M56.413,16.882c-0.19-0.1-0.38-0.2-0.569-0.3c2.601,0.064,5.2,0.127,7.803,0.191\n	c1.702,0.042,3.407,0.083,5.11,0.125c0.501,0.012,1.003,0.024,1.504,0.037c0.386,0.01,0.433,0.073,0.771,0.338\n	C66.159,17.142,61.286,17.012,56.413,16.882L56.413,16.882z\"/>\n<rect id=\"sliceCopy_x5F_15_1_\" x=\"88\" fill=\"none\" width=\"88.001\" height=\"40\"/>\n<rect id=\"sliceCopy_x5F_14_1_\" fill=\"none\" width=\"88\" height=\"40\"/>\n</svg>",
        [516]   = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 1.1//EN\" \"http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd\" [\n	<!ENTITY ns_flows \"http://ns.adobe.com/Flows/1.0/\">\n]>\n<svg version=\"1.1\"\n	 xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" xmlns:a=\"http://ns.adobe.com/AdobeSVGViewerExtensions/3.0/\"\n	 x=\"0px\" y=\"0px\" width=\"88px\" height=\"40px\" viewBox=\"0.77 0 88 40\" enable-background=\"new 0.77 0 88 40\" xml:space=\"preserve\">\n<defs>\n</defs>\n<path fill=\"#FFFFFF\" d=\"M39.819,18.713c-3.816-2.521-8.456-3.205-12.911-3.655c-1.623-0.165-3.235-0.311-4.863-0.412\n	c-0.538-0.034-1.075-0.068-1.613-0.1c-0.159-0.01-0.318-0.02-0.479-0.03c-0.18-0.011-0.169-0.156-0.402-0.156\n	c-0.279-0.069-0.704,0.03-0.877-0.277c-0.225-0.399-0.446-0.789-0.7-1.168c-0.246-0.37-0.446-0.301-0.539,0.159\n	c-0.094,0.473-0.188,0.947-0.284,1.42c-0.203,1.018-0.425,1.974-1.147,2.757c-0.984,1.065-2.342,1.691-3.772,1.313\n	c-0.854-0.298-1.648-0.852-1.924-1.745c-0.147-0.478-0.106-1.026-0.133-1.523c-0.059-1.112,0.609-2.198,1.063-3.181\n	c0.227-0.489,0.27-0.789,0.023-1.25c-0.413-0.775-0.994-1.449-1.688-1.99C9.208,8.592,8.341,7.818,7.863,8.289\n	c-0.44,0.432-0.74,1.047-1.037,1.579c-0.912,1.633-1.894,3.363-2.373,5.185c-0.599,2.272-0.47,4.667-0.36,6.989\n	c0.062,1.277,0.086,2.79,0.668,3.954c0.381,0.835,0.833,1.644,1.248,2.462c0.539,1.065,1.062,2.352,1.961,3.167\n	c0.946,0.857,2.176-0.845,2.719-1.498c0.365-0.437,0.684-0.875,0.757-1.468c0.054-0.435-0.254-0.8-0.428-1.177\n	c-0.237-0.514-0.438-1.049-0.557-1.603c-0.169-0.794-0.134-1.824,0.188-2.578c0.377-0.881,1.509-1.326,2.402-1.386\n	c0.962-0.066,1.745,0.299,2.438,0.949c0.495,0.464,1.428,1.289,1.51,2.023c0.072,0.657,0.033,1.829,0.373,2.421\n	c0.525,0.918,0.96-1.144,1.193-1.299c0.612-0.407,1.681-0.378,2.405-0.446c1.608-0.147,3.206-0.312,4.809-0.513\n	c2.037-0.257,4.112-0.418,6.12-0.867c3.532-0.786,6.885-2.261,10.021-4.045C41.246,19.593,40.566,19.161,39.819,18.713\n	C38.268,17.688,39.819,18.713,39.819,18.713z M7.05,11.394c0.205-0.387,0.612-1.51,1.192-1.409c0.578,0.102,0.951,0.505,1.378,0.867\n	c0.518,0.44-0.164,2.463-0.291,3.055c-0.106,0.503-0.234,0.714-0.777,0.49c-0.391-0.161-0.767-0.391-1.143-0.583\n	c-0.348-0.177-0.797-0.322-0.997-0.673C6.158,12.694,6.852,11.774,7.05,11.394C7.551,10.444,6.55,12.345,7.05,11.394z M9.303,29.563\n	c-0.61,0.508-0.913,0.652-1.397,0.019c-0.363-0.473-0.652-0.97-0.944-1.487c-0.139-0.245-0.501-0.75-0.155-0.983\n	c0.413-0.282,0.818-0.581,1.249-0.833c0.472-0.276,1.125-0.642,1.398,0.019c0.167,0.403,0.218,0.896,0.321,1.321\n	c0.091,0.371,0.122,0.761,0.179,1.139C10.004,29.09,9.533,29.344,9.303,29.563C8.853,29.938,9.303,29.563,9.303,29.563z\n	 M9.378,22.392c-0.637,0.556-1.272,1.112-1.909,1.667c-0.654,0.57-1.59,0.685-1.999-0.33c-0.427-1.06-0.398-2.318-0.479-3.447\n	c-0.057-0.791-0.002-1.643,0.072-2.433c0.051-0.556,0.089-1.315,0.461-1.771c0.266-0.327,0.892-0.504,1.252-0.195\n	c0.684,0.589,1.368,1.179,2.053,1.768c0.82,0.707,1.698,1.433,2.367,2.289c0.21,0.271,0.087,0.409-0.114,0.66\n	C10.568,21.243,9.964,21.817,9.378,22.392C9.378,22.392,10.704,21.092,9.378,22.392z M83.212,19.502\n	c-2.466-1.479-4.867-2.786-7.706-3.406c-1.438-0.313-2.866-0.668-4.332-0.816c-1.719-0.175-3.439-0.411-5.162-0.516\n	c-1.706-0.105-3.629,0.018-5.172-0.578c-0.378-0.144-0.848-2.228-1.291-1.23c-0.289,0.654-0.317,1.537-0.495,2.244\n	c-0.384,1.536-1.231,2.638-2.747,3.282c-1.175,0.498-2.948,0.057-3.651-1.054c-0.587-0.93-0.518-2.49-0.158-3.482\n	c0.175-0.482,0.408-0.944,0.624-1.41c0.158-0.34,0.577-0.995,0.382-1.36c-0.319-0.602-0.668-1.163-1.143-1.66\n	c-0.448-0.467-1.448-1.513-2.189-1.363c-0.389,0.079-0.693,0.74-0.873,1.037c-0.543,0.895-1.023,1.83-1.493,2.764\n	c-0.774,1.545-1.384,3.083-1.585,4.809c-0.135,1.167-0.161,2.354-0.132,3.53c0.053,2.085,0.061,4.343,1.02,6.233\n	c0.44,0.871,0.873,1.746,1.325,2.611c0.448,0.857,1.338,3.207,2.664,2.566c0.889-0.429,1.891-1.565,2.267-2.482\n	c0.385-0.937-0.248-1.583-0.565-2.454c-0.346-0.946-0.413-1.85-0.229-2.837c0.358-1.937,2.909-2.556,4.434-1.521\n	c0.735,0.5,1.458,1.27,1.894,2.05c0.255,0.458,0.243,0.987,0.301,1.497c0.032,0.296,0.329,2.197,0.796,1.404\n	c0.215-0.364,0.381-0.674,0.514-1.072c0.161-0.484,0.742-0.493,1.194-0.557c1.46-0.208,2.937-0.271,4.399-0.456\n	c2.037-0.255,4.072-0.512,6.108-0.767c4.156-0.522,8.183-2.312,11.793-4.365C83.736,19.928,83.475,19.715,83.212,19.502\n	L83.212,19.502z M49.129,11.394c0.204-0.387,0.611-1.51,1.192-1.409c0.576,0.102,0.95,0.505,1.377,0.867\n	c0.518,0.44-0.164,2.463-0.292,3.055c-0.105,0.503-0.233,0.714-0.776,0.49c-0.391-0.161-0.767-0.391-1.144-0.583\n	c-0.346-0.177-0.797-0.322-0.995-0.673C48.236,12.694,48.929,11.774,49.129,11.394C49.629,10.444,48.629,12.345,49.129,11.394z\n	 M51.381,29.563c-0.611,0.508-0.912,0.652-1.398,0.019c-0.361-0.473-0.65-0.97-0.942-1.487c-0.141-0.245-0.502-0.75-0.156-0.983\n	c0.413-0.282,0.819-0.581,1.248-0.833c0.473-0.276,1.126-0.642,1.398,0.019c0.168,0.403,0.22,0.896,0.322,1.321\n	c0.09,0.371,0.121,0.761,0.179,1.139C52.081,29.09,51.611,29.344,51.381,29.563C50.931,29.938,51.381,29.563,51.381,29.563z\n	 M51.456,22.392c-0.637,0.556-1.272,1.112-1.91,1.667c-0.653,0.57-1.589,0.685-1.998-0.33c-0.427-1.06-0.398-2.318-0.479-3.447\n	c-0.057-0.791-0.002-1.643,0.071-2.433c0.052-0.556,0.09-1.315,0.461-1.771c0.267-0.327,0.892-0.504,1.253-0.195\n	c0.685,0.589,1.369,1.179,2.053,1.768c0.819,0.707,1.699,1.433,2.367,2.289c0.21,0.271,0.087,0.409-0.114,0.66\n	C52.646,21.243,52.042,21.817,51.456,22.392C51.456,22.392,52.781,21.092,51.456,22.392z\"/>\n<rect id=\"sliceCopy_x5F_16_1_\" x=\"88.001\" fill=\"none\" width=\"88\" height=\"40\"/>\n<rect id=\"sliceCopy_x5F_15_1_\" fill=\"none\" width=\"88.001\" height=\"40\"/>\n</svg>",
    }
    for k, v in pairs(svg_table) do
        utils.weapon_icons[k] = renderer.load_svg(v, 50, 50)
    end
    svg_table = nil
    collectgarbage("collect")
end
utils.deg2rad2 = function(x)
    return x * (math.pi / 180.0);
end
utils.lerp_lite = function(a, b, percentage)
    return a + (b - a) * percentage
end
visuals.out_of_fov = function()
    local lplayer = entity.get_local_player()
    if lplayer == nil or not entity.is_alive(lplayer) then return end
    local camera = vector(client.camera_angles())
    local lpose = vector(entity.get_origin(lplayer))
    local ammo_col = {ui.get(skeetgui.visualgui.player_esp.ammo[2])}
    local name_col = {ui.get(skeetgui.visualgui.player_esp.name[2])}
    local weapon_col = {ui.get(skeetgui.visualgui.player_esp.weapon_icon[2])}
    local to_display = ui.get(tabs["Visuals"].out_of_fov[2])
    local radius = screen.y*0.5 * (ui.get(tabs["Visuals"].out_of_fov[3])*0.01)
    local adding = ui.get(tabs["Visuals"].out_of_fov[4])
    for _, ent in ipairs(rage.alive_players) do
        if entity.is_dormant(ent) then goto skip end
        local entorig = vector(entity.get_origin(ent))
        local x, y = renderer.world_to_screen(entorig:unpack())
        local entweapon = entity.get_player_weapon(ent)
        local ammo = entity.get_prop(entweapon, "m_iClip1")
        local clipsize = csgo_weapons(entweapon).primary_clip_size
        local overlay1 = c_entity(ent):get_anim_overlay(1)
        local ent_ptr = ffi.cast('uintptr_t*', native_GetClientEntity(ent))
        local seq = native_GetSequenceActivity(ent_ptr, overlay1.sequence)
        local cycle = overlay1.cycle
        local weight = overlay1.weight
        local is_reloading = seq == 967 and weight ~= 0 and cycle <= 0.98
        if (x == nil or x <= 0 or x >= screen.x) or (y == nil or y <= 0 or y >= screen.y) then
            local fromto = vector(lpose:to(entorig):angles())
            local angle = camera.y - fromto.y - 90;
            if angle < -90 and angle > -180 then angle = -180 end
            if angle > -90 and angle < 0 then angle = 0 end
            angle = angle - 5
            local degrad = utils.deg2rad2(angle - 5)
            local degrad1 = utils.deg2rad2(angle + 5)
            local aMX = degrad + 1 * (degrad1 - degrad);
            local name = entity.get_player_name(ent)
            local namew, nameh = renderer.measure_text(nil, name)
            local health = entity.get_prop(ent, "m_iHealth")
            local healthoffset = health*0.01
            renderat = vector(screen.x*0.49 + math.cos(aMX) * radius, screen.y*0.47 + math.sin(aMX) * radius)
            if utils.in_table(to_display, "Bounding box") then
                outlined_rectangle(renderat.x - 1, renderat.y - 1, 27+adding, 52+adding, 0, 0, 0, 255, 3)
                outlined_rectangle(renderat.x, renderat.y, 25+adding, 50+adding, 255, 255, 255, 255, 1)
            end

            if utils.in_table(to_display, "Name") then
                renderer.text(renderat.x + 12+adding*0.5, renderat.y - 7, name_col[1], name_col[2], name_col[3], name_col[4], "c", 0, name)
            end

            if utils.in_table(to_display, "Health") then
                outlined_rectangle(renderat.x - 7, renderat.y - 1, 4, 52+adding, 0, 0, 0, 255, 1)
                renderer.rectangle(renderat.x - 6, renderat.y, 2, 50+adding, 0, 0, 0, 160)
                renderer.rectangle(renderat.x - 6, renderat.y + 50+adding, 2, -(50+adding)*healthoffset, utils.lerp_lite(260, 120, healthoffset), utils.lerp_lite(45, 225, healthoffset), 80, 255)
                if health <= 92 then renderer.text(renderat.x - 7, renderat.y + (50+adding)-((50+adding)*healthoffset), 255, 255, 255, 255, "c-", 0, health) end
            end

            if utils.in_table(to_display, "Ammo") then
                local enemy_weapon = entity.get_player_weapon(ent)
                local enemy_class = enemy_weapon ~= nil and entity.get_classname(enemy_weapon)
                if enemy_class ~= "CKnife" and enemy_class ~= "CWeaponKnife" and enemy_class ~= "CKnifeGG" then
                    if is_reloading then ammo = utils.lerp_lite(0, clipsize, cycle) end
                    renderer.rectangle(renderat.x - 1, renderat.y + 53+adding, 27+adding, 4, 0, 0, 0, 160 * (ammo_col[4]/255))
                    renderer.rectangle(renderat.x, renderat.y + 54+adding, (25+adding) * (1/clipsize * ammo), 2, ammo_col[1], ammo_col[2], ammo_col[3], ammo_col[4])
                    if ammo < math.ceil(clipsize*0.25) and not is_reloading then renderer.text(renderat.x + (25+adding)*(1/clipsize * ammo), renderat.y + 56+adding, 255, 255, 255, 255, "c-", 0, ammo) end
                end
            end

            if utils.in_table(to_display, "Weapon icon") then
                renderer.texture(utils.weapon_icons[entity.get_prop(entweapon, "m_iItemDefinitionIndex")], renderat.x + 1, renderat.y + 59+adding, 27+adding, 20, 0, 0, 0, 255, "f")
                renderer.texture(utils.weapon_icons[entity.get_prop(entweapon, "m_iItemDefinitionIndex")], renderat.x, renderat.y + 58+adding, 27+adding, 20, weapon_col[1], weapon_col[2], weapon_col[3], weapon_col[4], "f")
            end
        end
        ::skip::
    end
end
ui.set_callback(tabs["Visuals"].out_of_fov[1], function(id)
    if ui.get(id) then
        client.set_event_callback("paint", visuals.out_of_fov)
    else
        client.unset_event_callback("paint", visuals.out_of_fov)
    end
end)
visuals.is_console = vtable_bind('engine.dll', 'VEngineClient014', 11, 'bool(__thiscall*)(void*)')
visuals.consolemat = nil
visuals.consolecolor = function(reset)
    if entity.get_local_player() == nil then return end
    if visuals.consolemat == nil then
        visuals.consolemat = {
            materialsystem.find_material('vgui_white'),
            materialsystem.find_material('vgui/hud/800corner1'),
            materialsystem.find_material('vgui/hud/800corner2'),
            materialsystem.find_material('vgui/hud/800corner3'),
            materialsystem.find_material('vgui/hud/800corner4'),
        }
    end
    local r, g, b, a = ui.get(tabs["Visuals"].concol[2])
    if not visuals.is_console() or reset == true then
        r, g, b, a = 255, 255, 255, 255
    end
    for k, mat in ipairs(visuals.consolemat) do
        mat:color_modulate(r, g, b)
        mat:alpha_modulate(a)
    end
end
ui.set_callback(tabs["Visuals"].concol[1], function(id)
    if ui.get(id) then
        client.set_event_callback("pre_render", visuals.consolecolor)
    else
        client.unset_event_callback("pre_render", visuals.consolecolor)
        visuals.consolecolor(true)
    end
end)
--region @visuals end

--region @antiaims
antiaims.current_cond = "Shared"
antiaims.condition = function(cmd)
    local lplayer = entity.get_local_player()
    if lplayer == nil or not entity.is_alive(lplayer) then return end
    if not ui.get(tabs["Anti-Aimbot"][1]) then 
        antiaims.current_cond = "Disabled"
        return 
    end
    local flags = entity.get_prop(lplayer, 'm_fFlags')
	local m_vecVelocity = { entity.get_prop(lplayer, 'm_vecVelocity') }
    local is_crouching = bit.band(flags, bit.lshift(1, 1)) ~= 0
    local on_ground = bit.band(flags, bit.lshift(1, 0)) ~= 0
    local standing = math.abs(m_vecVelocity[1]) + math.abs(m_vecVelocity[2]) < 2
    local slowwalking = ui.get(skeetgui.aagui.other.slow_motion[1]) and ui.get(skeetgui.aagui.other.slow_motion[2])
    local is_jumping = cmd.in_jump == 1
    local is_e = cmd.in_use == 1
    local fakelags = not ui.get(skeetgui.ragegui.aimbot.double_tap[2]) and not ui.get(skeetgui.aagui.other.on_shot_antiaim[2])
    local duckpeek = ui.get(skeetgui.ragegui.other.duck_peek_assist)
    --if duckpeek and cmd.in_duck == 1 then ui.set(skeetgui.ragegui.other.duck_peek_assist, "Off hotkey") end
    if ui.get(tabs["Anti-Aimbot"]["On-Use"].override) and is_e then
        local bomb = entity.get_all("CPlantedC4")
        if #bomb > 0 then
            local lpos = vector(entity.get_origin(lplayer))
            local c4pos = vector(entity.get_origin(bomb[#bomb]))
            if lpos:dist(c4pos) < 50 and entity.get_prop(lplayer, "m_iTeamNum") == 3 then
                antiaims.current_cond = "Disabled"
                return
            end
        end
        antiaims.current_cond = "On-Use"
        return
    elseif is_e then
        antiaims.current_cond = "Disabled"
        return
    end
    if ui.get(tabs["Anti-Aimbot"]["Duckpeek"].override) and duckpeek then
        antiaims.current_cond = "Duckpeek"
        return
    end
    if ui.get(tabs["Anti-Aimbot"]["Fakelags"].override) and fakelags then
        antiaims.current_cond = "Fakelags"
        return
    end
    if ui.get(tabs["Anti-Aimbot"]["Moving"].override) and not slowwalking and not is_crouching and not standing and on_ground and not is_jumping then
        antiaims.current_cond = "Moving"
        return
    end
    if ui.get(tabs["Anti-Aimbot"]["Slowwalk"].override) and slowwalking and not is_jumping and on_ground and not is_crouching then
        antiaims.current_cond = "Slowwalk"
        return
    end
    if ui.get(tabs["Anti-Aimbot"]["Crouch"].override) and is_crouching and on_ground and not is_jumping and standing then
        antiaims.current_cond = "Crouch"
        return
    end
    if ui.get(tabs["Anti-Aimbot"]["Crouch-Moving"].override) and is_crouching and on_ground and not is_jumping and not standing then
        antiaims.current_cond = "Crouch-Moving"
        return
    end
    if ui.get(tabs["Anti-Aimbot"]["Air-Crouch"].override) and is_crouching and (not on_ground or is_jumping) then
        antiaims.current_cond = "Air-Crouch"
        return
    end
    if ui.get(tabs["Anti-Aimbot"]["Air"].override) and ((not on_ground or is_jumping) and not is_crouching) then
        antiaims.current_cond = "Air"
        return
    end
    if ui.get(tabs["Anti-Aimbot"]["Standing"].override) and standing and on_ground and not is_jumping and not slowwalking and not is_crouching then
        antiaims.current_cond = "Standing"
        return
    end
    antiaims.current_cond = "Shared"
end
antiaims.desync_side = function()
    local lplayer = entity.get_local_player()
    if lplayer == nil then return end

    if globals.chokedcommands() ~= 0 then return end

    local body_yaw = entity.get_prop(lplayer, 'm_flPoseParameter', 11) * 120 - 60

    antiaims.current_side = body_yaw > 0
end
antiaims.manuals = {
    {name = "Left", yaw = -90, key = tabs["Anti-Aimbot"].manuals[2]},
    {name = "Right", yaw = 90, key = tabs["Anti-Aimbot"].manuals[3]},
    {name = "Reset", yaw = nil, key = tabs["Anti-Aimbot"].manuals[4]}
}
antiaims.manual_handler = function()
    if not ui.get(tabs["Anti-Aimbot"].manuals[1]) or not ui.get(tabs["Anti-Aimbot"][1]) then antiaims.is_manual = nil; return end
    local lplayer = entity.get_local_player()
    if not lplayer or not entity.is_alive(lplayer) then return end
    for k, v in pairs(antiaims.manuals) do
        local active, key = ui.get(v.key)
        if v.active == nil then v.active = active end
        if v.active == active then goto exit end
        v.active = active
        if v.yaw == nil then antiaims.is_manual = nil end
        antiaims.is_manual = antiaims.is_manual ~= k and k or nil goto exit
        ::exit::
    end
end
--local jitt = ui.get(skeetgui.aagui.angles.yaw_jitter[1])
antiaims.calculate = function(tab)
    local r = {}
    for key, value in pairs(tab) do
        if type(value) == "table" then
           r[key] = antiaims.calculate(value)
        else
            r[key] = ui.get(value)
        end
    end
    return r
end
antiaims.maxdelta = function(e)
    local anm = c_entity.new(e):get_anim_state()
    local duckamount = anm.duck_amount
    local speedfraction = math.max(0, math.min(anm.feet_speed_forwards_or_sideways, 1))
    local speedfactor = math.max(0, math.min(1, anm.feet_speed_unknown_forwards_or_sideways))
    local st1 = ((anm.stop_to_full_running_fraction * -0.30000001) - 0.19999999) * speedfraction + 1.0
    if duckamount > 0 then
        st1 = st1 + ((duckamount * speedfactor)*(0.5 - st1))
    end
    des = anm.max_yaw * st1
    return utils.clamp(des, 0, 58)
end
antiaims.safe = false
antiaims.safe_handler = function(cmd)
    local lplayer = entity.get_local_player()
    if lplayer == nil or not entity.is_alive(lplayer) then return end
    local is_knife = utils.multi_parse(tabs["Anti-Aimbot"].other[1], "Safe on knife") and rage.weapon == "CKnife"
    local is_zeus = utils.multi_parse(tabs["Anti-Aimbot"].other[1], "Safe on zeus") and rage.weapon == "CWeaponTaser"
    local is_high = utils.multi_parse(tabs["Anti-Aimbot"].other[1], "Safe on heigh") and rage.zdelta and rage.zdelta >= 80 and rage.distance <= 300
    local flags = entity.get_prop(lplayer, 'm_fFlags')
    local is_crouching = bit.band(flags, bit.lshift(1, 1)) ~= 0
    local on_ground = bit.band(flags, bit.lshift(1, 0)) ~= 0
    local is_jumping = cmd.in_jump == 1
    antiaims.safe = ((is_jumping and not on_ground and is_crouching and rage.zdelta and rage.zdelta >= -10) and (is_knife or is_zeus) or is_high) and antiaims.current_cond ~= "On-Use"
end
antiaims.sway, antiaims.sway_vec = {}, {}
antiaims.sway_handler = function(cmd, offset1, offset2, ticks)
    local lplayer = entity.get_local_player()
    local min = math.min(offset1, offset2)
    local max = math.max(offset1, offset2)
    local my_weapon = entity.get_player_weapon(lplayer)
    local simtime = entity.get_prop(lplayer, "m_flSimulationTime")
    local curtime = globals.curtime()
    local can_shoot = false
    local nading = false
    if my_weapon ~= nil then
        local weapon = csgo_weapons(my_weapon)
        if weapon.is_revolver then
            can_shoot = curtime > entity.get_prop(my_weapon, "m_flNextPrimaryAttack")
        elseif weapon.is_melee_weapon then
            can_shoot = curtime > math.max(entity.get_prop(lplayer, "m_flNextAttack"), entity.get_prop(my_weapon, "m_flNextPrimaryAttack"), entity.get_prop(my_weapon, "m_flNextSecondaryAttack")) - globals.tickinterval()
        elseif weapon.is_grenade then
            can_shoot = false
        else
            can_shoot = curtime > math.max(entity.get_prop(lplayer, "m_flNextAttack"), entity.get_prop(my_weapon, "m_flNextPrimaryAttack"), entity.get_prop(my_weapon, "m_flNextSecondaryAttack"))
        end
        if weapon.is_grenade and entity.get_prop(my_weapon, "m_fThrowTime") > 0 then nading = true end
    end
    if cmd.in_attack == 1 and can_shoot or nading then return end
    local yaw = entity.get_prop(lplayer, "m_angEyeAngles[1]")
    antiaims.sway[antiaims.current_cond] = antiaims.sway[antiaims.current_cond] or min
    antiaims.sway_vec[antiaims.current_cond] = antiaims.sway_vec[antiaims.current_cond] or 1
    if cmd.chokedcommands == 0 then
        if antiaims.sway[antiaims.current_cond] >= max then
            antiaims.sway_vec[antiaims.current_cond] = -1
        elseif antiaims.sway[antiaims.current_cond] <= min then
            antiaims.sway_vec[antiaims.current_cond] = 1
        end
        if utils.cmd_ticks() % ticks == 0 then
            antiaims.sway[antiaims.current_cond] = utils.clamp(antiaims.sway[antiaims.current_cond] + antiaims.sway_vec[antiaims.current_cond], min, max)
        end
        cmd.yaw = utils.normalize_yaw(yaw + (antiaims.maxdelta(lplayer) * antiaims.sway_vec[antiaims.current_cond]) + antiaims.sway[antiaims.current_cond]*5)
        cmd.allow_send_packet = false
    end
end
antiaims.nway = {}
antiaims.nway_handler = function(cmd, n, angle, delay)
    local lplayer = entity.get_local_player()
    if lplayer == nil or not entity.is_alive(lplayer) then return end
    antiaims.nway[antiaims.current_cond] = antiaims.nway[antiaims.current_cond] or angle
    if cmd.chokedcommands == 0 then
        local mplyer = (angle/n)*2
        if utils.cmd_ticks() % delay > 0 then return end
        if antiaims.nway[antiaims.current_cond] == -angle then
            antiaims.nway[antiaims.current_cond] = angle + mplyer
        end
        antiaims.nway[antiaims.current_cond] = utils.clamp(antiaims.nway[antiaims.current_cond] - mplyer, -angle, angle)
    end
end
modifier = {}
antiaims.myaw = {}
antiaims.myaw_handler = function(cmd, minang, maxang, speed, delay)
    local lplayer = entity.get_local_player()
    if lplayer == nil or not entity.is_alive(lplayer) then return end
    antiaims.myaw[antiaims.current_cond] = antiaims.myaw[antiaims.current_cond] or minang
    modifier[antiaims.current_cond] = modifier[antiaims.current_cond] or 1
    if cmd.chokedcommands == 0 then
        if utils.cmd_ticks()%(delay*2) ~= 0 then return end
        if antiaims.myaw[antiaims.current_cond] <= minang then
            modifier[antiaims.current_cond] = 1
        end
        if antiaims.myaw[antiaims.current_cond] >= maxang then
            modifier[antiaims.current_cond] = -1
        end
        antiaims.myaw[antiaims.current_cond] = utils.clamp(antiaims.myaw[antiaims.current_cond] + (modifier[antiaims.current_cond] * speed), minang, maxang)
    end
end
local nexttickjit = {}
antiaims.swap = false
antiaims.jitter, antiaims.lr = {}, {}
antiaims.jit_handler = function(cmd, jitangl, delay, delayr, deltaticks)
    local lplayer = entity.get_local_player()
    if lplayer == nil or not entity.is_alive(lplayer) then return end
    local ticks = client.random_int(utils.clamp(delay - delayr, 1, delay), utils.clamp(delay + delayr, delay, 14))
    if delayr > 0 then
        if not nexttickjit[1] or nexttickjit[2] <= globals.tickcount() then
            if ticks == nexttickjit[1] then
                ticks = utils.clamp(ticks - delayr, utils.clamp(delay - delayr, 1, 14), utils.clamp(delay + delayr, 1, 14))
            end
            nexttickjit[1] = ticks
            nexttickjit[2] = globals.tickcount() + deltaticks
        else
            ticks = nexttickjit[1]
        end
    end
    antiaims.jitter[antiaims.current_cond] = antiaims.jitter[antiaims.current_cond] or jitangl
    if cmd.chokedcommands == 0 then
        antiaims.swap = utils.cmd_ticks()%(ticks*2) >= ticks
        antiaims.jitter[antiaims.current_cond] = (antiaims.swap and jitangl or -jitangl)
    end
end

local function micro_move(cmd, lplayer)
    local speed = math.sqrt(entity.get_prop(lplayer, "m_vecVelocity[0]")^2 + entity.get_prop(lplayer, "m_vecVelocity[1]")^2)
    local is_quickpeek = ui.get(skeetgui.ragegui.other.quick_peek_assist[1]) and ui.get(skeetgui.ragegui.other.quick_peek_assist[2])
    if cmd.chokedcommands == 0 or speed > 2 or is_quickpeek or cmd.in_attack == 1 then return end
    cmd.forwardmove = 0.1
    cmd.in_forward = 1
end
antiaims.lby_breaker = function(cmd)
    if not ui.get(tabs["Anti-Aimbot"][1]) then return end
    if not ui.get(tabs["Anti-Aimbot"].lby_breaker[1]) or not ui.get(tabs["Anti-Aimbot"].lby_breaker[2]) then return end
    if antiaims.safe or antiaims.is_antibacsktab then return end
    if ui.get(skeetgui.ragegui.aimbot.double_tap[1]) and ui.get(skeetgui.ragegui.aimbot.double_tap[2]) or ui.get(skeetgui.aagui.other.on_shot_antiaim[1]) and ui.get(skeetgui.aagui.other.on_shot_antiaim[2]) then return end
    local lplayer = entity.get_local_player()
    if lplayer == nil or not entity.is_alive(lplayer) then return end
    local on_ladder = entity.get_prop(lplayer, "m_MoveType") == 9
    if on_ladder then return end
    local weapon = csgo_weapons(entity.get_player_weapon(lplayer))
    if weapon == nil or weapon.type == "grenade" then return end

    micro_move(cmd, lplayer)

    local body_side = ui.get(tabs["Anti-Aimbot"].inverter[1]) and -ui.get(tabs["Anti-Aimbot"].lby_breaker[3]) or ui.get(tabs["Anti-Aimbot"].lby_breaker[3])

    if not antiaims.point_at_enemy_180_active then
        if cmd.chokedcommands == 0 and cmd.in_attack ~= 1 then
            cmd.yaw = cmd.yaw - body_side
            cmd.allow_send_packet = false
        end
    end

    local short = skeetgui.aagui.angles
    local is_manual = antiaims.is_manual ~= nil and antiaims.manuals[antiaims.is_manual].yaw ~= nil
    ui.set(short.yaw[1], "180")
    local manual_yaw = is_manual and antiaims.manuals[antiaims.is_manual] and antiaims.manuals[antiaims.is_manual].yaw or 0
    if type(manual_yaw) == "table" then manual_yaw = manual_yaw[1] or 0 end
    ui.set(short.yaw[2], manual_yaw)
    ui.set(short.yaw_jitter[1], "Off")
    ui.set(short.body_yaw[1], "Static")
end
antiaims.c_cent = {}
antiaims.custom_center = function(cmd, base, factor, ticks)
    local rndm = client.random_int(-base * factor, base * factor)
    antiaims.c_cent[antiaims.current_cond] = antiaims.c_cent[antiaims.current_cond] or 0
    if cmd.chokedcommands == 0 then
        antiaims.c_cent[antiaims.current_cond] = (utils.cmd_ticks()%(ticks*2) >= ticks and -base or base) + rndm
    end
end
antiaims.c_off = {}
antiaims.custom_offset = function(cmd, base, factor, ticks)
    local rndm = client.random_int(-base * factor, base * factor)
    antiaims.c_off[antiaims.current_cond] = antiaims.c_off[antiaims.current_cond] or 0
    if cmd.chokedcommands == 0 then
        antiaims.c_off[antiaims.current_cond] = utils.cmd_ticks()%(ticks*2) >= ticks and base + rndm or 0
    end
end
antiaims.center_rand = {}
antiaims.center_next = {}
antiaims.center_rand_handler = function(cmd, base, min_ticks, max_ticks)
    local cond = antiaims.current_cond
    antiaims.center_rand[cond] = antiaims.center_rand[cond] or base
    antiaims.center_next[cond] = antiaims.center_next[cond] or globals.tickcount()
    if cmd.chokedcommands == 0 and globals.tickcount() >= antiaims.center_next[cond] then
        if antiaims.center_rand[cond] >= 0 then
            antiaims.center_rand[cond] = base * -1
        else
            antiaims.center_rand[cond] = base
        end
        local dur = client.random_int(min_ticks, max_ticks)
        antiaims.center_next[cond] = globals.tickcount() + dur
    end
end
antiaims.v2swap = 0
antiaims.jitter2 = function(cmd, base, tick)
    local lplayer = entity.get_local_player()
    local my_weapon = entity.get_player_weapon(lplayer)
    local simtime = entity.get_prop(lplayer, "m_flSimulationTime")
    local curtime = globals.curtime()
    local yaw = entity.get_prop(lplayer, "m_angEyeAngles[1]")
    local can_shoot = false
    local nading = false
    if my_weapon ~= nil then
        local weapon = csgo_weapons(my_weapon)
        if weapon.is_revolver then
            can_shoot = curtime > entity.get_prop(my_weapon, "m_flNextPrimaryAttack")
        elseif weapon.is_melee_weapon then
            can_shoot = curtime > math.max(entity.get_prop(lplayer, "m_flNextAttack"), entity.get_prop(my_weapon, "m_flNextPrimaryAttack"), entity.get_prop(my_weapon, "m_flNextSecondaryAttack")) - globals.tickinterval()
        elseif weapon.is_grenade then
            can_shoot = false
        else
            can_shoot = curtime > math.max(entity.get_prop(lplayer, "m_flNextAttack"), entity.get_prop(my_weapon, "m_flNextPrimaryAttack"), entity.get_prop(my_weapon, "m_flNextSecondaryAttack"))
        end
        if weapon.is_grenade and entity.get_prop(my_weapon, "m_fThrowTime") > 0 then nading = true end
    end
    if cmd.in_attack == 1 and can_shoot or nading then return end
    if cmd.chokedcommands == 0 then
        local side = antiaims.maxdelta(lplayer) + base
        antiaims.v2swap = utils.cmd_ticks()%(tick*2) >= tick and -1 or 1
        cmd.yaw = utils.normalize_yaw(yaw + (side * antiaims.v2swap))
        cmd.allow_send_packet = false
    end
end
antiaims.static2 = function(cmd, base, side)
    if base == 0 then return end
    local curside = base < 0 and -1 or 1
    local lplayer = entity.get_local_player()
    local my_weapon = entity.get_player_weapon(lplayer)
    local simtime = entity.get_prop(lplayer, "m_flSimulationTime")
    local curtime = globals.curtime()
    local yaw = entity.get_prop(lplayer, "m_angEyeAngles[1]")
    local can_shoot = false
    local nading = false
    if my_weapon ~= nil then
        local weapon = csgo_weapons(my_weapon)
        if weapon.is_revolver then
            can_shoot = curtime > entity.get_prop(my_weapon, "m_flNextPrimaryAttack")
        elseif weapon.is_melee_weapon then
            can_shoot = curtime > math.max(entity.get_prop(lplayer, "m_flNextAttack"), entity.get_prop(my_weapon, "m_flNextPrimaryAttack"), entity.get_prop(my_weapon, "m_flNextSecondaryAttack")) - globals.tickinterval()
        elseif weapon.is_grenade then
            can_shoot = false
        else
            can_shoot = curtime > math.max(entity.get_prop(lplayer, "m_flNextAttack"), entity.get_prop(my_weapon, "m_flNextPrimaryAttack"), entity.get_prop(my_weapon, "m_flNextSecondaryAttack"))
        end
        if weapon.is_grenade and entity.get_prop(my_weapon, "m_fThrowTime") > 0 then nading = true end
    end
    if cmd.in_attack == 1 and can_shoot or nading then return end
    if cmd.chokedcommands == 0 then
        local angle = (antiaims.maxdelta(lplayer) * curside) + base
        cmd.yaw = utils.normalize_yaw(yaw + (angle * side))
        cmd.allow_send_packet = false
    end
end
antiaims.lr_handler = function(cmd, left, right, factor, body_type)
    local lplayer = entity.get_local_player()
    if lplayer == nil or not entity.is_alive(lplayer) then return end
    local rndm = client.random_int(left * factor, right * factor)
    antiaims.lr[antiaims.current_cond] = antiaims.lr[antiaims.current_cond] or 0
    if cmd.chokedcommands == 0 then
        local sidelr;
        if body_type == "Custom Jitter" then
            sidelr = (antiaims.swap and left or right) + rndm
        elseif body_type == "Jitter v2" then
            sidelr = (antiaims.v2swap == -1 and left or right) + rndm
        else
            sidelr = (antiaims.current_side and left or right) + rndm
        end
        antiaims.lr[antiaims.current_cond] = utils.clamp(sidelr, -180, 180)
    end
end
antiaims.delayed = {}
antiaims.delayed_handler = function(cmd, left, right, ticks)
    antiaims.delayed[antiaims.current_cond] = antiaims.delayed[antiaims.current_cond] or 0
    if cmd.chokedcommands == 0 then
        antiaims.delayed[antiaims.current_cond] = utils.cmd_ticks()%(ticks*2) >= ticks and left or right
    end
end
local function get_fov(vector1, vector2)
    local delta = vector2 - vector1
    delta:normalize()
    return math.sqrt(delta.x^2 + delta.y^2)
end
antiaims.closest_enemy_targeting = function(crosshair, force_distance)
    local lplayer = entity.get_local_player()
    if lplayer == nil or not entity.is_alive(lplayer) then antiaims.target = nil; return end
    local target = {}
    local lorig = vector(entity.get_origin(lplayer))
    local center = vector(screen.x*0.5, screen.y*0.5)
    local leyes = vector(client.eye_position())
    local campos = vector(client.camera_position())
    for ent=1, globals.maxplayers() do
        if not entity.is_alive(ent) or not entity.is_enemy(ent) or entity.is_dormant(ent) then goto skip end
        local orig = vector(entity.get_origin(ent))
        local toscreen = vector(renderer.world_to_screen(orig:unpack()))
        local angles = vector(leyes:to(orig):angles())
        local dist = crosshair and center:dist(toscreen) or force_distance and lorig:dist(orig) or get_fov(vector(client.camera_angles()), angles)
        if target.dist == nil or dist < target.dist then
            target.dist = dist
            target.index = ent
        end
        ::skip::
    end
    if target.dist then
        antiaims.target = target.index
        return target
    end
    antiaims.target = nil
end
antiaims.crosshair = false
antiaims.force_distance = false
client.set_event_callback("paint", function()
    antiaims.closest_enemy_targeting(antiaims.crosshair, antiaims.force_distance)
end)
antiaims.fluctate_def = {}
mod = {}
antiaims.fluctate_handler = function(cmd, offset1, offset2, speed, oneway, ignored)
    local min = math.min(offset1, offset2)
    local max = math.max(offset1, offset2)
    antiaims.fluctate_def[antiaims.current_cond] = antiaims.fluctate_def[antiaims.current_cond] or min
    mod[antiaims.current_cond] = oneway and 1 or mod[antiaims.current_cond] or 1
    if cmd.chokedcommands == 0 or ignored then
        if antiaims.fluctate_def[antiaims.current_cond] >= max and oneway then 
            antiaims.fluctate_def[antiaims.current_cond] = min
        elseif not oneway and antiaims.fluctate_def[antiaims.current_cond] >= max then
            mod[antiaims.current_cond] = -1
        elseif not oneway and antiaims.fluctate_def[antiaims.current_cond] <= min then
            mod[antiaims.current_cond] = 1
        end
        antiaims.fluctate_def[antiaims.current_cond] = utils.clamp(antiaims.fluctate_def[antiaims.current_cond] + speed * mod[antiaims.current_cond], min, max)
    end
end
antiaims.pitch_jit = {}
antiaims.pitchjit_hamdler = function(cmd, offset1, offset2, ignored)
    antiaims.pitch_jit[antiaims.current_cond] = antiaims.pitch_jit[antiaims.current_cond] or offset1
    if cmd.chokedcommands == 0 or ignored then
        antiaims.pitch_jit[antiaims.current_cond] = utils.cmd_ticks()%2 == 0 and offset1 or offset2
    end
end
antiaims.yaw_oposite = {}
antiaims.yawopp_handler = function(cmd, offset)
    antiaims.yaw_oposite[antiaims.current_cond] = antiaims.yaw_oposite[antiaims.current_cond] or offset
    if cmd.chokedcommands == 0 then
        antiaims.yaw_oposite[antiaims.current_cond] = utils.cmd_ticks()%2 == 0 and offset or -offset
    end
end
antiaims.yaw_random = {}
antiaims.yawrndm_handler = function(cmd, offset1, offset2)
    antiaims.yaw_random[antiaims.current_cond] = antiaims.yaw_random[antiaims.current_cond] or 0
    if cmd.chokedcommands == 0 then
        antiaims.yaw_random[antiaims.current_cond] = client.random_int(offset1, offset2)
    end
end
antiaims.yaw_jit = {}
antiaims.yawjit_handler = function(cmd, offset1, offset2)
    antiaims.yaw_jit[antiaims.current_cond] = antiaims.yaw_jit[antiaims.current_cond] or offset1
    if cmd.chokedcommands == 0 then
        antiaims.yaw_jit[antiaims.current_cond] = utils.cmd_ticks()%2 == 0 and offset1 or offset2
    end
end
antiaims.spin2 = {}
antiaims.spin2_handler = function(cmd, offset1, offset2, speed)
    local min = math.min(offset1, offset2)
    local max = math.max(offset1, offset2)
    antiaims.spin2[antiaims.current_cond] = antiaims.spin2[antiaims.current_cond] or min
    if cmd.chokedcommands == 0 then
        if antiaims.spin2[antiaims.current_cond] >= max then antiaims.spin2[antiaims.current_cond] = min end
        antiaims.spin2[antiaims.current_cond] = utils.clamp(antiaims.spin2[antiaims.current_cond] + speed, min, max)
    end
end
antiaims.fluctutatefl = nil;
antiaims.radnomlags = function(fltype, max)
    local tb = tabs["Anti-Aimbot"][antiaims.current_cond].fakelagc[fltype]
    if ui.get(skeetgui.ragegui.other.duck_peek_assist) then
        ui.set(skeetgui.aagui.fakelag.limit, max)
        return
    end
    if fltype == "Dynamic" or fltype == "Fluctuate" or fltype == "Maximum" then
        ui.set(skeetgui.aagui.fakelag.amount, fltype)
        ui.set(skeetgui.aagui.fakelag.variance, ui.get(tb[1]))
        ui.set(skeetgui.aagui.fakelag.limit, max)
    elseif fltype == "Random" then
        local factor = ui.get(tb[1])*0.1
        ui.set(skeetgui.aagui.fakelag.amount, "Maximum")
        if factor == 0 then ui.set(skeetgui.aagui.fakelag.limit, max) return end
        local min = math.max(max - (max*factor), 1)
        ui.set(skeetgui.aagui.fakelag.limit, client.random_float(min, max))
    elseif fltype == "Jitter" then
        local offset = ui.get(tb[1])
        ui.set(skeetgui.aagui.fakelag.amount, "Maximum")
        ui.set(skeetgui.aagui.fakelag.limit, globals.tickcount()%14 >= 7 and offset or max)
    elseif fltype == "Fluctuate v2" then
        local variance = ui.get(tb[1])*0.01
        local min = ui.get(tb[2])
        antiaims.fluctutatefl = antiaims.fluctutatefl or min
        if math.floor(antiaims.fluctutatefl) ~= ui.get(skeetgui.aagui.fakelag.limit) then antiaims.fluctutatefl = ui.get(skeetgui.aagui.fakelag.limit) end
        if antiaims.fluctutatefl >= max then antiaims.fluctutatefl = min end
        if globals.tickcount()%5 == 0 then antiaims.fluctutatefl = math.min(antiaims.fluctutatefl + 2*variance, max) end
        ui.set(skeetgui.aagui.fakelag.amount, "Maximum")
        ui.set(skeetgui.aagui.fakelag.limit, antiaims.fluctutatefl)
    end
end
--antiaims.fakelagbox = {"Maximum", "Dynamic", "Fluctuate", "Fluctuate v2", "Jitter", "Random"}
antiaims.to_apply = nil
antiaims.manuals_tickstoflick = nil
ui.set(skeetgui.aagui.angles.freestanding[2], "Always On")
antiaims.spin_yaw = 180
local desync_side = 1
antiaims.handler = function(cmd)
    local lplayer = entity.get_local_player()
    if lplayer == nil or not entity.is_alive(lplayer) then return end
    if antiaims.current_cond == "Disabled" then
        ui.set(skeetgui.aagui.angles.enabled, ui.get(tabs["Anti-Aimbot"][1]))
        return
    end
    if antiaims.current_cond == "On-Use" then cmd.in_use = 0 end
    antiaims.to_apply = antiaims.calculate(tabs["Anti-Aimbot"][antiaims.current_cond])
    local is_manual = antiaims.is_manual ~= nil and antiaims.manuals[antiaims.is_manual].yaw ~= nil
    local defensive = antiaims.current_cond ~= "Fakelags" and antiaims.current_cond ~= "Duckpeek" and (antiaims.to_apply.defensive.enable and cmd.chokedcommands < 13 and ticks.tickbase_diff ~= nil and ticks.tickbase_diff ~= 1 and ticks.tickbase_diff < -antiaims.to_apply.defensive.tick)
    if defensive and is_manual and not utils.multi_parse(tabs["Anti-Aimbot"].other[1], "Allow defensive on manuals") then defensive = false end
    antiaims.point_at_enemy_180_active = false
    do
        local condtab = tabs["Anti-Aimbot"][antiaims.current_cond]
        local def_ui = condtab and condtab.defensive
        if def_ui and def_ui.point_180 and def_ui.yaw then
            antiaims.point_at_enemy_180_active = ui.get(def_ui.point_180) and ui.get(def_ui.yaw) == "180"
            if antiaims.point_at_enemy_180_active then
                antiaims.crosshair = false
                antiaims.force_distance = true
            end
        end
    end
    local pitch = antiaims.to_apply.pitch
    local custom_pitch = antiaims.to_apply.pitchc[1]
    local yaw_base = antiaims.to_apply.yaw_base
    local yaw = antiaims.to_apply.yaw
    local yaw_amount = antiaims.to_apply.yawc[yaw]
    local function get_yaw_value(yaw_val, index)
        if type(yaw_val) == "table" then
            return yaw_val[index] or yaw_val[1] or 0
        else
            return yaw_val or 0
        end
    end
    local yaw_jitter = antiaims.to_apply.yaw_jitter
    local yaw_jitter_amount = antiaims.to_apply.yaw_jitterc[yaw_jitter]
    local body_yaw = antiaims.to_apply.body_yaw
    local body_yaw_amount = antiaims.to_apply.body_yawc[body_yaw]
    local fs_body_yaw = antiaims.to_apply.body_yaw_freestand
    local fl_limit = antiaims.to_apply.fakelaglimit
    local fl_type = antiaims.to_apply.fakelag
    antiaims.is_antibacsktab = utils.multi_parse(tabs["Anti-Aimbot"].other[1], "Anti-Backstab") and rage.target_weapon ~= nil and string.match(rage.target_weapon, "Knife") and rage.distance <= 340 and math.abs(rage.zdelta) < 80
    antiaims.radnomlags(fl_type, fl_limit)
    if ui.get(tabs["Anti-Aimbot"].builder) == "gamesense" then 
        ui.set(skeetgui.aagui.angles.enabled, ui.get(tabs["Anti-Aimbot"][1]))
        if utils.multi_parse(tabs["Anti-Aimbot"].other[1], "Disable fakelags on os") and ui.get(skeetgui.aagui.other.on_shot_antiaim[1]) and ui.get(skeetgui.aagui.other.on_shot_antiaim[2]) then
            ui.set(skeetgui.aagui.fakelag.enabled[1], false)
            antiaims.better_os = true
        elseif antiaims.better_os and not ui.get(skeetgui.aagui.fakelag.enabled[1]) then
            ui.set(skeetgui.aagui.fakelag.enabled[1], true)
            antiaims.better_os = false
        end
        local short = skeetgui.aagui.angles

        if yaw == "Off" or yaw_amount == nil then
            yaw_jitter = "Off"
        end
        if not antiaims.safe and not antiaims.is_antibacsktab then
            if is_manual then
                local manual_yaw = antiaims.manuals[antiaims.is_manual] and antiaims.manuals[antiaims.is_manual].yaw or 0
                if type(manual_yaw) == "table" then manual_yaw = manual_yaw[1] or 0 end
                yaw_amount = manual_yaw
                if utils.multi_parse(tabs["Anti-Aimbot"].other[1], "Local view on manuals") then
                    yaw_base = "Local view"
                end
                if utils.multi_parse(tabs["Anti-Aimbot"].other[1], "Static on manuals") then
                    yaw = "180"
                    yaw_jitter = "Off"
                    body_yaw = "Static"
                    body_yaw_amount = 60
                end
                if utils.multi_parse(tabs["Anti-Aimbot"].other[1], "Flick manual on peek") and cmd.chokedcommands < 2 then
                    local target = client.current_threat()
                    if target == nil or vector(entity.get_prop(lplayer, 'm_vecVelocity')):lengthsqr() < 1 then goto skip end
                    local flag = entity.get_esp_data(target).flags or 0
                    local is_hittble = bit.band(flag, bit.lshift(1, 11)) ~= 0
                    if is_hittble and antiaims.manuals_tickstoflick == nil then
                        antiaims.manuals_tickstoflick = globals.tickcount() + 7
                    end
                    if antiaims.manuals_tickstoflick ~= nil and antiaims.manuals_tickstoflick > globals.tickcount() then
                        yaw_amount = -yaw_amount
                        pitch = "Custom"
                        custom_pitch = 0
                    elseif antiaims.manuals_tickstoflick ~= nil and antiaims.manuals_tickstoflick <= globals.tickcount() and not rage.hittable then
                        antiaims.manuals_tickstoflick = nil
                    end
                    ::skip::
                end
            end
            if yaw == "L&R" then
                antiaims.lr_handler(cmd, get_yaw_value(yaw_amount, 1), get_yaw_value(yaw_amount, 2), get_yaw_value(yaw_amount, 3)*0.01, body_yaw)
                yaw = "180"
                yaw_amount = utils.normalize_yaw(antiaims.lr[antiaims.current_cond] + (is_manual and get_yaw_value(yaw_amount, 1) or 0))
            elseif yaw == "Delayed" then
                antiaims.delayed_handler(cmd, get_yaw_value(yaw_amount, 1), get_yaw_value(yaw_amount, 2), get_yaw_value(yaw_amount, 3))
                yaw = "180"
                yaw_amount = utils.normalize_yaw(antiaims.delayed[antiaims.current_cond] + (is_manual and get_yaw_value(yaw_amount, 1) or 0))
            end
            if yaw_jitter == "Min/Max Center" then
                antiaims.myaw_handler(cmd, yaw_jitter_amount[1], yaw_jitter_amount[2], yaw_jitter_amount[3]*0.01, yaw_jitter_amount[4])
                yaw_jitter = "Center"
                yaw_jitter_amount = antiaims.myaw[antiaims.current_cond]
            elseif yaw_jitter == "Nway" then
                antiaims.nway_handler(cmd, yaw_jitter_amount[1], yaw_jitter_amount[2], yaw_jitter_amount[3])
                yaw_jitter = "Off"
                yaw_amount = utils.normalize_yaw(get_yaw_value(yaw_amount, 1)+antiaims.nway[antiaims.current_cond])
            elseif yaw_jitter == "L&R Center" then
                local factor = yaw_jitter_amount[3] * 0.01
                local rndm = client.random_int(yaw_jitter_amount[1] * factor, yaw_jitter_amount[2] * factor)
                yaw_jitter = "Center"
                yaw_jitter_amount = (antiaims.current_side and yaw_jitter_amount[1] or yaw_jitter_amount[2]) + rndm
            elseif yaw_jitter == "Skitter" then
                -- approximate Skitter by alternating around base using amount, then disable GS jitter UI
                if globals.tickcount()%3 == 0 then
                    yaw_amount = get_yaw_value(yaw_amount, 1) + (type(yaw_jitter_amount)=="table" and yaw_jitter_amount[1] or yaw_jitter_amount)*0.5
                elseif globals.tickcount()%3 == 2 then
                    yaw_amount = get_yaw_value(yaw_amount, 1) - (type(yaw_jitter_amount)=="table" and yaw_jitter_amount[1] or yaw_jitter_amount)*0.5
                end
                yaw_jitter = "Off"
            elseif yaw_jitter == "Center" then
                local base = (type(yaw_jitter_amount) == "table") and get_yaw_value(yaw_jitter_amount, 1) or yaw_jitter_amount
                local min_t = (type(yaw_jitter_amount) == "table") and (tonumber(yaw_jitter_amount[2]) or 3) or 3
                local max_t = (type(yaw_jitter_amount) == "table") and (tonumber(yaw_jitter_amount[3]) or 10) or 10
                if max_t < min_t then max_t = min_t end
                antiaims.center_rand_handler(cmd, tonumber(base) or 0, min_t, max_t)
                yaw_jitter = "Off"
                yaw_amount = utils.normalize_yaw(get_yaw_value(yaw_amount, 1) + (antiaims.center_rand[antiaims.current_cond] or 0))
                yaw_jitter_amount = 0
            elseif yaw_jitter == "Custom Center" then
                antiaims.custom_center(cmd, yaw_jitter_amount[1]*0.5, yaw_jitter_amount[2]*0.01, yaw_jitter_amount[3])
                yaw_jitter = "Off"
                yaw_amount = utils.normalize_yaw(get_yaw_value(yaw_amount, 1) + antiaims.c_cent[antiaims.current_cond])
                yaw_jitter_amount = 0
            elseif yaw_jitter == "Custom Offset" then
                antiaims.custom_offset(cmd, yaw_jitter_amount[1], yaw_jitter_amount[2]*0.01, yaw_jitter_amount[3])
                yaw_jitter = "Off"
                yaw_amount = utils.normalize_yaw(get_yaw_value(yaw_amount, 1) + antiaims.c_off[antiaims.current_cond])
                yaw_jitter_amount = 0
            end
            if body_yaw == "Custom Jitter" then
                antiaims.jit_handler(cmd, body_yaw_amount[1], body_yaw_amount[2], body_yaw_amount[3], body_yaw_amount[4])
                body_yaw = "Custom"
                body_yaw_amount = antiaims.jitter[antiaims.current_cond]
            elseif body_yaw == "Sway" then
                antiaims.sway_handler(cmd, body_yaw_amount[1], body_yaw_amount[2], body_yaw_amount[3])
                body_yaw = "Off"
            elseif body_yaw == "Jitter v2" then
                antiaims.jitter2(cmd, body_yaw_amount[1], body_yaw_amount[2])
                body_yaw = "Off"
            elseif body_yaw == "Static v2" then
                antiaims.static2(cmd, body_yaw_amount, ui.get(tabs["Anti-Aimbot"].inverter[1]) and -1 or 1)
                body_yaw = "Off"
            end
            if defensive then
                local defensive_pitch = antiaims.to_apply.defensive.pitch
                local defensive_custom = antiaims.to_apply.defensive.pitchc[defensive_pitch]
                local defensive_yaw = antiaims.to_apply.defensive.yaw
                local defensive_yaw_ammount = antiaims.to_apply.defensive.yawc[defensive_yaw]
                antiaims.point_at_enemy_180_active = ui.get(tabs["Anti-Aimbot"][antiaims.current_cond].defensive.point_180) and defensive_yaw == "180"
                if defensive_pitch ~= "Default" and not antiaims.point_at_enemy_180_active then
                    pitch = "Custom"
                    if defensive_pitch == "Zero" then
                        custom_pitch = 0
                    elseif defensive_pitch == "Custom" then
                        pitch = defensive_pitch
                        custom_pitch = defensive_custom
                    elseif defensive_pitch == "Random v2" then
                        custom_pitch = client.random_int(defensive_custom[1], defensive_custom[2])
                    elseif defensive_pitch == "Fluctate" then
                        antiaims.fluctate_handler(cmd, defensive_custom[2], defensive_custom[3], (defensive_custom[4]*0.01)*20, defensive_custom[1])
                        custom_pitch = antiaims.fluctate_def[antiaims.current_cond]
                    elseif defensive_pitch == "Jitter" then
                        antiaims.pitchjit_hamdler(cmd, defensive_custom[1], defensive_custom[2])
                        custom_pitch = antiaims.pitch_jit[antiaims.current_cond]
                    elseif defensive_pitch == "L&R" then
                        custom_pitch = antiaims.current_side and defensive_custom[1] or defensive_custom[2]
                    else
                        pitch = defensive_pitch
                    end
                end
                if defensive_yaw ~= "Default" then
                    if defensive_yaw == "180" or defensive_yaw == "Spin" then
                        yaw = defensive_yaw
                        yaw_amount = defensive_yaw_ammount
                    elseif defensive_yaw == "Spin v2" then
                        if defensive_yaw_ammount and defensive_yaw_ammount[1] and defensive_yaw_ammount[2] and defensive_yaw_ammount[3] then
                            antiaims.spin2_handler(cmd, defensive_yaw_ammount[1], defensive_yaw_ammount[2], (defensive_yaw_ammount[3]*0.01)*40)
                        else
                            antiaims.spin2_handler(cmd, -180, 180, 2)
                        end
                        yaw = "180"
                        yaw_amount = antiaims.spin2[antiaims.current_cond]
                    elseif defensive_yaw == "Random" then
                        if defensive_yaw_ammount and defensive_yaw_ammount[1] and defensive_yaw_ammount[2] then
                            antiaims.yawrndm_handler(cmd, defensive_yaw_ammount[1], defensive_yaw_ammount[2])
                        else
                            antiaims.yawrndm_handler(cmd, -180, 180)
                        end
                        yaw = "180"
                        yaw_amount = antiaims.yaw_random[antiaims.current_cond]
                    elseif defensive_yaw == "Opposite" then
                        if defensive_yaw_ammount then
                            antiaims.yawopp_handler(cmd, defensive_yaw_ammount)
                        else
                            antiaims.yawopp_handler(cmd, 180)
                        end
                        yaw = "180"
                        yaw_amount = antiaims.yaw_oposite[antiaims.current_cond]
                    elseif defensive_yaw == "Jitter" then
                        if defensive_yaw_ammount and defensive_yaw_ammount[1] and defensive_yaw_ammount[2] then
                            antiaims.yawjit_handler(cmd, defensive_yaw_ammount[1], defensive_yaw_ammount[2])
                        else
                            antiaims.yawjit_handler(cmd, -180, 180)
                        end
                        yaw = "180"
                        yaw_amount = antiaims.yaw_jit[antiaims.current_cond]
                    elseif defensive_yaw == "L&R" then
                        yaw = "180"
                        if defensive_yaw_ammount and defensive_yaw_ammount[1] and defensive_yaw_ammount[2] then
                            yaw_amount = antiaims.current_side and defensive_yaw_ammount[1] or defensive_yaw_ammount[2]
                        else
                            yaw_amount = antiaims.current_side and -180 or 180
                        end
                    end
                end
            end
            if yaw_base == "Closest enemy" then
                yaw_base = "Local view"
                antiaims.crosshair = false
                antiaims.force_distance = true
                if antiaims.target then
                    local torig = vector(entity.hitbox_position(antiaims.target, 0))
                    local lpos = vector(entity.hitbox_position(lplayer, 0))
                    local pitch, yawt = lpos:to(torig):angles()
                    yaw_amount = utils.normalize_yaw(get_yaw_value(yaw_amount, 1) + yawt)
                end
            end
            if antiaims.to_apply.def_flick[1] and rage.exploits and cmd.chokedcommands == 1 and not antiaims.point_at_enemy_180_active then
                pitch = "Custom"
                custom_pitch = 0
                yaw_base = "At targets"
                yaw = "180"
                yaw_jitter = "Off"
                body_yaw = "Static"
                body_yaw_amount = 50
                
                local hidden_pitch = globals.tickcount() % 12 > 1 and 89 or -89
                local hidden_yaw = globals.tickcount() % 48 > 24 and 90 or -90
                
                yaw_amount = hidden_yaw
                antiaims.fluctate_handler(cmd, hidden_pitch, hidden_pitch, 15, false, true)
            end
        elseif antiaims.safe then
            yaw = "180"
            yaw_amount = 0
            yaw_jitter = "Off"
            pitch = "Down"
            body_yaw = "Off"
            yaw_base = "At targets"
        end
        local notextdt = not ui.get(tabs["Anti-Aimbot"].exttep[1]) and not ui.get(tabs["Anti-Aimbot"].exttep[2])
        if antiaims.current_cond ~= "Fakelags" and antiaims.current_cond ~= "Duckpeek" and notextdt then 
            if antiaims.to_apply.force_def == "Always" or antiaims.to_apply.force_def == "On-Hittable" and rage.hittable then
                cmd.force_defensive = true
            end
        end
        if not antiaims.point_at_enemy_180_active then
            ui.set(short.pitch[1], pitch)
            ui.set(short.pitch[2], custom_pitch)
        end
        ui.set(short.yaw_base, yaw_base)
        local vj = { ["Off"] = true, ["Offset"] = true, ["Center"] = true, ["Random"] = true }
        if not vj[yaw_jitter] then yaw_jitter = "Off" end
        ui.set(short.yaw_jitter[1], yaw_jitter)
        -- map custom handler mode to GS-supported value
        ui.set(short.body_yaw[1], (body_yaw == "Custom" and "Static" or body_yaw))
        local vy = { ["Off"]=true, ["180"]=true, ["Spin"]=true, ["Static"]=true }
        if not vy[yaw] then yaw = "180" end
        ui.set(short.yaw[1], yaw)
        ui.set(short.edge_yaw, ui.get(tabs["Anti-Aimbot"].edgeyaw[1]))
        ui.set(short.freestanding[1], ui.get(tabs["Anti-Aimbot"].freestand[1]))
        ui.set(short.freestanding_body_yaw, fs_body_yaw)

        if yaw_jitter ~= "Off" then 
            local yj_num = type(yaw_jitter_amount) == "table" and get_yaw_value(yaw_jitter_amount, 1) or yaw_jitter_amount
            yj_num = tonumber(yj_num) or 0
            ui.set(short.yaw_jitter[2], yj_num) 
        end

        if body_yaw ~= "Off" and body_yaw ~= "Opposite" then
            body_yaw_amount = (body_yaw == "Static" and ui.get(tabs["Anti-Aimbot"].inverter[1])) and -body_yaw_amount or body_yaw_amount
            local by_num = type(body_yaw_amount) == "table" and get_yaw_value(body_yaw_amount, 1) or body_yaw_amount
            by_num = tonumber(by_num) or 0
            ui.set(short.body_yaw[2], by_num)
        end

        if yaw ~= "Off" then
            local yaw_amount_num = type(yaw_amount) == "table" and get_yaw_value(yaw_amount, 1) or yaw_amount
            yaw_amount_num = tonumber(yaw_amount_num) or 0
            ui.set(short.yaw[2], yaw_amount_num)
        end
    else
        if not ui.get(tabs["Anti-Aimbot"][1]) then return end
        ui.set(skeetgui.aagui.angles.enabled, false)
        local my_weapon = entity.get_player_weapon(lplayer)
        local simtime = entity.get_prop(lplayer, "m_flSimulationTime")
        local simdelta = simtime - (oldsimtime or simtime)
        oldsimtime = simtime
        local static_inverter = ui.get(tabs["Anti-Aimbot"].inverter[1])
        local curtime = globals.curtime()
        local eyes = vector(client.camera_angles())
        local cmdyaw = cmd.yaw
        local tick = globals.tickcount()
        local shifting = simdelta < 0
        local can_shoot = false
        local nading = false
        if my_weapon ~= nil then
            local weapon = csgo_weapons(my_weapon)
            if weapon.is_revolver then
                can_shoot = curtime > entity.get_prop(my_weapon, "m_flNextPrimaryAttack")
            --elseif weapon.is_melee_weapon then
            --    can_shoot = curtime > math.max(entity.get_prop(lplayer, "m_flNextAttack"), entity.get_prop(my_weapon, "m_flNextPrimaryAttack"), entity.get_prop(my_weapon, "m_flNextSecondaryAttack")) - globals.tickinterval()
            elseif weapon.is_grenade then
                can_shoot = false
            else
                can_shoot = curtime > math.max(entity.get_prop(lplayer, "m_flNextAttack"), entity.get_prop(my_weapon, "m_flNextPrimaryAttack"), entity.get_prop(my_weapon, "m_flNextSecondaryAttack")) - globals.tickinterval()
            end
            if weapon.is_grenade and entity.get_prop(my_weapon, "m_fThrowTime") > 0 then nading = true end
        end
        if not shifting and cmd.in_attack == 1 and can_shoot or nading then return end
        if antiaims.point_at_enemy_180_active and (pitch == "Default" or pitch == nil) then
            local gs_mode = ui.get(skeetgui.aagui.angles.pitch[1])
            if gs_mode == "Off" then
                pitch = nil
            elseif gs_mode == "Up" then
                pitch = -89
            elseif gs_mode == "Down" then
                pitch = 89
            elseif gs_mode == "Random" then
                pitch = client.random_float(-89, 89)
            elseif gs_mode == "Custom" then
                pitch = ui.get(skeetgui.aagui.angles.pitch[2])
            end
        end
        if pitch == "Off" then
            pitch = nil
        elseif pitch == "Up" then
            pitch = -89
        elseif pitch == "Down" then
            pitch = 89
        elseif pitch == "Random" then
            pitch = client.random_float(-89, 89)
        elseif pitch == "Custom" then
            pitch = custom_pitch
        end
        if antiaims.point_at_enemy_180_active and pitch == nil then
            local gs_mode = ui.get(skeetgui.aagui.angles.pitch[1])
            if gs_mode == "Off" then
                pitch = nil
            elseif gs_mode == "Up" then
                pitch = -89
            elseif gs_mode == "Down" then
                pitch = 89
            elseif gs_mode == "Random" then
                pitch = client.random_float(-89, 89)
            elseif gs_mode == "Custom" then
                pitch = ui.get(skeetgui.aagui.angles.pitch[2])
            end
        end
        if yaw == "Off" then
            yaw = nil
        elseif yaw == "180" then
            yaw_amount = 180 + get_yaw_value(yaw_amount, 1)
        elseif yaw == "Spin" then
            if (tick+1)%2 == 0 then
                antiaims.spin_yaw = antiaims.spin_yaw + get_yaw_value(yaw_amount, 1)
            end
            yaw_amount = antiaims.spin_yaw
        elseif yaw == "L&R" then
            if body_yaw == nil then
                yaw_amount = 180
            else
                yaw_amount = 180 + (antiaims.current_side and get_yaw_value(yaw_amount, 1) or get_yaw_value(yaw_amount, 2))
            end
        elseif yaw == "Delayed" then
            yaw_amount = 180 + (tick%(get_yaw_value(yaw_amount, 3)*2) >= get_yaw_value(yaw_amount, 3) and get_yaw_value(yaw_amount, 2) or get_yaw_value(yaw_amount, 1))
        end

        if yaw ~= nil and is_manual then
            if utils.multi_parse(tabs["Anti-Aimbot"].other[1], "Local view on manuals") then
                yaw_base = "Local view"
            end
            if utils.multi_parse(tabs["Anti-Aimbot"].other[1], "Static on manuals") then
                --yaw = "180"
                yaw_amount = 180
                yaw_jitter = "Off"
                body_yaw = "Static"
                body_yaw_amount = 60
            end
                local manual_yaw = antiaims.manuals[antiaims.is_manual] and antiaims.manuals[antiaims.is_manual].yaw or 0
            if type(manual_yaw) == "table" then manual_yaw = manual_yaw[1] or 0 end
            yaw_amount = get_yaw_value(yaw_amount, 1) + manual_yaw
        end

        if yaw_jitter == "Off" or yaw == nil then
            yaw_jitter = nil
        elseif yaw_jitter == "Skitter" then
            if tick%3 == 0 then
                yaw_amount = get_yaw_value(yaw_amount, 1) + yaw_jitter_amount*0.5
            elseif tick%3 == 2 then
                yaw_amount = get_yaw_value(yaw_amount, 1) - yaw_jitter_amount*0.5
            end
        elseif yaw_jitter == "Center" then
            local jitflip = tick%4 < 2 and -1 or 1
            yaw_amount = get_yaw_value(yaw_amount, 1) + yaw_jitter_amount*0.5*jitflip
        elseif yaw_jitter == "Offset" then
            yaw_amount = get_yaw_value(yaw_amount, 1) + (tick%4 < 2 and yaw_jitter_amount or 0)
        elseif yaw_jitter == "Random" then
            yaw_jitter_amount = math.abs(yaw_jitter_amount*0.5)
            yaw_amount = get_yaw_value(yaw_amount, 1) + client.random_float(-yaw_jitter_amount, yaw_jitter_amount)
        end
        --if cmd.chokedcommands > 0 then
        if antiaims.point_at_enemy_180_active then
            local target_idx = antiaims.target or client.current_threat()
            if target_idx ~= nil then
                local tpose = vector(entity.hitbox_position(target_idx, 0))
                local lpose = vector(client.eye_position())
                local pitcht, yawt = lpose:to(tpose):angles()
                yaw = "Static"
                yaw_jitter = "Off"
                body_yaw = "Off"
                yaw_amount = utils.normalize_yaw(yawt)
            end
        end
            if yaw ~= nil then
                if yaw == "Static" then
                    cmd.yaw = utils.normalize_yaw(yaw_amount)
                else
                    if yaw_base == "At targets" then
                        antiaims.crosshair = true
                        antiaims.force_distance = false
                        if antiaims.target ~= nil then
                            local tpose = vector(entity.get_origin(antiaims.target))
                            local lpose = vector(entity.get_origin(lplayer))
                            local pitcht, yawt = lpose:to(tpose):angles()
                            cmdyaw = yawt
                        end
                    elseif yaw_base == "Closest enemy" then
                        antiaims.crosshair = false
                        antiaims.force_distance = true
                        if antiaims.target ~= nil then
                            local tpose = vector(entity.get_origin(antiaims.target))
                            local lpose = vector(entity.get_origin(lplayer))
                            local pitcht, yawt = lpose:to(tpose):angles()
                            cmdyaw = yawt
                        end
                    end
                    cmd.yaw = utils.normalize_yaw(cmdyaw + get_yaw_value(yaw_amount, 1))
                end
            end
            if pitch ~= nil then
                cmd.pitch = pitch
            end
            if cmd.chokedcommands == 0 and body_yaw ~= "Off" then
                --local state = get_animstate(lplayer)
                local cmdtick = utils.cmd_ticks()
                if body_yaw == "Static" then
                    desync_side = body_yaw_amount == 0 and 0 or body_yaw_amount < 0 and 1 or -1
                    desync_side = static_inverter and -desync_side or desync_side
                    body_yaw_amount = 58
                elseif body_yaw == "Static v2" then
                    desync_side = body_yaw_amount < 0 and 1 or -1
                    desync_side = static_inverter and -desync_side or desync_side
                elseif body_yaw == "Opposite" then
                    if math.abs(entity.get_prop(lplayer, 'm_flPoseParameter', 11)*120-60) < 50  then
                        desync_side = -desync_side
                    end
                    body_yaw_amount = 58
                elseif body_yaw == "Jitter" then
                    desync_side = cmdtick%2 == 0 and 1 or -1
                    body_yaw_amount = body_yaw_amount < 0 and -58 or 58
                end
                local mdelta = antiaims.maxdelta(lplayer)
                --local speedport = state.speed_as_portion_of_walk_top_speed
                --local duckport = state.speed_as_portion_of_crouch_top_speed
                --local trans = state.walk_run_transition
                --local duck_amount = state.anim_duck_amount
                --local widerange = utils.lerp(utils.clamp(speedport, 0, 1), 1, utils.lerp(trans, 0.8, 0.5))
                --local aim_matrix = 0
                --if duck_amount > 0 then
                --    widerange = utils.lerp(duck_amount * utils.clamp(duckport, 0, 1), widerange, 0.5)
                --end
                --local max_range = 58 * widerange
                body_yaw_amount = (math.abs(body_yaw_amount) + mdelta) * desync_side
                --local fake = math.abs(body_yaw_amount) * widerange
                cmd.yaw = utils.normalize_yaw(cmd.yaw + body_yaw_amount)
                --local move_vectors = vector(cmd.forwardmove, cmd.sidemove)
                --body_yaw_amount = body_yaw_amount < 0 and body_yaw_amount + mdelta or body_yaw_amount - mdelta
                --local norm = move_vectors.x * math.cos(body_yaw_amount) - move_vectors.y * math.sin(body_yaw_amount)
                --local norm2 = move_vectors.x * math.sin(body_yaw_amount) + move_vectors.y * math.cos(body_yaw_amount)
                --cmd.forwardmove = -norm
                --cmd.sidemove = -norm2
                cmd.allow_send_packet = false
            end
            --print(entity.get_prop(lplayer, 'm_flPoseParameter', 11)*120-60)
        --end
    end
    --print(cmd.allow_send_packet)
    --print(entity.get_prop(lplayer, "m_angEyeAngles[1]"))

end
local function extentedtp(cmd)
    if ui.get(skeetgui.aagui.other.on_shot_antiaim[1]) and ui.get(skeetgui.aagui.other.on_shot_antiaim[2]) then return end
    if not ui.get(skeetgui.ragegui.aimbot.double_tap[1]) and not ui.get(skeetgui.ragegui.aimbot.double_tap[2]) then return end
    
    if ui.get(tabs["Anti-Aimbot"].exttep[1]) or ui.get(tabs["Anti-Aimbot"].exttep[2]) and rage.hittable then
        cmd.force_defensive = 1
        if ticks.tickbase_diff == -ui.get(tabs["Anti-Aimbot"].exttep[3]) then
            --ui.set(skeetgui.ragegui.aimbot.double_tap[1], false)
            cmd.discharge_pending = true
            cmd.force_defensive = false
        end
    else
        cmd.discharge_pending = false
        cmd.force_defensive = false
        --ui.set(skeetgui.ragegui.aimbot.double_tap[1], true)
    end
end
--region @antiaims end

--local function watermark()
--    local name = entity.get_player_name(rage.target)
--    if name ~= "unknown" then
--        renderer.text(10, screen.y*0.5, 255, 255, 255, 255, "d", 0, ">> target: ", name)
--    end
--end
--client.set_event_callback("paint", watermark)

--region @callbacks
utils.shtdwn = function()
    local lplayer = entity.get_local_player()
    if ui.get(tabs["Misc"].transcope[1]) and (entity.get_prop(lplayer, "m_bIsScoped") == 1 or entity.get_prop(lplayer, "m_bResumeZoom") == 1) then
        ui.set(skeetgui.visualgui.colored_models.local_chams[2], misc.chamscol[1], misc.chamscol[2], misc.chamscol[3], misc.chamscol[4])
    end
    if (ui.get(tabs["Rage"].onlyhs[2]) or rage.onlyhs) or (ui.get(tabs["Rage"].hitchance[2]) or rage.htch_override) then
        local cwp = ui.get(skeetgui.ragegui.weapon.weapon_type)
        for key, val in pairs(hitbx) do
            ui.set(skeetgui.ragegui.weapon.weapon_type, key)
            if ui.get(tabs["Rage"].onlyhs[2]) or rage.onlyhs then
                ui.set(skeetgui.ragegui.aimbot.hitboxes, val[1])
                ui.set(skeetgui.ragegui.aimbot.prefer_body_aim, val[2])
            end
            if (ui.get(tabs["Rage"].hitchance[2]) or rage.htch_override) and utils.in_table(rage.weaponstweaks, key) then
                ui.set(skeetgui.ragegui.aimbot.hitchance, hitch[key])
            end
        end
        ui.set(skeetgui.ragegui.weapon.weapon_type, cwp)
    end
    if antiaims.better_os then
        ui.set(skeetgui.aagui.fakelags.enabled[1], true)
    end
end
utils.pcfl_ohs = function()
    local ogwp = ui.get(skeetgui.ragegui.weapon.weapon_type)
    for _, val in ipairs(utils.weapgroup) do
        ui.set(skeetgui.ragegui.weapon.weapon_type, val)
        hitbx[val] = {ui.get(skeetgui.ragegui.aimbot.hitboxes), ui.get(skeetgui.ragegui.aimbot.prefer_body_aim)}
        if utils.in_table(rage.weaponstweaks, val) then
            hitch[val] = ui.get(skeetgui.ragegui.aimbot.hitchance)
        end
    end
    ui.set(skeetgui.ragegui.weapon.weapon_type, ogwp)
end
client.set_event_callback("pre_config_save", function()
    utils.shtdwn()
end)
client.set_event_callback("post_config_load", function()
    client.delay_call(2, utils.pcfl_ohs)
end)
client.set_event_callback("paint_ui", function()
    utils.handle_mouse()
    utils.handle_altui()
    utils.animmain()
    utils.searchui()
    visuals.draghandler()
    menu_visible()
    
    if ui.get(tabs["Visuals"].watermark[1]) then
        visuals.watermark()
    end
    if ui.get(tabs["Visuals"].keybinds[1]) then
        visuals.keybinds()
    end
    
    
    
    --get_keybindings()
end)
client.set_event_callback("aim_hit", function(e)
    logs.on_hit(e)
    local target_name = entity.get_player_name(e.target)
    local weapon = entity.get_classname(entity.get_player_weapon(entity.get_local_player()))
    hitlogger.add_entry("hit", target_name, e.damage, e.hitgroup, weapon)
end)
client.set_event_callback("aim_miss", function(e)
    logs.on_miss(e)
    local target_name = entity.get_player_name(e.target)
    local weapon = entity.get_classname(entity.get_player_weapon(entity.get_local_player()))
    local reason = e.reason or "unknown"
    if reason == "?" then reason = "correction" end
    hitlogger.add_entry("miss", target_name, 0, e.hitgroup, weapon, reason)
end)
client.set_event_callback("aim_fire", logs.on_fire)
client.set_event_callback("player_death", function(e)
    misc.trashmsg(e)
end)
client.set_event_callback("player_spawn", misc.buybot)
client.set_event_callback("player_hurt", function(e) 
    logs.on_hurt(e)
    logs.hurthit(e)
    local attacker = client.userid_to_entindex(e.attacker)
    local victim = client.userid_to_entindex(e.userid)
    local damage = e.dmg_health
    local hitgroup = e.hitgroup
    local lplayer = entity.get_local_player()
    
    if attacker == lplayer and e.health > 0 then
        local victim_name = entity.get_player_name(victim)
        local weapon = entity.get_classname(entity.get_player_weapon(attacker))
        hitlogger.add_entry("hurt", victim_name, damage, hitgroup, weapon)
    end
   
    if victim == lplayer and attacker ~= lplayer then
        local attacker_name = entity.get_player_name(attacker)
        local weapon = entity.get_classname(entity.get_player_weapon(attacker))
        hitlogger.add_entry("hurt_by", attacker_name, damage, hitgroup, weapon)
    end
end)
client.set_event_callback("round_start", function()
    misc.killer = nil
end)
client.set_event_callback("level_init", function()
    ticks.tickbase_max = nil
    ticks.tickbase_diff = nil
end)
client.set_event_callback("pre_render", function()
    misc.animfuck()
    misc.dumbfuck()
end)
client.set_event_callback("run_command", function(cmd)
    ticks.runc(cmd)
    misc.onrun_tag(cmd)
end)
client.set_event_callback("net_update_end", function()
    ticks.chokecalc()
end)
client.set_event_callback("predict_command", ticks.tickcalc)
antiaims.team_detection = function()
    local lplayer = entity.get_local_player()
    if lplayer == nil or not entity.is_alive(lplayer) then return "Unknown" end
    
    local team_num = entity.get_prop(lplayer, "m_iTeamNum")
    if team_num == 3 then
        return "CT"
    elseif team_num == 2 then
        return "T"
    else
        return "Unknown"
    end
end

antiaims.team_handler = function(cmd)
    local lplayer = entity.get_local_player()
    if lplayer == nil or not entity.is_alive(lplayer) then return end
    
    if not ui.get(tabs["Anti-Aimbot"].team_anti_aim.enabled) then return end
    
    local current_team = antiaims.team_detection()
    if current_team == "Unknown" then return end
    
    local team_settings = current_team == "CT" and tabs["Anti-Aimbot"].team_anti_aim.ct_settings or tabs["Anti-Aimbot"].team_anti_aim.t_settings
    
    ui.set(skeetgui.aagui.angles.enabled, ui.get(tabs["Anti-Aimbot"][1]))
    
    local pitch = ui.get(team_settings.pitch)
    local pitch_custom = ui.get(team_settings.pitch_custom)
    local yaw = ui.get(team_settings.yaw)
    local yaw_custom = ui.get(team_settings.yaw_custom)
    local yaw_jitter = ui.get(team_settings.yaw_jitter)
    local yaw_jitter_custom = ui.get(team_settings.yaw_jitter_custom)
    local body_yaw = ui.get(team_settings.body_yaw)
    local body_yaw_custom = ui.get(team_settings.body_yaw_custom)
    local fakelag = ui.get(team_settings.fakelag)
    local fakelag_limit = ui.get(team_settings.fakelag_limit)
    local fakelag_variance = ui.get(team_settings.fakelag_variance)
    
    if ui.get(tabs["Anti-Aimbot"].side_specific_enabled) then
        local current_condition = ui.get(tabs["Anti-Aimbot"].condition)
        local detected_team = antiaims.team_detection() -- "CT" or "T" - automatically detected from game
        local player_team = detected_team:lower()
        
        
        if detected_team ~= "Unknown" and side_specific_configs[current_condition] and side_specific_configs[current_condition][player_team] then
            local saved_settings = side_specific_configs[current_condition][player_team]
            
            if next(saved_settings) then -- Check if settings exist
                for setting_name, setting_value in pairs(saved_settings) do
                    if setting_name == "pitch" then pitch = setting_value
                    elseif setting_name == "pitchc" then pitch_custom = setting_value
                    elseif setting_name == "yaw" then yaw = setting_value
                    elseif setting_name == "yawc" then yaw_custom = setting_value
                    elseif setting_name == "yaw_jitter" then yaw_jitter = setting_value
                    elseif setting_name == "yaw_jitterc" then yaw_jitter_custom = setting_value
                    elseif setting_name == "body_yaw" then body_yaw = setting_value
                    elseif setting_name == "body_yawc" then body_yaw_custom = setting_value
                    elseif setting_name == "fakelag" then fakelag = setting_value
                    elseif setting_name == "fakelaglimit" then fakelag_limit = setting_value
                    elseif setting_name == "fakelagvariance" then fakelag_variance = setting_value
                    end
                end
            end
        end
    end
    
    if not antiaims.point_at_enemy_180_active then
        ui.set(skeetgui.aagui.angles.pitch[1], pitch)
        if pitch == "Custom" then
            ui.set(skeetgui.aagui.angles.pitch[2], pitch_custom)
        end
    end
    
    ui.set(skeetgui.aagui.angles.yaw[1], yaw)
    if yaw == "Static" then
        ui.set(skeetgui.aagui.angles.yaw[2], yaw_custom)
    end
    
    ui.set(skeetgui.aagui.angles.yaw_jitter[1], yaw_jitter)
    if yaw_jitter ~= "Off" then
        ui.set(skeetgui.aagui.angles.yaw_jitter[2], yaw_jitter_custom)
    end
    
    ui.set(skeetgui.aagui.angles.body_yaw[1], body_yaw)
    if body_yaw == "Static" then
        ui.set(skeetgui.aagui.angles.body_yaw[2], body_yaw_custom)
    end
    
    ui.set(skeetgui.aagui.fakelag.amount, fakelag)
    ui.set(skeetgui.aagui.fakelag.limit, fakelag_limit)
    if fakelag ~= "Maximum" then
        ui.set(skeetgui.aagui.fakelag.variance, fakelag_variance)
    end
end

client.set_event_callback("setup_command", function(cmd)
    extentedtp(cmd)
    misc.fastladder(cmd)
    misc.jitterfuck(cmd)
    misc.globalstates(cmd)
    handle_attack(cmd)
    rage.dormant(cmd)
    rage.jumpshot(cmd)
    rage.cond_mpoints(cmd)
    antiaims.condition(cmd)
    antiaims.desync_side()
    antiaims.safe_handler(cmd)
    antiaims.handler(cmd)
    antiaims.team_handler(cmd)
    antiaims.lby_breaker(cmd)
    antiaims.point_to_enemy_enforce(cmd)
end)
antiaims.team_indicator = function()
    if not ui.get(tabs["Anti-Aimbot"].team_anti_aim.enabled) then return end
    
    local current_team = antiaims.team_detection()
    if current_team == "Unknown" then return end
    
    local team_color = current_team == "CT" and {0, 150, 255, 255} or {255, 100, 0, 255}
    local team_text = current_team == "CT" and "CT ANTI-AIM" or "T ANTI-AIM"
    
    renderer.indicator(team_color[1], team_color[2], team_color[3], team_color[4], team_text)
end

client.set_event_callback("paint", function()
    expind()
    visuals.spectators()
    rage.paint()
    misc.onpaint_tag()
    rage.forcehead()
    rage.delayshot()
    local style = ui.get(tabs["Manipulations"].uistyle[1])
    if style == "Astral" then
        hitlogger.render_astral()
    else
        logs.screen_handler()
    end
    antiaims.manual_handler()
    antiaims.team_indicator()
    auto_detect_and_update_team()
    indicate.get_binds()
    indicate.cross()
end)
client.set_event_callback("shutdown", function() 
    utils.visibleparse(hide, true)
    misc.aspect_change(true)
    misc.tpdist(true)
    misc.viewmod(true)
    misc.leftknife(true)
    misc.scalemodel(true)
    misc.onpaint_tag(true)
    misc.scopetransp(true)
    visuals.consolecolor(true)
    fpsboost(true)
    utils.shtdwn()
    database.write("expensive::keypos", utils.keypos)
    database.write("expensive::specpos", utils.specpos)
    database.write("expensive::altuienabled", utils.is_altui)
    database.write("expensive::keynames", visuals.dbknames)
    database.write("osmanhook::hitlogger_x", hitlogger.x)
    database.write("osmanhook::hitlogger_y", hitlogger.y)
    _G.ui.name = utils.ogname
    _G.ui.new_hotkey = utils.oghotkey
    _G.ui.new_textbox = utils.ogtextbox
    _G.ui.new_color_picker = utils.ogpicker
    _G.ui.new_combobox = utils.ogcombo
    _G.ui.new_multiselect = utils.ogmulti
    _G.ui.new_slider = utils.ogslider
    _G.ui.new_checkbox = utils.ogcheckbox
end)
--region @callbacks end

--region @test
--local viem = ffi.cast("char*", client.find_signature("client.dll", "\x55\x8B\xEC\x80\xCC\xCC\xCC\xCC\xCC\xCC\x56\x57\x8B\xF9"))
--local viemw = ffi.cast("char*", client.find_signature("client.dll", "\x55\x8B\xEC\x51\x56\x8B\xF1\x57\x89"))
--[[client.set_event_callback("paint", function()
    local lplayer = entity.get_local_player()
    local target = client.current_threat()
    if lplayer == nil or target == nil or not entity.is_alive(lplayer) then return end
    local lpos = vector(entity.hitbox_position(lplayer, 13))
    local damagelist = {}
    for i=0, 18 do
        local tpos = vector(entity.hitbox_position(target, i))
        local ent, dmg = client.trace_bullet(lplayer, lpos.x, lpos.y, lpos.z, tpos.x, tpos.y, tpos.z, false)
        damagelist[i] = ent ~= nil and dmg or nil --and not utils.in_table(damagelist, dmg)
    end
    for k, v in ipairs(damagelist) do
        local tpos = vector(entity.hitbox_position(target, k)) + vector(0, 0, 5)
        local x, y = renderer.world_to_screen(tpos:unpack())
        renderer.text(x, y, 255, 255, 255, 255, "c-", 0, v)
    end
end)]]
--[[local break_lc = false
client.set_event_callback("net_update_end", function()
    local lplayer = entity.get_local_player()
    if lplayer == nil or not entity.is_alive(lplayer) then return end
    local record = {entity.get_prop(lplayer, "m_flSimulationTime"), vector(entity.get_origin(lplayer))}
    if prev_record then
        local defensive = toticks(record[1] - prev_record[1]) < 0
        local teleport = record[2]:distsqr(prev_record[2]) > 4096
        if defensive or teleport then
            break_lc = true
        else
            break_lc = false
        end
    end
    prev_record = record
end)
client.set_event_callback("paint", function()
    local lplayer = entity.get_local_player()
    if lplayer == nil or not entity.is_alive(lplayer) then return end
    renderer.indicator(break_lc and 255 or 160, break_lc and 0 or 200, break_lc and 0 or 40, 255, "LC")
end)
local function get_server_time(as_ticks)
    local predicted_server_tick = globals.tickcount() + globals.interpolationamount()
    if ticks.host_frameticks ~= nil and ticks.host_currentframetick ~= nil then
        local delta = ticks.host_frameticks[0] - ticks.host_currentframetick[0]
        local max_delta_for_tick_rate = math.floor(1 / globals.tickinterval()) / 8
        if delta > 0 and delta < max_delta_for_tick_rate then
            predicted_server_tick = predicted_server_tick + delta
        end
    end
    return as_ticks ~= true and totime(predicted_server_tick) or predicted_server_tick
end]]
--[[rage.records = {}
do
    for i=1, 32 do
        rage.records[i] = {}
    end
end
local function purgerecord(ent)
    rage.records[ent] = {}
end
local function getrecord(ent, tick)
    local simtime = entity.get_prop(ent, "m_flSimulationTime")
    local oldsimtime = rage.records[ent].old and rage.records[ent].old.simtime or simtime
    local origin = vector(entity.get_origin(ent))
    local old_origin = rage.records[ent].old and rage.records[ent].old.origin or origin
    local simtime_delta = toticks(simtime - oldsimtime)
    local origin_delta = origin:distsqr(old_origin)
    table.insert(rage.records, ent, {
        tick = tick,
        simtime = simtime,
        oldsimtime = oldsimtime,
        origin = origin,
        old_origin = old_origin,
        origin_delta = origin_delta,
        simtime_delta = simtime_delta,
        shifting = toticks(simtime) - tick - 1,
        choked = utils.clamp(rage.records[ent].old and simtime_delta-1 or 0, 0, 72),
        lc = simtime_delta < 0 or origin_delta > 4096,
        old = rage.records[ent],
    })
end
local function chokecalc1()
    local lplayer = entity.get_local_player()
    local enemy = entity.get_players(true)
    local tick = get_server_time(true)
    for _, ent in pairs(enemy) do
        getrecord(ent, tick)
    end
end
client.set_event_callback("net_update_end", chokecalc1)]]
--local lbl = ui.new_label("CONFIG", "Presets", "Test")
--ui.set(lbl, "test2")
--client.set_event_callback("setup_command", function(cmd)
--    local lplayer = entity.get_local_player()
--    local nlplayer = native_GetClientEntity(lplayer)
--    local oldsim = ffi.cast('float*', ffi.cast('uintptr_t', nlplayer) + 0x26C)[0]
--    local simtime = entity.get_prop(lplayer, "m_flSimulationTime")
--    if ui.get(skeetgui.ragegui.aimbot.double_tap[1]) and ui.get(skeetgui.ragegui.aimbot.double_tap[2]) or ui.get(skeetgui.aagui.other.on_shot_antiaim[1]) and ui.get(skeetgui.aagui.other.on_shot_antiaim[2]) then
--        cmd.force_defensive = true
--        if cmd.in_attack ~= 1 then
--            if simtime <= oldsim then
--                micro_move(cmd, lplayer)
--                cmd.yaw = cmd.yaw + 90
--                cmd.allow_send_packet = false
--            else
--                cmd.yaw = cmd.yaw - 90
--            end
--        end
--    end
--end)
--client.set_event_callback("setup_command", function(cmd)
--    local lplayer = entity.get_local_player()
--    if lplayer == nil or not entity.is_alive(lplayer) then return end
--    local nlplayer = native_GetClientEntity(lplayer)
--    local m_flOldSimulationTime = ffi.cast('float*', ffi.cast('uintptr_t', nlplayer) + 0x26C)[0]
--    local m_flSimulationTime = entity.get_prop(lplayer, 'm_flSimulationTime')
--    if m_flOldSimulationTime ~= m_flSimulationTime then
--        local delta = toticks(m_flSimulationTime - m_flOldSimulationTime) - 1
--        if delta >= 14 then
--        end
--    end
--    localprev = m_flSimulationTime
--end)
--local function distto(vec1, vec2)
--    local dist = vector(vec1.x - vec2.x, vec1.y - vec2.y, vec1.z - vec2.z)
--    return math.sqrt(dist.x^2 + dist.y^2 + dist.z^2)
--end
--[[client.set_event_callback("bullet_impact", function(e)
    local lplayer = entity.get_local_player()
    if not entity.is_alive(lplayer) then return end
    local attacker = client.userid_to_entindex(e.userid)
    local lpos = vector(entity.hitbox_position(lplayer, 3))
    local tpos = vector(entity.hitbox_position(attacker, 4))
    local epos = vector(e.x, e.y, e.z)
    --print("bultin: ", lpos:dist(epos))
    --print("custom: ", distto(lpos, epos))
    if attacker == lplayer or hitted then return end
    local function does_point_lie_between_points(point, start, endp)
 
        --using y = mx + c, glad i thought of that i was
        --going to rotate the points instead haha ( stupid )
        local gradient = ( ( endp.y - start.y ) / ( endp.x - start.x ) )

        --if the gradient is zero then we have a flat line
        if gradient == 0 then 
            return point.y == start.y
        end

        --perpendicular gradient remains the same for both lines
        local perpendicular_gradient = -1 / gradient

        --constants
        local perpendicular_constant_start = start.y - ( perpendicular_gradient * start.x )
        local perpendicular_constant_end = endp.y - ( perpendicular_gradient * endp.x )

        --if the y value lies between the two.
        return point.y >= ( perpendicular_gradient * point.x + perpendicular_constant_start ) and point.y <= ( perpendicular_gradient * point.x + perpendicular_constant_end )

    end
    --if the point isnt within the area of where the shot was fired
    if not (tpos.y > epos.y and does_point_lie_between_points( lpos, epos, tpos ) or does_point_lie_between_points( lpos, tpos, epos )) then
        return false
    end

    --if you dont understand how it works
    --try considering this as a triangle
    --and these are the triangles edge lengths
    local bullet_distance = tpos:dist(epos)
    local origin_to_observer_distance = tpos:dist(lpos)
    local observer_to_impact = lpos:dist(epos)

    --cosine rule
    local angle = math.acos((observer_to_impact^2-origin_to_observer_distance^2-bullet_distance^2)/(-2*bullet_distance*origin_to_observer_distance))

    --we have the angle that we want
    --so use it to find the distance
    --print((globals.chokedcommands() - toticks(client.latency()) + 1))
    --print(math.sin( angle ) * origin_to_observer_distance)
    if ( math.sin( angle ) * origin_to_observer_distance ) <= 57 then
        local info = {}
        info.col = colors.gray
        info.alpha = -1
        info.time = globals.realtime() + 5
        info.string = {"Detected a shot from ", entity.get_player_name(attacker)}
        table.insert(logs.screen_info, 1, info)
    end
    --the 1.f tollerance can be adjusted to your liking, find how big a
    --models head is for example...
end)]]
--test = ui.new_checkbox("CONFIG", "Presets", "Test")
--tests = ui.new_slider("CONFIG", "Presets", "SEQUENCE", 0, 300, 0, true, nil, 1, nil)
--testl = ui.new_slider("CONFIG", "Presets", "LAYER", 0, 12, 0, true, nil, 1, nil)
--testw = ui.new_slider("CONFIG", "Presets", "WEIGHT", 0, 100, 0, true, nil, 1, nil)
--testc = ui.new_slider("CONFIG", "Presets", "CYCLE", 0, 1000, 0, true, nil, 1, nil)
--client.set_event_callback("pre_render", function()
--    if ui.get(test) then
--        local lplayer = entity.get_local_player()
--        local self_index = c_entity.new(lplayer)
--        local self_anim_state = self_index:get_anim_state()
--        local self_anim_overlay = self_index:get_anim_overlay(ui.get(testl))
--        self_anim_overlay.weight = ui.get(testw)*0.01
--        self_anim_overlay.sequence = ui.get(tests)
--        self_anim_overlay.cycle = ui.get(testc)*0.001
--        local a = self_anim_overlay.sequence
--        print(self_anim_overlay.cycle)
--    end
--end)
--region @test end

--region @profile_picture
do
	local tab, container = 'VISUALS', 'Player ESP'
	local reference = {
		teammates = ui.reference(tab, container, 'Teammates')
	}

	local get_players = function(only_enemies)
		local result = {}
		local maxplayers = globals.maxplayers()
		local player_resource = entity.get_player_resource()

		for player = 1, maxplayers do
			local enemy = entity.is_enemy(player)
			local alive = entity.is_alive(player)

			if (not only_enemies or enemy) and alive then
				table.insert(result, player)
			end
		end

		return result
	end

	local on_paint = function()
		if not ui.get(tabs["Visuals"].profile_picture[1]) then return end
		
		local players = get_players(not ui.get(reference.teammates))
		local side = ui.get(tabs["Visuals"].profile_picture[2]) == "Left"

		for i=1, #players do
			local player = players[i]
			local x1, y1, x2, y2, alpha_multiplier = entity.get_bounding_box(player)

			if x1 and alpha_multiplier > 0 then
				local steamid3 = entity.get_steam64(player)
				local avatar = images.get_steam_avatar(steamid3)

				if avatar then
					local pos = vector(x1/2 + x2/2, y1 - 7)
					local name = entity.get_player_name(player)
					local size = vector(renderer.measure_text('c', name))
					local offset = side and (- size.x) or (size.x/2 + 2)

					avatar:draw(pos.x + offset, pos.y - size.y/2, nil, size.y)
				end
			end
		end
	end

	local handle_callbacks = function(self)
		local handle = ui.get(self) and client.set_event_callback or client.unset_event_callback
		handle('paint', on_paint)
	end

	handle_callbacks(tabs["Visuals"].profile_picture[1])
	ui.set_callback(tabs["Visuals"].profile_picture[1], handle_callbacks)
end
--region @profile_picture end

--region @icon_changer
local function auto_change_aa_icon()
    local tabs = {"RAGE", "AA", "LEGIT", "VISUALS", "MISC", "SKINS", "PLIST", "Tab"}
    local tabsptr = ffi.cast("intptr_t*", 0x434799AC + 0x54)
    local tabsinfo = {}
    
    for i = 0, #tabs do
        local tab = ffi.cast("int*", tabsptr[0])[i]
        tabsinfo[i] = { id = ffi.cast("int*", tab + 0x80), offset = ffi.cast("int*", tab + 0x84), width = ffi.cast("int*", tab + 0x8C), height = ffi.cast("int*", tab + 0x90)}
    end
    
    local icon_url = "https://raw.githubusercontent.com/masonfoxforth/gamesense/refs/heads/main/asd1.png"
    
    http.get(icon_url, function(status, response)
        if status and response.body then
            local texture_id = renderer.load_png(response.body, 48, 48)
            if texture_id and texture_id > 0 then
                for i = 0, #tabs do
                    if tabs[i + 1] == "AA" then
                        tabsinfo[i].id[0] = texture_id
                        break
                    end
                end
            end
        end
    end)
end

client.delay_call(0.001, auto_change_aa_icon)
