<?php
header('Content-Type: text/plain');

// --- Minimal, behavior-preserving hardening ---
// To allow debug output, set an environment variable on the server, e.g.
//   export SUBS_DEBUG_TOKEN="some-long-random-token"
// Then call: script.php?username=...&debug=some-long-random-token
$debug_token = getenv('SUBS_DEBUG_TOKEN'); // if unset, debug is disabled
$allowDebug = (isset($_GET['debug']) && $debug_token && hash_equals($debug_token, (string)$_GET['debug']));

// Database connection
$host = '185.194.177.9';
$db   = 'hrisito';
$user = 'interlection';
$pass = 'xRoles13:)';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
    // Don’t leak internal messages
    echo $allowDebug
        ? ("Database connection failed: " . $e->getMessage())
        : "Database connection failed.";
    exit;
}

// Get username from query
$username = isset($_GET['username']) ? trim($_GET['username']) : '';
if ($username === '') {
    echo "Error: No username provided";
    exit;
}

try {
    // Query gs_users table for expiration datetime
    $stmt = $pdo->prepare("
        SELECT csgo
        FROM gs_users
        WHERE username = ?
        LIMIT 1
    ");
    $stmt->execute([$username]);
    $result = $stmt->fetch();

    if (!$result) {
        echo "Error: No user found";
        exit;
    }

    // Check if csgo field has a valid timestamp
    if (empty($result['csgo'])) {
        echo "No subscription found";
        exit;
    }

    // Optional debug output (requires correct token)
    if ($allowDebug) {
        echo "=== DEBUG INFO ===\n";
        echo "Raw database value: " . $result['csgo'] . "\n";
        echo "Current server time: " . date('Y-m-d H:i:s') . "\n";
        echo "Current timezone: " . date_default_timezone_get() . "\n";
    }

    $expire = new DateTime($result['csgo']);
    $now = new DateTime();

    if ($allowDebug) {
        echo "Parsed expiration: " . $expire->format('Y-m-d H:i:s') . "\n";
        echo "Current datetime obj: " . $now->format('Y-m-d H:i:s') . "\n";
        echo "Expiration timestamp: " . $expire->getTimestamp() . "\n";
        echo "Current timestamp: " . $now->getTimestamp() . "\n";
    }

    // Calculate the difference in seconds
    $timeDiff = $expire->getTimestamp() - $now->getTimestamp();

    if ($allowDebug) {
        echo "Time difference (seconds): " . $timeDiff . "\n";
        echo "Time difference (hours): " . round($timeDiff / 3600, 2) . "\n";
        echo "Time difference (days): " . round($timeDiff / 86400, 2) . "\n";
        echo "=== END DEBUG ===\n\n";
    }

    if ($timeDiff <= 0) {
        echo "Subscription expired";
    } else {
        // Convert seconds to days (rounded down)
        $daysRemaining = floor($timeDiff / 86400);

        // Also calculate hours/minutes for debug only (keeps normal output identical)
        if ($allowDebug) {
            $hoursRemaining = floor($timeDiff / 3600);
            $minutesRemaining = floor($timeDiff / 60);
            echo "RESULT: " . $daysRemaining . " days, " . ($hoursRemaining % 24) . " hours, " . ($minutesRemaining % 60) . " minutes remaining\n";
        } else {
            echo $daysRemaining . " days remaining";
        }
    }
} catch (\Throwable $e) {
    // Don’t leak internal stack traces/messages
    echo $allowDebug
        ? ("Error: " . $e->getMessage())
        : "Error processing request.";
}