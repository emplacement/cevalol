<?php
// usercheck.php
// ----------------- CONFIG -----------------
$dbHost = '185.194.177.9';
$dbName = 'hrisito';
$dbUser = 'interlection';
$dbPass = 'xRoles13:)';
$usersTable = 'gs_users';
// Group 4 is explicitly excluded from allowed groups
$allowedGroups = [1, 2, 5, 8, 9]; // Group 4 not included = blocked

// Toggle: allow clients to send plaintext passwords?
// true  = accept either SHA-1 hex or plaintext (plaintext will be SHA-1'd server-side)
// false = require SHA-1 hex only; plaintext is rejected
$ALLOW_PLAIN_TEXT_PASSWORDS = false;
// ------------------------------------------

// Helper to output result and exit
function out($msg) {
    header('Content-Type: text/plain; charset=utf-8');
    echo $msg;
    exit;
}

// Helper: detect 40-char SHA-1 hex
function is_sha1_hex($s) {
    return (bool)preg_match('/^[0-9a-f]{40}$/i', $s);
}

// Grab input from GET
$username = isset($_GET['username']) ? trim($_GET['username']) : '';
$password = isset($_GET['password']) ? $_GET['password'] : '';

if ($username === '') out('incorrect username');
if ($password === '') out('incorrect password');

// Connect to database
$dsn = "mysql:host={$dbHost};dbname={$dbName};charset=utf8mb4";
try {
    $pdo = new PDO($dsn, $dbUser, $dbPass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
} catch (PDOException $e) {
    out('internal error');
}

// Fetch user by username (case-sensitive like your original)
$stmt = $pdo->prepare("SELECT * FROM {$usersTable} WHERE username = :u LIMIT 1");
$stmt->execute([':u' => $username]);
$user = $stmt->fetch();

if (!$user) {
    out('incorrect username');
}

// Check group - Group 4 will be rejected here
if (!in_array((int)$user['group_id'], $allowedGroups, true)) {
    out('user group not allowed');
}

// Verify password with toggle
if ($ALLOW_PLAIN_TEXT_PASSWORDS) {
    // Accept SHA-1 hex directly, or hash plaintext
    $incomingHex = is_sha1_hex($password) ? strtolower(trim($password)) : sha1($password);
} else {
    // Require SHA-1 hex only
    if (!is_sha1_hex($password)) {
        out('incorrect password'); // or 'plaintext not allowed'
    }
    $incomingHex = strtolower(trim($password));
}

// Compare (normalize DB value to lowercase just in case)
if ($incomingHex !== strtolower($user['password'])) {
    out('incorrect password');
}

// All checks passed
out('success');