<?php
// generate_invite.php � PunBB/FluxBB-compatible invite generator (ape only)
define('PUN_ROOT', dirname(__FILE__).'/');
require PUN_ROOT.'include/common.php';

// --- Access control: must be logged in and exactly user "Apeisito"
if ($pun_user['is_guest'] || $pun_user['username'] !== 'Apeisito') {
    message('403 Forbidden: you are not authorized to access this page.');
}

// --- Helpers ---
function h($s){ return htmlspecialchars($s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function is_valid_uid($uid){ return (bool)preg_match('/^[A-Za-z0-9_-]{3,64}$/', $uid); }

// Create invites table if it doesn't exist (MySQL/MariaDB)
$db->query('
    CREATE TABLE IF NOT EXISTS '.$db->prefix."invites (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT,
        invite_code VARCHAR(64) NOT NULL UNIQUE,
        target_uid VARCHAR(64) NOT NULL,
        created_by INT UNSIGNED NOT NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY created_by (created_by)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;"
) or error('Failed creating table', __FILE__, __LINE__, $db->error());

// --- POST handler ---
$errors = [];
$ok_msg = null;
$new_code = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // CSRF + referrer like core files do
    if (!isset($_POST['csrf_token'])) {
        message('Invalid session token.');
    }
    confirm_referrer('generate_invite.php');
    check_csrf($_POST['csrf_token']);

    $uid = isset($_POST['uid']) ? trim($_POST['uid']) : '';
    if ($uid === '' || !is_valid_uid($uid)) {
        $errors[] = 'Please enter a valid UID (3�64 chars: letters, numbers, underscore, dash).';
    } else {
        // Generate a unique invite code
        // Format: INV-XXXXXXXXYYYYYYYY-ZZZZZZZZ (URL safe)
        $attempts = 0;
        while ($attempts < 4) {
            $attempts++;
            $hex1 = strtoupper(bin2hex(random_bytes(8)));
            $hex2 = strtoupper(bin2hex(random_bytes(4)));
            $code = 'INV-'.substr($hex1,0,8).substr($hex1,8,8).'-'.$hex2;

            $code_esc = $db->escape($code);
            $uid_esc  = $db->escape($uid);
            $by_id    = (int)$pun_user['id'];

            // Try insert; on duplicate, loop again (extremely rare)
            $sql = 'INSERT INTO '.$db->prefix."invites (invite_code, target_uid, created_by)
                    VALUES ('$code_esc', '$uid_esc', $by_id)";
            $res = $db->query($sql);
            if ($res) {
                $new_code = $code;
                $ok_msg = 'Invite generated successfully for UID �'.h($uid).'�.';
                break;
            } else {
                // If duplicate key, try again; otherwise surface error
                $err = $db->error();
                if (stripos($err, 'duplicate') === false) {
                    $errors[] = 'Error creating invite: '.h($err);
                    break;
                }
            }
        }
        if (!$new_code && empty($errors)) {
            $errors[] = 'Could not generate a unique code. Please try again.';
        }
    }
}

// Fetch recent invites created by this user
$recent = [];
$q = $db->query('SELECT invite_code, target_uid, created_at
                 FROM '.$db->prefix.'invites
                 WHERE created_by='.(int)$pun_user['id'].'
                 ORDER BY id DESC
                 LIMIT 10');
if ($q) {
    while ($row = $db->fetch_assoc($q)) $recent[] = $row;
}

// --- Output (simple styled page independent of forum theme) ---
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Generate Invites (ape only)</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
:root{--bg:#0b0f14;--card:#11161d;--muted:#7c8a9a;--text:#e5eef9;--accent:#3aa0ff;--ok:#35c26b;--err:#ff5c5c;--border:#1d2630;}
html,body{margin:0;padding:0;background:var(--bg);color:var(--text);font-family:system-ui,-apple-system,Segoe UI,Roboto,Ubuntu,Cantarell,"Helvetica Neue",Arial,"Noto Sans",sans-serif;}
.wrap{max-width:720px;margin:40px auto;padding:0 16px;}
.card{background:var(--card);border:1px solid var(--border);border-radius:14px;padding:20px;box-shadow:0 8px 24px rgba(0,0,0,.25);}
h1{font-size:1.5rem;margin:0 0 12px;}
p.muted{color:var(--muted);margin:6px 0 18px;}
form{display:flex;gap:10px;flex-wrap:wrap;align-items:flex-end;}
label{display:block;font-size:.9rem;color:var(--muted);margin-bottom:6px;}
input[type="text"]{background:#0c1218;color:var(--text);border:1px solid var(--border);border-radius:10px;padding:12px;width:280px;outline:none;}
input[type="text"]:focus{border-color:var(--accent);box-shadow:0 0 0 3px rgba(58,160,255,.15);}
button{background:var(--accent);color:#001222;border:none;padding:12px 16px;border-radius:10px;font-weight:700;cursor:pointer;}
button:hover{filter:brightness(1.05);}
.alert{padding:12px 14px;border-radius:10px;margin-bottom:14px;border:1px solid var(--border);}
.alert.ok{background:rgba(53,194,107,.08);border-color:rgba(53,194,107,.35);}
.alert.err{background:rgba(255,92,92,.08);border-color:rgba(255,92,92,.35);}
.mono{font-family:ui-monospace,SFMono-Regular,Menlo,Monaco,Consolas,"Liberation Mono","Courier New",monospace;}
.hint{font-size:.85rem;color:var(--muted);margin-top:8px;}
table{width:100%;border-collapse:collapse;margin-top:12px;}
th,td{text-align:left;padding:10px;border-bottom:1px solid var(--border);font-size:.95rem;}
th{color:var(--muted);font-weight:600;}
.code-badge{display:inline-block;background:#0c1218;border:1px solid var(--border);padding:6px 8px;border-radius:8px;font-weight:700;}
</style>
</head>
<body>
<div class="wrap">
  <div class="card">
    <h1>Generate an Invite</h1>
    <p class="muted">Only <strong>ape</strong> can access this page. Enter the target user's UID and click <em>Generate</em>.</p>

    <?php if (!empty($errors)): ?>
      <div class="alert err">
        <?php foreach ($errors as $e): ?><div><?php echo h($e); ?></div><?php endforeach; ?>
      </div>
    <?php endif; ?>

    <?php if ($ok_msg): ?>
      <div class="alert ok">
        <div><?php echo $ok_msg; ?></div>
        <?php if ($new_code): ?>
          <div style="margin-top:8px">Invite Code:
            <span class="code-badge mono"><?php echo h($new_code); ?></span>
          </div>
          <div class="hint">Example signup URL:
            <span class="mono">/register.php?invite=<?php echo h($new_code); ?></span>
          </div>
        <?php endif; ?>
      </div>
    <?php endif; ?>

    <form method="post" action="generate_invite.php">
      <div>
        <label for="uid">Target UID</label>
        <input type="text" id="uid" name="uid" required minlength="3" maxlength="64"
               pattern="[A-Za-z0-9_-]{3,64}" placeholder="e.g. user_123"
               value="<?php echo isset($_POST['uid'])? h((string)$_POST['uid']) : ''; ?>">
        <div class="hint">Allowed: letters, numbers, underscore, dash (3�64 chars)</div>
      </div>
      <input type="hidden" name="csrf_token" value="<?php echo h(pun_csrf_token()); ?>">
      <div>
        <button type="submit">Generate</button>
      </div>
    </form>

    <?php if (!empty($recent)): ?>
      <h2 style="font-size:1.1rem;margin:14px 0 8px;">Recent Invites</h2>
      <table>
        <thead><tr><th>Created</th><th>Target UID</th><th>Invite Code</th></tr></thead>
        <tbody>
        <?php foreach ($recent as $r): ?>
          <tr>
            <td><?php echo h($r['created_at']); ?></td>
            <td class="mono"><?php echo h($r['target_uid']); ?></td>
            <td class="mono"><?php echo h($r['invite_code']); ?></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
      <div class="hint">Showing the 10 most recent invites created by �ape�.</div>
    <?php endif; ?>
  </div>
</div>
</body>
</html>
