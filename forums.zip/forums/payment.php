<head>
<title>Payment / HrisitoSense</title>
<link rel="stylesheet" type="text/css" href="style/Cobalt1.min.css?v=31" />
<link rel="stylesheet" type="text/css" href="/static/css/font-awesome.min.css" />
<link href="https://fonts.googleapis.com/css?family=Raleway:900,400" rel="stylesheet" type="text/css" />
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
<script src="/static/js/notifications.js?v=4" type="text/javascript" charset="UTF-8"></script>
<style type="text/css">.payment-field { box-sizing: border-box; width: 20em; padding: 5px; } #stripe-elements-card { box-sizing: border-box; width: 20em; padding: 5px; background-color: #212122; border: 1px solid #3e3e3e; }</style>
</head>
<?php
define('PUN_ROOT', dirname(__FILE__).'/');
require PUN_ROOT.'include/common.php';
require PUN_ROOT.'header.php';
if ($pun_user['g_read_board'] == '0')
	message($lang_common['No view']);
?>

<?php 

$myid1 = $pun_user['username'];
$myid2 = $pun_user['email'];

 ?>
<div id="brdmain">
<div class="blockform">
	<?php 
	if($pun_user['g_id'] == 4){
		echo "<h2><span>Buy HrisitoSense</span></h2>";
	}
	else
	{	
		echo "<h2><span>Extend HrisitoSense</span></h2>";
	}
	?>
	<div class="box">
		<div id="confirmation" class="fakeform hidden">
			<div id="success-message" class="status success hidden">
				<div class="flex-row">
					<div class="flex-col flex-30">
						<img class="statusimg" src="/static/img/checkmark.svg" />
					</div>
					<div class="flex-col flex-70">
						<h1>Success!</h1>
						<p class="note">We just sent a receipt to your email address, and your subscription will be extended soon.</p>
					</div>
				</div>
			</div>
			<div id="error-message" class="status error hidden">
				<div class="flex-row">
					<div class="flex-col flex-30">
						<img class="statusimg" src="/static/img/warning.svg" />
					</div>
					<div class="flex-col flex-70">
						<h1>Payment failed</h1>
						<p id="error-text">Something went wrong while activating your subscription. Please try again.</p>
					</div>
				</div>
			</div>
		</div>

		<div id="payment-container">
			<div class="centered">
				<div id="loading" class="spinner hidden centered">
					<div class="bounce1"></div><div class="bounce2"></div><div class="bounce3"></div>
				</div>
			</div>
			<form id="payment_options" method="post">
                <!-- CSRF token (added) -->
                <input type="hidden" id="csrf_token" name="csrf_token" value="<?php echo pun_csrf_token(); ?>">
				<div class="inform">
					<fieldset>
						<div class="fakeform">
							<table class="aligntop">
								<tbody>
									<tr>
										<th scope="row">Username</th>
										<td><input class="payment-field" id="username" type="text" name="username" value="<?php echo $pun_user['username'] ?>" maxlength="80" /></td>
									</tr>
									<tr>
										<th scope="row">Email</th>
										<td><input class="payment-field" id="billing_email" type="text" name="email" value="<?php echo $pun_user['email'] ?>" maxlength="80" /></td>
									</tr>
									<tr>
										<th scope="row">Game</th>
										<td>
											<select id="game" class="payment-field" name="game">
												<option value="csgo" selected>Counter-Strike: Global Offensive</option>
												<option value="minecraft" disabled>Minecraft</option>
											</select>
										</td>
									</tr>
									<tr>
										<th scope="row">Plan</th>
										<td>
											<select id="plan" class="payment-field" name="plan">
												<option value="30">30 days - $0.00</option>
												<option value="90">90 days - $0.00</option>
												<option value="365">365 days - $0.00</option>
												<option value="1825">5 years - $0.00</option>
											</select>
										</td>
									</tr>
									<tr>
										<th scope="row">Method</th>
										<td>
											<select id="pmethod" class="payment-field" name="pmethod">
												<option value="card">Card</option>
												<option value="card">Roblox gift card</option>
											</select>
										</td>
									</tr>
								</tbody>
							</table>
						</div>
					</fieldset>
					<div class="centered">
						<input class="button" id="payment_options_submit" type="submit" value="Continue"/>
					</div>
				</div>
			</form>
		</div>
	</div>
</div>

<script>
$(document).ready(function() {
	$('#payment_options').submit(function(e) {
		e.preventDefault();
		
		// Show loading
		$('#loading').removeClass('hidden');
		$('#payment-container').hide();
		
		// Get the form data (UI stays identical; server should not trust username/email)
		var planDays = parseInt($('#plan').val(), 10);
		var username = $('#username').val();
		var email = $('#billing_email').val();
		var game = $('#game').val();
        var csrf = $('#csrf_token').val();

        // Minimal validation to stop obvious abuse (no visual change)
        if (!Number.isInteger(planDays) || planDays < 1) {
            $('#loading').addClass('hidden');
            $('#payment-container').show();
            $('#error-text').text('Invalid plan selected.');
            $('#error-message').removeClass('hidden');
            $('#confirmation').removeClass('hidden');
            return;
        }
        if (game !== 'csgo') {
            $('#loading').addClass('hidden');
            $('#payment-container').show();
            $('#error-text').text('Invalid game selected.');
            $('#error-message').removeClass('hidden');
            $('#confirmation').removeClass('hidden');
            return;
        }
		
		// Make AJAX call to process subscription
		$.ajax({
			url: './process_free_subscription.php',
			method: 'POST',
			data: {
				username: username,
				email: email,
				game: game,
				days: planDays,
                csrf_token: csrf // send CSRF (added)
			},
			dataType: 'json',
			success: function(response) {
				$('#loading').addClass('hidden');
				
				if (response.success) {
					// Show success message
					$('#success-message').removeClass('hidden');
					$('#confirmation').removeClass('hidden');
					$('#payment-container').hide();
				} else {
					// Show error message with specific error
					$('#error-text').text(response.message);
					$('#error-message').removeClass('hidden');
					$('#confirmation').removeClass('hidden');
					$('#payment-container').hide();
				}
			},
			error: function() {
				$('#loading').addClass('hidden');
				$('#error-text').text('Connection error. Please try again.');
				$('#error-message').removeClass('hidden');
				$('#confirmation').removeClass('hidden');
				$('#payment-container').hide();
			}
		});
	});
});
</script>

<?php
require PUN_ROOT.'footer.php';
?>