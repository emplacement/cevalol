<?php


 //
 // This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
 // This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
 // You should have received a copy of the GNU General Public License along with this program. If not, see <https://www.gnu.org/licenses/>. 
// Tell header.php to use the admin template

define('PUN_ROOT', dirname(__FILE__).'/');
require PUN_ROOT.'include/common.php';
require PUN_ROOT.'include/common_admin.php';

require PUN_ROOT.'lang/'.$pun_user['language'].'/profile.php';

define('PUN_ACTIVE_PAGE', 'requests');
$page_title = array(pun_htmlspecialchars($pun_config['o_board_title']), "Referrals");
require PUN_ROOT.'header.php';		

$id = $pun_user['id'];

if ($id < 2)
	message($lang_common['No permission'], false, '404 Not Found');

// Fetch used invites
$result44 = $db->query("
	SELECT * FROM `gs_codes`
	WHERE `by`='$id' AND `used`='1'
	ORDER BY `usedat` ASC
") or error('Unable to fetch invite codes', __FILE__, __LINE__, $db->error());

// If no invites used, deny access
if (!$db->num_rows($result44))
	message('You have not invited anyone.');

generate_profile_menu();
							
?>

<div class="blockform">
    <h2><span>Referrals</span></h2>
    <div class="box">
        <form>
            <div class="inform">
                <fieldset>
                    <legend>Your referrals</legend>
                    <div class="infldset">
                        <div class="inbox">
                            <table>
                                <tbody>
                                    <?php 
                                    // Fetch only used invite codes by this user, oldest first
                                    $result44 = $db->query("
                                        SELECT * FROM `gs_codes`
                                        WHERE `by`='$id' AND `used`='1'
                                        ORDER BY `usedat` ASC
                                    ") or error('Unable to fetch invite codes', __FILE__, __LINE__, $db->error());

                                    if ($db->num_rows($result44)) {
                                        foreach($result44 as $item): 
                                            $usercode = $item['user'];

                                            // Fetch user info for the person who used the code
                                            $usercodel = $db->query("
                                                SELECT `username`, `group_id`
                                                FROM `gs_users`
                                                WHERE `id`='$usercode'
                                            ") or error('Unable to fetch user info', __FILE__, __LINE__, $db->error());

                                            $usercodel = $db->fetch_assoc($usercodel);    
                                            $username = $usercodel['username']; 
                                            $group_id = $usercodel['group_id'];  
                                    ?>
                                    <tr>
                                        <td class="tc3"><?php echo htmlspecialchars($item['code']); ?></td>
                                        <td class="tc3">
                                            <a href="profile.php?id=<?php echo $usercode; ?>">
                                                <?php echo colorize_group($username, $group_id); ?>
                                            </a>
                                        </td>
                                        <td class="tc3">
                                            <?php 
                                            if (!empty($item['usedat'])) {							
                                                $codedate1 = new DateTime($item['usedat']);				
                                                $codedate1 = format_time($codedate1->getTimestamp(), false, null, null, false, true);
                                                echo $codedate1;
                                            } else {
                                                echo "-";
                                            }
                                            ?>
                                        </td>
                                    </tr>
                                    <?php 
                                        endforeach; 
                                    } else { 
                                    ?>
                                        <p>You have not invited anybody.</p>
                                    <?php } ?> 
                                </tbody>
                            </table>
                        </div>
                    </div>
                </fieldset>
            </div>
            <p><a href="profile.php?section=premium&amp;id=<?php echo $id; ?>">Back to premium</a></p>
        </form>
    </div>
</div>
<div class="clearer"></div>



<?php

require PUN_ROOT.'footer.php';
	
?>