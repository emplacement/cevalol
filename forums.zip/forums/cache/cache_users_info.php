<?php

define('PUN_USERS_INFO_LOADED', 1);

$stats = array (
  'total_users' => '5734',
  'last_user' => 
  array (
    'id' => '5773',
    'username' => 'CheeseBurgerLover',
    'group_id' => '4',
  ),
);

?>