<?php
// download.php
// ----------------- CONFIG -----------------
$dbHost = '185.194.177.9';
$dbName = 'hrisito';
$dbUser = 'interlection';
$dbPass = 'xRoles13:)';
$usersTable = 'gs_users';
// Group 4 is explicitly excluded from allowed groups
$allowedGroups = [1, 2, 5, 8, 9];
// URL of the file to download
$file_url = 'https://hrisitosense.top/aosjrtijasb5ji/loader.exe';
// ------------------------------------------

// Helper to output error and exit
function error_exit($msg) {
    http_response_code(403);
    header('Content-Type: text/plain; charset=utf-8');
    echo $msg;
    exit;
}

// Get credentials from query parameters
$username = isset($_GET['username']) ? trim($_GET['username']) : '';
$password = isset($_GET['password']) ? $_GET['password'] : '';

if ($username === '') error_exit('incorrect username');
if ($password === '') error_exit('incorrect password');

// Connect to database
$dsn = "mysql:host={$dbHost};dbname={$dbName};charset=utf8mb4";
try {
    $pdo = new PDO($dsn, $dbUser, $dbPass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
} catch (PDOException $e) {
    error_exit('internal error');
}

// Fetch user by username
$stmt = $pdo->prepare("SELECT * FROM {$usersTable} WHERE username = :u LIMIT 1");
$stmt->execute([':u' => $username]);
$user = $stmt->fetch();

if (!$user) {
    error_exit('incorrect username');
}

// Check group - Group 4 will be rejected here
if (!in_array((int)$user['group_id'], $allowedGroups, true)) {
    error_exit('user group not allowed');
}

// Verify password (SHA1)
if (sha1($password) !== $user['password']) {
    error_exit('incorrect password');
}

// Authentication successful - proceed with download
// Initialize cURL session
$ch = curl_init($file_url);

// Set cURL options
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
curl_setopt($ch, CURLOPT_TIMEOUT, 300);

// Execute the request
$file_content = curl_exec($ch);
$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);

// Check for errors
if (curl_errno($ch) || $http_code !== 200) {
    curl_close($ch);
    http_response_code(500);
    error_exit('failed to download file');
}

curl_close($ch);

// Set headers for download
header('Content-Type: application/octet-stream');
header('Content-Disposition: attachment; filename="loader.exe"');
header('Content-Length: ' . strlen($file_content));
header('Cache-Control: no-cache, must-revalidate');
header('Pragma: no-cache');

// Output the file content
echo $file_content;
exit;
?>