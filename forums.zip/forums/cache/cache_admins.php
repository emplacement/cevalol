<?php

define('PUN_ADMINS_LOADED', 1);

$pun_admins = array (
  0 => '2',
  1 => '13',
  2 => '15',
  3 => '39',
  4 => '46',
  5 => '53',
  6 => '639',
  7 => '2118',
);

?>