<?php
//
// moderation.php
// GPL-3.0-or-later
//

// Tell header.php to use the admin template
define('PUN_ADMIN_CONSOLE', 1);

define('PUN_ROOT', dirname(__FILE__).'/');
require PUN_ROOT.'include/common.php';
require PUN_ROOT.'include/common_admin.php';

if (!$pun_user['is_admmod'])
    message($lang_common['No permission']);

// Load the admin_index.php language file
require PUN_ROOT.'lang/'.$admin_language.'/admin_index.php';

$page_title = array(pun_htmlspecialchars($pun_config['o_board_title']), "Moderation");
define('PUN_ACTIVE_PAGE', 'requests');
require PUN_ROOT.'header.php';

// ----------------------------------------------------------------------------
// Search handlers
// ----------------------------------------------------------------------------

// ----- Invite code search -----
$search_result = null;
$partial_results = [];

if (isset($_GET['action']) && $_GET['action'] == 'search_code' && isset($_GET['invite_code'])) {
    // CSRF check
    check_csrf($_GET['csrf_token']);

    $invite_code = trim($db->escape($_GET['invite_code']));

    // Try exact match first
    $result = $db->query("SELECT * FROM `gs_codes` WHERE `code` = '".$invite_code."' LIMIT 1")
        or error('Unable to search invite code', __FILE__, __LINE__, $db->error());

    if ($db->num_rows($result)) {
        // Found exact match
        $code_info = $db->fetch_assoc($result);

        // Owner info
        $user_info = $db->query("SELECT `username`, `group_id` FROM `gs_users` WHERE `id` = '".$code_info['by']."' LIMIT 1")
            or error('Unable to fetch user info', __FILE__, __LINE__, $db->error());
        $user = $db->fetch_assoc($user_info);

        // Used by info (kept for potential future use, but not shown in the compact row)
        $used_by_info = null;
        if (!empty($code_info['user'])) {
            $used_by_query = $db->query("SELECT `username`, `group_id` FROM `gs_users` WHERE `id` = '".$code_info['user']."' LIMIT 1")
                or error('Unable to fetch used-by user info', __FILE__, __LINE__, $db->error());
            $used_by_info = $db->fetch_assoc($used_by_query);
        }

        $search_result = [
            'code'          => $invite_code,
            'owner_id'      => $code_info['by'],
            'owner_name'    => $user['username'],
            'owner_group'   => $user['group_id'],
            'used'          => $code_info['used'],
            'used_at'       => $code_info['usedat'],
            'used_by'       => $used_by_info ? $used_by_info['username'] : null,
            'used_by_id'    => $used_by_info ? $code_info['user'] : null,
            'used_by_group' => $used_by_info ? $used_by_info['group_id'] : null,
            'date'          => $code_info['date'],
        ];
    } else {
        // No exact match — try partial search
        $invite_like = '%' . $db->escape($invite_code) . '%';

        $result_partial = $db->query("
            SELECT code, `by`, used, `user`, date, usedat
            FROM `gs_codes`
            WHERE `code` LIKE '".$invite_like."'
            ORDER BY `date` DESC
            LIMIT 20
        ") or error('Unable to search partial invites', __FILE__, __LINE__, $db->error());

        if ($db->num_rows($result_partial)) {
            while ($row = $db->fetch_assoc($result_partial)) {
                $user_info = $db->query("SELECT `username`, `group_id` FROM `gs_users` WHERE `id` = '".$row['by']."' LIMIT 1")
                    or error('Unable to fetch user info', __FILE__, __LINE__, $db->error());
                $user = $db->fetch_assoc($user_info);

                $partial_results[] = [
                    'code'        => $row['code'],
                    'owner_id'    => $row['by'],
                    'owner_name'  => $user['username'],
                    'owner_group' => $user['group_id'],
                    'used'        => $row['used'],
                    'date'        => $row['date'],
                ];
            }
        } else {
            $search_result = false;
        }
    }
}

// ----- Subscription expiry (csgo) search -----
$expiry_result_rows = [];
$expiry_query_raw = null;
$expiry_has_more = false; // <-- add this

if (isset($_GET['action']) && $_GET['action'] === 'search_expiry' && isset($_GET['expiry_query'])) {
    // CSRF check
    check_csrf($_GET['csrf_token']);

    $expiry_query_raw = trim($_GET['expiry_query']);

    // Normalize input: replace * -> %, collapse whitespace
    $like = preg_replace('/\s+/', ' ', $expiry_query_raw);
    $like = str_replace('*', '%', $like);

    // If no wildcard, wrap in %...%
    if (strpos($like, '%') === false && strpos($like, '_') === false) {
        $like = '%'.$like.'%';
    }

    // Escape for SQL string literal
    $like_sql = $db->escape($like);

    // Fetch 101 to know if there are more than 100
    $q = "
        SELECT id, username, group_id, csgo
        FROM `gs_users`
        WHERE `csgo` IS NOT NULL
          AND DATE_FORMAT(`csgo`, '%d-%m-%Y %H:%i:%s') LIKE '".$like_sql."'
        ORDER BY `csgo` DESC
        LIMIT 101
    ";

    $res = $db->query($q);
    if ($res === false) {
        error('Unable to search by subscription expiry: '.$db->error(), __FILE__, __LINE__);
    }

    $total = $db->num_rows($res);
    if ($total > 100) {
        $expiry_has_more = true; // <-- overflow flag
    }

    // Collect up to 100 rows for display
    $count = 0;
    if ($total) {
        while ($row = $db->fetch_assoc($res)) {
            if ($count >= 100) break;
            $expiry_result_rows[] = $row;
            $count++;
        }
    }
}


// ----------------------------------------------------------------------------
// HWID approve/decline actions
// ----------------------------------------------------------------------------

if (isset($_GET['hwid']) && isset($_GET['id'])) {
    // Add an extra layer of security
    confirm_referrer('moderation.php');
    // CSRF check
    check_csrf($_GET['csrf_token']);

    $resetid = intval($_GET['id']);

    if ($_GET['hwid'] == "approve" && isset($_GET['new']) && isset($_GET['ip'])) {
        $resetidnew = $db->escape($_GET['new']);
        $resetipnew = $db->escape($_GET['ip']);
        $db->query("UPDATE `gs_users` SET `hwid` = '$resetidnew', `hwid_new` = NULL, `hwid_reason` = NULL, `hwid_ip` = '$resetipnew', `hwid_ip_new` = NULL, `parts` = `newparts`, `newparts` = NULL WHERE `id` = '$resetid'")
            or error('Unable to update user', __FILE__, __LINE__, $db->error());

        // Notify user (accepted)
        $text = 'Your Hardware ID was accepted';
        $db->query('INSERT INTO gs_notifications (user_id, actor_id, type, message)
                    VALUES ('.$resetid.', '.$pun_user['id'].', "hwid_accept", "'.$db->escape($text).'")')
            or error('Unable to insert HWID approve notification', __FILE__, __LINE__, $db->error());

        redirect('moderation.php', "Request was approved");
        die();
    } elseif ($_GET['hwid'] == "decline") {
        $db->query("UPDATE `gs_users` SET `hwid_new` = NULL, `hwid_reason` = NULL, `hwid_ip_new` = NULL WHERE `id` = '$resetid'")
            or error('Unable to update user', __FILE__, __LINE__, $db->error());

        // Notify user (denied)
        $text = 'Your Hardware ID was denied';
        $db->query('INSERT INTO gs_notifications (user_id, actor_id, type, message)
                    VALUES ('.$resetid.', '.$pun_user['id'].', "hwid_deny", "'.$db->escape($text).'")')
            or error('Unable to insert HWID deny notification', __FILE__, __LINE__, $db->error());

        redirect('moderation.php', "Request was declined");
        die();
    } else {
        redirect('moderation.php', "Unknown parameters");
        die();
    }
}
?>
<div class="block">
    <h2 class="block2"><span>Hardware ID requests</span></h2>
    <div class="box">
        <div class="inbox" style="padding:0">
            <table>
                <thead>
                    <tr>
                        <th class="tc3">User</th>
                        <th class="tc3">Parts</th>
                        <th class="tc3">IP</th>
                        <th class="tc3">New parts</th>
                        <th class="tc3">Requested IP</th>
                        <th class="tc3">Reason</th>
                        <th class="tc3">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $result447 = $db->query("SELECT * FROM `gs_users` WHERE `hwid_reason` IS NOT NULL")
                        or error('Unable to fetch user info', __FILE__, __LINE__, $db->error());

                    foreach ($result447 as $item): ?>
                        <tr>
                            <td class="tc3"><a href="profile.php?id=<?php echo $item['id'] ?>"><?php echo colorize_group($item['username'],$item['group_id']) ?></a></td>
                            <td class="tc3"><?php echo pun_htmlspecialchars($item['parts']) ?></td>
                            <td class="tc3"><?php echo $item['registration_ip'] ?></td>
                            <td class="tc3"><?php echo pun_htmlspecialchars($item['newparts']) ?></td>
                            <td class="tc3"><?php echo $item['hwid_ip_new'] ?></td>
                            <td class="tc3"><?php echo pun_htmlspecialchars($item['hwid_reason']) ?></td>
                            <td class="tc3">
                                <a href="moderation.php?csrf_token=<?php echo pun_csrf_token() ?>&hwid=approve&id=<?php echo $item['id']?>&new=<?php echo $item['hwid_new']?>&ip=<?php echo $item['hwid_ip_new']?>">Approve</a>
                                /
                                <a href="moderation.php?csrf_token=<?php echo pun_csrf_token() ?>&hwid=decline&id=<?php echo $item['id']?>">Decline</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    <?php if (empty($result447) || !$db->num_rows($result447)): ?>
                        <tr>
                            <td colspan="8" style="text-align:center;border-width:0;padding:6px;">You're all caught up!</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <br>

    <h2 class="block2"><span>Search users by invite code</span></h2>
    <div id="adsearch" class="box">
        <div class="inbox">
            <form method="get" action="moderation.php">
                <input type="hidden" name="action" value="search_code">
                <input type="hidden" name="csrf_token" value="<?php echo pun_csrf_token(); ?>">
                <div class="infldset">
                    <input type="text" id="invite_code" name="invite_code"
                        value="<?php echo isset($_GET['invite_code']) ? pun_htmlspecialchars($_GET['invite_code']) : ''; ?>"
                        style="width:400px;padding:4px 8px;"
                        autocorrect="off" autocapitalize="off" spellcheck="false">
                    <input type="submit" value="Search" style="padding:4px 8px;">
                </div>
            </form>

            <?php if ($search_result === false && empty($partial_results)): ?>
                <p>No user found with that invite code.</p>

            <?php elseif (is_array($search_result) && empty($partial_results)): ?>
                <div style="margin-top: -8px;">
                    <table>
                        <thead>
                            <tr>
                                <th>Code</th>
                                <th>Owner</th>
                                <th>Status</th>
                                <th>Created on</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td><?php echo pun_htmlspecialchars($search_result['code']); ?></td>
                                <td>
                                    <a href="profile.php?id=<?php echo $search_result['owner_id']; ?>">
                                        <?php echo colorize_group($search_result['owner_name'], $search_result['owner_group']); ?>
                                    </a>
                                </td>
                                <td><?php echo $search_result['used'] == 1 ? '<span style="color:green;">Used</span>' : '<span style="color:orange;">Unused</span>'; ?></td>
                                <td><?php echo format_time(strtotime($search_result['date']), false, null, null, false, true); ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>

            <?php elseif (!empty($partial_results)): ?>
                <div style="margin-top: -8px;">
                    <table>
                        <thead>
                            <tr>
                                <th>Code</th>
                                <th>Owner</th>
                                <th>Status</th>
                                <th>Created on</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($partial_results as $res): ?>
                                <tr>
                                    <td><?php echo pun_htmlspecialchars($res['code']); ?></td>
                                    <td>
                                        <a href="profile.php?id=<?php echo $res['owner_id']; ?>">
                                            <?php echo colorize_group($res['owner_name'], $res['owner_group']); ?>
                                        </a>
                                    </td>
                                    <td><?php echo $res['used'] == 1 ? '<span style="color:green;">Used</span>' : '<span style="color:orange;">Unused</span>'; ?></td>
                                    <td><?php echo format_time(strtotime($res['date']), false, null, null, false, true); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <br>

    <h2 class="block2"><span>Search users by subscription expiry date</span></h2>
    <div id="adsearch-expiry" class="box">
        <div class="inbox">
            <form method="get" action="moderation.php" autocomplete="off">
                <input type="hidden" name="action" value="search_expiry">
                <input type="hidden" name="csrf_token" value="<?php echo pun_csrf_token(); ?>">
                <div class="infldset">
                    <input
                        type="text"
                        id="expiry_query"
                        name="expiry_query"
                        value="<?php echo isset($expiry_query_raw) ? pun_htmlspecialchars($expiry_query_raw) : ''; ?>"
                        style="width:400px;padding:4px 8px;"
                        autocorrect="off" autocapitalize="off" spellcheck="false"
                        placeholder="DD-MM-YYYY HH:MM:SS"
                    >
                    <input type="submit" value="Search" style="padding:4px 8px;">
                </div>
            </form>

            <?php if (isset($_GET['action']) && $_GET['action'] === 'search_expiry'): ?>
                <?php if (empty($expiry_result_rows)): ?>
                    <p>No users found for that pattern.</p>
                <?php else: ?>
                    <div>
                        <table>
                            <thead>
                                <tr>
                                    <th>User</th>
                                    <th>Group</th>
                                    <th>Expiry (raw)</th>
                                    <th>Expiry (formatted)</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($expiry_result_rows as $u): ?>
                                    <tr>
                                        <td>
                                            <a href="profile.php?id=<?php echo intval($u['id']); ?>">
                                                <?php echo colorize_group($u['username'], $u['group_id']); ?>
                                            </a>
                                        </td>
                                        <td><?php echo intval($u['group_id']); ?></td>
                                        <td><?php echo pun_htmlspecialchars($u['csgo']); ?></td>
                                        <td>
                                            <?php
                                                $ts = strtotime($u['csgo']);
                                                echo $ts ? format_time($ts, false, null, null, false, true) : '-';
                                            ?>
                                        </td>
                                        <td>
                                            <?php
                                                $is_active = false;
                                                if (!empty($u['csgo'])) {
                                                    $d1 = new DateTime($u['csgo']);
                                                    $d2 = new DateTime('now');
                                                    $is_active = ($d1 > $d2);
                                                }
                                                echo $is_active ? '<span style="color:green;">Active</span>' : '<span style="color:#999;">Expired</span>';
                                            ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
						<?php if (!empty($expiry_result_rows) && $expiry_has_more): ?>
							<p style="margin-top:6px;">100 results shown (max 100)</p>
						<?php endif; ?>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>

    <div class="clearer"></div>
</div>

<?php require PUN_ROOT.'footer.php'; ?>