// AJAX Chat Fix - Forces chat to load messages immediately
$(document).ready(function() {
    console.log('Chat fix loading...');
    
    // Wait a moment for the main chat script to initialize
    setTimeout(function() {
        console.log('Attempting to start chat...');
        
        // Method 1: Try to use the main chat object if it exists
        if (typeof ajaxChat !== 'undefined') {
            console.log('ajaxChat object found');
            if (ajaxChat.startChat) {
                ajaxChat.startChat();
            }
            if (ajaxChat.updateChat) {
                ajaxChat.updateChat();
            }
        }
        
        // Method 2: Force load messages directly using your config
        if (typeof ajaxChatConfig !== 'undefined') {
            console.log('Forcing message load...');
            $.ajax({
                url: ajaxChatConfig.ajaxURL,
                type: 'GET',
                success: function(data) {
                    console.log('Messages loaded successfully');
                    if ($('#' + ajaxChatConfig.domIDs.chatList).length) {
                        $('#' + ajaxChatConfig.domIDs.chatList).html(data);
                    }
                },
                error: function() {
                    console.log('Error loading messages');
                }
            });
        }
        
        // Method 3: Set up backup polling if main chat isn't working
        setInterval(function() {
            // Only poll if chat list appears empty
            if ($('#' + ajaxChatConfig.domIDs.chatList).children().length === 0) {
                $.ajax({
                    url: ajaxChatConfig.ajaxURL,
                    type: 'GET',
                    success: function(data) {
                        $('#' + ajaxChatConfig.domIDs.chatList).html(data);
                    }
                });
            }
        }, 2000); // Check every 2 seconds as backup
        
    }, 500); // Wait 500ms for main chat to initialize
});

// Also try to force update when input field gets focus (your current working trigger)
$(document).on('focus', '#' + ajaxChatConfig.domIDs.inputField, function() {
    console.log('Input focused - forcing update...');
    if (typeof ajaxChat !== 'undefined' && ajaxChat.updateChat) {
        ajaxChat.updateChat();
    }
});