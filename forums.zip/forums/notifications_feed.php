<?php
// notifications_feed.php
define('PUN_ROOT', dirname(__FILE__).'/');
require PUN_ROOT.'include/common.php';

header('Content-Type: application/json');

if ($pun_user['is_guest']) { echo json_encode([]); exit; }

// Optional: mark unread as read when opening the dropdown
$mark = isset($_GET['mark_read']) && $_GET['mark_read'] === '1';
if ($mark) {
    // CSRF
    if (!isset($_GET['csrf_token'])) { http_response_code(403); echo json_encode(['error'=>'csrf']); exit; }
    check_csrf($_GET['csrf_token']);
    $db->query('UPDATE gs_notifications SET is_read=1 WHERE user_id='.$pun_user['id'].' AND is_read=0')
        or error('Unable to mark notifications read', __FILE__, __LINE__, $db->error());
}

// latest 10
$q = $db->query('
    SELECT id, type, message, url, created_at
    FROM gs_notifications
    WHERE user_id='.$pun_user['id'].'
    ORDER BY created_at DESC
    LIMIT 10
') or error('Unable to fetch notifications', __FILE__, __LINE__, $db->error());

$out = [];
while ($n = $db->fetch_assoc($q)) {
    $text = $n['message'];
    if ($text === '' || $text === null) {
        if ($n['type']==='mention') $text = 'You were tagged in a post';
        elseif ($n['type']==='hwid_accept') $text = 'Your Hardware ID was accepted';
        elseif ($n['type']==='hwid_deny') $text = 'Your Hardware ID was denied';
        else $text = 'You have a new notification';
    }
    $out[] = [
        'id' => (int)$n['id'],
        'text' => $text,
        'url' => $n['url'],
        'time' => format_time(strtotime($n['created_at']), false, null, null, false, true),
    ];
}

echo json_encode($out);
