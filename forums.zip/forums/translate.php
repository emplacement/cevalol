<head>
<title>Language File Creator / HrisitoSense</title>
</head>
<?php
define('PUN_ROOT', dirname(__FILE__).'/');
require PUN_ROOT.'include/common.php';
require PUN_ROOT.'header.php';
if ($pun_user['g_read_board'] == '0')
    message($lang_common['No view']);
?>

<h2><span>Language File Creator</span></h2>

<div id="profile">
  <div class="blockform">
    <div class="box">
      <form id="lang_form" method="post" action="#">

        <div class="inform">
          <fieldset>
            <legend>Metadata</legend>
            <div class="infldset">
              <p>
                <label for="hlc-languageName">Language</label><br />
                <input id="hlc-languageName" type="text" name="languageName" placeholder="e.g., English" size="40" maxlength="80" />
              </p>
              <p>
                <label for="hlc-compatibility">Compatibility</label><br />
                <input id="hlc-compatibility" type="checkbox" name="compatibility" value="1" /> Enable
              </p>
            </div>
          </fieldset>
        </div>

        <div class="inform">
          <fieldset>
            <legend>Filter &amp; View</legend>
            <div class="infldset">
              <p>
                <label for="hlc-filter">Filter keys</label><br />
                <input id="hlc-filter" type="search" name="filter" placeholder="Type to filter by key name�" size="40" />
              </p>
              <p>
                <label for="hlc-showMode">Show</label><br />
                <select id="hlc-showMode" name="showMode">
                  <option value="all">All keys</option>
                  <option value="empty">Only empty</option>
                  <option value="filled">Only filled</option>
                </select>
              </p>
              <p class="note" id="hlc-stats">0/0 filled</p>
            </div>
          </fieldset>
        </div>

        <div class="inform">
          <fieldset>
            <legend>Import / Export</legend>
            <div class="infldset">
  <p>
    <label>Export / Import</label>
    <button type="button" class="button" id="hlc-exportBtn" name="export">Export .lang</button>
    <button type="button" class="button" id="hlc-importBtn" name="import">Import .lang</button>
    <input id="hlc-fileInput" type="file" accept=".lang,.txt" />
  </p>
  <p>
    <label>Clipboard & Drafts</label>
    <button type="button" class="button" id="hlc-copyBtn" name="copy">Copy to clipboard</button>
    <button type="button" class="button" id="hlc-saveDraftBtn" name="saveDraft">Save draft</button>
    <button type="button" class="button" id="hlc-loadDraftBtn" name="loadDraft">Load draft</button>
    <button type="button" class="button" id="hlc-resetBtn" name="reset">Reset</button>
  </p>
</div>
          </fieldset>
        </div>

        <div class="inform">
          <fieldset>
            <legend>Add custom key</legend>
            <div class="infldset">
              <p>
                <label for="hlc-newKey">Key</label><br />
                <input id="hlc-newKey" type="text" name="newKey" placeholder="NewKeyName" size="30" />
              </p>
              <p>
                <label for="hlc-newVal">Value</label><br />
                <input id="hlc-newVal" type="text" name="newVal" placeholder="Value" size="60" />
              </p>
              <p>
                <button type="button" class="button" id="hlc-addKeyBtn" name="addKey">Add</button>
              </p>
              <p>
                <button type="button" class="button" id="hlc-autofillBtn" name="autofill" title="Fill empty values with their key names">Autofill empties</button>
              </p>
            </div>
          </fieldset>
        </div>

        <div class="inform">
          <fieldset>
            <legend>Language entries</legend>
            <div class="infldset">
              <table id="hlc-table" aria-describedby="Language key/value editor">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>Key</th>
                    <th>Value</th>
                    <th>Tools</th>
                  </tr>
                </thead>
                <tbody id="hlc-tbody"></tbody>
              </table>
              <p>Tip: Use <kbd>Ctrl</kbd>/<kbd>Cmd</kbd>+<kbd>F</kbd> to search. Values auto-save while you type.</p>
            </div>
          </fieldset>
        </div>

      </form>
    </div>
  </div>
</div>

<style>
/* Compact, layout-only tweaks (no colors) */
#lang_form .infldset p{display:flex;align-items:center;gap:10px;margin:4px 0;flex-wrap:wrap}
#lang_form .infldset p>label{width:160px;text-align:right;margin:0}
#lang_form input[type="text"],
#lang_form input[type="search"],
#lang_form select{flex:1 1 360px;max-width:520px}
#lang_form input[type="file"]{flex:1 1 auto}
#lang_form .button{margin-right:6px}
#hlc-table{width:100%;border-collapse:collapse}
#hlc-table th,#hlc-table td{padding:6px 8px}
#hlc-table td input[type="text"]{width:100%}
#hlc-table td .button{margin-right:6px}
@media (max-width:700px){
  #lang_form .infldset p>label{width:120px;text-align:left}
}
</style>

<script>
(function(){
  const TEMPLATE = `language=blank\ncompatibility=false\nWeapon type=\nGlobal=\nG3SG1 / SCAR-20=\nSSG 08=\nAWP=\nR8 Revolver=\nDesert Eagle=\nPistol=\nZeus=\nRifle=\nShotgun=\nSMG=\nMachine gun=\nAimbot=\nEnabled=\nTarget selection=\nHighest damage=\nCycle=\nCycle (2x)=\nNear crosshair=\nBest hit chance=\nTarget hitbox=\nHead=\nChest=\nStomach=\nArms=\nLegs=\nFeet=\nMultiselect=\nMulti-point=\nMulti-point scale=\nSlider=\nMinimum hit chance=\nMinimum damage=\nMinimum damage override=\nPrefer safe point=\nForce safe point=\nAvoid unsafe hitboxes=\nPrefer body aim=\nPrefer body aim disablers=\nLow inaccuracy=\nTarget shot fired=\nTarget resolved=\nSafe point headshot=\nForce body aim=\nForce body aim on peek=\nQuick stop=\nEarly=\nSlow motion=\nDuck=\nFake duck=\nMove between shots=\nIgnore molotov=\nTaser=\nJump scout=\nDouble tap=\nOffensive=\nDefensive=\nDouble tap hit chance=\nDouble tap fake lag limit=\nDouble tap quick stop=\nAutomatic scope=\nOther=\nAccuracy boost=\nLow=\nMedium=\nHigh=\nMaximum=\nAnti-aim correction=\nAutomatic fire=\nAutomatic penetration=\nSilent aim=\nRemove recoil=\nDelay shot=\nQuick peek assist=\nQuick peek assist mode=\nRetreat on shot=\nRetreat on key release=\nQuick peek assist distance=\nDuck peek assist=\nReduce aim step=\nReduce aim step limit=\nMaximum FOV=\nLog misses due to spread=\nLow FPS mitigations=\nForce low accuracy boost=\nDisable multipoint: feet=\nDisable multipoint: arms=\nDisable multipoint: legs=\nDisable hitbox: feet=\nLower hit chance precision=\nLimit targets per tick=\nAnti-aimbot angles=\nPitch=\nOff=\nDefault=\nUp=\nDown=\nMinimal=\nRandom=\nCustom=\nYaw base=\nLocal view=\nAt targets=\nYaw=\n180=\nSpin=\nStatic=\nCrosshair=\nYaw jitter=\nOffset=\nCenter=\nSkitter=\nBody yaw=\nOpposite=\nJitter=\nFreestanding body yaw=\nEdge yaw=\nFreestanding=\nRoll=\nFake lag=\nAmount=\nDynamic=\nFluctuate=\nVariance=\nLeg movement=\nAlways slide=\nNever slide=\nOn shot anti-aim=\nFake peek=\nSpeed=\nSpeed (in attack)=\nSpeed scale - FOV=\nMaximum lock-on time=\nReaction time=\nRecoil compensation (P/Y)=\nAim through smoke=\nAim while blind=\nFirst shot delay range=\nTriggerbot=\nBurst fire=\nShoot through smoke=\nShoot while blind=\nAccuracy boost range=\nStandalone recoil compensation=\nPlayer ESP=\nActivation type=\nTeammates=\nDormant=\nBounding box=\nHealth bar=\nName=\nFlags=\nWeapon text=\nWeapon icon=\nAmmo=\nDistance=\nGlow=\nHit marker=\nHit marker sound=\nVisualize aimbot=\nVisualize aimbot (safe point)=\nVisualize sounds=\nLine of sight=\nMoney=\nSkeleton=\nOut of FOV arrow=\nOther ESP=\nRadar=\nDropped weapons=\nIcon=\nText=\nGrenades=\nInaccuracy overlay=\nRecoil overlay=\nBomb=\nGrenade trajectory=\nGrenade trajectory (hit)=\nGrenade proximity warning=\nSpectators=\nPenetration reticle=\nHostages=\nFeature indicators=\nShared ESP=\nShared ESP with other team=\nRestrict shared ESP updates=\nUpgrade tablet=\nDanger Zone items=\nDrone gun=\nBlackhawk=\nDrone=\nRandom case=\nTool case=\nPistol case=\nExplosive case=\nHeavy weapon case=\nLight weapon case=\nDufflebag=\nJammer=\nAmmobox=\nArmor=\nParachute pack=\nBriefcase=\nTablet upgrade zone=\nTablet upgrade drone=\nCash stack=\nEffects=\nRemove flashbang effects=\nRemove smoke grenades=\nRemove fog=\nRemove skybox=\nVisual recoil adjustment=\nRemove shake=\nRemove all=\nTransparent walls=\nTransparent props=\nBrightness adjustment=\nFullbright=\nNight mode=\nRemove scope overlay=\nInstant scope=\nDisable post processing=\nForce third person (alive)=\nForce third person (dead)=\nDisable rendering of teammates=\nDisable rendering of ragdolls=\nBullet tracers=\nBullet impacts=\nModulate harmless molotovs=\nColored models=\nPlayer=\nPlayer behind wall=\nTeammate=\nTeammate behind wall=\nLocal player=\nLocal player transparency=\nGrenade=\nScoped=\nLocal player fake=\nSolid=\nShaded=\nOriginal=\nOn shot=\nBubble=\nRagdolls=\nHands=\nWeapon viewmodel=\nMetallic=\nWeapons=\nDisable model occlusion=\nShadow=\nProps=\nMiscellaneous=\nOverride FOV=\nOverride zoom FOV=\nKnifebot=\nSwing, Full stab=\nZeusbot=\nAutomatic weapons=\nQuick switch=\nReveal competitive ranks=\nReveal Overwatch players=\nAuto-accept matchmaking=\nClan tag spammer=\nLog weapon purchases=\nLog damage dealt=\nAutomatic grenade release=\nMinimum grenade damage=\nSuper toss=\nPing spike=\nFree look=\nPersistent kill feed=\nLast second defuse=\nDisable sv_pure=\nRebuy fix=\nDraw console output=\nSteal player name=\nDump MM wins=\nMovement=\nStandalone quick stop=\nInfinite duck=\nEasy strafe=\nBunny hop=\nAir strafe=\nAir strafe direction=\nView angles=\nMovement keys=\nAir strafe smoothing=\nAvoid collisions=\nZ-Hop=\nPre-speed=\nNo fall damage=\nAir duck=\nSpam=\nFake=\nOn land=\nBlockbot=\nJump at edge=\nFast walk=\nSettings=\nMenu key=\nMenu color=\nDPI scale=\nAnti-untrusted=\nAllow custom game events=\nHide from OBS=\nLow FPS warning=\nLock menu layout=\nMultithreading=\nReset menu layout=\nUnload=\nsv_maxunlag=\nsv_maxusrcmdprocessticks=\nsv_clockcorrection_msecs=\nsv_maxusrcmdprocessticks_holdaim=\nFix viewmodel lag=\nFix networking=\nFix animations=\nFaster grenade toss=\nModel options=\nTeam=\nKnife changer=\nGlove changer=\nMask changer=\nAgent changer=\nWeapon skin=\nWeapon=\nStatTrak=\nQuality=\nSeed=\nFilter by weapon=\nPlayers=\nReset all=\nAdjustments=\nAdd to whitelist=\nAllow shared ESP updates=\nDisable visuals=\nHigh priority=\nForce pitch=\nForce pitch value=\nForce body yaw=\nForce body yaw value=\nCorrection active=\nOverride prefer body aim=\nOn=\nForce=\nOverride safe point=\nApply to all=\nPresets=\nLoad=\nSave=\nDelete=\nReset=\nImport from clipboard=\nExport to clipboard=\nOpen lua folder=\nOld ragebot tab=\nOld skinchanger tab=\nHrisito mode=\nHrisito DVD=\nApply Hrisito skybox=\nBeta nade warning=\nRemove nade warning timer=\nSafepoint=\nDisable stattrak (all skins)=\nShow all features=\nLua=\nAllow unsafe scripts=\nReload active scripts=\nUpdated ? days ago=\nLoad on startup=\nLoad script=`.replace(/\r\n/g, "\n");

  let entries = [];
  let meta = { language: "", compatibility: false };

  const tbody = document.querySelector('#hlc-tbody');
  const filterInput = document.querySelector('#hlc-filter');
  const showMode = document.querySelector('#hlc-showMode');
  const exportBtn = document.querySelector('#hlc-exportBtn');
  const importBtn = document.querySelector('#hlc-importBtn');
  const fileInput = document.querySelector('#hlc-fileInput');
  const copyBtn = document.querySelector('#hlc-copyBtn');
  const resetBtn = document.querySelector('#hlc-resetBtn');
  const languageName = document.querySelector('#hlc-languageName');
  const compatibility = document.querySelector('#hlc-compatibility');
  const statsEl = document.querySelector('#hlc-stats');
  const addKeyBtn = document.querySelector('#hlc-addKeyBtn');
  const newKey = document.querySelector('#hlc-newKey');
  const newVal = document.querySelector('#hlc-newVal');
  const saveDraftBtn = document.querySelector('#hlc-saveDraftBtn');
  const loadDraftBtn = document.querySelector('#hlc-loadDraftBtn');
  const autofillBtn = document.querySelector('#hlc-autofillBtn');

  function parseLang(text){
    const lines = text.split(/\n/);
    const out = []; const m = {language:"", compatibility:false};
    for(const raw of lines){
      if(!raw.trim()) continue;
      const i = raw.indexOf('=');
      const key = i === -1 ? raw.trim() : raw.slice(0,i).trim();
      const value = i === -1 ? '' : raw.slice(i+1);
      const kLower = key.toLowerCase();
      if(kLower === 'language') { m.language = value || ''; continue; }
      if(kLower === 'compatibility') { m.compatibility = (value||'').toLowerCase() === 'true'; continue; }
      out.push({ key, value });
    }
    return { meta: m, entries: out };
  }

  function serialize(){
    const header = `language=${meta.language || ''}\ncompatibility=${meta.compatibility ? 'true' : 'false'}`;
    const body = entries.map(e => `${e.key}=${e.value ?? ''}`).join('\n');
    return header + '\n' + body + '\n';
  }

  function render(){
    const q = (filterInput.value || '').toLowerCase();
    const mode = showMode.value;
    tbody.innerHTML = '';
    entries.forEach((e, idx) => {
      const isFilled = !!(e.value && e.value.length);
      if(q && !e.key.toLowerCase().includes(q)) return;
      if(mode === 'empty' && isFilled) return;
      if(mode === 'filled' && !isFilled) return;

      const tr = document.createElement('tr');
      const tdIdx = document.createElement('td'); tdIdx.textContent = idx+1;
      const tdKey = document.createElement('td'); tdKey.textContent = e.key;
      const tdVal = document.createElement('td');
      const input = document.createElement('input'); input.type = 'text'; input.value = e.value || '';
      input.placeholder = e.key;
      input.addEventListener('input', () => { e.value = input.value; saveDraft(); updateStats(); });
      tdVal.appendChild(input);
      const tdTools = document.createElement('td');
      const btnClear = document.createElement('button'); btnClear.className='button'; btnClear.type='button'; btnClear.textContent='Clear'; btnClear.addEventListener('click',()=>{ e.value=''; input.value=''; saveDraft(); updateStats(); });
      const btnDel = document.createElement('button'); btnDel.className='button'; btnDel.type='button'; btnDel.textContent='Delete'; btnDel.addEventListener('click',()=>{ entries.splice(idx,1); render(); saveDraft(); });
      const btnFill = document.createElement('button'); btnFill.className='button'; btnFill.type='button'; btnFill.textContent='Use key'; btnFill.title='Set value equal to key'; btnFill.addEventListener('click',()=>{ e.value=e.key; input.value=e.key; saveDraft(); updateStats(); });
      const wrap = document.createElement('span'); wrap.appendChild(btnFill); wrap.appendChild(document.createTextNode(' ')); wrap.appendChild(btnClear); wrap.appendChild(document.createTextNode(' ')); wrap.appendChild(btnDel);
      tdTools.appendChild(wrap);
      tr.append(tdIdx, tdKey, tdVal, tdTools);
      tbody.appendChild(tr);
    });
    updateStats();
  }

  function updateStats(){
    const total = entries.length;
    const filled = entries.filter(e => e.value && e.value.length).length;
    statsEl.textContent = `${filled}/${total} filled`;
  }

  function bootstrap(){
    const parsed = parseLang(TEMPLATE);
    meta = parsed.meta; entries = parsed.entries;
    languageName.value = meta.language || '';
    compatibility.checked = !!meta.compatibility;
    render();
  }

  const LS_KEY = 'hrisitosense-lang-builder';
  function saveDraft(){
    try { localStorage.setItem(LS_KEY, JSON.stringify({ meta, entries })); } catch {}
  }
  function loadDraft(){
    try {
      const raw = localStorage.getItem(LS_KEY);
      if(!raw) return false;
      const obj = JSON.parse(raw);
      if(!obj || !Array.isArray(obj.entries)) return false;
      meta = obj.meta || meta; entries = obj.entries || entries;
      languageName.value = meta.language || '';
      compatibility.checked = !!meta.compatibility;
      render();
      return true;
    } catch { return false; }
  }

  filterInput.addEventListener('input', render);
  showMode.addEventListener('change', render);
  languageName.addEventListener('input', () => { meta.language = languageName.value; saveDraft(); });
  compatibility.addEventListener('change', () => { meta.compatibility = compatibility.checked; saveDraft(); });

  exportBtn.addEventListener('click', () => {
    const blob = new Blob([serialize()], {type:'text/plain'});
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `language_${(meta.language||'blank').replace(/\s+/g,'_')}.lang`;
    a.click(); URL.revokeObjectURL(a.href);
  });

  copyBtn.addEventListener('click', async () => {
    try { await navigator.clipboard.writeText(serialize());
      copyBtn.textContent = 'Copied!'; setTimeout(()=> copyBtn.textContent='Copy to clipboard', 1200);
    } catch(e) { alert('Clipboard not available. Export the file instead.'); }
  });

  importBtn.addEventListener('click', () => fileInput.click());
  fileInput.addEventListener('change', async (ev) => {
    const f = ev.target.files[0]; if(!f) return;
    const text = await f.text();
    const parsed = parseLang(text);
    meta = parsed.meta; entries = parsed.entries;
    languageName.value = meta.language || '';
    compatibility.checked = !!meta.compatibility;
    render(); saveDraft(); fileInput.value='';
  });

  resetBtn.addEventListener('click', () => {
    if(confirm('Reset to template and clear values?')) { bootstrap(); saveDraft(); }
  });

  addKeyBtn.addEventListener('click', () => {
    const k = (newKey.value||'').trim();
    if(!k) return alert('Enter a key name');
    const exists = entries.find(x => x.key.toLowerCase() === k.toLowerCase());
    if(exists && !confirm('Key exists. Add duplicate anyway?')) return;
    entries.push({ key: k, value: newVal.value||'' }); newKey.value=''; newVal.value='';
    render(); saveDraft();
  });

  saveDraftBtn.addEventListener('click', () => { saveDraft(); saveDraftBtn.textContent='Saved'; setTimeout(()=> saveDraftBtn.textContent='Save draft', 900); });
  loadDraftBtn.addEventListener('click', () => { if(!loadDraft()) alert('No draft found.'); });
  autofillBtn.addEventListener('click', () => {
    let c=0; entries.forEach(e => { if(!e.value) { e.value = e.key; c++; } });
    render(); saveDraft();
    if(c===0){ const btn=document.querySelector('#hlc-autofillBtn'); btn.textContent='Nothing to fill'; setTimeout(()=>btn.textContent='Autofill empties', 900); }
  });

  bootstrap();
  loadDraft();
})();
</script>

<?php require PUN_ROOT.'footer.php'; ?>
