<?php
define('PUN_ROOT', dirname(__FILE__).'/');
require PUN_ROOT.'include/common.php';

if ($pun_user['is_guest'])
    message($lang_common['No permission'], false, '403 Forbidden');

// Allow admins or moderators only
$is_admin = ($pun_user['g_id'] == PUN_ADMIN);
$is_mod   = (!empty($pun_user['g_moderator']) && $pun_user['g_moderator'] == '1');
if (!$is_admin && !$is_mod)
    message($lang_common['No permission'], false, '403 Forbidden');

// CSRF (since we pass a token in the URL)
if (isset($_GET['csrf_token'])) {
    check_csrf($_GET['csrf_token']);
}

// Pick random user with NO client/HWID
// NOTE: Use RANDOM() if you're on PostgreSQL.
$sql = 'SELECT id
        FROM '.$db->prefix.'users
        WHERE (parts IS NULL OR parts = \'\')
          AND id >= 2
          AND group_id <> 4
        ORDER BY RAND()
        LIMIT 1';

$res = $db->query($sql) or error('Unable to fetch random user', __FILE__, __LINE__, $db->error());

if ($db->num_rows($res)) {
    $target_id = (int)$db->result($res);
    header('Location: profile.php?section=admin&id='.$target_id);
    exit;
}

message('No users without client/HWID found.', false, '404 Not Found');
