-- CrystalWin.cc Project by @osk4rrv
-- CrystalResolver for HrisitoSense.top
-- Version: V1.3.6 
-- Free Version
-- Writted by @osk4rrv
-- Sub to me pls https://youtube.com/@osk4rrv

local resolver_enabled = ui.new_checkbox("RAGE", "Other", "Enable CrystalResolver")

local resolver_type = ui.new_combobox("RAGE", "Other", "Resolver Type", "Agressive", "Defensive", "Dynamic Resolver")

local smart_mode_enabled = ui.new_checkbox("RAGE", "Other", "Enable Smart Mode")

local predict_enemy_move = ui.new_combobox("RAGE", "Other", "Predict enemy move", "Off", "Auto", "Manual")

local manual_ticks = ui.new_slider("RAGE", "Other", "Manual Prediction Ticks", 0, 16, 8, true, "t")

-- 4. Include Prediction (pod Predict enemy move)
local include_prediction = ui.new_checkbox("RAGE", "Other", "Include Prediction")

local include_ai = ui.new_checkbox("RAGE", "Other", "Include AI")

local silent_shot = ui.new_checkbox("RAGE", "Other", "Silent Shot")

local unsafe_charge_in_air = ui.new_checkbox("RAGE", "Other", "Unsafe Charge in Air")

local clantag_enabled = ui.new_checkbox("RAGE", "Other", "Enable ClanTag")
local clantag_style = ui.new_combobox("RAGE", "Other", "ClanTag Style", "CrystalWin.gs", "CrystalResolver")

local console_logs = ui.new_checkbox("RAGE", "Other", "Console Logs")
local on_fire_enable = ui.new_checkbox("RAGE", "Other", "Fire log")
local on_fire_colour = ui.new_color_picker("RAGE", "Other", "Fire log", 135, 206, 235, 255)
local on_miss_enable = ui.new_checkbox("RAGE", "Other", "Miss log")
local on_miss_colour = ui.new_color_picker("RAGE", "Other", "Miss log", 255, 0, 0, 255)
local on_damage_enable = ui.new_checkbox("RAGE", "Other", "Damage log")
local on_damage_colour = ui.new_color_picker("RAGE", "Other", "Damage log", 0, 255, 0, 255)

ui.new_label("LUA", "A", "---------------------------------------")
ui.new_label("LUA", "A", "CrystalWin.cc Project")
ui.new_label("LUA", "A", "CrystalResolver by @osk4rrv")
ui.new_label("LUA", "A", "User: FREE")
ui.new_label("LUA", "A", "Version: V1.2.6")
ui.new_label("LUA", "A", "---------------------------------------")

local function open_url(url)
    pcall(function()
        panorama.open().SteamOverlayAPI.OpenExternalBrowserURL(url)
    end)
end

ui.new_button("LUA", "A", "Telegram: t.me/@osk4rrv", function() open_url("https://t.me/osk4rrv") end)
ui.new_button("LUA", "A", "Youtube: Youtube.com/@osk4rrv", function() open_url("https://youtube.com/@osk4rrv") end)
ui.new_button("LUA", "A", "Discord: discord.gg/U4s4gbYCXx", function() open_url("https://discord.gg/U4s4gbYCXx") end)

local ref = {
    aimbot = ui.reference('RAGE', 'Aimbot', 'Enabled'),
    doubletap = {
        main = { ui.reference('RAGE', 'Aimbot', 'Double tap') },
        fakelag_limit = ui.reference('RAGE', 'Aimbot', 'Double tap fake lag limit')
    }
}

local player_data = {}
local head_stats = {}
local welcome_shown = false
local welcome_start = 0
local original_clantag = ""
local clantag_running = false
local local_player = nil
local charge_callback_reg = false
local dt_charged = false
local predicted_positions = {}
local shifting_players = {}
local tag_index = 1
local last_tag_update = 0
local tag_speed = 0.5

local function get_hitbox_xyz(ent, hitbox)
    if not ent then return nil end
    local ok, x, y, z = pcall(entity.hitbox_position, ent, hitbox)
    if not ok or not x then return nil end
    return type(x) == "table" and {x[1], x[2], x[3]} or {x, y, z}
end

local function get_origin(ent)
    if not ent then return nil end
    local ok, x, y, z = pcall(entity.get_prop, ent, "m_vecOrigin")
    if not ok or not x then return nil end
    return type(x) == "table" and {x[1], x[2], x[3]} or {x, y, z}
end

local function get_eye_pos()
    local ok, x, y, z = pcall(client.eye_position)
    if not ok or not x then return nil end
    return type(x) == "table" and {x[1], x[2], x[3]} or {x, y, z}
end

local function init_player(idx)
    if not player_data[idx] then
        player_data[idx] = { 
            misses = 0, 
            last_vel = {0,0,0}, 
            last_tick = 0, 
            lc_detected = false, 
            last_sim = 0,
            yaw_history = {},
            last_yaw = 0,
            last_lby = 0,
            fake_flick = false,
            defensive_flick = false,
            skitter_jitter = false,
            lby_break_detected = false,
            inverse_aa_detected = false,
            freestand_detected = false,
            hide_shot_miss_count = 0,
            last_shot_tick = 0,
            ai_bruteforce = 0,
            jumpscout_detected = false
        }
        head_stats[idx] = { hits = 0, misses = 0, total = 0 }
        predicted_positions[idx] = {}
        shifting_players[idx] = false
    end
end

local function toticks(seconds) 
    return math.floor(0.5 + seconds / (globals.tickinterval() or 0.015)) 
end

local function predict_pos(player)
    local mode = ui.get(predict_enemy_move)
    local ticks = 0

    if mode == "Manual" then
        ticks = ui.get(manual_ticks)
    elseif mode == "Auto" then
        local ti = globals.tickinterval()
        if ti and ti > 0 then
            ticks = math.floor(client.latency() / ti + 0.5)
        end
    end

    if ticks <= 0 then return get_origin(player) end

    local origin = get_origin(player)
    if not origin then return nil end

    local vel = entity.get_prop(player, "m_vecVelocity")
    if not vel or type(vel) ~= "table" then return origin end

    local ti = globals.tickinterval() or 0.015
    return {
        origin[1] + vel[1] * ti * ticks,
        origin[2] + vel[2] * ti * ticks,
        origin[3] + vel[3] * ti * ticks
    }
end

local function get_resolver_offset(player)
    local lby = entity.get_prop(player, "m_flLowerBodyYawTarget") or 0
    local eye = entity.get_prop(player, "m_angEyeAngles")
    local eye_y = (type(eye) == "table" and eye[2]) or (type(eye) == "number" and eye) or 0
    local delta = (lby - eye_y + 180) % 360 - 180
    return math.max(-120, math.min(120, delta))
end

local function detect_advanced_aa(enemy)
    local data = player_data[enemy]
    if not data then return end

    local eye_angles = entity.get_prop(enemy, "m_angEyeAngles")
    if not eye_angles then return end
    local yaw = type(eye_angles) == "table" and eye_angles[2] or eye_angles
    local lby = entity.get_prop(enemy, "m_flLowerBodyYawTarget") or 0
    local origin = get_origin(enemy)
    local vel = entity.get_prop(enemy, "m_vecVelocity")
    local speed = 0
    if vel and type(vel) == "table" then
        speed = math.sqrt(vel[1]^2 + vel[2]^2)
    end

    table.insert(data.yaw_history, yaw)
    if #data.yaw_history > 15 then table.remove(data.yaw_history, 1) end

    local near_wall = false
    if origin then
        local x, y, z = origin[1], origin[2], origin[3]
        local hit = client.trace_line(enemy, x, y, z, x + 50, y, z)
        if hit and type(hit) == "table" and hit.fraction then
            near_wall = hit.fraction < 0.9
        end
    end
    data.freestand_detected = speed < 5 and near_wall and math.abs((lby - yaw + 180) % 360 - 180) > 45

    local last_shot = entity.get_prop(enemy, "m_iShotsFired") or 0
    if last_shot == 0 and data.last_shot_tick > 0 then
        data.hide_shot_miss_count = data.hide_shot_miss_count + 1
    end
    data.last_shot_tick = last_shot

    local eye_to_lby = (lby - yaw + 180) % 360 - 180
    local last_eye_to_lby = (data.last_lby - data.last_yaw + 180) % 360 - 180
    local sign_change = (eye_to_lby > 0 and last_eye_to_lby < 0) or (eye_to_lby < 0 and last_eye_to_lby > 0)
    data.inverse_aa_detected = sign_change and math.abs(eye_to_lby) > 30

    local lby_diff = math.abs((lby - yaw + 180) % 360 - 180)
    data.lby_break_detected = speed > 10 and lby_diff > 45

    local flags = entity.get_prop(enemy, "m_fFlags") or 0
    local on_ground = bit.band(flags, 1) == 1
    local vel_z = vel and type(vel) == "table" and vel[3] or 0
    local was_in_air = bit.band(entity.get_prop(enemy, "m_fFlags", true) or 0, 1) == 0
    data.jumpscout_detected = not on_ground and was_in_air and math.abs(vel_z) > 180

    if ui.get(include_ai) and data.misses > 0 then
        data.ai_bruteforce = (data.ai_bruteforce + 1) % 3
    end

    data.last_yaw = yaw
    data.last_lby = lby
end

local function get_dynamic_resolver(enemy)
    local data = player_data[enemy]
    if not data then return "Agressive" end

    if data.hide_shot_miss_count >= 2 then return "HideShot" end
    if data.freestand_detected then return "Freestand" end
    if data.inverse_aa_detected then return "Inverse" end
    if data.lby_break_detected then return "LBY" end
    if data.jumpscout_detected then return "Jumpscout" end

    if ui.get(include_ai) and data.ai_bruteforce > 0 then
        if data.ai_bruteforce == 1 then return "Agressive" end
        if data.ai_bruteforce == 2 then return "Defensive" end
    end

    local stats = head_stats[enemy] or {hits=0, misses=0, total=0}
    local accuracy = stats.total > 0 and (stats.hits / stats.total) or 0
    return accuracy >= 0.75 and "Agressive" or (accuracy <= 0.4 and "Defensive" or "Agressive")
end

local function check_charge()
    if not local_player then return end
    local m_nTickBase = entity.get_prop(local_player, 'm_nTickBase')
    if not m_nTickBase then return end
    local client_latency = client.latency()
    local shift = math.floor(m_nTickBase - globals.tickcount() - 3 - toticks(client_latency) * 0.5 + 0.5 * (client_latency * 10))
    local wanted = -14 + (ui.get(ref.doubletap.fakelag_limit) - 1) + 3
    dt_charged = shift <= wanted
end

client.set_event_callback('setup_command', function(c)
    if not ui.get(resolver_enabled) then
        ui.set(ref.aimbot, true)
        if charge_callback_reg then
            client.unset_event_callback('run_command', check_charge)
            charge_callback_reg = false
        end
        return
    end

    local_player = entity.get_local_player()
    if not local_player or not entity.is_alive(local_player) then return end

    if not charge_callback_reg then
        client.set_event_callback('run_command', check_charge)
        charge_callback_reg = true
    end

    if ui.get(unsafe_charge_in_air) and ui.get(ref.doubletap.main[2]) and ui.get(ref.doubletap.main[1]) then
        local my_flags = entity.get_prop(local_player, 'm_fFlags') or 0
        local in_air = bit.band(my_flags, 1) == 0
        local threat = client.current_threat()

        if in_air and threat and bit.band(entity.get_prop(threat, 'm_fFlags') or 0, 1) == 0 then
            ui.set(ref.aimbot, dt_charged)
        else
            ui.set(ref.aimbot, true)
        end
    else
        ui.set(ref.aimbot, true)
    end
end)

client.set_event_callback("run_command", function()
    if not ui.get(resolver_enabled) or not ui.get(include_prediction) then return end

    local me = entity.get_local_player()
    if not me then return end

    local enemies = entity.get_players(true)
    local now = globals.curtime()

    for _, enemy in ipairs(enemies) do
        init_player(enemy)
        detect_advanced_aa(enemy)

        local data = player_data[enemy]
        local vel = entity.get_prop(enemy, "m_vecVelocity")
        local vel_z = vel and type(vel) == "table" and vel[3] or 0
        local flags = entity.get_prop(enemy, "m_fFlags") or 0
        local on_ground = bit.band(flags, 1) == 1
        local was_in_air = bit.band(entity.get_prop(enemy, "m_fFlags", true) or 0, 1) == 0

        if not on_ground and was_in_air and math.abs(vel_z) > 180 then
            data.lc_detected = true
            data.lc_start = now
            data.lc_origin = get_origin(enemy)
            data.lc_vel = vel and type(vel) == "table" and {vel[1], vel[2], vel[3]} or {0,0,0}
        end

        if data.lc_detected and data.lc_origin then
            predicted_positions[enemy] = {}
            local origin = data.lc_origin
            local vel = data.lc_vel
            local ti = globals.tickinterval()
            local gravity = 800

            for ticks = 1, 10 do
                local t = ticks * ti
                local new_z = origin[3] + vel[3] * t - 0.5 * gravity * t * t
                if new_z <= origin[3] - 60 then break end
                local pred = { origin[1] + vel[1] * t, origin[2] + vel[2] * t, new_z }
                table.insert(predicted_positions[enemy], pred)
            end
        end
    end
end)

local clantag_sequences = {
    ["CrystalWin.gs"] = {
        "C/", "Cr/", "Cry/", "Crys/", "Cryst/", "Crysta/", "Crystal/", "CrystalW/", 
        "CrystalWi/", "CrystalWin/", "CrystalWin/", "CrystalWin.g/", "CrystalWin.gs/", 
        "CrystalWin.gs", "CrystalWin.g\\", "CrystalWin\\", "CrystalWi\\", "CrystalW\\", 
        "Crystal\\", "Crysta\\", "Cryst\\", "Crys\\", "Cry\\", "Cr\\", "C\\"
    },
    ["CrystalResolver"] = {
        "C/", "Cr/", "Cry/", "Crys/", "Cryst/", "Crysta/", "Crystal/", "CrystalR/", 
        "CrystalRe/", "CrystalRes/", "CrystalReso/", "CrystalResol/", "CrystalResolv/", 
        "CrystalResolve/", "CrystalResolver/", "CrystalResolver", "CrystalResolve\\", 
        "CrystalResolv\\", "CrystalResol\\", "CrystalReso\\", "CrystalRes\\", 
        "CrystalRe\\", "CrystalR\\", "Crystal\\", "Crysta\\", "Cryst\\", "Crys\\", "Cry\\", "Cr\\", "C\\"
    }
}

local function update_clantag()
    if not ui.get(clantag_enabled) or not ui.get(resolver_enabled) then
        if clantag_running then
            pcall(client.set_clan_tag, original_clantag or "")
            clantag_running = false
            tag_index = 1
        end
        return
    end

    local style = ui.get(clantag_style)
    local sequence = clantag_sequences[style] or clantag_sequences["CrystalWin.gs"]
    local now = globals.realtime()

    if now - last_tag_update >= tag_speed then
        pcall(client.set_clan_tag, sequence[tag_index])
        tag_index = (tag_index % #sequence) + 1
        last_tag_update = now
        clantag_running = true
    end
end

local function show_welcome()
    if welcome_shown then return end
    welcome_shown = true
    welcome_start = globals.realtime()
    client.color_log(0, 255, 0, "CrystalResolver V1.2.3 Loaded!")
    client.color_log(56, 182, 229, "Fixed Trace Bug + Fixed ClanTag UI")
end

client.set_event_callback("paint", function()
    show_welcome()

    local elapsed = globals.realtime() - welcome_start
    if welcome_shown and elapsed < 3.0 then
        local alpha = elapsed < 0.5 and (elapsed / 0.5) * 220 or (elapsed > 2.5 and ((3.0 - elapsed) / 0.5) * 220 or 220)
        local w, h = client.screen_size()

        renderer.rectangle(0, 0, w, h, 0, 0, 0, alpha)
        renderer.text(w/2, h/2 - 80, 255, 255, 255, 255, "cb+", 0, "CRYSTALRESOLVER")
        renderer.text(w/2 - 180, h/2 - 30, 180, 180, 180, 255, "c", 0, "by osk4rrv")
        renderer.text(w/2 + 180, h/2 - 30, 180, 180, 180, 255, "cr", 0, "V1.2.3")
    end

    update_clantag()

    if ui.get(include_prediction) then
        for enemy, positions in pairs(predicted_positions) do
            if entity.is_alive(enemy) then
                for _, pos in ipairs(positions) do
                    local x, y = renderer.world_to_screen(pos[1], pos[2], pos[3])
                    if x and y then
                        renderer.circle_outline(x, y, 255, 215, 0, 255, 32, 0, 1, 3)
                        renderer.rectangle(x-16, y-16, 32, 32, 255, 215, 0, 80)
                    end
                end
            end
        end
    end
end)

client.set_event_callback("aim_fire", function(e)
    if not ui.get(resolver_enabled) then return end

    local target = e.target
    if not target or not entity.is_enemy(target) then return end

    init_player(target)
    local data = player_data[target]

    local pred_pos = predict_pos(target) or get_origin(target)

    if ui.get(include_prediction) and data.lc_detected and data.lc_origin then
        local on_ground = bit.band(entity.get_prop(target, "m_fFlags") or 0, 1) == 1
        if on_ground and #predicted_positions[target] == 0 then
            pred_pos = data.lc_origin
        end
    end

    local mode = ui.get(resolver_type)
    if mode == "Dynamic Resolver" then
        mode = get_dynamic_resolver(target)
    end

    local offset = get_resolver_offset(target)

    if mode == "LBY" then
        offset = get_resolver_offset(target)
    elseif mode == "Inverse" then
        offset = -offset
    elseif mode == "Defensive" then
        offset = -offset
    elseif mode == "Freestand" then
        offset = 0
    elseif mode == "HideShot" then
        offset = offset * 1.5
    elseif mode == "Jumpscout" then
        offset = offset * 0.8
    end

    local eye = get_eye_pos()
    if not eye or not pred_pos then return end

    local dx, dy, dz = pred_pos[1]-eye[1], pred_pos[2]-eye[2], pred_pos[3]-eye[3]
    local yaw = math.atan2(dy, dx) * 180 / math.pi + offset
    local pitch = -math.atan2(dz, math.sqrt(dx*dx + dy*dy)) * 180 / math.pi

    e.yaw = yaw
    e.pitch = pitch
end)

client.set_event_callback("aim_miss", function(e)
    if not ui.get(resolver_enabled) then return end
    local target = e.target
    if not target or not entity.is_enemy(target) then return end
    local data = player_data[target]
    if data then
        data.misses = data.misses + 1
    end
end)

local hitgroup_names = { "body", "head", "chest", "stomach", "left arm", "right arm", "left leg", "right leg", "neck", "?", "gear" }
local function get_hitgroup_name(hg) return hitgroup_names[(hg or 0) + 1] or "?" end

client.set_event_callback('aim_fire', function(e)
    if not ui.get(resolver_enabled) or not ui.get(console_logs) or not ui.get(on_fire_enable) then return end
    local r, g, b = ui.get(on_fire_colour)
    local group = get_hitgroup_name(e.hitgroup)
    local target_name = entity.get_player_name(e.target) or "unknown"
    client.color_log(r, g, b, "[crystalresolver] fired at " .. string.lower(target_name) .. "'s " .. group .. " for " .. e.damage .. " (hc: " .. e.hit_chance .. "%)")
end)

client.set_event_callback('player_hurt', function(e)
    if not ui.get(resolver_enabled) or not ui.get(console_logs) or not ui.get(on_damage_enable) then return end
    local attacker = client.userid_to_entindex(e.attacker)
    if attacker ~= entity.get_local_player() then return end
    local group = get_hitgroup_name(e.hitgroup)
    local target_name = entity.get_player_name(client.userid_to_entindex(e.userid)) or "unknown"
    local msg = "[crystalresolver] hit " .. string.lower(target_name) .. "'s " .. group .. " for " .. e.dmg_health .. " (" .. e.health .. " hp left)"
    if e.health <= 0 then msg = msg .. " *dead*" end
    local r, g, b = ui.get(on_damage_colour)
    client.color_log(r, g, b, msg)
end)

client.set_event_callback('aim_miss', function(e)
    if not ui.get(resolver_enabled) or not ui.get(console_logs) or not ui.get(on_miss_enable) then return end
    local r, g, b = ui.get(on_miss_colour)
    local group = get_hitgroup_name(e.hitgroup)
    local target_name = entity.get_player_name(e.target) or "unknown"
    local reason = (e.reason == "?") and "resolver" or e.reason
    client.color_log(r, g, b, "[crystalresolver] missed " .. string.lower(target_name) .. "'s " .. group .. " due to " .. reason)
end)

local function handle_console_visibility()
    local enabled = ui.get(console_logs) and ui.get(resolver_enabled)
    ui.set_visible(on_fire_enable, enabled)
    ui.set_visible(on_fire_colour, enabled and ui.get(on_fire_enable))
    ui.set_visible(on_miss_enable, enabled)
    ui.set_visible(on_miss_colour, enabled and ui.get(on_miss_enable))
    ui.set_visible(on_damage_enable, enabled)
    ui.set_visible(on_damage_colour, enabled and ui.get(on_damage_enable))
end

local function update_visibility()
    local enabled = ui.get(resolver_enabled)
    local pmode = ui.get(predict_enemy_move)
    
    ui.set_visible(resolver_type, enabled)
    ui.set_visible(smart_mode_enabled, enabled)
    ui.set_visible(predict_enemy_move, enabled)
    ui.set_visible(manual_ticks, enabled and pmode == "Manual")
    ui.set_visible(include_prediction, enabled)
    ui.set_visible(include_ai, enabled)
    ui.set_visible(silent_shot, enabled)
    ui.set_visible(unsafe_charge_in_air, enabled)
    ui.set_visible(clantag_enabled, enabled)
    ui.set_visible(clantag_style, enabled and ui.get(clantag_enabled))  -- TERAZ DZIAŁA
    ui.set_visible(console_logs, enabled)
    
    handle_console_visibility()
end

ui.set_callback(resolver_enabled, update_visibility)
ui.set_callback(predict_enemy_move, update_visibility)
ui.set_callback(clantag_enabled, update_visibility)  -- DODANO CALLBACK
ui.set_callback(console_logs, handle_console_visibility)
ui.set_callback(on_fire_enable, handle_console_visibility)
ui.set_callback(on_miss_enable, handle_console_visibility)
ui.set_callback(on_damage_enable, handle_console_visibility)

update_visibility()

client.set_event_callback("round_start", function()
    player_data = {}
    head_stats = {}
    predicted_positions = {}
    shifting_players = {}
    tag_index = 1
    pcall(client.set_clan_tag, original_clantag or "")
end)

client.set_event_callback("shutdown", function()
    ui.set(ref.aimbot, true)
    pcall(client.set_clan_tag, original_clantag or "")
end)

pcall(function()
    if client.get_clan_tag then
        original_clantag = client.get_clan_tag() or ""
    end
end)