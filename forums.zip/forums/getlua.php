<?php
// getlua.php - Returns Lua script contents by ID
header('Content-Type: text/plain; charset=utf-8');

// ----------------- DATABASE CONFIG -----------------
$dbHost = '185.194.177.9';
$dbName = 'hrisito';
$dbUser = 'interlection';
$dbPass = 'xRoles13:)';
$usersTable = 'gs_users';
// Group 4 is explicitly excluded from allowed groups
$allowedGroups = [1, 2, 5, 8, 9];
// ---------------------------------------------------

// Toggle: allow clients to send plaintext passwords?
// true  = accept either SHA-1 hex or plaintext (plaintext will be SHA-1'd server-side)
// false = require SHA-1 hex only; plaintext is rejected
$ALLOW_PLAIN_TEXT_PASSWORDS = false;

// Helper: detect 40-char SHA-1 hex
function is_sha1_hex($s) {
    return (bool)preg_match('/^[0-9a-f]{40}$/i', $s);
}

// Get parameters
$luaId    = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$username = isset($_GET['username']) ? trim($_GET['username']) : '';
$password = isset($_GET['password']) ? $_GET['password'] : '';

// Validate Lua ID
if ($luaId <= 0) {
    echo json_encode(["error" => "Invalid Lua ID"]);
    exit;
}

// Validate input
if ($username === '') {
    echo json_encode(["error" => "Incorrect credentials"]);
    exit;
}

if ($password === '') {
    echo json_encode(["error" => "Incorrect credentials"]);
    exit;
}

// Connect to database
$dsn = "mysql:host={$dbHost};dbname={$dbName};charset=utf8mb4";
try {
    $pdo = new PDO($dsn, $dbUser, $dbPass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
} catch (PDOException $e) {
    echo json_encode(["error" => "Database connection failed"]);
    exit;
}

// Fetch user by username
$stmt = $pdo->prepare("SELECT * FROM {$usersTable} WHERE username = :u LIMIT 1");
$stmt->execute([':u' => $username]);
$user = $stmt->fetch();

if (!$user) {
    echo json_encode(["error" => "Incorrect credentials"]);
    exit;
}

// Check group - Group 4 will be rejected here
if (!in_array((int)$user['group_id'], $allowedGroups, true)) {
    echo json_encode(["error" => "User group not allowed"]);
    exit;
}

// Verify password with toggle
if ($ALLOW_PLAIN_TEXT_PASSWORDS) {
    // Accept SHA-1 hex directly, or hash plaintext
    $incomingHex = is_sha1_hex($password) ? strtolower(trim($password)) : sha1($password);
} else {
    // Require SHA-1 hex only
    if (!is_sha1_hex($password)) {
        echo json_encode(["error" => "Incorrect credentials"]);
        exit;
    }
    $incomingHex = strtolower(trim($password));
}

// Compare (normalize DB value to lowercase just in case)
if ($incomingHex !== strtolower($user['password'])) {
    echo json_encode(["error" => "Incorrect credentials"]);
    exit;
}

// Authentication successful, proceed with original functionality

// Sanitize username for filesystem
$username = preg_replace('/[^a-zA-Z0-9_-]/', '', $username);

// Check if user is subscribed to this Lua
$userFile = "userslua/{$username}.txt";
$isSubscribed = false;

if (file_exists($userFile)) {
    // Ensure IDs are integers for a reliable comparison
    $subscribedLuas = array_map(
        'intval',
        array_filter(array_map('trim', file($userFile)))
    );
    $isSubscribed = in_array($luaId, $subscribedLuas, true);
}

if (!$isSubscribed) {
    echo json_encode(["error" => "Access denied - not subscribed to this Lua"]);
    exit;
}

// Get available Lua scripts with persistent ID system
function getLuaScripts() {
    $scripts = [];
    $idMappingFile = 'luas/id_mapping.json';

    // Load existing ID mappings
    $idMapping = [];
    if (file_exists($idMappingFile)) {
        $idMapping = json_decode(file_get_contents($idMappingFile), true) ?: [];
    }

    if (is_dir('luas')) {
        $files = scandir('luas');
        $nextId = empty($idMapping) ? 1 : max($idMapping) + 1;
        $updated = false;

        foreach ($files as $file) {
            if (pathinfo($file, PATHINFO_EXTENSION) === 'lua') {
                // If file doesn't have an ID yet, assign one
                if (!isset($idMapping[$file])) {
                    $idMapping[$file] = $nextId;
                    $nextId++;
                    $updated = true;
                }

                $id = $idMapping[$file];
                $filePath = 'luas/' . $file;

                $scripts[$id] = [
                    'id'   => $id,
                    'name' => pathinfo($file, PATHINFO_FILENAME),
                    'file' => $file
                ];
            }
        }

        // Remove mappings for deleted files
        foreach ($idMapping as $file => $id) {
            if (!file_exists('luas/' . $file)) {
                unset($idMapping[$file]);
                $updated = true;
            }
        }

        // Save updated mappings
        if ($updated) {
            file_put_contents($idMappingFile, json_encode($idMapping, JSON_PRETTY_PRINT));
        }

        // Sort scripts by ID
        ksort($scripts);
    }

    return $scripts;
}

$luaScripts = getLuaScripts();

// Check if Lua ID exists
if (!isset($luaScripts[$luaId])) {
    echo json_encode(["error" => "Lua script not found"]);
    exit;
}

// Get the Lua file path
$luaFile = 'luas/' . $luaScripts[$luaId]['file'];

// Check if file exists and read contents
if (!file_exists($luaFile)) {
    echo json_encode(["error" => "Lua file not found on server"]);
    exit;
}

// Output the Lua script contents as plain text
$contents = file_get_contents($luaFile);
echo $contents;